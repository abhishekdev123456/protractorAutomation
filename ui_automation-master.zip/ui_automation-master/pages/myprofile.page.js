var myprofilepage = function(){
    
    var firstName = element(by.name("first_name"));
    var lastName = element(by.name("last_name"));
    var email = element(by.name("email"));
    var officePhone = element(by.name("contact_phone"));
    var mobilePhone = element(by.name("contact_cellphone"));
    var updateButton = element(by.xpath("//button/span[text()='Update']/.."));

    this.getFirstName = async function(){
        return await firstName.getAttribute("ng-reflect-model");
    }

    this.getLastName = async function(){
        return await lastName.getAttribute("ng-reflect-model");
    }
    
    this.getEmail = async function(){
        return await email.getAttribute("ng-reflect-model");
    }

    this.getOfficePhone = async function(){
        return await officePhone.getAttribute("ng-reflect-model");
    }

    this.getMobilePhone = async function(){
        return await mobilePhone.getAttribute("ng-reflect-model");
    }

    this.setFirstName = async function(first){
        await firstName.clear();
        await firstName.sendKeys(first);
    }

    this.setLastName = async function(last){
        await lastName.clear();
        await lastName.sendKeys(last);
    }
    
    this.setEmail = async function(emailaddress){
        await email.sendKeys(emailaddress);
    }

    this.setOfficePhone = async function(officephone){
        await officePhone.clear();
        await officePhone.sendKeys(officephone);
    }

    this.setMobilePhone = async function(cellphone){
        await mobilePhone.clear();
        await mobilePhone.sendKeys(cellphone);
    }

    this.clickUpdate = async function(){
        await updateButton.click();
    }
    
}



module.exports = new myprofilepage();