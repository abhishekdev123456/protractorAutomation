
var recommenderpage = function(){

    this.getUrl = async function(){
        return browser.params.env.url+"/account/recommender";
    }

}

module.exports = new recommenderpage();