var utils = require('../utilities/utils');


var dealerconsolepage = function(){
    var searchDealershipTxt = element(by.xpath("//input[@type='text']"));   
    //var searchDealershipTxt = element(by.tagName("Input"));   
    var searchBtn = element(by.xpath("//button[@title='Search']"));
    var dealershipTable = element(by.xpath("//tbody"));
    var firstCheckBoxDealershipTable = element(by.xpath("//tbody/tr/td/span[@class='checkbox']"));
    var editBtn = element(by.xpath("//button[@title='Update']"));
    
    //element.all(by.xpath("//tbody[@role='rowgroup']"));

    this.getUrl = async function(){
        return browser.params.env.url+"/account/dealer-console";
    }

    this.getSearchDealershipTxt = async function(){
        return searchDealershipTxt;
    }


    this.searchDealership = async function(searchtext){
        try{
            //await browser.waitForAngularEnabled(false);
            utils.logInfo("Clear Search");
            await searchDealershipTxt.clear();

            utils.logInfo("Enter Search: "+searchtext);
            await searchDealershipTxt.sendKeys(searchtext);

            utils.logInfo("Search Click");
            await searchBtn.click();
            //await browser.waitForAngularEnabled(true);
        }
        catch(err){
            utils.logInfo("Error - dealerconsolepage:searchDealership(): "+err);
        }
    }

    this.getDealershipRowCount = async function(){
        try{
            return await dealershipTable.all(by.tagName("tr")).count();
            //return await appraisalsTable.all(by.tagName("tr")).count();

        }
        catch(err){
            //var e = err;
            utils.logInfo("Error - dealerconsolepage:getDealershipRowCount(): "+err);
        }
        //done(e);    
    }

    this.selectFirstDealership = async function(){
        await firstCheckBoxDealershipTable.click();
        //return await appraisalsTable.all(by.tagName("tr")).count();

    }

    this.editDealership = async function(){
        try{
            await editBtn.click();
            utils.logInfo("After Edit Dealership inside function");
        }
        catch(err){
            utils.logInfo("Error - dealerconsolepage:editDealership(): "+err);
        }
    }

}


module.exports = new dealerconsolepage();
