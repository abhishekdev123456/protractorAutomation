var utils = require('../utilities/utils');
var homepage = require('../pages/home.page');
var dealerconsolepage = require('../pages/dealer.console.page');

var dealershippage = function(){

    var editBtn = element(by.xpath("//button[@title='Update']"));

    var generalTab = element(by.xpath("//a[@href='#general']"));
    var dealershipNameTxt = element(by.xpath("//input[@id='id_name']"));
    var addressGeneralTab = element(by.xpath("//input[@id='id_contact_address']"));
    var saveBtnGeneralTab = element(by.xpath("//div[@class='panes']/div[@class='pane'][1]/*/*/*/button[text()='Save']"));
    var productDropdownGeneralTab = element(by.xpath("//select[@name='product']"));

    var accutradeTab = element(by.xpath("//a[@href='#accu-trade']"));
    var guaranteedPriceLbl = element(by.xpath("//label[text()='Guaranteed Price']"));
    var digitalRetailFlowAccutradeTab = element(by.xpath("//input[@id='id_perseus_dealer_preference-single_page_workflow']/.."));
    var saveBtnAccutradeTab = element(by.xpath("//div[@class='panes']/div[@class='pane'][2]/*/*/button[text()='Save']"));
    var offerViewBaseURLInput = element(by.xpath("//input[@id='id_perseus_dealer_preference-offer_view_base_url']"));
    var appointmentContactInputAccutradeTab = element(by.xpath("//input[@id='id_perseus_dealer_preference-appointment_contact']"));

    var advancedTab = element(by.xpath("//a[@href='#advanced']"));
    var allowChromeLookupsLbl = element(by.xpath("//span[text()='Allow Chrome lookups']"));
    var crmEmailNameTxtAdvancedTab = element(by.xpath("//input[@id='id_crm_emails-0-name']"));
    var allowHVMSPushSliderAdvancedTab = element(by.xpath("//input[@id='id_hvms_push']/following-sibling::div[@class='slider']"));
    var iasSyncSliderAdvancedTab = element(by.xpath("//input[@id='id_ias_allow_sync']/following-sibling::div[@class='slider']"));
    var saveBtnAdvancedTab = element(by.xpath("//div[@class='panes']/div[@class='pane'][6]/*/*/button[text()='Save']"));
    var crmNameAdvancedTab = element(by.xpath("//input[@id='id_crm_emails-0-name']"));
    var crmEmailAdvancedTab = element(by.xpath("//input[@id='id_crm_emails-0-email']"));    
    var deleteCRMBtnAdvancedTab = element(by.xpath("//input[@id='id_crm_emails-0-DELETE']"));

    var customizationTab = element(by.xpath("//a[@href='#customization']"));
    var bannelURLTxt = element(by.xpath("//input[@id='id_perseus_dealer_preference-banner_url']"));
    var colorSelectorShapeCustomizationTab = element(by.xpath("//select[@id='id_perseus_dealer_preference-color_selector_shape']"));
    var saveBtnCustomizationTab = element(by.xpath("//div[@class='panes']/div[@class='pane'][5]/*/*/button[text()='Save']"));
    var logoURLInputCustomizationTab = element(by.xpath("//input[@id='id_perseus_dealer_preference-logo_url']"));

    var employeesTab = element(by.xpath("//a[@href='#employees']"));
        var employeeTable = element(by.xpath("//tbody"));
        var newAPIBtn = element(by.xpath("//button[@title='Creates a new API account for this dealership']"));
        //var firstCheckBoxEmployeeTable = element(by.xpath("//tbody/tr[1]/td[1]/span[@class='checkbox']"));
        var firstCheckBoxEmployeeTable = element(by.xpath("//table/tbody/tr[1]"));
        var lastNameTxtEmployeeTab = element(by.xpath("//input[@id='id_last_name']"));
        var increaseOfferSliderEmployeeTab = element(by.xpath("//input[@id='id_bid_advancement']/following-sibling::div[@class='slider']"));
        var saveBtnEmployeeTab = element(by.xpath("//button[text()='Copy to all Employees']/preceding-sibling::button[text()='Save']"));
    
    var msgInfo = element(by.xpath("//div[@class='message info']/div"));

    // this.isPresentNotification = async function(){
    //     return await msgInfo.isPresent();
    // }

    // this.isPresentNotification = async function(msg){
    //     if(msg == await msgInfo.getText())
    //         {return true;}
    //     else
    //         {return false;}    
    // }

    this.getDealer = async function(dealername){

        await browser.waitForAngularEnabled(true); // *** Angular Enabled
        await browser.refresh();

        await utils.logInfo("Navigate to Dealer Console"); //**** Navigate to Dealer Console ****/
        await homepage.navigateThroughMenu("Dealer Console");
        
        browser.driver.sleep(browser.params.sleep.sleep10);

        browser.switchTo().frame(0);
        await utils.logInfo("Switched to iFrame");

        await browser.waitForAngularEnabled(false);

        await utils.logInfo("Search Dealership");
        await dealerconsolepage.searchDealership(dealername);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Get number of dealers : "+await dealerconsolepage.getDealershipRowCount());

        await utils.logInfo("Select first Dealership");
        await dealerconsolepage.selectFirstDealership();
        
        await utils.logInfo("Click on Dealership Edit Button");
        await dealerconsolepage.editDealership();

    }

    this.deleteCRMNameEmail = async function(){
        browser.executeScript('arguments[0].scrollIntoView()', deleteCRMBtnAdvancedTab.getWebElement());
        await deleteCRMBtnAdvancedTab.click();
    }

    this.getCRMName = async function(){
        return await crmNameAdvancedTab.getAttribute("value");
    }

    this.getCRMEmail = async function(){
        return await crmEmailAdvancedTab.getAttribute("value");
    }

    this.toggleHVMSPush = async function(){
        browser.executeScript('arguments[0].scrollIntoView()', allowHVMSPushSliderAdvancedTab.getWebElement());
        await allowHVMSPushSliderAdvancedTab.click();
    }

    this.getHVMSPushStatus = async function(){
        return await allowHVMSPushSliderAdvancedTab.getText();
    }

    this.toggleIASSync = async function(){
        await iasSyncSliderAdvancedTab.click();
    }

    this.getIASSyncStatus = async function(){
        return await iasSyncSliderAdvancedTab.getText();
    }

    this.toggleIncreaseOffer = async function(){
        browser.executeScript('arguments[0].scrollIntoView()', increaseOfferSliderEmployeeTab.getWebElement());
        await increaseOfferSliderEmployeeTab.click();
    }

    this.getIncreaseOfferStatus = async function(){
        return await increaseOfferSliderEmployeeTab.getText();
    }

    

    this.getNotificationWebElement = function(){
        return msgInfo;
    }

    this.clickGeneralSaveBtn = async function(){
        browser.executeScript('arguments[0].scrollIntoView()', saveBtnGeneralTab.getWebElement());
        await saveBtnGeneralTab.click();
    }

    this.clickAccutradeSaveBtn = async function(){
        browser.executeScript('arguments[0].scrollIntoView()', saveBtnAccutradeTab.getWebElement());
        await saveBtnAccutradeTab.click();
    }

    this.clickCustomizationSaveBtn = async function(){
        //await browser.driver.sleep(browser.params.sleep.sleep10);
        browser.executeScript('arguments[0].scrollIntoView()', saveBtnCustomizationTab.getWebElement());
        //await utils.logInfo("Inside Customization after scroll");
        await saveBtnCustomizationTab.click();
    }

    this.clickAdvancedSaveBtn = async function(){
        browser.executeScript('arguments[0].scrollIntoView()', saveBtnAdvancedTab.getWebElement());
        await saveBtnAdvancedTab.click();
    }

    this.clickEmployeeSaveBtn = async function(){
        utils.logInfo("Scrolling to Save button for selected Employee");
        browser.executeScript('arguments[0].scrollIntoView()', saveBtnEmployeeTab.getWebElement());

        var EC = protractor.ExpectedConditions;
        browser.wait(EC.presenceOf(saveBtnEmployeeTab), 10000);

        utils.logInfo("Click on Save button of selected Employee")
        await saveBtnEmployeeTab.click();
    }

    this.isGeneralTabPresent = async function(){
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.presenceOf(generalTab), 3000);
        return await generalTab.isPresent();
    }      

    this.isAccutradeTabPresent = async function(){
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.presenceOf(accutradeTab), 3000);
        return await accutradeTab.isPresent();
    }    

    this.isCustomizationTabPresent = async function(){
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.presenceOf(customizationTab), 3000);
        return await customizationTab.isPresent();
    }   

    this.isAdvancedTabPresent = async function(){
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.presenceOf(advancedTab), 3000);
        return await advancedTab.isPresent();
    }   

    this.isEmployeeTabPresent = async function(){
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.presenceOf(employeesTab), 3000);
        return await employeesTab.isPresent();
    }   

    this.isPresentDealershipNameGeneralTab = async function(){
        return await dealershipNameTxt.isPresent();
    }

    this.isPresentGuaranteedPriceAccutradeTab = async function(){
        return await guaranteedPriceLbl.isPresent();

    }

    this.isPresentBannerURLCustomizationTab = async function(){
        return await bannelURLTxt.isPresent();

    }

    this.isPresentAllowChromeLookupAdvancedTab = async function(){
        return await allowChromeLookupsLbl.isPresent();

    }

    this.isPresentEmployeeTableEmployeesTab = async function(){
        browser.switchTo().frame(0);
        var emprow = element(by.xpath("//tbody/tr[1]"));
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.presenceOf(emprow), 10000);
        browser.executeScript('arguments[0].scrollIntoView()', emprow.getWebElement());
        return await employeeTable.isPresent();

    }

    //General Tab
    this.getAddressGeneralTab = async function(){
        return await addressGeneralTab.getAttribute("value");
    }

    this.setAddressGeneralTab = async function(address){
        await addressGeneralTab.clear();
        await addressGeneralTab.sendKeys(address);

    }

    this.setProductGeneralTab = async function(productname){
        browser.executeScript('arguments[0].scrollIntoView()', productDropdownGeneralTab.getWebElement());
        switch(productname){
            case 'Accu-Trade - Appraiser Basic' :
                productname = "1";
                break;
            case 'Accu-Trade - Appraiser Plus' :
                productname = "2";
                break;
            case 'Accu-Trade - Appraiser Pro' :
                productname = "3";
                break;
            case 'TrueCar - Appraiser Basic' :
                productname = "4";
                break;
            case 'TrueCar - Appraiser Plus' :
                productname = "5";
                break;
            case 'TrueCar - Appraiser Pro' :
                productname = "6";
                break;
            case 'TrueCar - Appraiser VOI' :
                productname = "7";
                break;
        }//switch

        await productDropdownGeneralTab.$("[value='"+productname+"']").click();

    }

    this.getSelectedProductGeneralTab = async function(){
        return await productDropdownGeneralTab.$('option:checked').getText();
    }



    this.getAppointmentContactAccutradeTab = async function(){
        return await appointmentContactInputAccutradeTab.getAttribute("value");
    }

    this.setAppointmentContactAccutradeTab = async function(contact){
        await appointmentContactInputAccutradeTab.clear();
        await appointmentContactInputAccutradeTab.sendKeys(contact);
    }

    this.getLogoUrlCustomizationTab = async function(){
        return await logoURLInputCustomizationTab.getAttribute("value");
    }

    this.setLogoUrlCustomizationTab = async function(url){
        await logoURLInputCustomizationTab.clear();
        await logoURLInputCustomizationTab.sendKeys(url);
    }



    this.getColorSelectorShapeCustomizationTab = async function(){

    }

    this.setColorSelectorShapeCustomizationTab = async function(optionvalue){

    }

    this.getCRMEmailNameAdvancedTab = async function(){
        return await crmEmailNameTxtAdvancedTab.getAttribute("value");
    }

    this.setCRMEmailNameAdvancedTab = async function(email){
        await crmEmailNameTxtAdvancedTab.clear();
        await crmEmailNameTxtAdvancedTab.sendKeys(email);
    }

    this.getlastNameEmployeeTab = async function(){
        //browser.switchTo().frame(0);
        browser.executeScript('arguments[0].scrollIntoView()', lastNameTxtEmployeeTab.getWebElement());
        return await lastNameTxtEmployeeTab.getAttribute("value");
    }

    this.setlastNameEmployeeTab = async function(lastname){
        //browser.switchTo().frame(0);
        browser.executeScript('arguments[0].scrollIntoView()', lastNameTxtEmployeeTab.getWebElement());
        await lastNameTxtEmployeeTab.clear();
        await lastNameTxtEmployeeTab.sendKeys(lastname);
    }

    this.selectFirstCheckBoxEmployeeTable = async function(){
        utils.logInfo("Scrolling to first checkbox of Employees table");
        //browser.executeScript('arguments[0].scrollIntoView()', firstCheckBoxEmployeeTable.getWebElement());
        browser.executeScript('arguments[0].scrollIntoView()', employeeTable.getWebElement());

        // var EC = protractor.ExpectedConditions;
        // utils.logInfo("Waiting for checkbox to be clickable");
        // browser.wait(await EC.elementToBeClickable(firstCheckBoxEmployeeTable), 30000);

        utils.logInfo("Select employee checkbox");
        try{
            await firstCheckBoxEmployeeTable.click();
        }
        catch(err){
            utils.logInfo("Catch Error in dealershippage.selectFirstCheckBoxEmployeeTable().firstCheckBoxEmployeeTable.click() :"+err)
        }    
    }

    this.clickGeneralTab = async function(){
        await generalTab.click();
    }

    this.clickAccutradeTab = async function(){
        await accutradeTab.click();
    }

    this.clickCustomizationTab = async function(){
        await customizationTab.click();
    }

    this.clickAdvancedTab = async function(){
        await advancedTab.click();
    }

    this.clickEmployeesTab = async function(){
        await employeesTab.click();
    }

    this.clickEditButton = async function(){
        browser.executeScript('arguments[0].scrollIntoView()', editBtn.getWebElement());
        await editBtn.click();
    }

    this.getSearchDealershipTxt = async function(){
        return searchDealershipTxt;
    }

    this.getEmployeeRowCount = async function(){
        try{
            return await employeeTable.all(by.tagName("tr")).count();
        }
        catch(err){
            utils.logInfo("Error - dealershippage:getEmployeeRowCount(): "+err);
        }
    }
   

}


module.exports = new dealershippage();
