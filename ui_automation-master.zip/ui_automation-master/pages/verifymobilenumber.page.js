var verifymobilenumberpage = function(){
    
    var mobileTxt = element(by.name('contact_cellphone'));
    var remindmeBtn = element(by.buttonText('Remind me later'));
    var sendBtn = element(by.buttonText('Send'));

    this.getUrl = async function(){
        //return 'https://hercules-qa.accu-trade.com/auth/signup/verify-cellphone';
        return browser.params.env.url+"/auth/signup/verify-cellphone";

    }
    
    this.getMobileNumber = async function(){
        return mobileTxt.getAttribute("ng-reflect-model");
    }

    this.setMobileNumber = async function (mobilenumber) {
        await mobileTxt.sendKeys(mobilenumber);
    };

    this.clickRemindme = async function () {
        await remindmeBtn.click();



        
    };

    this.clickSend = async function () {
        await sendBtn.click();
    };

}

module.exports = new verifymobilenumberpage();
