var utils = require('../utilities/utils');

var crpage = function(){
    var crvehicledealer = element(by.xpath("//cr-vehicle-dealer"));    
    var generatePDF = element(by.xpath("//footer-button[@ng-reflect-text='Generate PDF']"));
    var downloadPDF = element(by.xpath("//footer-button[@ng-reflect-text='Download PDF']"));
    var shareCR = element(by.xpath("//footer-button[@ng-reflect-text='Share']"));
    var emailTabShareReport = element(by.xpath("//*[text()='Email']"));
    var generatedLinkShareReport = element(by.xpath("//section[@class='link']/span"));
    var TextMsgTabShareReport = element(by.xpath("//*[text()='Text Message']"));
    var emailInputShareReport = element(by.xpath("//input[@type='email']"));
    var phoneInputShareReport = element(by.xpath("//input[@placeholder='Phone Number']"));
    var messageInputShareReport = element(by.xpath("//textarea[@placeholder='Message (Optional)']")); 
    var sendEmailBtnShareReport = element(by.xpath("//fa-observable-button[@ng-reflect-text='Send Email']"));
    var sendTextBtnShareReport = element(by.xpath("//fa-observable-button[@ng-reflect-text='Send Text']"));
    var emailSuccessMsg = element(by.xpath("//*[text()='An Email has been sent to']"));
    var textSuccessMsg = element(by.xpath("//*[text()='A text has been sent to']"));
    var closeBtnShareReport = element(by.xpath("//*[@class='share-cr-modal open']/div/*[@class='material-icons close-button md-24']"));
    var consumerOfferValue = element(by.xpath("//*[@class='price-label-container']/*[@class='price']"));
    var dealerOfferValue = element(by.xpath("//appraisal-price[@ng-reflect-klass='target-trade']"));
    var dealerAuctionValue = element(by.xpath("//appraisal-price[@ng-reflect-label='Target Auction']"));
    var dealerRetailValue = element(by.xpath("//appraisal-price[@ng-reflect-label='Target Retail']"));
    var copyLinkShareReport = element(by.xpath("//*[text()=' Copy Link ']"));
    var linkCopiedNotificationMsg = element(by.xpath("//*[text()=' Link Copied ']"));
    var backToAppraisalLink = element(by.xpath("//*[text()='Back To Appraisal']"));
    var vinCR = element(by.xpath("//cr-vehicle-dealer/*[@class='vin-mi-reports']"));
    var damageEstimate = element(by.xpath("//cr-damage-estimate/cr-panel"))
    var reportSettingsBtn = element(by.xpath("//*[text()='Report Settings']"));
    //var backArrowBtn = element(by.xpath("//mat-icon[text()='chevron_left']"));


    //CONSUMER REPORT BRANDING
    var brandLogoLeftSection = element(by.xpath("//img[@class='consumer-mode-image']"));
    var reportBrandLogo = element(by.xpath("//brand-image/img"));
    var consumerReportPriceLabel = element(by.xpath("//cr-header/div[contains(@class,'price-label-container')]/label"));
    //old //cr-header/div[@class='price-label-container']/label

    //DEALER REPORT BRANDING
    var dealerReportOfferPriceLabel = element(by.xpath("//price-bar/appraisal-price[1]/div[@ng-reflect-klass='label']"));
    var valuesFirstCheckLabelReportSettings = element(by.xpath("//cr-configurator-pricebar/div/div[1]/checkbox/label"));

    this.isPresentBrandLogoLeftSection = async function(){
        return await brandLogoLeftSection.isPresent();
    }

    this.getBrandLogoLeftSectionImgSrc = async function(){
        return brandLogoLeftSection.getAttribute("src");
    }

    this.isPresentReportBrandLogo = async function(){
        return await reportBrandLogo.isPresent();
    }

    this.getReportBrandLogoImageSrc = async function(){
        return await reportBrandLogo.getAttribute("src");
    }

    this.isPresentConsumerReportPriceLabel = async function(){
        return await consumerReportPriceLabel.isPresent();
    }

    this.getConsumerReportPriceLabel = async function(){
        return await consumerReportPriceLabel.getText();
    }

    this.isPresentDealerReportOfferPriceLabel = async function(){
        return await dealerReportOfferPriceLabel.isPresent();
    }

    this.getDealerReportOfferPriceLabel = async function(){
        return await dealerReportOfferPriceLabel.getText();
    }

    this.isPresentValuesFirstCheckLabelReportSettings = async function(){
        return await valuesFirstCheckLabelReportSettings.isPresent();
    }

    this.getValuesFirstCheckLabelReportSettings = async function(){
        return await valuesFirstCheckLabelReportSettings.getText();
    }

    this.clickReportSettingBtn = async function(){
        await reportSettingsBtn.click();
    }

    // this.clickBackArrowBtn = async function(){
    //     await backArrowBtn.click();
    // }

    this.isPresentDamageEstimate = async function(){
        return await damageEstimate.isPresent();
    }

    this.getDamageEstimateValue = async function(){
        return await damageEstimate.getAttribute("ng-reflect-price");
    }

    this.getVINCR = async function(){
        var sVIN = await vinCR.getText();
        sVIN = utils.splitInToTwoReturnFirstPart(sVIN,"|")
        return sVIN.trim();
    }

    this.getCRVehicleInfo = async function(){
        return await crvehicledealer.getText();
    }

    this.getConsumerCROfferValue = async function(){
        return await consumerOfferValue.getText();
    }

    this.getDealerCROfferValue = async function(){
        return await dealerOfferValue.getAttribute("ng-reflect-price");
    }

    this.getDealerCRAuctionValue = async function(){
        return await dealerAuctionValue.getAttribute("ng-reflect-price");
    }

    this.getDealerCRRetailValue = async function(){
        return await dealerRetailValue.getAttribute("ng-reflect-price");
    }

    this.clickBackToAppraisalLink = async function(){
        await backToAppraisalLink.click();
    }

    this.clickGeneratePDF = async function(){
        try{
            await utils.logInfo("Before Generate PDF Click");
            await generatePDF.click();
            await utils.logInfo("After Generate PDF Click");
        }
        catch(err){
            utils.logInfo("Catch error is "+err);
        }
    }

    this.clickDownloadPDF = async function(){
        await downloadPDF.click();
    }

    this.clickShareCR = async function(){
        await shareCR.click();
    }

    this.enterEmailAddressShareReport = async function(email){
        await emailInputShareReport.clear();
        await emailInputShareReport.sendKeys(email);
    }

    this.enterMsgShareReport = async function(msg){
        //await messageInputShareReport.clear();
        await utils.logInfo("value is "+msg);
        await messageInputShareReport.sendKeys(msg);
    }

    this.getMsgContentShareReport = async function(){
        return await messageInputShareReport.getAttribute("ng-reflect-model");
    }

    this.getMsgShareReportWebElement = function(){ //this is needs to be non async
        return messageInputShareReport;
    }

    this.getGeneratedLinkShareReport = async function(){
        return await generatedLinkShareReport.getText();
    }

    this.enterPhoneShareReport = async function(phone){
        await phoneInputShareReport.clear();
        await phoneInputShareReport.sendKeys(phone);
    }

    this.clickTextMsgTabShareReport = async function(){
        await TextMsgTabShareReport.click();
    }

    this.clickEmailTabShareReport = async function(){
        await emailTabShareReport.click();
    }

    this.clickSendEmailBtnShareReport = async function(){
        await sendEmailBtnShareReport.click();
    }

    this.clickSendTextBtnShareReport = async function(){
        await sendTextBtnShareReport.click();
    }

    this.clickCopyLinkShareReport = async function(){
        await copyLinkShareReport.click();
    }

    this.isPresentCopyLinkWebElement = async function(){
        return await copyLinkShareReport.isPresent();
    }

    this.isPresentLinkCopiedNotificationMsg = async function(){
        return await linkCopiedNotificationMsg.isPresent();
    }

    this.getCopyLinkShareReportWebElement = function(){
        return copyLinkShareReport;
    }

    this.isPresentEmailSuccessMsg = async function(){
        return await emailSuccessMsg.isPresent();
    }

    this.isPresentSendEmailButton = async function(){
        return await sendEmailBtnShareReport.isPresent();
    }

    this.isPresentSendTextButton = async function(){
        return await sendTextBtnShareReport.isPresent();
    }

    this.isPresentEmailInput = async function(){
        return await emailInputShareReport.isPresent();
    }

    this.isPresentSMSInput = async function(){
        return await phoneInputShareReport.isPresent();
    }

    this.isPresentTextSuccessMsg = async function(){
        return await textSuccessMsg.isPresent();
    }

    this.closeShareReportScreen = async function(){
        await closeBtnShareReport.click();
    }

    this.getSendEmailBtnWebElement = function(){
        return sendEmailBtnShareReport;
    }

    this.getCRPhotosCount = async function(){
        return await element.all(by.xpath("//cr-photo-gallery/div[@class='photo']")).count();
    }

    this.assertCR = async function(crtype, mainadjustment,adjustment,category,subcategory,vin, offerprice, targetauction, targetretail, adjustmentvalue, finalofferprice, finaltargetauction, finaltargetretail){
        var panelPrice = "0";
        var adjustmentPrice = "0";
        var tireTreadAdjustmentPriceLocator = "//*[text()='"+category+"']/following-sibling::td[@class='price']/formatted-price";
        var tireConditionAdjustmentPriceLocator = "//*[text()='"+subcategory+"']/following-sibling::td[@class='price']/formatted-price";

        switch(mainadjustment){
            case 'Options':
                panelPrice = "//*[@ng-reflect-title='"+mainadjustment+"']";
                await utils.logInfo("assertCR mainadjustment value: "+panelPrice);

                adjustmentPrice = "//*[text()='"+adjustment+"']/../following-sibling::adjustment-list-price/formatted-price";
                await utils.logInfo("assertCR adjustment value: "+adjustmentPrice);
                var panelWebElement = element(by.xpath(panelPrice)); //*[@ng-reflect-title='Options']
                var adjustmentWebElement = element(by.xpath(adjustmentPrice)); //*[text()='WITHOUT AC']/../following-sibling::adjustment-list-price/formatted-price
                    //*[text()='Front Door Panel Right scratched']/../following-sibling::adjustment-list-price/formatted-price
        
                await utils.logInfo("Panel Price value is "+await panelWebElement.getAttribute("ng-reflect-price"));
                await utils.logInfo("Adjustment Price value is "+await adjustmentWebElement.getAttribute("ng-reflect-price"));
                
                await utils.logInfo("Verify the aggergate adjustment CR value is "+adjustmentvalue);
                expect(await panelWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify aggregate Adjustment Value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                await utils.logInfo("Verify the individual adjustment CR value is "+adjustmentvalue);
                expect(await adjustmentWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify the individual adjustment value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                break;
            case 'Vehicle History':
                //*[text()='Bad VHR ']/../adjustment-list-price/formatted-price
                panelPrice = "//*[@ng-reflect-title='"+mainadjustment+"']";
                await utils.logInfo("assertCR mainadjustment value: "+panelPrice);
                if(adjustment == "Bad VHR"){
                    adjustmentPrice = "//*[text()='"+adjustment+" ']/../adjustment-list-price/formatted-price";
                }
                else{
                    adjustmentPrice = "//*[text()='"+adjustment+"']/../adjustment-list-price/formatted-price";
                }
                await utils.logInfo("assertCR: "+adjustmentPrice);
                var panelWebElement = element(by.xpath(panelPrice)); //*[@ng-reflect-title='Options']
                var adjustmentWebElement = element(by.xpath(adjustmentPrice)); //*[text()='WITHOUT AC']/../following-sibling::adjustment-list-price/formatted-price
                    //*[text()='Front Door Panel Right scratched']/../following-sibling::adjustment-list-price/formatted-price
        
                await utils.logInfo("Panel Price value is "+await panelWebElement.getAttribute("ng-reflect-price"));
                await utils.logInfo("Adjustment Price value is "+await adjustmentWebElement.getAttribute("ng-reflect-price"));
                
                await utils.logInfo("Verify the aggergate adjustment CR value is "+adjustmentvalue);
                expect(await panelWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify aggregate Adjustment Value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                await utils.logInfo("Verify the individual adjustment CR value is "+adjustmentvalue);
                expect(await adjustmentWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify the individual adjustment value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                break;
            case 'Original Owner':
                //*[text()='1 Owner(s)']/../following-sibling::adjustment-list-price/formatted-price
                panelPrice = "//*[@ng-reflect-title='"+mainadjustment+"']";
                await utils.logInfo("assertCR mainadjustment value: "+panelPrice);

                adjustmentPrice = "//*[text()='"+adjustment+" Owner(s)']/../following-sibling::adjustment-list-price/formatted-price";
                await utils.logInfo("assertCR: "+adjustmentPrice);
                var panelWebElement = element(by.xpath(panelPrice)); //*[@ng-reflect-title='Options']
                var adjustmentWebElement = element(by.xpath(adjustmentPrice)); //*[text()='WITHOUT AC']/../following-sibling::adjustment-list-price/formatted-price
                    //*[text()='Front Door Panel Right scratched']/../following-sibling::adjustment-list-price/formatted-price
        
                await utils.logInfo("Panel Price value is "+await panelWebElement.getAttribute("ng-reflect-price"));
                await utils.logInfo("Adjustment Price value is "+await adjustmentWebElement.getAttribute("ng-reflect-price"));
                
                await utils.logInfo("Verify the aggergate adjustment CR value is "+adjustmentvalue);
                expect(await panelWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify aggregate Adjustment Value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                await utils.logInfo("Verify the individual adjustment CR value is "+adjustmentvalue);
                expect(await adjustmentWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify the individual adjustment value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                break;
            case 'Color':
                //*[text()='Exterior - Pearl White']/following-sibling::adjustment-list-price/formatted-price
                panelPrice = "//*[@ng-reflect-title='"+mainadjustment+"']";
                await utils.logInfo("assertCR mainadjustment value: "+panelPrice);

                if(adjustment.includes("Exterior")){
                    adjustmentPrice = "//*[text()='"+"Exterior - "+category+"']/following-sibling::adjustment-list-price/formatted-price";
                }
                else{
                    adjustmentPrice = "//*[text()='"+"Interior - "+category+"']/following-sibling::adjustment-list-price/formatted-price";

                }
                await utils.logInfo("assertCR: "+adjustmentPrice);
                var panelWebElement = element(by.xpath(panelPrice)); //*[@ng-reflect-title='Options']
                var adjustmentWebElement = element(by.xpath(adjustmentPrice)); //*[text()='WITHOUT AC']/../following-sibling::adjustment-list-price/formatted-price
                    //*[text()='Front Door Panel Right scratched']/../following-sibling::adjustment-list-price/formatted-price
        
                await utils.logInfo("Panel Price value is "+await panelWebElement.getAttribute("ng-reflect-price"));
                await utils.logInfo("Adjustment Price value is "+await adjustmentWebElement.getAttribute("ng-reflect-price"));
                
                await utils.logInfo("Verify the aggergate adjustment CR value is "+adjustmentvalue);
                expect(await panelWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify aggregate Adjustment Value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                await utils.logInfo("Verify the individual adjustment CR value is "+adjustmentvalue);
                expect(await adjustmentWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify the individual adjustment value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                break;
            case 'Keys':
                panelPrice = "//*[@ng-reflect-title='"+mainadjustment+"']";
                await utils.logInfo("assertCR mainadjustment value: "+panelPrice);

                if(adjustment == "1"){
                    adjustmentPrice = "//*[text()='Key']/../following-sibling::adjustment-list-price/formatted-price";
                }
                else{
                    adjustmentPrice = "//*[text()='Keys']/../following-sibling::adjustment-list-price/formatted-price";
                }

                await utils.logInfo("assertCR: "+adjustmentPrice);
                var panelWebElement = element(by.xpath(panelPrice)); //*[@ng-reflect-title='Options']
                var adjustmentWebElement = element(by.xpath(adjustmentPrice)); //*[text()='WITHOUT AC']/../following-sibling::adjustment-list-price/formatted-price
                    //*[text()='Front Door Panel Right scratched']/../following-sibling::adjustment-list-price/formatted-price
        
                await utils.logInfo("Panel Price value is "+await panelWebElement.getAttribute("ng-reflect-price"));
                await utils.logInfo("Adjustment Price value is "+await adjustmentWebElement.getAttribute("ng-reflect-price"));
                
                await utils.logInfo("Verify the aggergate adjustment CR value is "+adjustmentvalue);
                expect(await panelWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify aggregate Adjustment Value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                await utils.logInfo("Verify the individual adjustment CR value is "+adjustmentvalue);
                expect(await adjustmentWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify the individual adjustment value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                break;
            case 'Service Status':
                panelPrice = "//*[@ng-reflect-title='"+mainadjustment+"']";
                await utils.logInfo("assertCR mainadjustment value: "+panelPrice);

                adjustmentPrice = "//*[text()='"+adjustment+"']/../following-sibling::adjustment-list-price/formatted-price";
                await utils.logInfo("assertCR: "+adjustmentPrice);
                var panelWebElement = element(by.xpath(panelPrice)); //*[@ng-reflect-title='Options']
                var adjustmentWebElement = element(by.xpath(adjustmentPrice)); //*[text()='WITHOUT AC']/../following-sibling::adjustment-list-price/formatted-price
                    //*[text()='Front Door Panel Right scratched']/../following-sibling::adjustment-list-price/formatted-price
        
                await utils.logInfo("Panel Price value is "+await panelWebElement.getAttribute("ng-reflect-price"));
                await utils.logInfo("Adjustment Price value is "+await adjustmentWebElement.getAttribute("ng-reflect-price"));
                
                await utils.logInfo("Verify the aggergate adjustment CR value is "+adjustmentvalue);
                expect(await panelWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify aggregate Adjustment Value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                await utils.logInfo("Verify the individual adjustment CR value is "+adjustmentvalue);
                expect(await adjustmentWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify the individual adjustment value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                break;
            case 'Odometer':
                //*[text()='75,000 Miles']/following-sibling::adjustment-list-price/formatted-price
                panelPrice = "//*[@ng-reflect-title='"+mainadjustment+"']";
                await utils.logInfo("assertCR mainadjustment value: "+panelPrice);

                adjustmentPrice = "//*[text()='"+adjustment+" Miles']/following-sibling::adjustment-list-price/formatted-price";
                await utils.logInfo("assertCR: "+adjustmentPrice);
                var panelWebElement = element(by.xpath(panelPrice)); //*[@ng-reflect-title='Options']
                var adjustmentWebElement = element(by.xpath(adjustmentPrice)); //*[text()='WITHOUT AC']/../following-sibling::adjustment-list-price/formatted-price
                    //*[text()='Front Door Panel Right scratched']/../following-sibling::adjustment-list-price/formatted-price
        
                await utils.logInfo("Panel Price value is "+await panelWebElement.getAttribute("ng-reflect-price"));
                await utils.logInfo("Adjustment Price value is "+await adjustmentWebElement.getAttribute("ng-reflect-price"));
                
                await utils.logInfo("Verify the aggergate adjustment CR value is "+adjustmentvalue);
                expect(await panelWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify aggregate Adjustment Value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                await utils.logInfo("Verify the individual adjustment CR value is "+adjustmentvalue);
                expect(await adjustmentWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify the individual adjustment value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                break;
            case 'Body':
                panelPrice = "//*[@ng-reflect-title='"+mainadjustment+" Damage']";
                await utils.logInfo("assertCR mainadjustment value: "+panelPrice);

                adjustmentPrice = "//*[text()='"+"• "+adjustment+"  "+category+" - "+subcategory+"']/following-sibling::formatted-price";
                await utils.logInfo("assertCR: "+adjustmentPrice);
                var panelWebElement = element(by.xpath(panelPrice)); //*[@ng-reflect-title='Options']
                var adjustmentWebElement = element(by.xpath(adjustmentPrice)); //*[text()='WITHOUT AC']/../following-sibling::adjustment-list-price/formatted-price
                    //*[text()='Front Door Panel Right scratched']/../following-sibling::adjustment-list-price/formatted-price
        
                await utils.logInfo("Panel Price value is "+await panelWebElement.getAttribute("ng-reflect-price"));
                await utils.logInfo("Adjustment Price value is "+await adjustmentWebElement.getAttribute("ng-reflect-price"));
                
                await utils.logInfo("Verify the aggergate adjustment CR value is "+adjustmentvalue);
                expect(await panelWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify aggregate Adjustment Value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                await utils.logInfo("Verify the individual adjustment CR value is "+adjustmentvalue);
                expect(await adjustmentWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify the individual adjustment value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                break;
            case 'Tire/Wheel':
                //{mainadjustment:'Tire/Wheel',adjustment:'Rear Right',category:'4/32 - 7/32',subcategory:'replace wheel'}
                //*[text()='4/32 - 7/32']/following-sibling::td[@class='price']/formatted-price
                //*[text()='replace wheel']/following-sibling::td[@class='price']/formatted-price
                var tireTreadExpectedValue = utils.splitInToTwoReturnFirstPart(adjustmentvalue,":");
                var tireConditionExpectedValue = utils.splitInToTwoReturnSecondPart(adjustmentvalue,":");
                adjustmentvalue = parseInt(tireTreadExpectedValue)+parseInt(tireConditionExpectedValue);
                adjustmentvalue = adjustmentvalue.toString();

                panelPrice = "//*[@ng-reflect-title='"+mainadjustment+"']";
                await utils.logInfo("assertCR mainadjustment value: "+panelPrice);

                await utils.logInfo("assertCR:tireTreadAdjustmentPriceLocator - "+tireTreadAdjustmentPriceLocator);
                await utils.logInfo("assertCR: tireConditionAdjustmentPriceLocator - "+tireConditionAdjustmentPriceLocator);

                var tireTreadAdjustmentPriceWebElement = element(by.xpath(tireTreadAdjustmentPriceLocator));
                var tireConditionAdjustmentPriceWebElement = element(by.xpath(tireConditionAdjustmentPriceLocator));

                await utils.logInfo("Value of Tire Tread in CR is "+await tireTreadAdjustmentPriceWebElement.getAttribute("ng-reflect-price"));
                await utils.logInfo("Value of Tire Condition in CR is "+await tireConditionAdjustmentPriceWebElement.getAttribute("ng-reflect-price"));

                expect(await tireTreadAdjustmentPriceWebElement.getAttribute("ng-reflect-price")).toBe(tireTreadExpectedValue,"Verify value of Tire Tread in CR");
                expect(await tireConditionAdjustmentPriceWebElement.getAttribute("ng-reflect-price")).toBe(tireConditionExpectedValue,"Verify value of Tire Condition in CR");
                
                var panelWebElement = element(by.xpath(panelPrice)); //*[@ng-reflect-title='Options']
                var adjustmentWebElement = element(by.xpath(adjustmentPrice)); //*[text()='WITHOUT AC']/../following-sibling::adjustment-list-price/formatted-price
                    //*[text()='Front Door Panel Right scratched']/../following-sibling::adjustment-list-price/formatted-price
        
                await utils.logInfo("Panel Price value is "+await panelWebElement.getAttribute("ng-reflect-price"));
                
                await utils.logInfo("Verify the aggergate adjustment CR value is "+adjustmentvalue);
                expect(await panelWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify aggregate Adjustment Value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                //await utils.logInfo("Verify the individual adjustment CR value is "+adjustmentvalue);
                //expect(await adjustmentWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify the individual adjustment value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        

                break;
            case 'Warning Lights':
            case 'Lights':    
                //mainadjustment = "Lights";
                panelPrice = "//*[@ng-reflect-title='"+mainadjustment+"']";
                await utils.logInfo("assertCR mainadjustment value: "+panelPrice);

                adjustmentPrice = "//*[text()='"+adjustment+"']/../following-sibling::adjustment-list-price/formatted-price";
                await utils.logInfo("assertCR: "+adjustmentPrice);
                var panelWebElement = element(by.xpath(panelPrice)); //*[@ng-reflect-title='Options']
                var adjustmentWebElement = element(by.xpath(adjustmentPrice)); //*[text()='WITHOUT AC']/../following-sibling::adjustment-list-price/formatted-price
                    //*[text()='Front Door Panel Right scratched']/../following-sibling::adjustment-list-price/formatted-price
        
                await utils.logInfo("Panel Price value is "+await panelWebElement.getAttribute("ng-reflect-price"));
                await utils.logInfo("Adjustment Price value is "+await adjustmentWebElement.getAttribute("ng-reflect-price"));
                
                await utils.logInfo("Verify the aggergate adjustment CR value is "+adjustmentvalue);
                expect(await panelWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify aggregate Adjustment Value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                await utils.logInfo("Verify the individual adjustment CR value is "+adjustmentvalue);
                expect(await adjustmentWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify the individual adjustment value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                break;            
            case 'Interior':
                panelPrice = "//*[@ng-reflect-title='"+mainadjustment+" Damage']";
                await utils.logInfo("assertCR mainadjustment value: "+panelPrice);
                await utils.logInfo("assertCR Value of adjustment is "+adjustment);
                var fpart = utils.splitInToTwoReturnFirstPart(adjustment,'-');
                var spart = utils.splitInToTwoReturnSecondPart(adjustment,'-');
                adjustment = fpart.concat(" "+spart);

                adjustmentPrice = "//*[text()='"+"• "+adjustment+" "+category+"']/following-sibling::formatted-price";
                await utils.logInfo("assertCR: "+adjustmentPrice);
                var panelWebElement = element(by.xpath(panelPrice)); //*[@ng-reflect-title='Options']
                var adjustmentWebElement = element(by.xpath(adjustmentPrice)); //*[text()='WITHOUT AC']/../following-sibling::adjustment-list-price/formatted-price
                    //*[text()='Front Door Panel Right scratched']/../following-sibling::adjustment-list-price/formatted-price
        
                await utils.logInfo("Panel Price value is "+await panelWebElement.getAttribute("ng-reflect-price"));
                await utils.logInfo("Adjustment Price value is "+await adjustmentWebElement.getAttribute("ng-reflect-price"));
                
                await utils.logInfo("Verify the aggergate adjustment CR value is "+adjustmentvalue);
                expect(await panelWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify aggregate Adjustment Value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                await utils.logInfo("Verify the individual adjustment CR value is "+adjustmentvalue);
                expect(await adjustmentWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify the individual adjustment value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                break;
            case 'Mechanical':
                panelPrice = "//*[@ng-reflect-title='"+mainadjustment+"']";
                await utils.logInfo("assertCR mainadjustment value: "+panelPrice);
                if(adjustment == 'Engine'){
                    adjustmentPrice = "//cr-mechanical-panel/cr-panel/div/adjustment-list/ul/li/div/*[text()='"+adjustment+"']/../following-sibling::adjustment-list-price/formatted-price";
                    //cr-mechanical-panel/cr-panel/div/adjustment-list/ul/li/div/*[text()='Engine']/../following-sibling::adjustment-list-price/formatted-price
                }
                else{
                adjustmentPrice = "//*[text()='"+adjustment+"']/../following-sibling::adjustment-list-price/formatted-price";
                }
                await utils.logInfo("assertCR: "+adjustmentPrice);
                var panelWebElement = element(by.xpath(panelPrice)); //*[@ng-reflect-title='Options']
                var adjustmentWebElement = element(by.xpath(adjustmentPrice)); //*[text()='WITHOUT AC']/../following-sibling::adjustment-list-price/formatted-price
                    //*[text()='Front Door Panel Right scratched']/../following-sibling::adjustment-list-price/formatted-price
        
                await utils.logInfo("Panel Price value is "+await panelWebElement.getAttribute("ng-reflect-price"));
                await utils.logInfo("Adjustment Price value is "+await adjustmentWebElement.getAttribute("ng-reflect-price"));
                
                await utils.logInfo("Verify the aggergate adjustment CR value is "+adjustmentvalue);
                expect(await panelWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify aggregate Adjustment Value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                await utils.logInfo("Verify the individual adjustment CR value is "+adjustmentvalue);
                expect(await adjustmentWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify the individual adjustment value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                break;   
            case 'Aftermarket':
                mainadjustment = "Aftermarket Modifications";
                panelPrice = "//*[@ng-reflect-title='"+mainadjustment+"']";
                await utils.logInfo("assertCR mainadjustment value: "+panelPrice);

                if(adjustment == 'Exhaust'){
                    adjustmentPrice = "//cr-aftermarket-panel/cr-panel/div/adjustment-list/ul/li/div/span[text()='"+adjustment+"']/../following-sibling::adjustment-list-price/formatted-price";
                }
                else{
                    adjustmentPrice = "//*[text()='"+adjustment+"']/../following-sibling::adjustment-list-price/formatted-price";
                }

                await utils.logInfo("assertCR: "+adjustmentPrice);
                var panelWebElement = element(by.xpath(panelPrice)); //*[@ng-reflect-title='Options']
                var adjustmentWebElement = element(by.xpath(adjustmentPrice)); //*[text()='WITHOUT AC']/../following-sibling::adjustment-list-price/formatted-price
                    //*[text()='Front Door Panel Right scratched']/../following-sibling::adjustment-list-price/formatted-price
        
                await utils.logInfo("Panel Price value is "+await panelWebElement.getAttribute("ng-reflect-price"));
                await utils.logInfo("Adjustment Price value is "+await adjustmentWebElement.getAttribute("ng-reflect-price"));
                
                await utils.logInfo("Verify the aggergate adjustment CR value is "+adjustmentvalue);
                expect(await panelWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify aggregate Adjustment Value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                await utils.logInfo("Verify the individual adjustment CR value is "+adjustmentvalue);
                expect(await adjustmentWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify the individual adjustment value of '"+mainadjustment+":"+adjustmentvalue+"' in CR");
        
                break;            
            case 'Glass':
                //*[text()='• Back Glass right cracked']/following-sibling::formatted-price
                panelPrice = "//*[@ng-reflect-title='"+mainadjustment+" Damage']";
                await utils.logInfo("assertCR mainadjustment value: "+panelPrice);

                adjustmentPrice = "//*[text()='"+"• "+adjustment+"  "+category+"']/following-sibling::formatted-price";
                await utils.logInfo("assertCR: "+adjustmentPrice);
                var panelWebElement = element(by.xpath(panelPrice)); //*[@ng-reflect-title='Options']
                var adjustmentWebElement = element(by.xpath(adjustmentPrice)); //*[text()='WITHOUT AC']/../following-sibling::adjustment-list-price/formatted-price
                    //*[text()='Front Door Panel Right scratched']/../following-sibling::adjustment-list-price/formatted-price
        
                await utils.logInfo("Panel Price value is "+await panelWebElement.getAttribute("ng-reflect-price"));
                await utils.logInfo("Adjustment Price value is "+await adjustmentWebElement.getAttribute("ng-reflect-price"));
                
                await utils.logInfo("Verify the aggergate adjustment CR value is "+adjustmentvalue);
                expect(await panelWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify aggregate Adjustment Value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                await utils.logInfo("Verify the individual adjustment CR value is "+adjustmentvalue);
                expect(await adjustmentWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify the individual adjustment value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                break;         
            case 'Other':
                mainadjustment = "Disclosures";
                panelPrice = "//*[@ng-reflect-title='"+mainadjustment+"']";
                await utils.logInfo("assertCR mainadjustment value: "+panelPrice);

                adjustmentPrice = "//*[text()='"+adjustment+"']/../following-sibling::adjustment-list-price/formatted-price";
                await utils.logInfo("assertCR: "+adjustmentPrice);
                var panelWebElement = element(by.xpath(panelPrice)); //*[@ng-reflect-title='Options']
                var adjustmentWebElement = element(by.xpath(adjustmentPrice)); //*[text()='WITHOUT AC']/../following-sibling::adjustment-list-price/formatted-price
                    //*[text()='Front Door Panel Right scratched']/../following-sibling::adjustment-list-price/formatted-price
        
                await utils.logInfo("Panel Price value is "+await panelWebElement.getAttribute("ng-reflect-price"));
                await utils.logInfo("Adjustment Price value is "+await adjustmentWebElement.getAttribute("ng-reflect-price"));
                
                await utils.logInfo("Verify the aggergate adjustment CR value is "+adjustmentvalue);
                expect(await panelWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify aggregate Adjustment Value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                await utils.logInfo("Verify the individual adjustment CR value is "+adjustmentvalue);
                expect(await adjustmentWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify the individual adjustment value of '"+mainadjustment+"-"+adjustmentvalue+"' in CR");
        
                break;         
         
        } //switch



    }


    this.waitForElementToBeClickable = async function(){
        await utils.logInfo("Before getAttribute('ng-reflect-disabled') = "+await generatePDF.getAttribute("ng-reflect-disabled"));
        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(generatePDF), 10000);
        await utils.logInfo("After getAttribute('ng-reflect-disabled') = "+await generatePDF.getAttribute("ng-reflect-disabled"));

    }

    this.waitForWebElementToBeVisible = async function(webelement){
        var EC = protractor.ExpectedConditions;

        switch(webelement){
            case "Generate PDF":
                await utils.logInfo(webelement+" getAttribute('ng-reflect-disabled') = "+await generatePDF.getAttribute("ng-reflect-disabled"));
                await browser.wait(EC.elementToBeClickable(generatePDF), 10000);
                utils.logInfo("generatePDF.isPresent(): "+await generatePDF.isPresent());
                utils.logInfo("shareCR.isPresent(): "+await shareCR.isPresent());

                await utils.logInfo(webelement+" getAttribute('ng-reflect-disabled') = "+await generatePDF.getAttribute("ng-reflect-disabled"));            
                break;
            case "Download PDF":
                await utils.logInfo("Inside Download PDF");
                utils.logInfo("shareCR.isPresent(): "+await shareCR.isPresent());
                utils.logInfo("generatePDF.isPresent(): "+await generatePDF.isPresent());
                utils.logInfo("downloadPDF.isPresent(): "+await downloadPDF.isPresent());
                //await utils.logInfo(webelement+" getAttribute('ng-reflect-disabled') = "+await downloadPDF.getAttribute("ng-reflect-disabled"));
                //var EC = protractor.ExpectedConditions;
                //await browser.wait(EC.presenceOf(downloadPDF), 20000);
                await utils.logInfo("before sleep");
                await browser.sleep(10000);
                await utils.logInfo("after sleep");
                await utils.logInfo("downloadPDF.isPresent(): "+await downloadPDF.isPresent());

                //await utils.logInfo(webelement+" getAttribute('ng-reflect-disabled') = "+await downloadPDF.getAttribute("ng-reflect-disabled"));    
                break;
            default:
                await utils.logInfo("The crpage.waitForWebElementToBeVisible() function parameter: '"+webelement+"' is invalid");
        }

    }

}


module.exports = new crpage();
