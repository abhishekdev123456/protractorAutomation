var utils = require('../utilities/utils');
// var myaccountpage = require('../pages/myaccount.page');
// var verifymobilenumberpage = require('../pages/verifymobilenumber.page');
// var appraisalpage = require('../pages/appraisal.page');


var perseuspage = function(){

    var enterVinTab = element(by.xpath("//input[@data-identifier='vin']/.."));
    var vinInput = element(by.id("vehicle_vin"));
    var trimDropdown = element(by.id("vinVehicleStyle"));
    var continueBtn = element(by.xpath("//button"));
    
    //var getStartedBtn = element(by.xpath("//*[text()='Get Started']/.."));
    var getStartedBtn = element(by.xpath("//*[@class='form-group pr-cta-container']"));
    var blackColorBtn = element(by.xpath("//*[@style='background-color: rgb(37, 38, 39);']"));
    var mileageInput = element(by.id("vehicle_mileage"));
    var zipCodeInput = element(by.id("postal_code"));

    //var autoCheckReportTitle = element(by.xpath("//*[@class='title'] [text()='AutoCheck® Report']"));

    var originalOwnerYesInput = element(by.xpath("//input[@name='is_original_owner'][@value='true']"));
    //var originalOwnerYesInput = element(by.xpath("//input[@name='is_original_owner'][@value='true']/following-sibling::span"));//Amit

    var originalOwnerNoInput = element(by.xpath("//input[@name='is_original_owner'][@value='false']"));

    //var stillMakingPaymentInput = element(by.name("is_liened")); 
    var stillMakingPaymentYesInput = element(by.xpath("//input[@name='is_liened'][@value='true']"));

    var stillMakingPaymentNoInput = element(by.xpath("//input[@name='is_liened'][@value='false']"));
    //var stillMakingPaymentNoInput = element(by.xpath("//input[@name='is_liened'][@value='false']/following-sibling::span"));//Amit

    var isInterestedReplacementVehicleYesInput = element(by.xpath("//input[@name='is_interested_new_vehicle'][@value='true']"));
    var isInterestedReplacementVehicleNoInput = element(by.xpath("//input[@name='is_interested_new_vehicle'][@value='false']"));


    var nextConditionBtn = element(by.xpath("//*[text()='Next: Condition']/..")); //Amit
    //var nextConditionBtn = element(by.xpath("//*[text()='Next: condition']/..")); //Amit

    //var hasVehicleAccidentInput = element(by.name("has_accident"));
    var hasVehicleAccidentYesInput = element(by.xpath("//input[@name='has_accident'][@value='true']"));
    var hasVehicleAccidentNoInput = element(by.xpath("//input[@name='has_accident'][@value='false']"));


    //var hasExternalDamageInput = element(by.name("has_external_damage"));
    var hasExternalDamageYesInput = element(by.xpath("//input[@name='has_external_damage'][@value='true']"));
    var hasExternalDamageNoInput = element(by.xpath("//input[@name='has_external_damage'][@value='false']"));


    //var hasMechanicalIssuesInput = element(by.name("has_mechanical_issues"));
    var hasMechanicalIssuesYesInput = element(by.xpath("//input[@name='has_mechanical_issues'][@value='true']"));
    var hasMechanicalIssuesNoInput = element(by.xpath("//input[@name='has_mechanical_issues'][@value='false']"));


    //var hasWarningLightsInput = element(by.name("has_warning_lights"));
    var hasWarningLightsYesInput = element(by.xpath("//input[@name='has_warning_lights'][@value='true']"));
    var hasWarningLightsNoInput = element(by.xpath("//input[@name='has_warning_lights'][@value='false']"));


    //var hasModificationsInput = element(by.name("has_modifications"));
    var hasModificationsYesInput = element(by.xpath("//input[@name='has_modifications'][@value='true']"));
    var hasModificationsNoInput = element(by.xpath("//input[@name='has_modifications'][@value='false']"));

    //var hasOdorInput = element(by.name("has_odor"));
    var hasOdorYesInput = element(by.xpath("//input[@name='has_odor'][@value='true']"));
    var hasOdorNoInput = element(by.xpath("//input[@name='has_odor'][@value='false']"));


    //var hasOtherIssuesInput = element(by.name("has_other_issues"));
    var hasOtherIssuesYesInput = element(by.xpath("//input[@name='has_other_issues'][@value='true']"));
    var hasOtherIssuesNoInput = element(by.xpath("//input[@name='has_other_issues'][@value='false']"));

    var nextOfferBtn = element(by.xpath("//*[text()='Next: Accu-Trade Instant Offer']/.."));
    var nextTrueCashOfferBtn = element(by.xpath("//*[text()='Next: True Cash Offer']/.."));

    var getTrueCarOfferBtn = element(by.xpath("//*[text()='Get True Cash Offer']/.."));


    var frontTiresConditionDropdown = element(by.xpath("//select[@ng-reflect-name='front_tire_age']"));
    var rearTiresConditionDropdown = element(by.xpath("//select[@ng-reflect-name='rear_tire_age']"));
    

    var firstNameInput = element(by.id("firstName"));
    var lastNameInput = element(by.id("lastName"));
    var cellPhoneInput = element(by.id("cellPhone"));
    var emailInput = element(by.id("email"));
    var whenToSellDropdown = element(by.id("expect_transact_months"));
    var termsCheckBox = element(by.xpath("//input[@id='prAgreement']/following-sibling::span"));
    var getInstantOfferBtn = element(by.xpath("//*[text()='Get Accu-Trade Instant Offer']/.."));


    this.isPresentWhenToSellDropdown = async function(){
        return await whenToSellDropdown.isPresent();
    }

    this.setFirstName = async function(fname){
        await browser.sleep(browser.params.sleep.sleep2);
        await firstNameInput.sendKeys(fname);
        await browser.sleep(browser.params.sleep.sleep2);
    }

    this.setLastName = async function(lname){
        await lastNameInput.sendKeys(lname);
    }

    this.setCellPhone = async function(phone){
        await cellPhoneInput.sendKeys(phone);
    }

    this.setEmail = async function(email){
        await emailInput.sendKeys(email);
    }

    this.setWhenToSellDropdown = async function(value){
        value = "1";
        await whenToSellDropdown.$('[value="'+value+'"]').click();

    }

    this.selectTermsCheckBox = async function(){
        await termsCheckBox.click();
    }

    this.setFrontTiresCondition = async function(condition){
        //await ownersDropdown.$('[value="0"]').click();
        await frontTiresConditionDropdown.$('[value="'+condition+'"]').click();
    }

    this.setRearTiresCondition = async function(condition){
        await rearTiresConditionDropdown.$('[value="'+condition+'"]').click();

    }

    this.setHasVehicleAccidentInput = async function(value){
        if(value){
            await hasVehicleAccidentYesInput.click();
        }
        else{
            await hasVehicleAccidentNoInput.click();
        }
    }

    this.setHasExternalDamageInput = async function(value){
        if(value){
            await hasExternalDamageYesInput.click();
        }
        else{
            await hasExternalDamageNoInput.click();
        }
    }
    
    this.setHasMechanicalIssuesInput = async function(value){
        if(value){
            await hasMechanicalIssuesYesInput.click();
        }
        else{
            await hasMechanicalIssuesNoInput.click();
        }
    }

    this.setHasWarningLightsInput = async function(value){
        if(value){
            await hasWarningLightsYesInput.click();
        }
        else{
            await hasWarningLightsNoInput.click();
        }
    }

    this.setHasModificationsInput = async function(value){
        if(value){
            await hasModificationsYesInput.click();
        }
        else{
            await hasModificationsNoInput.click();
        }
    }

    this.setHasOdorInput = async function(value){
        if(value){
            await hasOdorYesInput.click();
        }
        else{
            await hasOdorNoInput.click();
        }
    }

    this.setHasOtherIssuesInput = async function(value){
        if(value){
            await hasOtherIssuesYesInput.click();
        }
        else{
            await hasOtherIssuesNoInput.click();
        }
    }

    this.setOriginalOwner = async function(value){
        if(value){
            await originalOwnerYesInput.click();
        }
        else{
            await originalOwnerNoInput.click();
        }
    }

    this.setStillMakingPayment = async function(value){
        if(value){
            await stillMakingPaymentYesInput.click();
        }
        else{
            await stillMakingPaymentNoInput.click();
        }
    }

    this.setInterestedReplacementVehicle = async function(value){
        if(value){
            await isInterestedReplacementVehicleYesInput.click();
        }
        else{
            await isInterestedReplacementVehicleNoInput.click();
        }
    }

    this.isPresentInterestedReplacementVehicleNoInput = async function(){
        return await isInterestedReplacementVehicleNoInput.isPresent();
    }

    this.setMileage = async function(miles){
        await mileageInput.sendKeys(miles);
    }

    this.setZipCode = async function(zip){
        await zipCodeInput.sendKeys(zip)
    }

    this.clickNextConditionBtn = async function(){
        await nextConditionBtn.click();
    }

    this.clickNextOfferBtn = async function(){
        await nextOfferBtn.click();
    }

    this.clickNextTrueCashOfferBtn = async function(){
        await nextTrueCashOfferBtn.click();
    }

    this.clickTrueCashOfferBtn = async function(){
        await getTrueCarOfferBtn.click();
    }

    this.clickInstantOfferBtn = async function(){
        await getInstantOfferBtn.click();
    }

    this.get = async function(perseusurl){
        await browser.get(perseusurl);
    }

    this.setTrim = async function(index){
        // //trim = "string:"+trim;
        // trim = "string:L 4 DOOR SEDAN 2.5L 4 CYL";
        // //await trimDropdown.click();
        // var locator = '[value="'+trim+'"]';
        await this.selectEnterVinTab();
        await browser.sleep(browser.params.sleep.sleep2);

        // await trimDropdown.$(locator).click();
        // //await ownersDropdown.$('[value="0"]').click();
        await utils.logInfo("Is Trim Disabled perseuspage.isDisabledTrimDropdown() ="+await this.isDisabledTrimDropdown());

        
        element.all(by.tagName('option')).then(function(options) {
            if(options.length == 1){
                options[1].click();
            }
            else{
                options[index].click();
            }
        });    

    }

    this.isDisabledTrimDropdown = async function(){
        if(await trimDropdown.getAttribute("disabled") == "disabled"){
            return true;
        }
        else{
            return false;
        }
    }

    this.clickContinueBtn = async function(){
        await continueBtn.click();
    }

    this.clickGetStartedBtn = async function(){
        await getStartedBtn.click();
        //var enter = browser.actions().sendKeys(protractor.Key.RETURN);
        //enter.perform();
        //await vinInput.sendKeys(protractor.Key.chord(protractor.Key.RETURN));
    }

    this.selectEnterVinTab = async function(){
        await enterVinTab.click();
    }

    this.selectBlackColor = async function(){
        await blackColorBtn.click();
    }

    this.setVIN = async function(vin){
        await vinInput.clear();
        await browser.sleep(browser.params.sleep.sleep2);
        await vinInput.sendKeys(vin);
    }

    this.createBasicProspectWithRandomVIN = async function(brand,perseusurl,fname,lname,zip){
        await browser.waitForAngularEnabled(true); // *** Angular Enabled False

        var trimDisableStatus = false;
        var alertElement = element(by.xpath("//div[@role='alert']"));
        var alertStatus = false;
        var round = 1 ;

        do{
            await utils.logInfo("do while() round ="+round);
            await browser.sleep(browser.params.sleep.sleep5);
            var vin = await utils.generateRandomRealVIN();
            await utils.logInfo("Generated Random VIN is "+vin);
    
            await utils.logInfo("Get Perseus Page");
            await browser.waitForAngularEnabled(true); // *** Angular Enabled False
            await this.get(perseusurl);

            await utils.logInfo("Disable Wait for Angular");
            await browser.waitForAngularEnabled(false); // *** Angular Enabled False
    
            await utils.logInfo("Select Enter VIN Tab");
            await this.selectEnterVinTab();

            await utils.logInfo("Enter VIN into vin textfield");
            await this.setVIN(vin);//browser.params.vin.validvin

            await utils.logInfo("Select Enter VIN Tab");
            await this.selectEnterVinTab();
            await browser.sleep(browser.params.sleep.sleep5);

            trimDisableStatus = await this.isDisabledTrimDropdown();

            if(!trimDisableStatus){
                await utils.logInfo("Enter TRIM into trim textfield");
                await this.setTrim(2);
            }

            await browser.sleep(browser.params.sleep.sleep2);

            alertStatus = await alertElement.isPresent();

            await utils.logInfo("trimDisableStatus = "+trimDisableStatus);
            await utils.logInfo("alertStatus = "+alertStatus);
            //expect(await alertElement.isPresent()).toBeFalsy("*** Error: This test needs to be rerun as Prospect can't be created with this Random VIN:"+vin);
            round = round+1;

        }while(trimDisableStatus || alertStatus);



        await browser.sleep(browser.params.sleep.sleep5);

        browser.executeScript("document.getElementById('vinVehicleStyle').style.backgroundColor='yellow'");
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Click 'Get Started' Button");
        await this.clickGetStartedBtn();
        await utils.logInfo("after Sleeping for 5 seconds");
        await browser.sleep(browser.params.sleep.sleep5);

        //Vehicle Details
        await this.selectBlackColor();
        browser.executeScript('arguments[0].scrollIntoView()', mileageInput.getWebElement());

        await browser.sleep(browser.params.sleep.sleep2);
        await this.setMileage("20000");
        //await browser.sleep(browser.params.sleep.sleep2);
        await this.setZipCode(zip);
        //await browser.sleep(browser.params.sleep.sleep2);
        await this.setOriginalOwner(true);
        //await browser.sleep(browser.params.sleep.sleep2);

        await this.setStillMakingPayment(false);
        //await browser.sleep(browser.params.sleep.sleep2);

        if(await this.isPresentInterestedReplacementVehicleNoInput()){
            await this.setInterestedReplacementVehicle(false);
        }

        await browser.sleep(browser.params.sleep.sleep2);
        await utils.logInfo("Click on Next Condition Button");
        await this.clickNextConditionBtn();
        await utils.logInfo("Before Sleeping for 5 seconds");
        await browser.sleep(browser.params.sleep.sleep5);
        await utils.logInfo("After Sleeping for 5 seconds");


        //Vehicle Condition
        await this.setHasVehicleAccidentInput(false);
        await this.setHasExternalDamageInput(false);
        await this.setFrontTiresCondition("good");
        await this.setRearTiresCondition("good");

        browser.executeScript('arguments[0].scrollIntoView()', hasMechanicalIssuesYesInput.getWebElement());
        await this.setHasMechanicalIssuesInput(false);
        await this.setHasWarningLightsInput(false);
        await this.setHasModificationsInput(false);
        await this.setHasOdorInput(false);
        await this.setHasOtherIssuesInput(false);
        await browser.sleep(browser.params.sleep.sleep2);

        if(brand.includes("truecar")){
            utils.logInfo("Click on Next TrueCash Offer button");
            await this.clickNextTrueCashOfferBtn();
        }
        else{
            utils.logInfo("Click on Next Offer button");
            await this.clickNextOfferBtn();
        }
        await utils.logInfo("after Sleeping for 5 seconds");
        await browser.sleep(browser.params.sleep.sleep5);

        //Your Offer
        await utils.logInfo("Enter First Name");
        await this.setFirstName(fname);
        await utils.logInfo("Enter Last Name");
        await this.setLastName(lname);
        await utils.logInfo("Enter Cell Phone");
        await this.setCellPhone("5123334444");
        await utils.logInfo("Enter Email");
        await this.setEmail("amit+AutomatedProspect@acc-trade.com");

        if(await this.isPresentWhenToSellDropdown()){
            await utils.logInfo("Select When to Sell");
            await this.setWhenToSellDropdown("1");
        }

        await browser.sleep(browser.params.sleep.sleep2);
        await utils.logInfo("Select Terms CheckBox");
        await browser.sleep(browser.params.sleep.sleep2);
        await this.selectTermsCheckBox();
        //await utils.logInfo("Click Instant Offer Button");
        await browser.sleep(browser.params.sleep.sleep2);

        if(brand.includes("truecar")){
            utils.logInfo("Click on TrueCash Offer button");
            await this.clickTrueCashOfferBtn();
        }
        else{
            utils.logInfo("Click on Next Offer button");
            await this.clickInstantOfferBtn();
        }

        await utils.logInfo("Sleeping for 10 seconds");
        await browser.sleep(browser.params.sleep.sleep10);

    }


}

module.exports = new perseuspage();
