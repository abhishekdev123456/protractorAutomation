var utils = require('../utilities/utils');
var myaccountpage = require('../pages/myaccount.page');
var verifymobilenumberpage = require('../pages/verifymobilenumber.page');
var appraisalpage = require('../pages/appraisal.page');


var homepage = function(){

    var odometerReadingText = element(by.xpath("//input[@ng-reflect-name='odometer']"));

    //var startappraisalBtn = element(by.buttonText('Start Appraisal '));
    var startappraisalBtn = element(by.css('.add-unit'));
    var consumerStartAppraisalBtn = element(by.xpath("//button[@ng-reflect-klass='consumer'][@routerlink='/appraisal/new']"));

    var vinTxt = element(by.xpath("//input[@ng-reflect-name='vinInput']"));
    var vinSearchBtn = element(by.buttonText('Search'));
    var firstTrim = element(by.xpath("//*[@class='vehicle-trims']/list-item[1]/div"));
    var secondTrim = element(by.xpath("//*[@class='vehicle-trims']/list-item[2]/div"));
    var firstTrimYMMT = element(by.xpath("//new-appraisal-trim/list-item[2]/div"));
    var threeDotsAppraisalMenu = element(by.xpath("//*[@class='menu-consumer-container']/i[text()='more_vert']"));
    var appraisalVIN = element(by.xpath("//div[@class='vin-mileage']"));
    //var appraisalVIN = element(by.xpath("//div[@class='vin-mileage']/div[@ng-reflect-klass='vin']"));
    //div[@class='vin-mileage']/div[@ng-reflect-klass='vin']
    var appraisalCloseBtn = element(by.xpath("//i[@class='material-icons close']"));
    var customerAppraisalMenuItem = element (by.xpath("//*[text()='Customer Appraisal Report']")); 
    var dealerAppraisalMenuItem = element(by.xpath("//*[text()='Dealer Condition Report']"));
    var appraisalsTable = element.all(by.xpath("//tbody[@role='rowgroup']"));
    var walkmeWelcome = element(by.xpath("//div[@id='wm-shoutout-158665']"));
    //var walkmeWelcome = element(by.xpath("//div[@id='walkme-visual-design-8eca8995cbae1528737a5b7148819cc1']"));
    //var walkmeCloseBtn = element(by.xpath("//*[text()='Close']"));
    //var walkmeDoneBtn = element(by.xpath("//*[text()='Done']"));
    var walkmeShoutOutCloseBtn = element(by.xpath("//*[@id='wm-shoutout-158665']/div/div/span[text()='Close']"));
    var walkmeWelcomeCloseBtn = element(by.xpath("//img[contains(@src,'close.svg')]"));
    var selectTrimNewAppraisalLabel = element(by.xpath("//*[text()='Select a trim to create a new appraisal']"));
    var selectTrimNewAppraisalCloseBtn = element(by.xpath("//new-appraisal-header/*[text()='close']"));
    

    this.isPresentSelectTrimNewAppraisalScreen = async function(){
        return await selectTrimNewAppraisalLabel.isPresent();
    }

    this.closeSelectTrimNewAppraisalScreen = async function(){
        await selectTrimNewAppraisalCloseBtn.click();
    }


    // **************************** Walk Me *******************************

    //WalkemeShoutOut
    this.closeWalkMeShoutOut = async function(){
        await walkmeShoutOutCloseBtn.click();
    }

    this.getWalkMeShoutOutCloseBtnWebElement = function(){
        return walkmeShoutOutCloseBtn;
    }

    this.isPresentWalkMeShoutOutCloseBtn = async function(){
        return await walkmeShoutOutCloseBtn.isPresent();
    }

    //WalkmeWelcome
    this.closeWalkmeWelcome = async function(){
        await walkmeWelcomeCloseBtn.click();
    }

    this.getWalkmeWelcomeCloseBtnWebElement = function(){
        return walkmeWelcomeCloseBtn;
    }

    this.isPresentWalkmeWelcomeCloseBtn = async function(){
        return await walkmeWelcomeCloseBtn.isPresent();
    }

    this.closeAllWalkme = async function(){
        //var EC = protractor.ExpectedConditions;
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Is Present Walk Me Welcome Screen Close Button");
        if (await this.isPresentWalkmeWelcomeCloseBtn()){
            await utils.logInfo("Click on Close button of Walk Me Welcome Screen");
            await this.closeWalkmeWelcome(); //Close Walkme Welcome
        }
        
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Is Present Walk Me ShoutOut Screen Close Button");
        if (await this.isPresentWalkMeShoutOutCloseBtn()){
            await utils.logInfo("Click on Close button of Walk Me Shoutout Screen");
            await this.closeWalkMeShoutOut(); //Close Walkme ShoutOut
        }    
        

    }
    

    // **************************** Admin Menu ****************************
    //var threeDotsMainMenu = element(by.xpath("//*[text()='more_vert']"));
    var threeDotsMainMenu = element(by.xpath("//*[text()='keyboard_arrow_down']"));

    //var myAccountMenuItem = element(by.xpath("//li[text()='My Account']"));
    var myAccountMenuItem = element(by.xpath("//li[@ng-reflect-router-link='/account,my-account']"));

    //var userManagementMenuItem = element(by.xpath("//li[text()='User Management']"));
    var userManagementMenuItem = element(by.xpath("//li[@ng-reflect-router-link='/account,user-management']"));

    //var dealerConsoleMenuItem = element(by.xpath("//li[text()='Dealer Console']"));
    var dealerConsoleMenuItem = element(by.xpath("//li[@ng-reflect-router-link='/account,dealer-console']"));

    var logOutMenuItem = element(by.xpath("//*[text()='Log out']"));

    //var recommenderMenuItem = element(by.xpath("//*[text()='Recommender']"));
    var recommenderMenuItem = element(by.xpath("//li[@ng-reflect-router-link='/account,recommender']"));

    //var trueCashOfferMenuItem = element(by.xpath("//*[text()='True Cash Offer Link']"));
    var customerExperienceMenuItem = element(by.xpath("//li[@ng-reflect-href='https://perseus-consumer-qa.rh']"));


    var allAppraisalsText = element(by.xpath("//*[text()='All Appraisals']"));

    this.isPresentMyAccountMenuItem = async function(){
        return await myAccountMenuItem.isPresent();
    }

    this.isPresentUserManagementMenuItem = async function(){
        return await userManagementMenuItem.isPresent();
    }

    this.isPresentDealerConsoleMenuItem = async function(){
        return await dealerConsoleMenuItem.isPresent();
    }

    this.isPresentRecommenderMenuItem = async function(){
        return await recommenderMenuItem.isPresent();
    }

    this.isPresentCustomerExperienceMenuItem = async function(){
        return await customerExperienceMenuItem.isPresent();
    }

    this.isPresentLogOutMenuItem =async function(){
        return await logOutMenuItem.isPresent();
    }

    // New Appraisals
    var newAppraisalVINTab = element(by.xpath("//new-appraisal-header/following-sibling::tabs/div/div[1]"));
    var newAppraisalYMMTTab = element(by.xpath("//new-appraisal-header/following-sibling::tabs/div/div[2]"));   

    //Appraisal List Filters
    var filterBtnAppraisalList = element(by.xpath("//*[@id='appraisalListGridControls']/div/div/div/grid-filters-toggle-button/grid-control-button/span/*[text()='filter_list ']"));
    var closeBtnFilterAppraisalList = element(by.xpath("//*[text()='Filters']/preceding-sibling::*[text()='close ']"));
    var showCRMCheckboxFilterAppraisalList = element(by.xpath("//*[@ng-reflect-label='Show CRM Only']/preceding-sibling::mat-checkbox"));
    var dateFilterAppraisalList = element(by.xpath("//mat-select[@ng-reflect-placeholder='Date']"));

    this.openFilterAppraisalList = async function(){
        await filterBtnAppraisalList.click();
    }
    this.closeFilterAppraisalList = async function(){
        await browser.sleep(browser.params.sleep.sleep5);
        await closeBtnFilterAppraisalList.click();
    }

    this.clickShowCRMCheckboxFilterAppraisalList = async function(){
        await showCRMCheckboxFilterAppraisalList.click();
    }

    this.selectShowCRMFilterAppraisalList = async function(){
        await this.openFilterAppraisalList();
        if(await showCRMCheckboxFilterAppraisalList.getAttribute("ng-reflect-checked")){
            //Do Nothing
        }
        else{
            await this.clickShowCRMCheckboxFilterAppraisalList();
        }
        await this.closeFilterAppraisalList();
    }

    this.unselectShowCRMFilterAppraisalList = async function(){
        await this.openFilterAppraisalList();
        if(await showCRMCheckboxFilterAppraisalList.getAttribute("ng-reflect-checked")){
            await this.clickShowCRMCheckboxFilterAppraisalList();
        }
        else{
            //Do Nothing    
        }        
        await this.closeFilterAppraisalList();
    }

    this.setDateFilterAppraialList = async function(dateoption){        
        await this.openFilterAppraisalList();
        await dateFilterAppraisalList.click();
        var optionLocator = "//mat-option/span[text()=' "+dateoption+" ']";
        var optionElement = element(by.xpath(optionLocator)); 
        await optionElement.click();
        await this.closeFilterAppraisalList();
    }

    //Appraisal List Settings
    var settingsAppraisalList = element(by.xpath("//*[@id='appraisalListGridControls']/div/div/div/grid-column-selectors-toggle-button/grid-control-button/span/mat-icon"));
    var historyCheckboxSettingsAppraisalList = element(by.xpath("//*[@ng-reflect-label='History']/div/mat-checkbox/label/div/input"));
    var pricingCheckboxSettingsAppraisalList = element(by.xpath("//*[@ng-reflect-label='Pricing']/div/mat-checkbox/label/div/input"));

    var updateBtnSettingsAppraisalList = element(by.xpath("//*[text()=' Update ']"));

    this.clickUpdateBtnSettingsAppraisalList = async function(){
        await updateBtnSettingsAppraisalList.click();
    }

    this.clickSettingsAppraisalList = async function(){
        await settingsAppraisalList.click();
    }

    this.getHistoryCheckboxSettingsAppraisalList = async function(){
        return await historyCheckboxSettingsAppraisalList.getAttribute("aria-checked");
    }

    this.setHistoryCheckboxSettingsAppraisalList = async function(setvalue){
        utils.logInfo("Value of checkbox BEFORE is "+await this.getHistoryCheckboxSettingsAppraisalList());

        if(setvalue == "ON"){
            if (await this.getHistoryCheckboxSettingsAppraisalList() == "false"){
                utils.logInfo("Inside");
                await element(by.xpath("//*[@ng-reflect-label='History']/div/mat-checkbox/label/div")).click();
                //await historyCheckboxSettingsAppraisalList.click();
            }
        }
        else{ // if setvalue = "OFF"
            if (await this.getHistoryCheckboxSettingsAppraisalList() == "true"){
                //await historyCheckboxSettingsAppraisalList.click();
                await element(by.xpath("//*[@ng-reflect-label='History']/div/mat-checkbox/label/div")).click();
            }
        }
        utils.logInfo("Value of checkbox AFTER is "+await this.getHistoryCheckboxSettingsAppraisalList());
    }

    this.getPricingCheckboxSettingsAppraisalList = async function(){
        return await pricingCheckboxSettingsAppraisalList.getAttribute("aria-checked");
    }

    this.setPricingCheckboxSettingsAppraisalList = async function(setvalue){
        utils.logInfo("Value of checkbox BEFORE is "+await this.getPricingCheckboxSettingsAppraisalList());

        if(setvalue == "ON"){
            if (await this.getPricingCheckboxSettingsAppraisalList() == "false"){
                utils.logInfo("Inside");
                await element(by.xpath("//*[@ng-reflect-label='Pricing']/div/mat-checkbox/label/div")).click();
                //await getPricingCheckboxSettingsAppraisalList.click();
            }
        }
        else{ // if setvalue = "OFF"
            if (await this.getPricingCheckboxSettingsAppraisalList() == "true"){
                //await getPricingCheckboxSettingsAppraisalList.click();
                await element(by.xpath("//*[@ng-reflect-label='Pricing']/div/mat-checkbox/label/div")).click();
            }
        }
        utils.logInfo("Value of checkbox AFTER is "+await this.getPricingCheckboxSettingsAppraisalList());
    }



    //Appraisal List
    var firstAppraisal = element(by.xpath("//tbody/tr[1]/td[2]"));   
    var prospectsAppraisals = element(by.xpath("//stat-block[@ng-reflect-label='prospects']"));
    var activeAppraisals = element(by.xpath("//stat-block[@ng-reflect-label='appraisals']"));
    var groundedAppraisals = element(by.xpath("//stat-block[@ng-reflect-label='grounded']"));
    var offersAppraisals = element(by.xpath("//stat-block[@ng-reflect-label='offers']"));
    var archivedAppraisals = element(by.xpath("//stat-block[@ng-reflect-label='archived']"));
    var dispositionAppraisalList = element(by.xpath("//appraisal-disposition/div/property-box"));
    var carFaxGrayIconAppraisalList = element(by.xpath("//img[@src='assets/images/vhr/carfax-none.svg']"));
    var autoCheckGrayIconAppraisalList = element(by.xpath("//img[@src='assets/images/vhr/autocheck-none.svg']"));
    var badVHRRedIconAppraisalList = element(by.xpath("//img[@src='assets/images/vhr/bad-vhr.svg']"));
    var searchResultMsg = element(by.xpath("//grid-search-results-display"));
    var vinAppraisalList = element(by.xpath("//table/tbody/tr/td[3]/generic-cell/div/span"));
    var yearAppraisalList = element(by.xpath("//table/tbody/tr[1]/td[4]/generic-cell/div/span"));


    // Archive/Unarchive Appraisal
    var archiveAppraisalListBtn = element(by.xpath("//*[text()='Archive ']"));
    var unarchiveAppraisalListBtn = element(by.xpath("//*[text()='Unarchive ']"));

    var firstCheckBoxAppraisalList = element(by.xpath("//table/tbody/tr[1]/td[1]"));

    this.isPresentYearAppraisalList = async function(){
        return await yearAppraisalList.isPresent();
    }

    this.generateCheckboxWebElementAppraisalList = function(rownum){
        var locator = "//table/tbody/tr["+rownum+"]/td[1]";
        return element(by.xpath(locator));
    }

    this.clickCheckBoxAppraisalList = async function(rownum){
        await this.generateCheckboxWebElementAppraisalList(rownum).click();
    }

    this.clickFirstCheckBoxAppraisalList = async function(){
        await firstCheckBoxAppraisalList.click();
    }

    this.openAppraisalFromAppraisalList = async function(rownum){
        rownum = Number(rownum)+1;
        rownum= rownum.toString();
        var locator = "//table/tbody/tr["+rownum+"]";
        await utils.logInfo("Value of Appraisal Locator is "+locator);
        var elem = element(by.xpath(locator));
        await elem.click();

    }

    this.clickArchiveAppraisalListBtn = async function(){
        await archiveAppraisalListBtn.click();
    }

    this.clickUnarchiveAppraisalListBtn = async function(){
        await unarchiveAppraisalListBtn.click();
    }

    this.archiveAppraisalByID = async function(appraisalID){
        await utils.logInfo("Get Home Page");
        await this.get();

        await utils.logInfo("Search Appraisal on Appraisal List");
        await browser.sleep(browser.params.sleep.sleep5);
        await this.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep5);

        //Verify Search Results in Appraisal List
        await utils.logInfo("Verify Search Results in Appraisal List");
        expect(await this.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
        expect(await this.getSearchResultSearchTerm()).toBe(appraisalID,"Verify Search results showing searched term at the bottom of Appraisal List");

        await utils.logInfo("Click checkbox of Searched Appraisal List");
        await this.clickFirstCheckBoxAppraisalList();
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Click on Archive button");
        await this.clickArchiveAppraisalListBtn();
        await browser.sleep(browser.params.sleep.sleep5);        
    }

    this.openArchivedAppraisalByID = async function(appraisalID){

        await this.clickCancelSearchAppraisalListBtn();

        await utils.logInfo("Get Home Page");
        await this.get();

        await utils.logInfo("Click on Archived Appraisal List");
        await this.clickArchivedAppraisalList();
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Search Appraisal on Appraisal List");
        await this.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Search Results in Appraisal List
        expect(await this.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
        expect(await this.getSearchResultSearchTerm()).toBe(appraisalID,"Verify Search results showing searched term at the bottom of Appraisal List");

        await utils.logInfo("Opent the first Archived Appraisal List");
        await this.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep5);

        expect(await appraisalpage.getAppraisalID()).toBe(appraisalID,"Verify searched Archived Appraisal open successfully");

    }

    this.getSearchResultCount = async function(){
        return await searchResultMsg.getAttribute("ng-reflect-total");
    }

    this.getSearchResultSearchTerm = async function(){
        return await searchResultMsg.getAttribute("ng-reflect-search-term");
    }


    this.isPresentCarFaxGrayIconAppraisalList = async function(){
        return await carFaxGrayIconAppraisalList.isPresent();
    }

    this.isPresentAutoCheckGrayIconAppraisalList = async function(){
        return await autoCheckGrayIconAppraisalList.isPresent();
    }

    // this.isPresentVINSearchedAppraisalList = async function(){
    //     return await vinAppraisalList.isPresent();
    // }

    this.getVINSearchedAppraisalList = async function(){
        return await vinAppraisalList.getText();
    }

    this.isPresentBadVHRRedIconAppraisalList = async function(){
        return await badVHRRedIconAppraisalList.isPresent();
    }

    this.getDispositionValueAppraisalList = async function(){
        return await dispositionAppraisalList.getAttribute("ng-reflect-label");
    }
    
    this.getDispositionColorAppraisalList = async function(){
        return await dispositionAppraisalList.getAttribute("ng-reflect-color-class");
    }
    

    this.getAppraisalButton = function(){
        return startappraisalBtn;
    }


    this.clickProspectsAppraisalList = async function(){
        try{
            await prospectsAppraisals.click();
            await browser.refresh();
        }
        catch(err){
            await utils.logInfo("error is"+err);
        }  
    }

    this.clickActiveAppraisalList = async function(){
        try{
            await activeAppraisals.click();
            await browser.refresh();
        }
        catch(err){
            await utils.logInfo("error is"+err);
        }    
    }

    this.clickGroundedAppraisalList = async function(){
        try{
            await groundedAppraisals.click();
            await browser.refresh();
        }
        catch(err){
            await utils.logInfo("error is"+err);
        }
        
    }


    this.clickOffersAppraisalList = async function(){
        try{
            await offersAppraisals.click();
            await browser.refresh();
        }
        catch(err){
            await utils.logInfo("error is"+err);
        }
        
    }

    this.clickArchivedAppraisalList = async function(){
        try{
            await archivedAppraisals.click();
            await browser.refresh();
        }
        catch(err){
            await utils.logInfo("error is"+err);
        }
    }

    //Is Active Appraisal Tab Selcted
    this.isActiveAppraisalListTabSelected = async function(){
        return await activeAppraisals.getAttribute("ng-reflect-is-active");
    }

    //Is Prospects Appraisal Tab Selcted
    this.isProspectsAppraisalListTabSelected = async function(){
        return await prospectsAppraisals.getAttribute("ng-reflect-is-active");
    }

    //Is Grounded Appraisal Tab Selcted
    this.isGroundedAppraisalListTabSelected = async function(){
        return await groundedAppraisals.getAttribute("ng-reflect-is-active");
    }

    //Is Offer Appraisal Tab Selcted
    this.isOffersAppraisalListTabSelected = async function(){
        return await offersAppraisals.getAttribute("ng-reflect-is-active");
    }

    //Is Archived Appraisal Tab Selcted
    this.isArchivedAppraisalListTabSelected = async function(){
        return await archivedAppraisals.getAttribute("ng-reflect-is-active");
    }

    // Get Prospects Appraisals Tab Count
    this.getProspectsAppraisalsTabCount = async function(){
        return await prospectsAppraisals.getAttribute("ng-reflect-total");
    }

    // Get Active Appraisals Tab Count
    this.getActiveAppraisalsTabCount = async function(){
        return await activeAppraisals.getAttribute("ng-reflect-total");
    }
    
    // Get Grounded Appraisals Tab Count
    this.getGroundedAppraisalsTabCount = async function(){
        return await groundedAppraisals.getAttribute("ng-reflect-total");
    }
    
    // Get Offers Appraisals Tab Count
    this.getOffersAppraisalsTabCount = async function(){
        return await offersAppraisals.getAttribute("ng-reflect-total");
    }
    
    // Get Archived Appraisals Tab Count
    this.getArchivedAppraisalsTabCount = async function(){
        return await archivedAppraisals.getAttribute("ng-reflect-total");
    }

    //Tabs
    var tabScorecard = element(by.xpath("//div[text()='Scorecard']"));
    var tabGuidebooks = element(by.xpath("//div[text()='Guidebooks']"));
    var tabScorecard = element(by.xpath("//div[text()='Local Market']"));

    //Scorecard Labels
    var labelOdometer = element(by.xpath("//section/label[text()='Odometer']"));
    var labelOptions = element(by.xpath("//section/label[text()='Options']"));
    var labelVHR = element(by.xpath("//section/label[text()='VHR']"));
    var labelDamage = element(by.xpath("//section/label[text()='Damage']"));
    var labelDepreciation = element(by.xpath("//section/label[text()='Depreciation']"));
    var labelLocalDOM = element(by.xpath("//section/label[text()='Local DOM']"));
    var labelMDS = element(by.xpath("//section/label[text()='Market Day Supply']"));
    var labelConsumerInterest = element(by.xpath("//section/label[text()='Consumer Interest']"));
    var labelCommonProblems = element(by.xpath("//section/label[text()='Common Problems']"));
    
    //Scorecard Values
    // var labelOdometer = element(by.xpath("//section/label[text()='Odometer']"));
    // var labelOptions = element(by.xpath("//section/label[text()='Options']"));
    // var labelVHR = element(by.xpath("//section/label[text()='VHR']"));
    // var labelDamage = element(by.xpath("//section/label[text()='Damage']"));
    // var labelDepreciation = element(by.xpath("//section/label[text()='Depreciation']"));
    // var labelLocalDOM = element(by.xpath("//section/label[text()='Local DOM']"));
    // var labelMDS = element(by.xpath("//section/label[text()='Market Day Supply']"));
    // var labelConsumerInterest = element(by.xpath("//section/label[text()='Consumer Interest']"));
    // var labelCommonProblems = element(by.xpath("//section/label[text()='Common Problems']"));


//************************ Appraisal Header ************************
var labelAppraisalHeaderYMM = element(by.xpath("//appraisal-vehicle-data/*[@class='year-make-model']"));
var labelAppraisalHeaderStyle = element(by.xpath("//appraisal-vehicle-data/*[@class='style']"));
var labelAppraisalHeaderVinMileage = element(by.xpath("//appraisal-vehicle-data/*[@class='wrapper']"));


//************************ Guidebooks Pricebar ************************

//Instant Offer
var instantOfferPrice = element(by.xpath("//appraisal-price/div[@class='price-container']"));

//Target Auction
var targetAuctionPrice = element(by.xpath("//appraisal-price[2]/div[@class='price-container']"));

//Blackbook Price
var bbPrice = element(by.xpath("//blackbook-price/appraisal-price/div[@class='price-container']"));

//KBB Price
var kbbPrice = element(by.xpath("//kbb-price/appraisal-price/div[@class='price-container']"));

//Nada Price
var nadaPrice = element(by.xpath("//nada-price/appraisal-price/div[@class='price-container']"));

//Manheim Price
var mmrPrice = element(by.xpath("//mmr-price/appraisal-price/div[@class='price-container']"));

//************************ Valuations Guidebooks ************************

//Black Book Button
var bbButton = element(by.xpath("//guidebook-tile[@ng-reflect-src='assets/images/logos/blackbook-']/button"));

//KBB Button
var kbbButton = element(by.xpath("//guidebook-tile[@ng-reflect-src='assets/images/logos/kbb-logo-f']/button"));

//Manheim Button
var mmrButton = element(by.xpath("//guidebook-tile[@ng-reflect-src='assets/images/logos/manheim-lo']/button"));

//Nada Button
var nadaButton = element(by.xpath("//guidebook-tile[@ng-reflect-src='assets/images/logos/nada-logo-']/button"));

    
    

//************************ Local Market ************************

// most recent listing
//local-market-most-recent-listing
//local-market-most-recent-listing/div[@class='local-market-most-recent-listing']/div[@class='content']/div[@class='heading-row']
//local-market-most-recent-listing/div[@class='local-market-most-recent-listing']/div[@class='content']/div[@class='heading-row']/div[@class='details']/div[@class='first-row']
//local-market-most-recent-listing/div[@class='local-market-most-recent-listing']/div[@class='content']/div[@class='heading-row']/div[@class='details']/div[@class='second-row']
//local-market-most-recent-listing/div[@class='local-market-most-recent-listing']/div[@class='content']/div[@class='heading-row']/div[@class='details']/div[@class='third-row']

//View Details Link
var marketRecentListViewDetails = element(by.xpath("//a[text()='View Details']"));

//Local Market Stats
//local-market-stats/*[@class = 'local-market-stats']

//Median Price
//local-market-stats/*[@class = 'local-market-stats']/div[1]/div[@class='wrapper']/div[@class='value']
var marketMedianPrice = element(by.xpath(""));

//Median Odometer
//local-market-stats/*[@class = 'local-market-stats']/div[2]/div[@class='wrapper']/div[@class='value']
var marketMedianOdometer = element(by.xpath(""));


//Median DOM
//local-market-stats/*[@class = 'local-market-stats']/div[3]/div[@class='wrapper']/div[@class='value']
var marketMedianDOM = element(by.xpath(""));


//Market Day Supply
//local-market-stats/*[@class = 'local-market-stats']/div[4]/div[@class='wrapper']/div[@class='value']
var marketMedianMDS = element(by.xpath(""));




//************************ Side Bar ************************

var prospectsSideBar = element(by.xpath("//sidebar-list-item/*[text()='Prospects']"));

//SideBar Active
var activeSideBar = element(by.xpath("//sidebar-list-item/*[text()='Active']"));

//SideBar Grounded
var groundedSideBar = element(by.xpath("//sidebar-list-item/*[text()='Grounded']"));

//SideBar Offers
var offersSideBar = element(by.xpath("//sidebar-list-item/*[text()='Prospects']"));

//SideBar Archived
var archivedSideBar = element(by.xpath("//sidebar-list-item/*[text()='Prospects']"));

//************************ Appraisal Search & Other Options ************************

//Appraisal List Search
var searchAppraisalListInput = element(by.xpath("//input[@placeholder='Search']"));
var cancelSearchAppraisalListBtn = element(by.xpath("//input[@placeholder='Search']/following-sibling::*[@ng-reflect-icon-name='cancel']"));
var searchAppraisalListBtn = element(by.xpath("//button/*[text()='Search ']"));

//Appraisal List Filter
var filterAppraisalList = element(by.xpath("//mat-icon[text()='filter_list ']"));

//Appraisal List Refresh
var refreshAppraisalList = element(by.xpath("//mat-icon[text()='refresh ']"));

//Appraisal List Settings
//var settingsAppraisalList = element(by.xpath("//mat-icon[text()='settings ']"));

//************************ Pagination ************************

// Paginator Range String such as '1 - 50 of 1642'
var paginatorRange = element(by.xpath("//*[@class='mat-paginator-range-label']"));

//Appraisal List Next Page
var nextAppraisalList = element(by.xpath("//button[@ng-reflect-message='Next page']"));

//Appraisal List Previou Page
var nextAppraisalList = element(by.xpath("//button[@ng-reflect-message='Previous page']"));

//Appraisal List Last page
var nextAppraisalList = element(by.xpath("//button[@ng-reflect-message='Last page']"));

//Appraisal List First page
var nextAppraisalList = element(by.xpath("//button[@ng-reflect-message='First page']"));


//************************ Coloumn Sorting ************************

//Sort Year
var sortYear = element(by.xpath("//span[text()='Year']"));

//Sort Make
var sortMake = element(by.xpath("//span[text()='Make']"));

//Sort Model
var sortModel = element(by.xpath("//span[text()='Model']"));

//Sort Style
var sortStyle = element(by.xpath("//span[text()='Style']"));

//Odometer
var sortOdometer = element(by.xpath("//span[text()='Odometer']"));

//Value
var sortValue = element(by.xpath("//span[text()='Value']"));

//Dealership
var sortDealership = element(by.xpath("//span[text()='Dealership']"));

//Customer Name
var sortCustomerName = element(by.xpath("//span[text()='Customer Name']"));

//Customer Phone
var sortCustomerPhone = element(by.xpath("//span[text()='Customer Phone']"));

//Customer Email
var sortCustomerEmail = element(by.xpath("//span[text()='Customer Email']"));

//Sales Rep
var sortSalesRep = element(by.xpath("//span[text()='Sales Rep']"));

//Sales Rep Email
var sortSalesRepEmail = element(by.xpath("//span[text()='Sales Rep Email']"));

//Sales Rep Phone
var sortSalesRepPhone = element(by.xpath("//span[text()='Sales Rep Phone']"));


    // Methods to perform actions


    this.getUrl = async function(){
        return browser.params.env.url+"/report/active";
    }
    
    this.get = async function(){
        await browser.get(browser.params.env.url+"/report/active");
    }

    this.getVinInputElement = function(){
        return vinTxt;
    }

    this.getAllAppraisalsLabel =  async function(){
        return await allAppraisalsText.getText();
    }

    this.clickAllAppraisals = async function(){
        await allAppraisalsText.click();
        await browser.refresh();
    }

    this.clickFirstAppraisal = async function(){
        await firstAppraisal.click();
    }
    
    this.getAppraisalVIN = async function(){
        return await appraisalVIN.getText();
    }

    this.isPresentStartAppraisalBtn = async function(){
        return await startappraisalBtn.isPresent();
    }

    this.clickStartAppraisalBtn = async function () {
        await startappraisalBtn.click();
        await browser.refresh();
    };

    this.clickConsumerStartAppraisalBtn = async function(){
        await consumerStartAppraisalBtn.click();
        //await browser.refresh();
    }

    this.getConsumerStartAppraisalBtnText = async function(){
        return await consumerStartAppraisalBtn.getText();
    }

    this.isPresentConsumerStartAppraisalBtn = async function(){
        return await consumerStartAppraisalBtn.isPresent();
    }

    this.setVin = async function(vin){
        //await vinTxt.clear();
        await vinTxt.sendKeys(vin);
    }

    this.getVINInputMaxLength = async function(){
        return await vinTxt.getAttribute("maxlength");
    }

    this.setSearchAppraisalListInput = async function(searchkeyword){
        await searchAppraisalListInput.sendKeys(searchkeyword); 
    }


    this.searchAppraisalList = async function(searchkeyword){
        await utils.logInfo("Clear the Search Input Field");
        await searchAppraisalListInput.clear();

        await utils.logInfo("Enter term - '"+searchkeyword+"' into Search Input Field");
        await searchAppraisalListInput.sendKeys(searchkeyword);
        await browser.sleep(browser.params.sleep.sleep5);
        await utils.logInfo("Click on the Search Button");
        await searchAppraisalListBtn.click();   

    }


    this.clickCancelSearchAppraisalListBtn = async function(){
        await cancelSearchAppraisalListBtn.click();
    }

    this.isPresentCancelSearchAppraisalListBtn = async function(){
        return await cancelSearchAppraisalListBtn.isPresent();
    }

    this.openAdminMenu = async function(){
        await threeDotsMainMenu.click();
    }

    this.clickVinSearch = async function() {
        await vinSearchBtn.click();
    }

    this.clickFirstTrim = async function(){
        await utils.logInfo("Click on the vehicle trim : "+await firstTrim.getText());
        await firstTrim.click();
    }

    this.clickFirstTrimYMMT = async function(){
        await utils.logInfo("Click on the vehicle trim : "+await firstTrimYMMT.getText());
        await firstTrimYMMT.click();
    }

    this.clickSecondTrim = async function(){
        await utils.logInfo("Click on the vehicle trim : "+await secondTrim.getText());
        await secondTrim.click();
    }

    this.clickLogout = async function(){
        await threeDotsMainMenu.click();
        await logOutMenuItem.click();    
    }

    this.getMyProfile = async function(){
        await threeDotsMainMenu.click();
    }

    this.getMyAccount = async function(){
        await threeDotsMainMenu.click();
        await myAccountMenuItem.click();        
    }

    this.loadConsumerCR = async function(){
        await threeDotsAppraisalMenu.click();
        await customerAppraisalMenuItem.click();
    }
    
    this.loadDealerCR = async function(){
        await threeDotsAppraisalMenu.click();
        await dealerAppraisalMenuItem.click();

    }

    this.getUserManagementPage = async function(){
        await threeDotsMainMenu.click();
        await userManagementMenuItem.click();        
    }

    this.closeAppraisal = async function(){
        await appraisalCloseBtn.click();
    }

    this.setOdometerReading = async function(miles){
        await odometerReadingText.sendKeys(miles);
    }

    this.getOdometerReading = async function(){
        await utils.logInfo("homepage:getOdometerReading- Getting Odometer Reading");
        return await odometerReadingText.getAttribute("ng-reflect-name");        
    }

    this.clickNewAppraisalYMMT = async function(){
        await newAppraisalYMMTTab.click();
    }

    this.clickNewAppraisalVINTab = async function(){
        await newAppraisalVINTab.click();
    }

    // this.selectYearYMMT = async function(){
    //     await newAppraisal2017YearYMMT.click();
    // }

    // this.selectMakeYMMT = async function(){
    //     await newAppraisalAcuraMakeYMMT.click();
    // }

    // this.selectModelYMMT = async function(){
    //     await newAppraisalMDXModelYMMT.click();
    // }

    // this.selectTrimYMMT = async function(){
    //     await newAppraisalAWDTrimYMMT.click();
    // }



    this.selectYearNewAppraisalYMMT = async function(sYear){
        //new-appraisal-year/list-item/div[text()='2018']
        var yearLocator = "//new-appraisal-year/list-item/div[text()='"+sYear+"']";
        var yearWebElement = element(by.xpath(yearLocator));
        await utils.logInfo("Value of Year Locator is "+yearLocator);
        browser.executeScript('arguments[0].scrollIntoView()', yearWebElement.getWebElement());
        await yearWebElement.click();
    }

    this.selectMakeNewAppraisalYMMT = async function(sMake){
        //new-appraisal-make/list-item/div[text()='ASTON MARTIN']
        var makeLocator = "//new-appraisal-make/list-item/div[text()='"+sMake+"']";
        var makeWebElement = element(by.xpath(makeLocator));
        await utils.logInfo("Value of Make Locator is "+makeLocator);
        browser.executeScript('arguments[0].scrollIntoView()', makeWebElement.getWebElement());
        await makeWebElement.click();
    }

    this.selectModelNewAppraisalYMMT = async function(sModel){
        //new-appraisal-model/list-item/div[text()='RAPIDE']
        var modelLocator = "//new-appraisal-model/list-item/div[text()='"+sModel+"']";
        var modelWebElement = element(by.xpath(modelLocator));
        await utils.logInfo("Value of Model Locator is "+modelLocator);
        browser.executeScript('arguments[0].scrollIntoView()', modelWebElement.getWebElement());
        await modelWebElement.click();
    }

    this.selectTrimNewAppraisalYMMT = async function(sTrim){
        //new-appraisal-trim/list-item/div[text()='S 4D SEDAN 6.0L 12 CYL']
        var trimLocator = "//new-appraisal-trim/list-item/div[text()='"+sTrim+"']";
        var trimWebElement = element(by.xpath(trimLocator));
        await utils.logInfo("Value of Trim Locator is "+trimLocator);
        browser.executeScript('arguments[0].scrollIntoView()', trimWebElement.getWebElement());
        await trimWebElement.click();
    }

    this.createNewAppraisalYMMT = async function(sYear,sMake,sModel,sTrim){
        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await this.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
                await browser.sleep(browser.params.sleep.sleep5);
                await browser.refresh();
            }
        });

        await utils.logInfo("Click new Appraisal YMMT Tab");
        await this.clickNewAppraisalYMMT();
        await browser.waitForAngularEnabled(false); // *** Angular Enabled True

        await this.selectYearNewAppraisalYMMT(sYear);
        await this.selectMakeNewAppraisalYMMT(sMake);
        await this.selectModelNewAppraisalYMMT(sModel);

        if(sTrim == "first"){
            await utils.logInfo("Click on First Trim");
            await this.clickFirstTrimYMMT();
        }
        else{
            await this.selectTrimNewAppraisalYMMT(sTrim);
        }    


        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sYMM = await appraisalpage.getAppraisalYMM();
        var appraisalTrim = await appraisalpage.getAppraisalTrim();


        await utils.logInfo("Value of Appraisal Year Make Model is " + sYMM);
        await utils.logInfo("Value of Appraisal Trim is " + appraisalTrim);

        await utils.logInfo("Verify Appraisal Year Make Model matching expected YMM");
        expect(sYMM).toContain(sYear+" "+sMake+" "+sModel,"Verify Appraisal Year Make Model matching expected YMM on Appraisal Page"); //*** Assertion ***/
        
        if(sTrim != "first"){
            await utils.logInfo("Verify Appraisal Trim matching expected trim");
            expect(appraisalTrim).toContain(sTrim,"Verify Appraisal Trim matching expected trim on Appraisal Page"); //*** Assertion ***/
        }


        // await utils.logInfo("Enable Wait for Angular");
        // await browser.waitForAngularEnabled(true); // *** Angular Enabled True


    }

    this.createNewAppraisalVIN = async function(vin,trim){
        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await this.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
                await browser.sleep(browser.params.sleep.sleep5);
                await browser.refresh();
            }
        });

        await this.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + vin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(this.getVinInputElement(), 5000));
        await this.setVin(vin); //set VIN
        await utils.logInfo("Click on the VIN Search button");
        await this.clickVinSearch();

        if(trim == "first"){
            await utils.logInfo("Click on First Trim");
            await this.clickFirstTrim();
        }
        else{
            var trimLocator = "//*[text()='"+sTrim+"']";
            var trimElem = element(by.xpath(trimLocator));
            await trimElem.click();
        }

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var vinAppraisalPage = await this.getAppraisalVIN();
        await utils.logInfo("Value of Appraisal VIN is " + vinAppraisalPage);

        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        expect(await vinAppraisalPage).toContain(vin.toUpperCase(),"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   



        // await utils.logInfo("Enable Wait for Angular");
        // await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    } // function finished

    this.createCustomerNewAppraisalVIN = async function(vin,trim){
        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await browser.refresh();
        await utils.logInfo("Click on Customer Start Appraisal Button");
        await this.clickConsumerStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
                await browser.sleep(browser.params.sleep.sleep5);
                await browser.refresh();
            }
        });

        await utils.logInfo("Click on the VIN tab of New Appraisal screen");
        await this.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + vin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(this.getVinInputElement(), 5000));
        await this.setVin(vin); //set VIN
        await utils.logInfo("Click on the VIN Search button");
        await this.clickVinSearch();

        if(trim == "first"){
            await utils.logInfo("Click on First Trim");
            await this.clickFirstTrim();
        }
        else{
            var trimLocator = "//*[text()='"+sTrim+"']";
            var trimElem = element(by.xpath(trimLocator));
            await trimElem.click();
        }

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var vinAppraisalPage = await this.getAppraisalVIN();

        await utils.logInfo("Value of Appraisal VIN is " + vinAppraisalPage);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        expect(await vinAppraisalPage).toContain(vin.toUpperCase(),"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   

    }

    this.createNewAppraisalVINWithOutAssertion = async function(vin,trim){
        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await this.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
                await browser.sleep(browser.params.sleep.sleep5);
                await browser.refresh();
            }
        });

        await this.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + vin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(this.getVinInputElement(), 5000));
        await this.setVin(vin); //set VIN
        await utils.logInfo("Click on the VIN Search button");
        await this.clickVinSearch();

        if(trim == "first"){
            await utils.logInfo("Click on First Trim");
            await this.clickFirstTrim();
        }
        else{
            var trimLocator = "//*[text()='"+sTrim+"']";
            var trimElem = element(by.xpath(trimLocator));
            await trimElem.click();
        }

        // await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        // await browser.sleep(browser.params.sleep.sleep10);

        // await utils.logInfo("Disable Wait for Angular");
        // await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        // await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        // var vinAppraisalPage = await this.getAppraisalVIN();
        // await utils.logInfo("Value of Appraisal VIN is " + vinAppraisalPage);

        // await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        // expect(await vinAppraisalPage).toContain(vin.toUpperCase(),"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   

        // // await utils.logInfo("Enable Wait for Angular");
        // // await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    } // function finished


    this.openReadOnlyFirstArchivedAppraisal = async function(){
        await browser.waitForAngularEnabled(true); // *** Angular Enabled
        await this.get();
        await this.clickArchivedAppraisalList();
        await this.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep10);
    }

    this.getAppraisalsRowCount = async function(){
        return await appraisalsTable.all(by.tagName("tr")).count();
    }

    

    this.getPaginatorRange = async function(){
        return await paginatorRange.getText();
    }

    this.getThreeDotsMainMenuElement = function(){
        return threeDotsMainMenu;
    }



    this.navigateThroughURL = async function(menuitem){
        switch(menuitem) {
            case "My Account":
                await browser.get(browser.params.env.url+"/account/my-account");  
                break;
            case "User Management":
                await browser.get(browser.params.env.url+"/account/user-management");
                break;
            case "Dealer Console":
                await browser.get(browser.params.env.url+"/account/dealer-console"); 
                break;    
            case "My Profile":
                await browser.get(browser.params.env.url+"/account/my-profile");
                break;
            default:
                await utils.logInfo("The navigateTo function parameter: '"+menuitem+"' is invalid");
          }        
    }

    this.navigateThroughMenu = async function(menuitem){
        
        //await utils.logInfo("inside navigateThroughMenu("+menuitem+") function");
        await browser.get(browser.params.env.url+"/report/active");

        try{
        switch(menuitem){
            case "My Account":
                await utils.logInfo("Click Admin Menu>My Account");
                await threeDotsMainMenu.click();
                await myAccountMenuItem.click();   
                break;
            case "User Management":
                await utils.logInfo("Click Admin Menu>User Management");
                await threeDotsMainMenu.click();
                await userManagementMenuItem.click(); 
                break;
            case "Log Out":
                await utils.logInfo("Click Admin Menu>Logout");
                await threeDotsMainMenu.click(); 
                await logOutMenuItem.click();
                break;
            case "Log out":
                await utils.logInfo("Click Admin Menu>Logout");
                await threeDotsMainMenu.click();
                await logOutMenuItem.click();
                break;
            case "Dealer Console":
                await utils.logInfo("Click Admin Menu>Dealer Console");
                await threeDotsMainMenu.click(); 
                await dealerConsoleMenuItem.click();
                break;            
            case "My Profile":
                await utils.logInfo("Click Admin Menu>My Account>Edit Profile");
                await threeDotsMainMenu.click();
                await myAccountMenuItem.click(); 
                await myaccountpage.clickEditProfileLink();
                break;
            case "Recommender":
                await utils.logInfo("Click Admin Menu>Recommender");
                await threeDotsMainMenu.click();
                await recommenderMenuItem.click(); 
                break; 
            case "Customer Experience":
                await utils.logInfo("Click Admin Menu>Launch Customer Experience");
                await threeDotsMainMenu.click();
                await customerExperienceMenuItem.click();
                break;
            default:
                await utils.logInfo("The navigateTo function parameter: '"+menuitem+"' is invalid");
          }//switch
        }//try
        catch(err){
            utils.logInfo("Catched Error - homepage.navigateThroughMenu(): "+err);
        }//catch

        await browser.waitForAngularEnabled(false); 
        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        })
        await browser.waitForAngularEnabled(true); 


    }//navigateThroughMenu() function

    

}

module.exports = new homepage();
