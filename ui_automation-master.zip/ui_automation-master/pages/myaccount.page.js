var utils = require('../utilities/utils');
var verifymobilenumberpage = require('../pages/verifymobilenumber.page');

var myaccountpage = function(){
    var priceBarConfigLink = element(by.xpath("//list-item[@ng-reflect-router-link='/account,my-pricebar']"));
    var carFaxAccountLink = element(by.xpath("//list-item[@ng-reflect-router-link='/account,my-carfax']"));
    var autoCheckAccountLink = element(by.xpath("//list-item[@ng-reflect-router-link='/account,my-autocheck']"));
    var leftArrowBtn = element(by.xpath("//i[text()='chevron_left']"));
    var email = element(by.xpath("//*[@class='email']"));
    var editProfileLink = element(by.xpath("//a[@href='/account/my-profile']"));
    var threeDotsMainMenu = element(by.xpath("//i[text()='more_vert']"));
    var logOutMenuItem = element(by.xpath("//*[text()='Log out']"));

    //Carfax and Autocheck
    var carFaxUserInput = element(by.name("carfax_userid"));
    var carFaxPasswordInput = element(by.name("carfax_password"));
    var carFaxCheckBox = element(by.name("carfax_allowed"));
    var carFaxSaveBtn = element(by.xpath("//stateful-button[@ng-reflect-button-text='Save']"));
    var carFaxRemoveBtn = element(by.xpath("//stateful-button[@ng-reflect-button-text='Remove']"));

    var autoCheckUserInput = element(by.name("autocheck_userid"));
    var autoCheckPasswordInput = element(by.name("autocheck_password"));
    var autoCheckCheckBox = element(by.name("autocheck_allowed"));
    var autoCheckSaveBtn = element(by.xpath("//stateful-button[@ng-reflect-button-text='Save']"));
    var autoCheckRemoveBtn = element(by.xpath("//stateful-button[@ng-reflect-button-text='Remove']"));

    this.isPresentCarFaxRemoveBtn = async function(){
        return await carFaxRemoveBtn.isPresent();
    }
    
    this.isPresentAutoCheckRemoveBtn = async function(){
        return await autoCheckRemoveBtn.isPresent();
    }

    this.clickLeftArrowBtn = async function(){
        await leftArrowBtn.click();
    }

    this.clickCarFaxAccountLink = async function(){
        await carFaxAccountLink.click();
    }

    this.clickAutoCheckAccountLink = async function(){
        await autoCheckAccountLink.click();
    }


    this.setCarFaxUser = async function(user){
        await carFaxUserInput.clear();
        await carFaxUserInput.sendKeys(user);
    }

    this.setCarFaxPassword = async function(pwd){
        await carFaxPasswordInput.clear();
        await carFaxPasswordInput.sendKeys(pwd);
    }

    this.selectCarFaxCheckBox = async function(){
        await carFaxCheckBox.click();
    }

    this.clickCarFaxSaveBtn = async function(){
        await carFaxSaveBtn.click();
    }

    this.setCarFaxCredentials = async function(user,pwd){
        await utils.logInfo("Enter User in Carfax Screen");
        await this.setCarFaxUser(user);
        await utils.logInfo("Enter Password in Carfax Screen");
        await this.setCarFaxPassword(pwd);
        await utils.logInfo("Select Checkbox in Carfax Screen");
        await this.selectCarFaxCheckBox();
        await utils.logInfo("Click Save Button in Carfax Screen");
        await this.clickCarFaxSaveBtn();
    }

    this.clickCarFaxRemoveBtn = async function(){
        await carFaxRemoveBtn.click();
    }

    this.setAutoCheckUser = async function(user){
        await autoCheckUserInput.clear();
        await autoCheckUserInput.sendKeys(user);
    }
    this.setAutoCheckPassword = async function(pwd){
        await autoCheckPasswordInput.clear();
        await autoCheckPasswordInput.sendKeys(pwd);
    }

    this.selectAutoCheckCheckBox = async function(){
        await autoCheckCheckBox.click();
    }

    this.clickAutoCheckSaveBtn = async function(){
        await autoCheckSaveBtn.click();
    }

    this.clickAutoCheckRemoveBtn = async function(){
        await autoCheckRemoveBtn.click();
    }

    this.setAutoCheckCredentials = async function(user,pwd){
        await utils.logInfo("Enter User in AutoCheck Screen");
        await this.setAutoCheckUser(user);
        await utils.logInfo("Enter Password in AutoCheck Screen");
        await this.setAutoCheckPassword(pwd);
        await utils.logInfo("Select Checkbox in AutoCheck Screen");
        await this.selectAutoCheckCheckBox();
        await utils.logInfo("Click Save Button in AutoCheck Screen");
        await this.clickAutoCheckSaveBtn();
    }

    
    this.clickLogOut = async function(){
        await utils.logInfo("My Account:clickLogOut - Navigate to Homepage");
        await browser.get(browser.params.env.url+"/report/all");

        await utils.logInfo("My Account:clickLogOut - Click on 'three dots' menu");
        await threeDotsMainMenu.click();

        await utils.logInfo("My Account:clickLogOut - Click on 'Log Out' menu item under three dots menu");
        await logOutMenuItem.click();
    }

    this.getEmail = async function(){
        return await email.getText();
    }

    this.navigateTo = async function(){
        await browser.get(browser.params.env.url+"/account/my-account");
    }

    this.getUrl = async function(){
        return browser.params.env.url+"/account/my-account";
    }

    this.navigateToThruMenu = async function(){
        
    }

    this.clickEditProfileLink = async function(){
        await utils.logInfo("My Account:clickEditProfileLink - Click on Edit Profile Link");
        await utils.logInfo("Getting URL:"+browser.params.env.url+"/account/my-profile");

        //await editProfileLink.click();
        await browser.get(browser.params.env.url+"/account/my-profile");
        
        // await browser.getCurrentUrl().then(async function(url){
        //     if(url == await verifymobilenumberpage.getUrl()){
        //         await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
        //         await utils.logInfo("Click Remind me on Verify Mobile Number Page");
        //         await verifymobilenumberpage.clickRemindme();
        //     }
        // });

        var currentURL = await browser.getCurrentUrl();
        utils.logInfo("browser.getCurrentUrl():"+currentURL);

        if(currentURL ==  await verifymobilenumberpage.getUrl()){
            await utils.logInfo("Click Remind me on Verify Mobile Number Page");
            await verifymobilenumberpage.clickRemindme();

        }//if
        await utils.logInfo("Getting URL:"+browser.params.env.url+"/account/my-profile");
        await browser.get(browser.params.env.url+"/account/my-profile");


    }

}



module.exports = new myaccountpage();