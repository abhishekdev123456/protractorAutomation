var utils = require('../utilities/utils');
var homepage = require('../pages/home.page');

var edituserpage = function(){

    //var firstNameTxt = element(by.name("first_name"));
    //var firstNameTxt = element(by.xpath("//input[@name='first_name']"));
    var firstNameTxt = element(by.xpath("//input[@name='first_name']"));
    var lastNameTxt = element(by.xpath("//input[@name='last_name']"));

    //var lastNameTxt = element(by.name("last_name"));
    var userRole = element.all(by.name("user_role"));
    var acquisitionManagerRadio = element(by.xpath("//*[text()='Acquisition Manager']"));
    var acquisitionUserRadio = element(by.xpath("//*[text()='Acquisition User']"));
    var salesManagerRadio = element(by.xpath("//*[text()='Sales Manager']"));
    var BDCManagerRadio = element(by.xpath("//*[text()='BDC Manager']"));

    var updateAccountBtn = element(by.xpath("//stateful-button[@ng-reflect-button-text='Update Account']/button"));
    var EC = protractor.ExpectedConditions;

    this.setFirstName = async function(fname){
        browser.wait(EC.elementToBeClickable(firstNameTxt));
        await firstNameTxt.clear();
        await firstNameTxt.sendKeys(fname);

    }

    this.setLastName = async function(lname){
        browser.wait(EC.elementToBeClickable(lastNameTxt));
        await lastNameTxt.clear();
        await lastNameTxt.sendKeys(lname);
    }

    this.getFirstName = async function(){
        return await firstNameTxt.getAttribte("ng-reflect-model");
    }

    this.getLastName = async function(){
        return await lastNameTxt.getAttribte("ng-reflect-model");
    }

    this.getFirstNameElement = function(){
        return firstNameTxt;
    }

    this.clickUpdateAccountBtn = async function(){
        await browser.wait(EC.elementToBeClickable(updateAccountBtn));
        await updateAccountBtn.click();
    }

    this.selectRole = async function(role){
        switch(role) {
            case "Acquisition Manager":
                await acquisitionManagerRadio.click(); 
                break;
            case "Acquisition User":
                await acquisitionUserRadio.click(); 
                break;
            case "Sales Manager":
                await salesManagerRadio.click(); 
                break;    ``
            case "BDC Manager":
                await BDCManagerRadio.click();
                break;
            default:
                await utils.logInfo("edituserpage:selectRole() function parameter: '"+role+"' is invalid");
          }     

    }


    
    
}



module.exports = new edituserpage();