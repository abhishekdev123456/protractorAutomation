var utils = require('../utilities/utils');

var loginpage = function(){
    var userNameTxtFld = element(by.name('username'));
    var passwordTxtFld = element(by.name('password'));
    var signInBtn = element(by.buttonText('Sign In'));
    var wrongCredentialsText = element(by.xpath("//*[@title='Wrong email or password.']"));

    this.get = async function() {
        await browser.get(browser.params.env.url+"/auth/login?force=true");
        var round = 1;
        do{
            await utils.logInfo("login page wait fo 5 seconds round "+round);
            await browser.sleep(browser.params.sleep.sleep5);
            round = round+1;
        }
        while((await userNameTxtFld.isPresent() == false) && round < 5);

        var EC = ExpectedConditions;
        var condition = EC.presenceOf(userNameTxtFld);
        browser.wait(condition, 30000);


    };

    this.getForceURL = async function(){
        return await browser.params.env.url+"/auth/login?force=true";
    }

    this.getURL = async function(){
        return await browser.params.env.url+"/auth/login";
    }

    this.setUsername = async function (username) {
        await userNameTxtFld.clear();
        await userNameTxtFld.sendKeys(username);
    };
    
    this.setPassword = async function (password) {
        await passwordTxtFld.sendKeys(password);
    };
    
    this.clickSignIn = async function () {
        await signInBtn.click();
    };
    
    this.signIn = async function(user,pwd){
        await utils.logInfo("Set User Name :"+user);
        await this.setUsername(user);

        await utils.logInfo("Set Password :"+pwd);
        await this.setPassword(pwd);

        await utils.logInfo("Click on Sign-In Buttton");
        await this.clickSignIn();
    }

    this.getLoginError =async function(){
        return await wrongCredentialsText.getText();
    }
}

module.exports = new loginpage();
