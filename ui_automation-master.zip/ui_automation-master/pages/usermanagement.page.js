var utils = require('../utilities/utils');
var homepage = require('../pages/home.page');

var usermanagementpage = function(){
    var priceBarConfigLink = element(by.xpath("//list-item[@ng-reflect-router-link='/account,my-pricebar']"));
    var email = element(by.xpath("//*[@class='email']"));
    //var addUserBtn = element(by.xpath("//button[text()='Add User']"));
    var addUserBtn = element(by.buttonText("Add User"));
    var addNewUsersTxt = element(by.name("emails"));
    var inviteBtn = element(by.xpath("//button/*[text()='Invite']/.."));    
    var searchTxt = element(by.xpath("//input[@placeholder='Search']"));
    var searchBtn = element(by.xpath("//button[@class='search-button ng-star-inserted']"));
    var EC = protractor.ExpectedConditions;

    this.getUrl = async function(){
        return browser.params.env.url+"/account/user-management";
    }

    this.isPresent = async function(){
        //console.log("tests");        
    }

    this.getAddUserButton = function(){
        return addUserBtn;
    }

    this.getSearchButtonElement = function(){
        return searchBtn;
    }

    this.searchUser = async function(searchterm){
        utils.logInfo("Inside Search User function");
        //browser.actions().mouseMove(searchTxt).click().perform();
        //utils.logInfo("After Action");

        await searchTxt.clear();

        //browser.actions().mouseMove(searchTxt).sendKeys(searchterm).perform();

        await searchTxt.sendKeys(searchterm);
        browser.wait(EC.presenceOf(this.getSearchButtonElement()), 10000);
        await searchBtn.click();
        //browser.actions().mouseMove(searchTxt).click().perform();

    }

    this.addUser = async function(email){
        try{
            await utils.logInfo("User Mgmt:addUser - Click on 'Add User' Button");
            await addUserBtn.click();
        }
        catch(err){
            utils.logInfo("Catch Error in addUserBtn.click(): "+err);
        }
        await utils.logInfo("User Mgmt:addUser - Enter new user email");
        await addNewUsersTxt.clear();
        await addNewUsersTxt.sendKeys(email);

        await utils.logInfo("User Mgmt:addUser - Click on Invite Button");
        await inviteBtn.click();

    }

    this.isPresentUser = async function(name,email){
        //*[@ng-reflect-color-seed='aa1569361645157@aa.com'] [@ng-reflect-name='AA User']
        //var locator = "//*[@ng-reflect-name='"+name+" "+email+"']";
        var locator = "//*[@ng-reflect-color-seed='"+email+"'] [@ng-reflect-name='"+name+"']";
        utils.logInfo("locator is "+locator);
        var user = element(by.xpath(locator));
        browser.executeScript('arguments[0].scrollIntoView()', user.getWebElement());

        return await user.isPresent();
    }
    
    
}



module.exports = new usermanagementpage();