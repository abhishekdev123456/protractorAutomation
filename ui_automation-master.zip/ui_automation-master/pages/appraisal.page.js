
//var util = require("util");
var utils = require('../utilities/utils');
var path = require("path");


var appraisalpage = function(){

var appraisalID = element(by.xpath("//*[@class='appraisal-id']"));
var readOnlyHeader = element(by.xpath("//*[text()='Read Only']"));
var appraisalVIN = element(by.xpath("//div[@class='vin-mileage']"));
var enterVINBtn = element(by.xpath("//button[text()='Enter VIN']"));
var enterVINInput = element(by.xpath("//input[@placeholder='Enter VIN']"));
var updateVINBtn = element(by.xpath("//button[text()='Update']"));

// ************************ Appraisal Menu ************************ 
//var threeDotsAppraisalMenu = element(by.xpath("//*[@class='menu-consumer-container']/i[text()='more_vert']"));
var appraisalToolsMenu = element(by.xpath("//appraisal-tools"));
var assignedToModify = element(by.xpath("//*[text()='(Modify)']"));
var assignedToDealershipPersonName = element(by.xpath("//*[@class='salesperson-info-container']/*[@class='name']"));
var assignedToDealershipName = element(by.xpath("//*[@class='salesperson-info-container']/*[@class='dealership']"));
//var assignedToEmail = element(by.xpath("//*[text()='Email'][1]"));
var emailAppraisalMenu = element(by.xpath("//appraisal-tools-menu-icon/*[text()='Email']"));
var consumerAppraisalMenuItem = element (by.xpath("//*[text()='Consumer Appraisal Report']")); 
var dealerAppraisalMenuItem = element(by.xpath("//*[text()='Dealer Condition Report']"));
var customerInfoMenuItem = element(by.xpath("//*[text()='Customer Information']"));
var carfaxAppraisalMenuItem = element(by.xpath("//*[text()='CARFAX® Report']"));
var autocheckAppraisalMenuItem = element(by.xpath("//*[text()='AutoCheck® Report']"));
var guidebookAppraisalMenuItem = element(by.xpath("//*[text()='Guidebooks']"));
var scorecardAppraisalMenuItem = element(by.xpath("//*[text()='Scorecard']"));
var localMarketAppraisalMenuItem = element(by.xpath("//*[text()='Local Market']"));
var photoGalleryAppraisalMenuItem = element(by.xpath("//*[text()='Photo Gallery']"));
var recallNotesAppraisalMenuItem = element(by.xpath("//*[text()='Recall Notes']"));
var appraisalNotesMenuItem = element(by.xpath("//*[text()='Appraisal Notes']"));
var unitHistoryMenuItem = element(by.xpath("//*[text()='Unit History']"));
var copyAppraisalMenuItem = element(by.xpath("//*[text()='Copy Appraisal']"));
var shareEmail = element(by.xpath("//appraisal-tools-menu-icon/*[text()='Email']"));
var shareSMS = element(by.xpath("//appraisal-tools-menu-icon/*[text()='SMS']"));
var giveFeedback = element(by.xpath("//*[text()='Feedback']"));
var googleVIN = element(by.xpath("//*[text()='Google VIN']"));
var copyVIN = element(by.xpath("//*[text()='Copy VIN']"));
var openMMR = element(by.xpath("//img[@src='assets/images/manheim.svg']/../.."));
var commonProblemsLabel = element(by.xpath("//*[text()='Common Problems']"));
var commonProblemsPanel = element(by.xpath("//common-problems-panel"));
var commonProblemsList = element(by.xpath("//common-problems-panel/ul"));
var feebackInput = element(by.xpath("//textarea[@placeholder='Enter your feedback or issue']"));
var sendFeedbackBtn = element(by.xpath("//textarea[@placeholder='Enter your feedback or issue']/following-sibling::*[@ng-reflect-text='Send']"));
var successFeedbackMsgPart1 = element(by.xpath("//*[text()='Thank You ']"));
var successFeedbackMsgPart2 = element(by.xpath("//*[text()='for giving us feedback on this valuation.']"));
var recallCloseBtn = element(by.xpath("//vehicle-recall/modal/*[@class='modal-content open']/i[text()='close ']"));
var recallLinkCommonProblems = element(by.xpath("//common-problems-panel/ul/li/a[text()=' Recalls ']"));

var leftPhotoGalleryBtn = element(by.xpath("//appraisal-subpage-nav/main/section/*[text()='chevron_left']"));

var appraisalIDLabel = element(by.xpath("//appraisal-menu-header/div[1]/span[2]"));
var addImageBtn = element(by.xpath("//*[@class='add-images']/*[text()='Add Images']"));
var imagesAvailableBtn = element(by.xpath("//*[@class='add-images']/*[text()='Images Available']"));
var clickToAddPhotosGalleryBtn = element(by.xpath("//*[text()='Click to add photos']"));
var photoCameraGalleryButton = element(by.xpath("//*[@class='needsclick no-photos-upload']/*[text()='photo_camera']"));
var appraisalThumbnailBtn = element(by.xpath("//appraisal-thumbnail"));
var deleteIconPhotoGallery = element(by.xpath("//*[@class='material-icons trash'][text()='delete']"));
var uploadAdditionalPhotosGalleryBtn = element(by.xpath("//*[@class='needsclick upload-additional-photos']/*[text()='photo_camera']"));
var addCaptionInputPhotoGallery = element(by.xpath("//input[@placeholder='Add Caption']"));
var exteriorPhotoTagGalleryBtn = element(by.xpath("//fa-button[@ng-reflect-text='Exterior']"));
var interiorPhotoTagGalleryBtn = element(by.xpath("//fa-button[@ng-reflect-text='Interior']"));
var damagePhotoTagGalleryBtn = element(by.xpath("//fa-button[@ng-reflect-text='Damage']"));
var repairedPhotoTagGalleryBtn = element(by.xpath("//fa-button[@ng-reflect-text='Repaired']"));
var odometerPhotoTagGalleryBtn = element(by.xpath("//fa-button[@ng-reflect-text='Odometer']"));
var picsNotAvailableMsgGallery = element(by.xpath("//*[text()='Pictures are no longer available for this vehicle.']"));

var estimateDamageGradeSlider = element(by.xpath("//input[@formcontrolname='gradeSlider']"));
var estimateDamageGradeAmountInput = element(by.xpath("//condition-estimate/div/input"));
var estimateDamageGradeNumber = element(by.xpath("//*[@ng-reflect-klass='range-value']"));

var cdModeEstimateToggleBtn = element(by.xpath("//*[text()='Estimate']"));
var cdModeDetailedToggleBtn = element(by.xpath("//*[text()='Detailed']"));

var walkMeGroundMsgDialogCloseBtn = element(by.xpath("//*[@id='walkme-balloon-3473537']/div/div[1]/div[2]/div/div[@title='Stop Walk-thru']"));
var walkMeAlreadyGroundedMsgDialogCloseBtn = element(by.xpath("//*[@id='walkme-balloon-3540673']/div/div[1]/div[2]/div/div[@title='Stop Walk-thru']"));

var refreshOfferBtn = element(by.xpath("//button[text()='Refresh Offer']"));

var generateAppraisalReportDesc = element(by.xpath("//*[text()=' Generate Appraisal Report ']/following-sibling::div"));

//Branding
var brandLogoLeftSection = element(by.xpath("//img[@class='consumer-mode-image']"));
//src=assets/images/logos/accutrade-appraiser-white.png
var brandLogoPriceBar = element(by.xpath("//consumer-price-bar/brand-image/img"));
//src=assets/images/logos/accutrade-appraiser-dark.png
var offerPriceLabelConsumerPriceBar = element(by.xpath("//consumer-price-bar/brand-image/following-sibling::div[1]"));
//getText()=Accu-Trade Instant Offer

var offerPriceLabelDealerPriceBar = element(by.xpath("//price-bar/appraisal-price[1]/div[@ng-reflect-klass='label']"));

var offerPriceLabelReviewSend = element(by.xpath("//trade-desk-dock-list/following-sibling::div/div[1]"));
//getText()=Accu-Trade Instant Offer


this.isPresentBrandLogoLeftSection = async function(){
    return await brandLogoLeftSection.isPresent();
}

this.getBrandLogoLeftSectionImgSrc = async function(){
    return brandLogoLeftSection.getAttribute("src");
}

this.isPresentBrandLogoPriceBar = async function(){
    return await brandLogoPriceBar.isPresent();
}

this.getBrandLogoPriceBarImgSrc = async function(){
    return await brandLogoPriceBar.getAttribute("src");
}

this.isPresentOfferPriceLabelConsumerPriceBar = async function(){
    return await offerPriceLabelConsumerPriceBar.isPresent();
}

this.getOfferPriceLabelConsumerPriceBar = async function(){
    return await offerPriceLabelConsumerPriceBar.getText();
}

this.isPresentOfferPriceLabelDealerPriceBar = async function(){
    return await offerPriceLabelDealerPriceBar.isPresent();
}

this.getOfferPriceLabelDealerPriceBar = async function(){
    return await offerPriceLabelDealerPriceBar.getText();
}

this.isPresentOfferPriceLabelReviewSend = async function(){
    return await offerPriceLabelReviewSend.isPresent();    
}

this.getOfferPriceLabelReviewSend = async function(){
    return await offerPriceLabelReviewSend.getText();
}

this.isPresentWalkMeGroundMsgDialog = async function(){
    return await walkMeGroundMsgDialogCloseBtn.isPresent();
}

this.closeWalkMeGroundMsgDialog = async function(){
    await walkMeGroundMsgDialogCloseBtn.click();
}

this.isPresentWalkMeAlreadyGroundedMsgDialog = async function(){
    return await walkMeAlreadyGroundedMsgDialogCloseBtn.isPresent();
}

this.closeWalkMeAlreadyGroundedMsgDialog = async function(){
    await walkMeAlreadyGroundedMsgDialogCloseBtn.click();
}

this.getGenerateAppraisalReportDesc = async function(){
    return await generateAppraisalReportDesc.getText();
}

this.clickRefreshOfferBtn = async function(){
    await refreshOfferBtn.click();
}

this.isPresentRefreshOfferBtn = async function(){
    return await refreshOfferBtn.isPresent();
}

this.getEstimateDamageGradeNumber = async function(){
    return await estimateDamageGradeNumber.getText();
} 

this.isPresentEstimateDamageGradeSlider = async function(){
    return await estimateDamageGradeSlider.isPresent();
}

this.isPresentEstimateDamageGradeAmountInput = async function(){
    return await estimateDamageGradeAmountInput.isPresent();
}

this.setEstimateDamageGradeAmountValue = async function(amountValue){
    await estimateDamageGradeAmountInput.sendKeys(amountValue);
}

this.getEstimateDamageGradeAmountValue = async function(){
    return await estimateDamageGradeAmountInput.getAttribute("ng-reflect-model");
} 

this.clickEstimateDamageGradeSlider = async function(){
    await estimateDamageGradeSlider.click();
}

this.clickEstimateCDModeToggleBtn = async function(){
    await cdModeEstimateToggleBtn.click();
}

this.clickDetailedCDModeToggleBtn = async function(){
    await cdModeDetailedToggleBtn.click();
}

this.getMMRIconURL = async function(){
    return await openMMR.getAttribute("ng-reflect-href");
}

this.isPresentMMRIcon = async function(){
    return await openMMR.isPresent();
}

this.isHiddenCommonProblems = async function(){

    if(await commonProblemsPanel.isPresent()){
        var status = await commonProblemsPanel.getAttribute("class");
        if (status == "hidden"){
            return true;
        } // status == "hidden"
        else{
            return false;
        }
    }// commonProblemsPanel.isPresent()
    else{
        return true;
    }
}

this.clickEnterVINBtn = async function(){
    await enterVINBtn.click();
}

this.setVIN = async function(vin){
    await enterVINBtn.click();
    await browser.sleep(browser.params.sleep.sleep2);
    await enterVINInput.sendKeys(vin);
    await browser.sleep(browser.params.sleep.sleep2);
    await updateVINBtn.click();
}

this.isPresentClickToAddPhotosGalleryBtn = async function(){
    return await clickToAddPhotosGalleryBtn.isPresent();
}

this.isPresentPhotoCameraGalleryBtn = async function(){
    return await photoCameraGalleryButton.isPresent();
}

this.isPresentImagesAvailableBtn = async function(){
    return await imagesAvailableBtn.isPresent();
}

this.clickImagesAvailableBtn = async function(){
    await imagesAvailableBtn.click();
}

this.clickAppraisalThumbnailBtn = async function(){
    await appraisalThumbnailBtn.click();
}

this.isPresentAppraisalThumbnailBtn = async function(){
    return await appraisalThumbnailBtn.isPresent();
}

this.isPresentAddCaptionInputPhotoGallery = async function(){
    return await addCaptionInputPhotoGallery.isPresent();
}

this.isPresentUploadAdditionalPhotosGalleryBtn = async function(){
    return await uploadAdditionalPhotosGalleryBtn.isPresent();
}

this.isPresentExteriorPhotoTagGalleryBtn = async function(){
    return await exteriorPhotoTagGalleryBtn.isPresent();
}

this.isPresentInteriorPhotoTagGalleryBtn = async function(){
    return await interiorPhotoTagGalleryBtn.isPresent();
}

this.isPresentDamagePhotoTagGalleryBtn = async function(){
    return await damagePhotoTagGalleryBtn.isPresent();
}

this.isPresentRepairedPhotoTagGalleryBtn = async function(){
    return await repairedPhotoTagGalleryBtn.isPresent();
}

this.isPresentOdometerPhotoTagGalleryBtn = async function(){
    return await odometerPhotoTagGalleryBtn.isPresent();
}

this.isDisabledExteriorPhotoTagGalleryBtn = async function(){
    return ((await exteriorPhotoTagGalleryBtn.getAttribute("class")) == "disabled"?true:false);
}

this.isDisabledInteriorPhotoTagGalleryBtn = async function(){
    return ((await interiorPhotoTagGalleryBtn.getAttribute("class")) == "disabled"?true:false);
}

this.isDisabledDamagePhotoTagGalleryBtn = async function(){
    return ((await damagePhotoTagGalleryBtn.getAttribute("class")) == "disabled"?true:false);
}

this.isDisabledRepairedPhotoTagGalleryBtn = async function(){
    return ((await repairedPhotoTagGalleryBtn.getAttribute("class")) == "disabled"?true:false);
}

this.isDisabledOdometerPhotoTagGalleryBtn = async function(){
    return ((await odometerPhotoTagGalleryBtn.getAttribute("class")) == "disabled"?true:false);
}

this.isPresentPicsNotAvailableGallery = async function(){
    return await picsNotAvailableMsgGallery.isPresent();
}

//Carfax and Autocheck Appraisal
var carFaxImage = element(by.xpath("//carfax/section/i"));
var autoCheckImage = element(by.xpath("//autocheck/section/i"));
var vinCarFaxReport = element(by.xpath("//*[@id='vin']")); //Return "VIN: JF1SG63645G733373"
var vinAutoCheckReport = element(by.xpath("//*[@class='decodelabel'][text()='VIN:']/following-sibling::*")); //Return "JF1SG63645G733373"
var frameCarFaxAutoCheck = element(by.xpath("//iframe[contains(@srcdoc, 'SafeValue')]"));


this.clickRecallLinkCommonProblems = async function(){
    await recallLinkCommonProblems.click();
}    

this.isPresentRecallLinkCommonProblems = async function(){
    return await recallLinkCommonProblems.isPresent();
}

this.isPresentGoodCarFaxImage = async function(){
    if(await carFaxImage.isPresent() == true){
        var imageText = await carFaxImage.getText();
        return ((imageText == "check_circle")?true:false);
    }
    else{
        return false;
    }
}
this.isPresentBadCarFaxImage = async function(){
    if(await carFaxImage.isPresent() == true){
        var imageText = await carFaxImage.getText();
        return ((imageText == "remove_circle")?true:false);
    }
    else{
        return false;
    }
}
this.isPresentGoodAutoCheckImage = async function(){
    if(await autoCheckImage.isPresent() == true){
        var imageText = await autoCheckImage.getText();
        return ((imageText == "check_circle")?true:false);
    }
    else{
        return false;
    }

}
this.isPresentBadAutoCheckImage = async function(){
    if(await autoCheckImage.isPresent() == true){
        var imageText = await autoCheckImage.getText();
        return ((imageText == "remove_circle")?true:false);
    }
    else{
        return false;
    }
}
this.clickCarFaxImage = async function(){
    await carFaxImage.click();
}
this.clickAutoCheckImage = async function(){
    await autoCheckImage.click();
}


//Existing Appraisals under New Appraisals/Trim 

var existingAppraisalText = element(by.xpath("//*[text()='We found the following appraisal(s) matching that VIN:']"))

var customerFirstExistingAppraisalSelectTrimScreen = element(by.xpath("//appraisal-card[1]/footer/div/*[text()='Customer:']/following-sibling::*"));
var salesPersonFirstExistingAppraisalSelectTrimScreen = element(by.xpath("//appraisal-card[1]/footer/div/*[text()='Sales Person:']/following-sibling::*"));
var dealerFirstExistingAppraisalSelectTrimScreen = element(by.xpath("//appraisal-card[1]/footer/div/*[text()='Dealer:']/following-sibling::*"));

var ymmFirstExistingAppraisalSelectTrimScreen = element(by.xpath("//appraisal-card[1]/*[@class='data-container']/*[@class='appraisal-info-container']/*[@class='year-make-model-container']/*[@class='year-make-model']"));
var ageFirstExistingAppraisalSelectTrimScreen = element(by.xpath("//appraisal-card[1]/*[@class='data-container']/*[@class='appraisal-info-container']/*[@class='year-make-model-container']/*[@class='age-container']")); 
var trimFirstExistingAppraisalSelectTrimScreen = element(by.xpath("//appraisal-card[1]/*[@class='data-container']/*[@class='appraisal-info-container']/*[@class='style']"));
var vinMileageFirstExistingAppraisalSelectTrimScreen = element(by.xpath("//appraisal-card[1]/*[@class='data-container']/*[@class='appraisal-info-container']/*[@class='vin-odometer']"));
var locationFirstExistingAppraisalSelectTrimScreen = element(by.xpath("//appraisal-card[1]/*[@class='data-container']/*[@class='appraisal-info-container']/*[@class='location-source-container']/*[@class='location']"));

this.getCustomerNameFirstExistingAppraisalSelectTrimScreen = async function(){
    var cname = await customerFirstExistingAppraisalSelectTrimScreen.getText();
    return await utils.splitInToTwoReturnFirstPart(cname,",");
}

this.getSalesPersonFirstExistingAppraisalSelectTrimScreen = async function(){
    var sPerson = await salesPersonFirstExistingAppraisalSelectTrimScreen.getText();
    return await utils.splitInToTwoReturnFirstPart(sPerson,",");
}

this.getDealerFirstExistingAppraisalSelectTrimScreen = async function(){
    return await dealerFirstExistingAppraisalSelectTrimScreen.getText();
}

this.getYMMFirstExistingAppraisalSelectTrimScreen = async function(){
    return await ymmFirstExistingAppraisalSelectTrimScreen.getText();
}

this.getAgeFirstExistingAppraisalSelectTrimScreen = async function(){
    return await ageFirstExistingAppraisalSelectTrimScreen.getText();
}

this.getTrimFirstExistingAppraisalSelectTrimScreen = async function(){
    return await trimFirstExistingAppraisalSelectTrimScreen.getText();

}

this.getVINFirstExistingAppraisalSelectTrimScreen = async function(){
    var vinMileage = await vinMileageFirstExistingAppraisalSelectTrimScreen.getText();
    var vin = utils.splitInToTwoReturnFirstPart(vinMileage,"|");
    //var mileage = utils.splitInToTwoReturnSecondPart(vinMileage,"|");

    return vin.trim();

}

this.getMileageFirstExistingAppraisalSelectTrimScreen = async function(){
    var vinMileage = await vinMileageFirstExistingAppraisalSelectTrimScreen.getText();
    //var vin = utils.splitInToTwoReturnFirstPart(vinMileage,"|");
    var mileage = utils.splitInToTwoReturnSecondPart(vinMileage,"|");

    return mileage.trim();
}

this.getLocationFirstExistingAppraisalSelectTrimScreen = async function(){
    return await locationFirstExistingAppraisalSelectTrimScreen.getText();
}


//Customer Info under Appraisal Menu
var customerFirstNameLabel = element(by.xpath("//*[text()='Customer First Name']")); 
var firstNameInputCustomerInfo = element(by.xpath("//*[text()='Customer First Name']/following-sibling::input[1]"));
var lastNameInputCustomerInfo = element(by.xpath("//*[text()='Customer Last Name']/following-sibling::input[1]"));
var zipCodeCustomerInfo = element(by.xpath("//*[text()='Zip Code']/following-sibling::input[1]"));
var primaryPhoneCustomerInfo = element(by.xpath("//*[text()='Primary Phone']/following-sibling::input[1]"));
var emailAddressCustomerInfo = element(by.xpath("//*[text()='Email Address']/following-sibling::input[1]"));
var priceDealerPurchasedFromCustomerInfo = element(by.xpath("//*[text()='Price dealer purchased from consumer']/following-sibling::input[1]"));
var dealerOfferCustomerInfo = element(by.xpath("//*[text()='Dealer Offer']/following-sibling::input[1]"));
var redemptionCodeCustomerInfo = element(by.xpath("//*[text()='Redemption Code']/following-sibling::input[1]"));
var openStatusBtnCustomerInfo = element(by.xpath("//*[text()='Status']/following-sibling::button-group/button-group-item[@ng-reflect-text='Open']"));
var wonStatusBtnCustomerInfo = element(by.xpath("//*[text()='Status']/following-sibling::button-group/button-group-item[@ng-reflect-text='Won']"));
var lostStatusBtnCustomerInfo = element(by.xpath("//*[text()='Status']/following-sibling::button-group/button-group-item[@ng-reflect-text='Lost']"));
var lostReasonCustomerInfo = element(by.xpath("//*[text()='Lost Reason']/following-sibling::select"));
var closeBtnCustomerInfo = element(by.xpath("//*[text()='Customer Information']/following-sibling::i[text()='close ']"));

//Appraisal Notes under Appraisal Menu
var appraisalNotestHeader = element(by.xpath("//header[text()=' Appraisal Notes ']"));
var commentInputAppraisalNotes = element(by.xpath("//*[text()=' Appraisal Notes ']/following-sibling::textarea"));
var closeBtnAppraisalNotes = element(by.xpath("//appraisal-notes/modal/*[@ng-reflect-klass='modal-content']/i[text()='close ']"));

//GID under appraisal menu
var gidAppraisalMenu = element(by.xpath("//appraisal-tools-menu/div[@class='debug-info']"));

this.getGIDDebugInfoAppraisalMenu = async function(){
    return await gidAppraisalMenu.getText(); //gid: 205187 None ti: 2150 gmr: 2950 adj: 0 region: 6
}


this.setCommentAppraisalNotes = async function(sComment){
    await commentInputAppraisalNotes.sendKeys(sComment);
}

this.clickCloseBtnAppraisalNotes = async function(){
    await closeBtnAppraisalNotes.click();
}

this.getCommentAppraisalNotes = async function(){
    return await commentInputAppraisalNotes.getAttribute("ng-reflect-model");
}

this.isDisabledCommentAppraisalNotes = async function(){
    return await commentInputAppraisalNotes.getAttribute("disabled");
}

//Unit History under Appraisal Menu
var unitHistoryHeader = element(by.xpath("//*[text()='Unit History']"));
var backArrowBtn = element(by.xpath("//mat-icon[text()='chevron_left']"));
var groundedAppraisalLabel = element(by.xpath("//section[contains(@class,'center')]/div/div[text()='Grounded']"));
var appraisalPersonIcon = element(by.xpath("//section/div/mat-icon[text()='person']"));

//Consumer Mode (Customer Detail)
var firstNameCustomerDetail = element(by.id("firstName"));
var lastNameCustomerDetail = element(by.id("lastName"));
var phoneCustomerDetail = element(by.id("phoneNumber"));
var zipCodeCustomerDetail = element(by.id("zipcode"));
var emailCustomerDetail = element(by.id("emailAddress"));
var paymentYesBtnCustomerDetail = element(by.xpath("//*[@ng-reflect-label='Still Making Payments']/div/button[text()='Yes']"));
var paymentNoBtnCustomerDetail = element(by.xpath("//*[@ng-reflect-label='Still Making Payments']/div/button[text()='No']"));
var loanRadioBtnCustomerDetail = element(by.id("paymentTypeLoan"));
var leaseRadioBtnCustomerDetail = element(by.id("paymentTypeLease"));
var loanAmountRemainingCustomerDetail = element(by.xpath("//input[@placeholder='Approximate Amount Remaining']"));
var monthlyPaymentCustomerDetail = element(by.xpath("//input[@placeholder='Mo. Payment']")); 
var numberOfPaymentsCustomerDetail = element(by.xpath("//input[@placeholder='No. Payments']"));
var paymentAmountCustomerDetail = element(by.xpath("//input[@placeholder='Amount']"));
var replacementVehicleYesBtnCustomerDetail = element(by.xpath("//*[@ng-reflect-label='Interested in a replacement ve']/div/button[text()='Yes']"));
var replacementVehicleNoBtnCustomerDetail = element(by.xpath("//*[@ng-reflect-label='Interested in a replacement ve']/div/button[text()='No']"));
var newPurchaseRadioBtnCustomerDetail = element(by.id("purchaseTypeNew"));
var usedPurchaseRadioBtnCustomerDetail = element(by.id("purchaseTypeUsed"));
var cpoPurchaseRadioBtnCustomerDetail = element(by.id("purchaseTypeCPO"));
var notSurePurchaseRadioBtnCustomerDetail = element(by.id("purchaseTypeNotSure"));
var yearInputCustomerDetail = element(by.xpath("//input[@placeholder='Year']"));
var makeInputCustomerDetail = element(by.xpath("//input[@placeholder='Make']"));
var modelInputCustomerDetail = element(by.xpath("//input[@placeholder='Model']"));
var trimInputCustomerDetail = element(by.xpath("//input[@placeholder='Trim']"));


this.clickPaymentYesBtnCustomerDetail = async function(){
    await paymentYesBtnCustomerDetail.click();
}

this.isSelectedPaymentYesBtnCustomerDetail = async function(){
    var status = await paymentYesBtnCustomerDetail.getAttribute("class");
    if(status == "selected"){
        return true;
    }
    else{
        return false;
    }
}

this.clickPaymentNoBtnCustomerDetail = async function(){
    await paymentNoBtnCustomerDetail.click();
}

this.isSelectedPaymentNoBtnCustomerDetail = async function(){
    var status = await paymentNoBtnCustomerDetail.getAttribute("class");
    if(status == "selected"){
        return true;
    }
    else{
        return false;
    }
}

this.selectLoanRadioBtnCustomerDetail = async function(){
    await loanRadioBtnCustomerDetail.click();
}

this.isPresentLoanRadioBtnCustomerDetail = async function(){
    return await loanRadioBtnCustomerDetail.isPresent();
}

this.selectLeaseRadioBtnCustomerDetail = async function(){
    await leaseRadioBtnCustomerDetail.click();
}

this.isPresentLeaseRadioBtnCustomerDetail = async function(){
    return await leaseRadioBtnCustomerDetail.isPresent();
}

this.setLoanAmountRemainingCustomerDetail = async function(){
    await loanAmountRemainingCustomerDetail.clear();
    await loanAmountRemainingCustomerDetail.sendKeys();
}

this.isPresentLoanAmountRemainingCustomerDetail = async function(){
    return await loanAmountRemainingCustomerDetail.isPresent();
}

this.setMonthlyPaymentCustomerDetail = async function(){
    await monthlyPaymentCustomerDetail.clear();
    await monthlyPaymentCustomerDetail.sendKeys();
}

this.isPresentMonthlyPaymentCustomerDetail = async function(){
    return await monthlyPaymentCustomerDetail.isPresent();
}

this.setNumberOfPaymentsCustomerDetail = async function(){
    await numberOfPaymentsCustomerDetail.clear();
    await numberOfPaymentsCustomerDetail.sendKeys();
}

this.isPresentNumberOfPaymentsCustomerDetail = async function(){
    return await numberOfPaymentsCustomerDetail.isPresent();
}

this.clickReplacementVehicleYesBtnCustomerDetail = async function(){
    await replacementVehicleYesBtnCustomerDetail.click();
}

this.isSelectedReplacementVehicleYesBtnCustomerDetail = async function(){
    var status = await replacementVehicleYesBtnCustomerDetail.getAttribute("class");
    if(status == "selected"){
        return true;
    }
    else{
        return false;
    }
}

this.clickReplacementVehicleNoBtnCustomerDetail = async function(){
    await replacementVehicleNoBtnCustomerDetail.click();
}

this.isSelectedReplacementVehicleNoBtnCustomerDetail = async function(){
    var status = await replacementVehicleNoBtnCustomerDetail.getAttribute("class");
    if(status == "selected"){
        return true;
    }
    else{
        return false;
    }
}

this.selectNewPurchaseRadioBtnCustomerDetail = async function(){
    await newPurchaseRadioBtnCustomerDetail.click();
}

this.isPresentNewPurchaseRadioBtnCustomerDetail = async function(){
    return await newPurchaseRadioBtnCustomerDetail.isPresent();
}

this.selectUsedPurchaseRadioBtnCustomerDetail = async function(){
    await usedPurchaseRadioBtnCustomerDetail.click();
}

this.isPresentUsedPurchaseRadioBtnCustomerDetail = async function(){
    return await usedPurchaseRadioBtnCustomerDetail.isPresent();
}

this.selectCPOPurchaseRadioBtnCustomerDetail = async function(){
    await cpoPurchaseRadioBtnCustomerDetail.click();
}

this.isPresentCPOPurchaseRadioBtnCustomerDetail = async function(){
    return await cpoPurchaseRadioBtnCustomerDetail.isPresent();
}

this.selectNotSurePurchaseRadioBtnCustomerDetail = async function(){
    await notSurePurchaseRadioBtnCustomerDetail.click();
}

this.isPresentNotSurePurchasedRadioBtnCustomerDetail = async function(){
    return await notSurePurchaseRadioBtnCustomerDetail.isPresent();
}

this.setYearInputCustomerDetail = async function(year){
    await yearInputCustomerDetail.clear();
    await yearInputCustomerDetail.sendKeys(year);
}

this.getYearInputCustomerDetail = async function(){
    return await yearInputCustomerDetail.getAttribute("ng-reflect-model");
}

this.isPresentYearInputCustomerDetail = async function(){
    return await yearInputCustomerDetail.isPresent();
}

this.setMakeInputCustomerDetail = async function(make){
    await makeInputCustomerDetail.clear();
    await makeInputCustomerDetail.sendKeys(make);
}

this.getMakeInputCustomerDetail = async function(){
    return await makeInputCustomerDetail.getAttribute("ng-reflect-model");
}

this.isPresentMakeInputCustomerDetail = async function(){
    return await makeInputCustomerDetail.isPresent();
}

this.setModelInputCustomerDetail = async function(model){
    await modelInputCustomerDetail.clear();
    await modelInputCustomerDetail.sendKeys(model);
}

this.getModelInputCustomerDetail = async function(){
    return await modelInputCustomerDetail.getAttribute("ng-reflect-model");
}

this.isPresentModelInputCustomerDetail = async function(){
    return await modelInputCustomerDetail.isPresent();
}

this.setTrimInputCustomerDetail = async function(trim){
    await trimInputCustomerDetail.clear();
    await trimInputCustomerDetail.sendKeys(trim); 
}

this.getTrimInputCustomerDetail = async function(){
    return await trimInputCustomerDetail.getAttribute("ng-reflect-model");
}

this.isPresentTrimInputCustomerDetail = async function(){
    return await trimInputCustomerDetail.isPresent();
}

this.setFirstNameConsumerModeCustomerDetail = async function(fname){
    await firstNameCustomerDetail.clear();
    await browser.sleep(browser.params.sleep.sleep5);
    await firstNameCustomerDetail.sendKeys(fname);
}

this.setLastNameConsumerModeCustomerDetail = async function(lname){
    await lastNameCustomerDetail.clear();
    await lastNameCustomerDetail.sendKeys(lname);
}

this.setPhoneConsumerModeCustomerDetail = async function(phone){
    await phoneCustomerDetail.clear();
    await phoneCustomerDetail.sendKeys(phone);

}

this.setZipCodeConsumerModeCustomerDetail = async function(zip){
    await zipCodeCustomerDetail.clear();
    await zipCodeCustomerDetail.sendKeys(zip);
}

this.setEmailConsumerModeCustomerDetail = async function(email){
    await emailCustomerDetail.clear();
    await emailCustomerDetail.sendKeys(email);
}

this.getFirstNameConsumerModeCustomerDetail = async function(){
    return await firstNameCustomerDetail.getAttribute("ng-reflect-model");
}

this.getLastNameConsumerModeCustomerDetail = async function(){
    return await lastNameCustomerDetail.getAttribute("ng-reflect-model");
}

this.getPhoneConsumerModeCustomerDetail = async function(){
    return await phoneCustomerDetail.getAttribute("ng-reflect-model");
}

this.getZipCodeConsumerModeCustomerDetail = async function(){
    return await zipCodeCustomerDetail.getAttribute("ng-reflect-model");
}

this.getEmailConsumerModeCustomerDetail = async function(){
    return await emailCustomerDetail.getAttribute("ng-reflect-model");
}

this.isDisabledReplacementVehicleYesBtnCustomerDetail  = async function(){
    return await replacementVehicleYesBtnCustomerDetail.getAttribute("disabled");
}

this.isDisabledCPORadioBtnCustomerDetail = async function(){
    return await cpoPurchaseRadioBtnCustomerDetail.getAttribute("disabled");
}

this.isDisabledYearInputCustomerDetail = async function(){
    return await yearInputCustomerDetail.getAttribute("disabled");
}

this.isDisabledMakeInputCustomerDetail = async function(){
    return await makeInputCustomerDetail.getAttribute("disabled");
}

this.isDisabledModelInputCustomerDetail = async function(){
    return await modelInputCustomerDetail.getAttribute("disabled");
}

this.isDisabledTrimInputCustomerDetail = async function(){
    return await trimInputCustomerDetail.getAttribute("disabled");
}


// ************************ Ground Appraisal ************************ 

var groundAppraisalTrimCheckBox = element(by.xpath("//inventory-checkbox-form-control[@ng-reflect-label='trim:']/*/*/inventory-checkbox"));
var groundAppraisalOdometerCheckBox = element(by.xpath("//inventory-checkbox-form-control[@ng-reflect-label='odometer:']/*/*/inventory-checkbox"));
var groundAppraisalConditionDisclosuresCheckBox = element(by.xpath("//inventory-checkbox-form-control[@ng-reflect-label='conditionDisclosures:']/*/*/inventory-checkbox"));
var groundAppraisalTrimContent = element(by.xpath("//inventory-checkbox-form-control[@ng-reflect-label='trim:']"));
var groundAppraisalOdometerContent = element(by.xpath("//inventory-checkbox-form-control[@ng-reflect-label='odometer:']"));
var groundAppraisalConditionDisclosuresContent = element(by.xpath("//inventory-checkbox-form-control[@ng-reflect-label='conditionDisclosures:']"));
var groundAppraisalConfirmAndGroundBtn = element(by.xpath("//pill-button[@ng-reflect-label='confirmAndGround']"));
var groundAppraisalCancelBtn = element(by.xpath("//cancel-pill-button[@ng-reflect-label='cancel']"));
var groundAppraisalBodyCDValue = element(by.xpath("//adjustments-list/div/*[text()='Body']/../adjustment-value"));
var groundAppraisalGlassCDValue = element(by.xpath("//adjustments-list/div/*[text()='Glass']/../adjustment-value"));
var groundAppraisalInteriorCDValue = element(by.xpath("//adjustments-list/div/*[text()='Interior']/../adjustment-value"));
var groundAppraisalTiresWheelsCDValue = element(by.xpath("//adjustments-list/div/*[text()='Tires & Wheels']/../adjustment-value"));
var groundAppraisalWarningLightsCDValue = element(by.xpath("//adjustments-list/div/*[text()='Warning Lights']/../adjustment-value"));
var groundAppraisalMechanicalCDValue = element(by.xpath("//adjustments-list/div/*[text()='Mechanical']/../adjustment-value"));
var groundAppraisalAftermarketCDValue = element(by.xpath("//adjustments-list/div/*[text()='Aftermarket']/../adjustment-value"));
var groundAppraisalOtherCDValue = element(by.xpath("//adjustments-list/div/*[text()='Other']/../adjustment-value"));
var groundAppraisalSuccessMessage = element(by.xpath("//*[text()='Successfully Grounded']"));
var groundAppraisalSuccessDateMessage = element(by.xpath("//*[text()='Successfully Grounded']/../../following-sibling::div[@class='description']/*/span"));
var groundAppraisalBackBtn = element(by.xpath("//cancel-pill-button[@ng-reflect-label='back']"));

this.isPresentGroundAppraisalSuccessMessage = async function(){
    return await groundAppraisalSuccessMessage.isPresent();
}

this.isPresentGroundAppraisalSuccessDateMessage = async function(){
    return await groundAppraisalSuccessDateMessage.isPresent();
}

this.getGroundAppraisalSuccessMessageValue = async function(){
    return await groundAppraisalSuccessMessage.getText();
}

this.getGroundAppraisalSuccessDateMessageValue = async function(){
    return await groundAppraisalSuccessDateMessage.getText();
}

this.clickGroundAppraisalBackBtn = async function(){
    await groundAppraisalBackBtn.click();
}

this.getGroundAppraisalBodyCDValue = async function(){
    return await groundAppraisalBodyCDValue.getAttribute("ng-reflect-value");
}

this.getGroundAppraisalGlassCDValue = async function(){
    return await groundAppraisalGlassCDValue.getAttribute("ng-reflect-value");
}

this.getGroundAppraisalInteriorCDValue = async function(){
    return await groundAppraisalInteriorCDValue.getAttribute("ng-reflect-value");
}

this.getGroundAppraisalTiresWheelsCDValue = async function(){
    return await groundAppraisalTiresWheelsCDValue.getAttribute("ng-reflect-value");
}

this.getGroundAppraisalWarningLightsCDValue = async function(){
    return await groundAppraisalWarningLightsCDValue.getAttribute("ng-reflect-value");
}

this.getGroundAppraisalMechanicalCDValue = async function(){
    return await groundAppraisalMechanicalCDValue.getAttribute("ng-reflect-value");
}

this.getGroundAppraisalAftermarketCDValue = async function(){
    return await groundAppraisalAftermarketCDValue.getAttribute("ng-reflect-value");
}

this.getGroundAppraisalDisclosuresCDValue = async function(){
    return await groundAppraisalOtherCDValue.getAttribute("ng-reflect-value");
}

this.getGroundAppraisalOtherCDValue = async function(){
    return await groundAppraisalOtherCDValue.getAttribute("ng-reflect-value");
}

this.getGroundAppraisalTrim = async function(){
    return await groundAppraisalTrimContent.getAttribute("ng-reflect-description");
}

this.getGroundAppraisalOdometer = async function(){
    return await groundAppraisalOdometerContent.getAttribute("ng-reflect-description");
}

this.clickGroundAppraisalTrimCheckBox = async function(){
    await groundAppraisalTrimCheckBox.click();
}

this.clickGroundAppraisalOdometerCheckBox = async function(){
    await groundAppraisalOdometerCheckBox.click();
}

this.clickGroundAppraisalConditionDisclosuresCheckBox = async function(){
    await groundAppraisalConditionDisclosuresCheckBox.click();
}

this.clickGroundAppraisalCancelBtn = async function(){
    await groundAppraisalCancelBtn.click();
}

this.clickGroundAppraisalConfirmAndGroundBtn = async function(){
    await groundAppraisalConfirmAndGroundBtn.click();

    //Check for Walk Me Screen
    await browser.sleep(browser.params.sleep.sleep10);
    if(await this.isPresentWalkMeAlreadyGroundedMsgDialog()){
        await this.closeWalkMeAlreadyGroundedMsgDialog();
    }

    if(await this.isPresentWalkMeGroundMsgDialog()){
        await this.closeWalkMeGroundMsgDialog();
    }
}


// ************************ Appraisals Tools Menu Screens ************************ 

var feedbackTitle = element(by.xpath("//*[@class='title'] [text()='Feedback']"));
var carFaxReportTitle = element(by.xpath("//*[@class='title'] [text()='CARFAX® Report']"));
var carFaxReportCloseBtn = element(by.xpath("//*[text()='CARFAX® Report']/following-sibling::i[text()='close ']"));
var autoCheckReportCloseBtn = element(by.xpath("//*[text()='AutoCheck® Report']/following-sibling::i[text()='close ']"));
var autoCheckReportTitle = element(by.xpath("//*[@class='title'] [text()='AutoCheck® Report']"));
var guideBooksScreenTitle = element(by.xpath("//*[@class='center'] [text()='Guidebooks']"));
var scorecardScreenTitle = element(by.xpath("//*[@class='center'] [text()='Scorecard']"));
var localMarketScreenTitle = element(by.xpath("//*[@class='center'] [text()='Local Market']"));
var galleryScreenTitle = element(by.xpath("//*[@class='center'] [text()='Gallery']"));
var recallsScreenTitle = element(by.xpath("//vehicle-recall/modal/div/header[text()=' Recalls ']"));


// ************************ Review & Send ************************ 
var reviewSendBtn = element(by.xpath("//div[text()='Review & Send']"));
//var offerAmountReviewSendScreenATBranding = element(by.xpath("//*[text()='Accu-Trade Instant Offer']/following-sibling::div"));
//var offerAmountReviewSendScreenTCBranding = element(by.xpath("//*[text()='True Cash Offer']/following-sibling::div"));

var offerAmountReviewSendScreen = element(by.xpath("//*[@class='pricing-container']/div[2]"));
var basePriceReviewSendScreen = element(by.xpath("//*[@class='base-price-container']/div[2]"));
//var conditionValueReviewSendScreen = element(by.xpath("//*[@ng-reflect-title='Condition']"));
var selectAction = element(by.xpath("//*[text()='Select Action']"));

var viewConditionReportLinkReviewSendScreen = element(by.xpath("//*[text()='View Condition Report']"));

this.clickSelectAction = async function(){
    await selectAction.click();
}

this.clickViewConditionReportLinkReviewSendScreen = async function(){
    await viewConditionReportLinkReviewSendScreen.click();
}

this.isPresentViewConditionReportLinkReviewSendScreen = async function(){
    return await viewConditionReportLinkReviewSendScreen.isPresent();
}

//*[@ng-reflect-title='Odometer']
//*[@ng-reflect-title='Options']
//*[@ng-reflect-title='Color']
//*[@ng-reflect-title='Keys']
//*[@ng-reflect-title='Bad VHR']
//*[@ng-reflect-title='Frame Damage']
//*[@ng-reflect-title='Original Owner']
//*[@ng-reflect-title='Service Status']
//*[@ng-reflect-title='Condition']
//*[@ng-reflect-title='Inventory Consultant Adjustmen']
// or //*[@class='condition-report']
var conditionReportReviewSendScreen = element(by.xpath("//*[text()='View Condition Report']"));
var prospectStartBtn = element(by.xpath("//pill-button[@ng-reflect-label='start']"));
var selectActionReviewSend = element(by.xpath("//*[text()='Select Action']"));
var groundVehicleBtn = element(by.xpath("//*[text()=' Ground ']"));
var increaseOfferBtn = element(by.xpath("//*[text()=' Increase Offer ']"));
var sendToCRMBtn = element(by.xpath("//*[text()=' Send to CRM ']"));
var sendToIASBtn = element(by.xpath("//*[text()=' Send to IAS ']"));
var sendToHVMSBtn = element(by.xpath("//*[text()=' Send to HVMS ']"));
var groundedMsg = element(by.xpath("//*[text()=' Grounded ']"));
var groundedCountdownTimer = element(by.xpath("//grounded-countdown-timer"));
//var disclosureConfirmationBtn = element(by.xpath("//button[text()='Confirm']"));
var disclosureConfirmationBtn = element(by.buttonText('Confirm'));
var disclosureConfirmationAlert = element(by.xpath("//disclosures-confirmation"));

//Get Accu-Trade or True Cash Offer
var getAccutradeInstantOfferBtn = element(by.xpath("//*[text()=' Get Instant Offer ']")); //Accutrade
var getTrueCarOfferBtn = element(by.xpath("//*[text()=' Get True Cash Offer ']")); //TrueCar
var getInstantCashOfferBtn = element(by.xpath("//*[text()=' Get Instant Cash Offer ']")); //Trader
var getOfferCheckBox = element(by.xpath("//checkbox"));
var getOfferSubmitBtn = element(by.xpath("//*[@ng-reflect-label='confirmAndGetOffer']"));
var getAccutradeInstantOfferSuccessMsg = element(by.xpath("//*[text()='Successfully Submitted']"));
var getOfferSuccessMsg = element(by.xpath("//*[text()='Successfully Submitted']"));
var getAccutradeInstantOfferSuccessDescriptionMsg = element(by.xpath("//*[text()='Successully Submitted']/../../following-sibling::div/translation/span"));
var getOfferSuccessDescriptionMsg = element(by.xpath("//*[text()='Successfully Submitted']/../../following-sibling::div/translation/span"));
//This vehicle was submitted for Accu-Trade Instant Offer on 10/20/2019.
var getAccutradeInstantOfferPendingMsg = element(by.xpath("//*[text()=' Accu-Trade Instant Offer Pending']"));
var getOfferBackBtn = element(by.xpath("//cancel-pill-button[@ng-reflect-label='back']"));
var getOfferAppraisalLabel = element(by.xpath("//section[@class='center']/div/div[text()='Offer']"));
var getOfferTermsConditionsLink = element(by.xpath("//a[contains(@ng-reflect-href, 'https://lyra-qa.accu-trade.com')]"));
var getOfferArbitrationLink = element(by.xpath("//a[contains(@ng-reflect-href, 'https://www.naaa.com')]"));

// For Branding
var getOfferBtnText = element(by.xpath("//selectable-options/div[@class='selectable-options']/div/standard-option/div/div[@class='label-and-description']/div[contains(text(),'Offer')][1]"));
//" Get Instant Offer "

var getOfferBtnDescription = element(by.xpath("//selectable-options/div[@class='selectable-options']/div/standard-option/div/div[@class='label-and-description']/div[contains(text(),'Offer')]/following-sibling::div[@class='description']"));
//Get a check for the Instant Offer amount

var getOfferScreenHeading = element(by.xpath("//div[contains(@ng-reflect-klass,'cta-title-row')]/div[@class='text']"));
//Get Instant Offer

var getOfferScreenTitle = element(by.xpath("//div[contains(@class,'form')]/div/div[@class='offer-title']"));
//Accu-Trade Instant Offer

var successfulOfferSubmissionMsgDescription = element(by.xpath("//div[contains(@class,'success')]/div[@class='description']"));
//This vehicle was submitted for Accu-Trade Instant Offer on 12/04/2019.

var getOfferPendingMsgStatusBar = element(by.xpath("//status-bar/div[contains(@class,'title')]"));
//" Accu-Trade Instant Offer Pending"


this.isPresentGetOfferBtn = async function(){
    return await getOfferBtnText.isPresent();
}

this.getOfferBtnText = async function(){
    return await getOfferBtnText.getText();
}

this.clickGetOfferBtn = async function(){
    await getOfferBtnText.click();
}

this.isPresentGetOfferBtnDescription = async function(){
    return await getOfferBtnDescription.isPresent();
}

this.getOfferBtnDescription = async function(){
    return await getOfferBtnDescription.getText();
}

this.isPresentGetOfferScreenHeading = async function(){
    return await getOfferScreenHeading.isPresent();
}

this.getOfferScreenHeading = async function(){
    return await getOfferScreenHeading.getText();
}

this.isPresentGetOfferScreenTitle = async function(){
    return await getOfferScreenTitle.isPresent();
}

this.getOfferScreenTitle = async function(){
    return await getOfferScreenTitle.getText();
}

this.isPresentSuccessfulOfferSubmissionMsgDescription = async function(){
    return await successfulOfferSubmissionMsgDescription.isPresent();
}

this.getSuccessfulOfferSubmissionMsgDescription = async function(){
    return await successfulOfferSubmissionMsgDescription.getText();
}

this.isPresentGetOfferPendingMsgStatusBar = async function(){
    return await getOfferPendingMsgStatusBar.isPresent();
}

this.getOfferPendingMsgStatusBar = async function(){
    return await getOfferPendingMsgStatusBar.getText();
}




//Increase Offer
//var increaseOfferBtn = element(by.xpath("//dock-button[@ng-reflect-text='Increase Offer']")); //Old UI
var increaseOfferAmountInput = element(by.xpath("//*[text()='Increase Offer Amount By']/following-sibling::input"));
var increaseOfferExpiresInput = element(by.xpath("//*[text()='Increase Offer Expires In']/following-sibling::input"));
var increaseOfferAgreementCheckBox = element(by.xpath("//*[@class='agreement']/*/*/mat-checkbox"));
var increaseOfferYesBtn = element(by.xpath("//*[@class='agreement']/*/*[text()='Yes']"));
var increaseOfferNextBtn = element(by.xpath("//pill-button[@ng-reflect-label='next']"));
var increaseOfferSendBtn = element(by.xpath("//pill-button[@ng-reflect-label='send']"));
var increaseOfferDoneBtn = element(by.xpath("//footer-button[@ng-reflect-text='Done']"));
var increaseOfferConfirmationMsg = element(by.xpath("//increase-offer-confirmation"));

var increaseOfferLabel = element(by.xpath("//increase-offer-pricing/div[contains(@class,'increase-offer-pricing')]/div[@class='main-offer']/div[@class='left']/div[@class='title']"));
//getText()=Accu-Trade Instant Offer

var increaseOfferDescription = element(by.xpath("//increase-offer-pricing/div[contains(@class,'increase-offer-pricing')]/div[@class='main-offer']/div[@class='left']/div[@class='message']"));
//getText()=If the Accu-Trade Instant Offer is expired, Dealer is responsible for the entire Updated Offer Amount

var updatedOfferLabel = element(by.xpath("//increase-offer-pricing/div[contains(@class,'increase-offer-pricing')]/div[@class='updated-offer']/div[@class='title']"));
//getText()=Updated Accu-Trade Instant Offer

var updatedOfferAgreementText = element(by.xpath("//increase-offer-pricing/div[//increase-offer-pricing/div[contains(@class,'increase-offer-pricing')]/div[@class='main-offer']/div[@class='left']/div[@class='message']]/div[@class='agreement']/div[@class='text']"));
//getText()=As an authorized representative of Amit Accu-Trade USSA Dealership, I acknowledge that I am responsible for any offer increase amount above the Accu-Trade Instant Offer amount and any extension of the offer period.

var increaseOfferConfirmationLabel = element(by.xpath("//increase-offer-message/div[contains(@class,'increase-offer-message')]/div[@class='title']/div[@class='text']"));
//getText()= Updated Accu-Trade Instant Offer:


this.isPresentIncreaseOfferLabel = async function(){
    return await increaseOfferLabel.isPresent();
}

this.getIncreaseOfferLabel = async function(){
    return await increaseOfferLabel.getText();
}


this.isPresentIncreaseOfferDescription = async function(){
    return await increaseOfferDescription.isPresent();
}

this.getIncreaseOfferDescription = async function(){
    return await increaseOfferDescription.getText();
}


this.isPresentUpdatedOfferLabel = async function(){
    return await updatedOfferLabel.isPresent();
}

this.getUpdatedOfferLabel = async function(){
    return await updatedOfferLabel.getText();
}


this.isPresentUpdatedOfferAgreementText = async function(){
    return await updatedOfferAgreementText.isPresent();
}

this.getUpdatedOfferAgreementText = async function(){
    return await updatedOfferAgreementText.getText();
}


this.isPresentIncreaseOfferConfirmationLabel = async function(){
    return await increaseOfferConfirmationLabel.isPresent();
}

this.getIncreaseOfferConfirmationLabel = async function(){
    return await increaseOfferConfirmationLabel.getText();
}








// ************************ Alerts  ************************ 
var alertMsgTxtLocator = "//*[@class='notification-text']";
var alertMsgText = element(by.xpath(alertMsgTxtLocator));

var cdAlertIndicator = element(by.xpath("//appraisal-price/i"));
var alertCloseBtn = element(by.xpath("//*[@class='notification-main']/following-sibling::i[@class='material-icons close']"));

this.closeAlertMsg = async function(){
    await alertCloseBtn.click();
}

this.getAlertMsgText = async function(){
    return await alertMsgText.getText();
}

this.isPresentAlertMsg = async function(){
    return await alertMsgText.isPresent();
}

this.isPresentCDAlertIndicator = async function(){
    return await cdAlertIndicator.isPresent();
}

this.getAlertMsgCount = async function(){
    return await element.all(by.xpath(alertMsgTxtLocator)).count();
}

// ************************ Chat  ************************ 

var chatLinkAlertMsg = element(by.xpath("//*[text()=' Start a chat now. ']"));
var chatWindowCloseBtn = element(by.xpath("//chat/modal/*[@class='modal-content open']/*[text()='close ']"));
var chatWindow = element(by.xpath("//chat/modal[@class='open']"));
var chatIcon = element(by.xpath("//actions-chat/*/chat-icon/mat-icon[text()='chat']"));
var chatAccutradeLogo = element(by.xpath("//chat-user-icon/img[@src='assets/images/logos/accutrade-logo-16-16.svg']"));


this.isPresentChatWindow = async function(){
    return await chatWindow.isPresent();
}

this.openChatWindowFromAlertMsg = async function(){
    await chatLinkAlertMsg.click();
}

this.openChatWindow = async function(){
    await chatIcon.click();
}

this.closeChatWindow = async function(){
    await chatWindowCloseBtn.click();
}

this.isPresentAccutradeLogoOnChatWindow = async function(){
    return await chatAccutradeLogo.isPresent();
}

// ************************ Appraisal Page Year Make Model ************************ 
//var appraisalVehicleDataYMM = element(by.xpath("//appraisal-vehicle-data/div[@class='year-make-model']"));
var appraisalVehicleDataYMM = element(by.xpath("//*[@class='year-make-model']"));
//var appraisalVehicleDataTrim = element(by.xpath("//appraisal-vehicle-data/form/select"));
var appraisalVehicleDataTrim = element(by.xpath("//*[@class='year-make-model']/following-sibling::masked-select/select"));
var appraisalVehicleDataSingleTrim = element(by.xpath("//*[@class='year-make-model']/following-sibling::div"));
var appraisalMileage = element(by.xpath("//div[@class='mileage']"));


    
// ************************ Upload Images ************************ 
//var uploadImageBtn = element(by.xpath('//appraisal-thumbnail'));
var uploadImageBtn = element(by.xpath("//appraisal-thumbnail/div[contains(@class,'add-images')]"));
var addPhotosBtn = element(by.xpath("//div[text()='Click to add photos']"));

// ************************ Price Bar ************************ 
var priceBar = element(by.xpath("//price-bar"));
var consumerPriceBar = element(by.xpath("//consumer-price-bar"));
var priceBarBlackBookTrimDropdown = element(by.xpath("//appraisal-price[@ng-reflect-label='Black Book']/div/masked-select/select"));
var priceBarBlueBookTrimDropdown = element(by.xpath("//appraisal-price[@ng-reflect-label='Kelly Blue Book']/div/masked-select/select"));
var priceBarNadaTrimDropdown = element(by.xpath("//appraisal-price[@ng-reflect-label='NADA']/div/masked-select/select"));

var offerPricePB = element(by.xpath("//appraisal-price[@ng-reflect-klass='target-trade']"));
var targetTradePB = element(by.xpath("//appraisal-price[@ng-reflect-klass='target-trade']"));
var targetAuctionPB = element(by.xpath("//appraisal-price[@ng-reflect-label='Target Auction']"));
var targetRetailPB = element(by.xpath("//appraisal-price[@ng-reflect-label='Target Retail']"));

var targetTradeTextPB = element(by.xpath("//appraisal-price[@ng-reflect-label='Target Trade']/div[@ng-reflect-klass='price-container']/div"));
var targetAuctionTextPB = element(by.xpath("//appraisal-price[@ng-reflect-label='Target Auction']/div[@ng-reflect-klass='price-container']/div"));
var targetRetailTextPB = element(by.xpath("//appraisal-price[@ng-reflect-label='Target Retail']/div[@ng-reflect-klass='price-container']/div"));



// ************************ Customer Detail Panel(Consumer Mode) ************************ 
var customerDetailPanel = element(by.xpath("//customer-detail-panel"));


// ************************ Guide Book ************************ 
var guidebookTab = element(by.xpath("//*[text()='Guidebooks']"));
var guidebookTrimDropdown = element(by.xpath("//*[text()='Trim:']/../masked-select/select"));
var guidebookRegionDropdown = element(by.xpath("//*[text()='Region:']/../masked-select/select"));
var guidebookOptionsEditDropdown = element(by.xpath("//*[text()='Edit']"));
var guidbook18InchWheelsOption = element(by.xpath("//selection-group-item[@ng-reflect-label='18-Inch Wheels']"));
var guidebookSelectedOptions = element(by.xpath("//div[@class='options-list']"));
var guidebookConditionDropdown = element(by.xpath("//*[text()='Condition:']/../following-sibling::masked-select/select"));
var firstGuidebook = element(by.xpath("//guidebook-tile[1]"));
var secondGuidebook = element(by.xpath("//guidebook-tile[2]"));
var thirdGuidebook = element(by.xpath("//guidebook-tile[3]"));
var fourthGuidebook = element(by.xpath("//guidebook-tile[4]"));

// ************************ Scorecard ************************ 
var scorecardBar = element(by.xpath("//appraisal-scorecard-bar"));
var vinScoreCard = element(by.xpath("//span[@class='vin']"));

//scorecard bar Icon
var scorecardBarOdometerIcon = element(by.xpath("//scorecard-odometer-icon/scorecard-icon/*[text()='network_check']"));
var scorecardBarOptionsIcon = element(by.xpath("//scorecard-options-icon/scorecard-icon/*[text()='offline_pin']"));
var scorecardBarVHRIcon = element(by.xpath("///scorecard-vhr-icon/scorecard-icon/*[text()='history']"));
var scorecardBarDamageIcon = element(by.xpath("//scorecard-damage-icon/scorecard-icon/*[text()='warning']"));
var scorecardBarDepreciationIcon = element(by.xpath("//scorecard-depreciation-icon/scorecard-icon/*[text()='trending_down']"));
var scorecardBarLocalDOMIcon = element(by.xpath("//scorecard-local-dom-icon/scorecard-icon/*[text()='date_range']"));
var scorecardBarMDSIcon = element(by.xpath("//scorecard-mds-icon/scorecard-icon/*[text()='insert_chart']"));
var scorecardBarConsumerInterestIcon = element(by.xpath("//scorecard-consumer-interest-icon/scorecard-icon/*[text()='face']"));
var scorecardBarCommonProblemsIcon = element(by.xpath("//scorecard-common-problems-icon/scorecard-icon/*[text()='error_outline']"));

//scorecard screen Icon
var scorecardScreenOdometerIcon = element(by.xpath("//scorecard-odometer-icon/scorecard-icon/*[text()='network_check']"));
var scorecardScreenOptionsIcon = element(by.xpath("//scorecard-options-icon/scorecard-icon/*[text()='offline_pin']"));
var scorecardScreenVHRIcon = element(by.xpath("///scorecard-vhr-icon/scorecard-icon/*[text()='history']"));
var scorecardScreenDamageIcon = element(by.xpath("//scorecard-damage-icon/scorecard-icon/*[text()='warning']"));
var scorecardScreenDepreciationIcon = element(by.xpath("//scorecard-depreciation-icon/scorecard-icon/*[text()='trending_down']"));
var scorecardScreenLocalDOMIcon = element(by.xpath("//scorecard-local-dom-icon/scorecard-icon/*[text()='date_range']"));
var scorecardScreenMDSIcon = element(by.xpath("//scorecard-mds-icon/scorecard-icon/*[text()='insert_chart']"));
var scorecardScreenConsumerInterestIcon = element(by.xpath("//scorecard-consumer-interest-icon/scorecard-icon/*[text()='face']"));
var scorecardScreenCommonProblemsIcon = element(by.xpath("//scorecard-common-problems-icon/scorecard-icon/*[text()='error_outline']"));

//scorecard screen label
var scorecardScreenOdometerLabel = element(by.xpath("//scorecard-odometer-icon/following-sibling::label"));
var scorecardScreenOptionsLabel = element(by.xpath("//scorecard-options-icon/following-sibling::label"));
var scorecardScreenVHRLabel = element(by.xpath("///scorecard-vhr-icon/following-sibling::label"));
var scorecardScreenDamageLabel = element(by.xpath("//scorecard-damage-icon/following-sibling::label"));
var scorecardScreenDepreciationLabel = element(by.xpath("//scorecard-depreciation-icon/following-sibling::label"));
var scorecardScreenLocalDOMLabel = element(by.xpath("//scorecard-local-dom-icon/following-sibling::label"));
var scorecardScreenMDSLabel = element(by.xpath("//scorecard-mds-icon/following-sibling::label"));
var scorecardScreenConsumerInterestLabel = element(by.xpath("//scorecard-consumer-interest-icon/following-sibling::label"));
var scorecardScreenCommonProblemsLabel = element(by.xpath("//scorecard-common-problems-icon/following-sibling::label"));

//scorecard screen value
var scorecardScreenOdometerValue = element(by.xpath("//scorecard-odometer-icon/following-sibling::*[text()='Odometer']/following-sibling::*"));
var scorecardScreenOptionsValue = element(by.xpath("//scorecard-options-icon/following-sibling::*[text()='Options']/following-sibling::*"));
var scorecardScreenVHRValue = element(by.xpath("//scorecard-vhr-icon/following-sibling::*[text()='VHR']/following-sibling::*"));
var scorecardScreenDamageValue = element(by.xpath("//scorecard-damage-icon/following-sibling::*[text()='Damage']/following-sibling::*"));
var scorecardScreenDepreciationValue = element(by.xpath("//scorecard-depreciation-icon/following-sibling::*[text()='Depreciation']/following-sibling::*"));
var scorecardScreenLocalDOMValue = element(by.xpath("//scorecard-local-dom-icon/following-sibling::*[text()='Local DOM']/following-sibling::*"));
var scorecardScreenMDSValue = element(by.xpath("//scorecard-mds-icon/following-sibling::*[text()='Market Day Supply']/following-sibling::*"));
var scorecardScreenConsumerInterestValue = element(by.xpath("//scorecard-consumer-interest-icon/following-sibling::*[text()='Consumer Interest']/following-sibling::*"));
var scorecardScreenCommonProblemsValue = element(by.xpath("//scorecard-common-problems-icon/following-sibling::*[text()='Common Problems']/following-sibling::*"));

//scorecard bar icon presence
this.isPresentScorecardBarOdometerIcon = async function(){return await scorecardBarOdometerIcon.isDisplayed();}
this.isPresentScorecardBarOptionsIcon = async function(){return await scorecardBarOptionsIcon.isDisplayed();}
this.isPresentScorecardBarVHRIcon = async function(){return await scorecardBarVHRIcon.isDisplayed();}
this.isPresentScorecardBarDamageIcon = async function(){return await scorecardBarDamageIcon.isDisplayed();}
this.isPresentScorecardBarDepreciationIcon = async function(){return await scorecardBarDepreciationIcon.isDisplayed();}
this.isPresentScorecardBarLocalDOMIcon = async function(){return await scorecardBarLocalDOMIcon.isDisplayed();}
this.isPresentScorecardBarMDSIcon = async function(){return await scorecardBarMDSIcon.isDisplayed();}
this.isPresentScorecardBarConsumerInterestIcon = async function(){return await scorecardBarConsumerInterestIcon.isDisplayed();}
this.isPresentScorecardBarCommonProblemsIcon = async function(){return await scorecardBarCommonProblemsIcon.isDisplayed();}

//scorecard bar icon color
this.getColorScorecardBarIcon = async function(icon){
    var classAttribute = "black";
    await utils.logInfo("Value of passed parameter icon is "+icon);
    switch(icon){
        case 'odometer':
            classAttribute = await scorecardBarOdometerIcon.getAttribute("class");
            break;
        case 'options':
            classAttribute = await scorecardBarOptionsIcon.getAttribute("class");
            break;
        case 'vhr':
            classAttribute = await scorecardBarVHRIcon.getAttribute("class");
            break;
        case 'damage':
            classAttribute = await scorecardBarDamageIcon.getAttribute("class");
            break;
        case 'depreciation':
            classAttribute = await scorecardBarDepreciationIcon.getAttribute("class");
            break;
        case 'local dom':
            classAttribute = await scorecardBarLocalDOMIcon.getAttribute("class");
            break;
        case 'dom':
            classAttribute = await scorecardBarLocalDOMIcon.getAttribute("class");
            break;
        case 'mds':
            classAttribute = await scorecardBarMDSIcon.getAttribute("class");
            break;
        case 'market day supply':
            classAttribute = await scorecardBarMDSIcon.getAttribute("class");
            break;
        case 'consumer interest':
            classAttribute = await scorecardBarConsumerInterestIcon.getAttribute("class");
            break;
        case 'common problems':
            classAttribute = await scorecardBarCommonProblemsIcon.getAttribute("class");
            break;
        default:
            await utils.logInfo("*** Error: Icon parameter value '"+icon+"' invalid - appraisalpage.getColorScorecardBarIcon(icon)");    
    }//switch

    await utils.logInfo("Value of Class Attribute is "+classAttribute);

    if(classAttribute.includes("yellow")){
        return "yellow";
    }
    else if(classAttribute.includes("red")){
        return "red";
    }
    else if(classAttribute.includes("green")){
        return "green";
    }
    else if(classAttribute.includes("grey")){
        return "grey";
    }
    else{
        return "black";
    } //if

}

//scorecard screen icon presence
this.isPresentScorecardScreenOdometerIcon = async function(){return await scorecardScreenOdometerIcon.isDisplayed();}
this.isPresentScorecardScreenOptionsIcon = async function(){return await scorecardScreenOptionsIcon.isDisplayed();}
this.isPresentScorecardScreenVHRIcon = async function(){return await scorecardScreenVHRIcon.isDisplayed();}
this.isPresentScorecardScreenDamageIcon = async function(){return await scorecardScreenDamageIcon.isDisplayed();}
this.isPresentScorecardScreenDepreciationIcon = async function(){return await scorecardScreenDepreciationIcon.isDisplayed();}
this.isPresentScorecardScreenLocalDOMIcon = async function(){return await scorecardScreenLocalDOMIcon.isDisplayed();}
this.isPresentScorecardScreenMDSIcon = async function(){return await scorecardScreenMDSIcon.isDisplayed();}
this.isPresentScorecardScreenConsumerInterestIcon = async function(){return await scorecardScreenConsumerInterestIcon.isDisplayed();}
this.isPresentScorecardScreenCommonProblemsIcon = async function(){return await scorecardScreenCommonProblemsIcon.isDisplayed();}

//scorecard screen icon color
this.getColorScorecardScreenIcon = async function(icon){
    var classAttribute = "black";
    await utils.logInfo("Value of passed parameter icon is "+icon);

    switch(icon){
        case 'odometer':
            classAttribute = await scorecardScreenOdometerIcon.getAttribute("class");
            break;
        case 'options':
            classAttribute = await scorecardScreenOptionsIcon.getAttribute("class");
            break;
        case 'vhr':
            classAttribute = await scorecardScreenVHRIcon.getAttribute("class");
            break;
        case 'damage':
            classAttribute = await scorecardScreenDamageIcon.getAttribute("class");
            break;
        case 'depreciation':
            classAttribute = await scorecardScreenDepreciationIcon.getAttribute("class");
            break;
        case 'local dom':
            classAttribute = await scorecardScreenLocalDOMIcon.getAttribute("class");
            break;
        case 'dom':
            classAttribute = await scorecardScreenLocalDOMIcon.getAttribute("class");
            break;
        case 'mds':
            classAttribute = await scorecardScreenMDSIcon.getAttribute("class");
            break;
        case 'market day supply':
            classAttribute = await scorecardScreenMDSIcon.getAttribute("class");
            break;
        case 'consumer interest':
            classAttribute = await scorecardScreenConsumerInterestIcon.getAttribute("class");
            break;
        case 'common problems':
            classAttribute = await scorecardScreenCommonProblemsIcon.getAttribute("class");
            break;
        default:
            await utils.logInfo("*** Error: Icon parameter value '"+icon+"' invalid - appraisalpage.getColorScorecardBarIcon(icon)");    
    }//switch

    await utils.logInfo("Value of Class Attribute is "+classAttribute);

    if(classAttribute.includes("yellow")){
        return "yellow";
    }
    else if(classAttribute.includes("red")){
        return "red";
    }
    else if(classAttribute.includes("green")){
        return "green";
    }
    else if(classAttribute.includes("grey")){
        return "grey";
    }
    else{
        return "black";
    } //if

}

//scorecard screen icon value
this.getValueScorecardScreenOdometer = async function(){return await scorecardScreenOdometerValue.getText();}
this.getValueScorecardScreenOptions = async function(){return await scorecardScreenOptionsValue.getText();}
this.getValueScorecardScreenVHR = async function(){return await scorecardScreenVHRValue.getText();}
this.getValueScorecardScreenDamage = async function(){return await scorecardScreenDamageValue.getText();}
this.getValueScorecardScreenDepreciation = async function(){return await scorecardScreenDepreciationValue.getText();}
this.getValueScorecardScreenLocalDOM = async function(){return await scorecardScreenLocalDOMValue.getText();}
this.getValueScorecardScreenMDS = async function(){return await scorecardScreenMDSValue.getText();}
this.getValueScorecardScreenConsumerInterest = async function(){return await scorecardScreenConsumerInterestValue.getText();}
this.getValueScorecardScreenCommonProblems = async function(){return await scorecardScreenCommonProblemsValue.getText();}

//scorecard screen icon label
this.getLabelScorecardScreenOdometer = async function(){return await scorecardScreenOdometerLabel.getText();}
this.getLabelScorecardScreenOptions = async function(){return await scorecardScreenOptionsLabel.getText();}
this.getLabelScorecardScreenVHR = async function(){return await scorecardScreenVHRLabel.getText();}
this.getLabelScorecardScreenDamage = async function(){return await scorecardScreenDamageLabel.getText();}
this.getLabelScorecardScreenDepreciation = async function(){return await scorecardScreenDepreciationLabel.getText();}
this.getLabelScorecardScreenLocalDOM = async function(){return await scorecardScreenLocalDOMLabel.getText();}
this.getLabelScorecardScreenMDS = async function(){return await scorecardScreenMDSLabel.getText();}
this.getLabelScorecardScreenConsumerInterest = async function(){return await scorecardScreenConsumerInterestLabel.getText();}
this.getLabelScorecardScreenCommonProblems = async function(){return await scorecardScreenCommonProblemsLabel.getText();}

this.openScorecardScreenByScorecardBar = async function(){
    await browser.waitForAngularEnabled(false); // *** Angular Disabled
    await this.scorecardBar.click();
    await browser.sleep(browser.params.sleep.sleep2);
}

this.openScorecardScreenByAppraisalMenu = async function(){
    await browser.waitForAngularEnabled(false); // *** Angular Disabled

    await utils.logInfo("Click on Main Appraisal Menu");
    await this.getAppraisalMenu();

    await utils.logInfo("Click on Scorecard Appraisal menu item to open Scorecard Screen");
    await this.clickScorecardAppraisalMenuItem();
    await browser.sleep(browser.params.sleep.sleep2);
}

// ************************* Unit History ***********************
var unitHistoryTab = element(by.xpath("//div[@ng-reflect-klass='tabs-container']/div/*[text()='Unit History']/.."));
var vinHistoryTab = element(by.xpath("//div[@ng-reflect-klass='tabs-container']/div/*[text()='VIN History']/.."));
var chartVINHistory = element(by.xpath("//unit-history-chart/highcharts-chart/div[@class='highcharts-container ']"));


this.clickFirstGuidebook = async function(){
    await firstGuidebook.click();
}

this.clickSecondGuidebook = async function(){
    await secondGuidebook.click();
}

this.clickThirdGuidebook = async function(){
    await thirdGuidebook.click();
}

this.clickFourthGuidebook = async function(){
    await fourthGuidebook.click();
}

this.isPresentPriceBarBlackBookTrimDropdown = async function(){
    return await priceBarBlackBookTrimDropdown.isPresent();
}

this.isPresentPriceBarBlueBookTrimDropdown = async function(){
    return await priceBarBlueBookTrimDropdown.isPresent();
}

this.isPresentPriceBarNadaTrimDropdown = async function(){
    return await priceBarNadaTrimDropdown.isPresent();
}

this.isPresentChartVINHistory = async function(){
    return await chartVINHistory.isPresent();
}

this.clickUnitHistoryTab = async function(){
    await unitHistoryTab.click();
}

this.clickVINHistoryTab = async function(){
    await vinHistoryTab.click();
}

this.isSelectedUnitHistoryTab = async function(){
    if((await unitHistoryTab.getAttribute("class")).includes("active")){
        return true;
    }
    else{
        return false;
    }

}

this.isSelectedVINHistoryTab = async function(){
    if((await vinHistoryTab.getAttribute("class")).includes("active")){
        return true;
    }
    else{
        return false;
    }
}

//************************ Apraisals Adjustment Values ************************
//Options Value
var optionsAmountValue = element(by.xpath("//*[@ng-reflect-title='Options']/formatted-price/*"));

//Keys Value
var keysValue = element(by.xpath("//*[@ng-reflect-title='Keys']/formatted-price/*"));

//Service Status Value
var serviceStatusAmountValue = element(by.xpath("//*[@ng-reflect-title='Service Status']/formatted-price/*"));

//Colors Value
var colorsValue = element(by.xpath("//*[@ng-reflect-title='Colors']/formatted-price/*"));

//Vehicle History Value
var vhsValue = element(by.xpath("//*[@ng-reflect-title='Vehicle History']/formatted-price/*"));

//Owners Dropdown
//var ownersDropdown = element(by.xpath("//original-owner-panel/select"));
var ownersDropdown = element(by.xpath("//original-owner-panel/section/select"));

//Number of Owners Value
var ownersValue = element(by.xpath("//*[@ng-reflect-title='Owner(s)']/formatted-price/*"));

//Condition Disclosures Value
var conditionDisclosuresValue = element(by.xpath("//*[@ng-reflect-title='Condition Disclosures']/formatted-price/*"));


//************************ Apraisals Adjustment Selection ************************

//Odometer
var odometerText = element(by.xpath("//input[@ng-reflect-name='odometer']"));
var lowMileageAlertLabel = element(by.xpath("//*[@class='low-mileage']/strong"));
var lowMileageAlertDesc = element(by.xpath("//*[@class='low-mileage']/span"));
var setToBaseOdometerLink = element(by.xpath("//a[text()='Set To Base']"));
var baseOdometerReading = element(by.xpath("//*[@ng-reflect-klass='base-mileage']"));

//Common Problems
var commonProblemLabel = element(by.xpath("//*[text()='Common Problems']"));

//Keys
var keysZeroBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='0']"));
var keysOneBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='1']"));
var keysTwoBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='2']"));
var keysThreeBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='3+']"));

//Colors
var intColorBtn = element(by.xpath("//color-picker[@ng-reflect-label='Interior']"));
var extColorBtn = element(by.xpath("//color-picker[@ng-reflect-label='Exterior']"));

//Exterior Color Buttons
var extBlackBtn = element(by.xpath("//color-picker-swatch[2]"));
var extWhiteBtn = element(by.xpath("//color-picker-swatch[3]"));
var intBlackBtn = element(by.xpath("//color-picker-swatch[2]"));
var intWhiteBtn = element(by.xpath("//color-picker-swatch[3]"));

//Vehicle History
var badVHRBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='Bad VHR']"));
var badFrameDamageBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='Frame Damage']"));

//Owners
var ownerDropDown = element(by.xpath("//panel-header[@ng-reflect-title='Owner(s)']/following-sibling::select"));

//Service Status
var serviceStatusOEMBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='OEM Certified']"));
var serviceStatusAsTradedBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='As Traded']"));
var serviceStatusFlunkedShopBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='Flunked Shop']"));
var serviceStatusRecordsBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='Service Records']"));

//Options
var options4WheelDriveBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='4 WHEEL DRIVE']"));
var optionsPowerWindowBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='POWER WINDOWS']"));
var optionsLabel = element(by.xpath("//options-panel/*[@ng-reflect-title='Options']"));

this.generateOptionsWebElement = function(option){
    var locator = "//adjustment-item[@ng-reflect-label='"+option+"']";
    return this.generateXpathWebElement(locator);
}

this.getOptionValue = async function(option){
    var optionWebElement = this.generateOptionsWebElement(option);
    var priceOptionWebElement = optionWebElement.element(by.tagName("formatted-price"));
    if(await priceOptionWebElement.isPresent()){
        return await priceOptionWebElement.getAttribute("ng-reflect-price");
    }
    else{
        return "0";
    }
}

this.selectOption = async function(option){
    var optionWebElement = this.generateOptionsWebElement(option);
    
    if(await optionWebElement.getAttribute("ng-reflect-checked") == "false"){
        await utils.logInfo("Select an option '"+option+"'");
        await optionWebElement.click();
    }
}

this.unselectOption = async function(option){
    var optionWebElement = this.generateOptionsWebElement(option);
    
    if(await optionWebElement.getAttribute("ng-reflect-checked") == "true"){
        await utils.logInfo("Unselect an option '"+option+"'");
        await optionWebElement.click();
    }
}

this.isSelectedOption = async function(option){
    var optionWebElement = this.generateOptionsWebElement(option);
    return await optionWebElement.getAttribute("ng-reflect-checked");
}

//Conditional Disclosure

//Body
var cdBodyTab = element(by.xpath("//condition-disclosures-menu-item[@ng-reflect-text='Body']"));

    var cdBodyHoodBtn = element(by.xpath("//*[@id='ext_hood']"));
    var cdBodyExtFrontBumperBtn = element(by.xpath("//*[@id='ext_front-bumper']"));
    var cdBodyExtFrontLeftLightBtn = element(by.xpath("//*[@id='ext_front-left-light']"));  
    var cdBodyExtFrontRightLightBtn = element(by.xpath("//*[@id='ext_front-right-light']"));
    var cdBodyExtRightBackDoorBtn = element(by.xpath("//*[@id='ext_right-back-door']")); 
    var cdBodyChippedDamageTypeBtn = element(by.xpath("//*[@ng-reflect-label='chipped']"));
    var cdBodyPrevReplacementDamageTypeBtn = element(by.xpath("//*[@ng-reflect-label='prev replacement']"));
    var cdBodyPrevReplacementWetSandDamageTypeBtn = element(by.xpath("//*[@ng-reflect-label='wet sand']"));

    
//Glass
var cdGlassTab = element(by.xpath("//condition-disclosures-menu-item[@ng-reflect-text='Glass']"));

    var cdGlassWindShieldBtn = element(by.xpath("//*[@id='ext_windshield']"));
    var cdGlassRearWindowBtn = element(by.xpath("//*[@id='ext_rear-window']"));
    var cdGlassRightFrontBtn = element(by.xpath("//*[@id='ext_right-front-glass']"));
    var cdGlassRightBackBtn = element(by.xpath("//*[@id='ext_right-back-glass']"));
    var cdGlassLeftFrontBtn = element(by.xpath("//*[@id='ext_left-front-glass']"));
    var cdGlassLeftBackBtn = element(by.xpath("//*[@id='ext_left-back-glass']"));
    
//Interior
var cdInteriorTab = element(by.xpath("//condition-disclosures-menu-item[@ng-reflect-text='Interior']"));

    var cdIntRightFrontDoorBtn = element(by.xpath("//*[@id='int_right-front-door-panel']"));
    var cdIntRightRearDoorBtn = element(by.xpath("//*[@id='int_right-rear-door-panel']"));
    var cdIntLeftFrontDoorBtn = element(by.xpath("//*[@id='int_left-front-door-panel']"));
    var cdIntLeftRearDoorBtn = element(by.xpath("//*[@id='int_left-rear-door-panel']"));
    var cdIntLeftFrontSeatBtn = element(by.xpath("//*[@id='int_left-front-seat']"));
    var cdIntRightFrontSeatBtn = element(by.xpath("//*[@id='int_right-front-seat']"));
    var cdIntLeftRearSeatBtn = element(by.xpath("//*[@id='int_left-rear-seat']"));
    var cdIntRightRearSeatBtn = element(by.xpath("//*[@id='int_right-rear-seat']"));
    var cdIntCenterConsoleBtn = element(by.xpath("//*[@id='int_center-console']"));
    var cdIntGloveBoxBtn = element(by.xpath("//*[@id='int_glove-box']"));

//Tires
//var cdTireWheelTab = element(by.xpath("//condition-disclosures-menu-item[@ng-reflect-text='Tires']"));
var cdTireWheelTab = element(by.xpath("//condition-disclosures-menu-item[contains(@ng-reflect-text,'Tire')]"));



    //Front Right
    var cdTiresFRZeroBtn = element(by.xpath("//*[text()='Front Right']/../following-sibling::div/adjustment-item[@ng-reflect-label='0 - 3/32']"));
    var cdTiresFRFourBtn = element(by.xpath("//*[text()='Front Right']/../following-sibling::div/adjustment-item[@ng-reflect-label='4/32 - 7/32']"));
    var cdTiresFREightBtn = element(by.xpath("//*[text()='Front Right']/../following-sibling::div/adjustment-item[@ng-reflect-label='8/32 +']"));
    var cdTiresFRCurbRashBtn = element(by.xpath("//*[text()='Front Right']/../following-sibling::div/adjustment-item[@ng-reflect-label='curb rash']"));
    var cdTiresFRNonStdWheelBtn = element(by.xpath("//*[text()='Front Right']/../following-sibling::div/adjustment-item[@ng-reflect-label='non-standard wheel']"));
    var cdTiresFRReplaceWheelBtn = element(by.xpath("//*[text()='Front Right']/../following-sibling::div/adjustment-item[@ng-reflect-label='replace wheel']"));
    var cdTiresFROxidizedBtn = element(by.xpath("//*[text()='Front Right']/../following-sibling::div/adjustment-item[@ng-reflect-label='oxidized']"));
    var cdTiresFRMismatchedBtn = element(by.xpath("//*[text()='Front Right']/../following-sibling::div/adjustment-item[@ng-reflect-label='mismatched']"));
    var cdTiresFRHubcapMissingBtn = element(by.xpath("//*[text()='Front Right']/../following-sibling::div/adjustment-item[@ng-reflect-label='hubcap missing']"));
    var cdTiresFRReplaceBtn = element(by.xpath("//*[text()='Front Right']/../following-sibling::div/adjustment-item[@ng-reflect-label='replace tire']"));

    //Front Left
    var cdTiresFLZeroBtn = element(by.xpath("//*[text()='Front Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='0 - 3/32']"));
    var cdTiresFLFourBtn = element(by.xpath("//*[text()='Front Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='4/32 - 7/32']"));
    var cdTiresFLEightBtn = element(by.xpath("//*[text()='Front Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='8/32 +']"));
    var cdTiresFLCurbRashBtn = element(by.xpath("//*[text()='Front Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='curb rash']"));
    var cdTiresFLNonStdWheelBtn = element(by.xpath("//*[text()='Front Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='non-standard wheel']"));
    var cdTiresFLReplaceWheelBtn = element(by.xpath("//*[text()='Front Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='replace wheel']"));
    var cdTiresFLOxidizedBtn = element(by.xpath("//*[text()='Front Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='oxidized']"));
    var cdTiresFLMismatchedBtn = element(by.xpath("//*[text()='Front Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='mismatched']"));
    var cdTiresFLHubcapMissingBtn = element(by.xpath("//*[text()='Front Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='hubcap missing']"));
    var cdTiresFLReplaceBtn = element(by.xpath("//*[text()='Front Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='replace tire']"));

    //Rear Right
    var cdTiresRRZeroBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='0 - 3/32']"));
    var cdTiresRRFourBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='4/32 - 7/32']"));
    var cdTiresRREightBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='8/32 +']"));
    var cdTiresRRCurbRashBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='curb rash']"));
    var cdTiresRRNonStdWheelBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='non-standard wheel']"));
    var cdTiresRRReplaceWheelBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='replace wheel']"));
    var cdTiresRROxidizedBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='oxidized']"));
    var cdTiresRRMismatchedBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='mismatched']"));
    var cdTiresRRHubcapMissingBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='hubcap missing']"));
    var cdTiresRRReplaceBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='replace tire']"));

    //Rear Left
    var cdTiresRLZeroBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='0 - 3/32']"));
    var cdTiresRLFourBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='4/32 - 7/32']"));
    var cdTiresRLEightBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='8/32 +']"));
    var cdTiresRLCurbRashBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='curb rash']"));
    var cdTiresRLNonStdWheelBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='non-standard wheel']"));
    var cdTiresRLReplaceWheelBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='replace wheel']"));
    var cdTiresRLOxidizedBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='oxidized']"));
    var cdTiresRLMismatchedBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='mismatched']"));
    var cdTiresRLHubcapMissingBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='hubcap missing']"));
    var cdTiresRLReplaceBtn = element(by.xpath("//*[text()='Rear Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='replace tire']"));
    
//Lights
var cdLightsTab = element(by.xpath("//condition-disclosures-menu-item[@ng-reflect-text='Lights']"));

    var cdLightsABSBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='ABS']"));
    var cdLightsBatteryBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='Battery']"));
    var cdLightsBrakeBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='Brake']"));
    var cdLightsEngineBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='Engine']"));
    var cdLightsAirbagBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='Airbag/SRS']"));
    var cdLightsSuspensionFaultBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='Suspension Fault']"));
    var cdLightsTPMSBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='TPMS']"));
    var cdLightsTractionBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='Traction']"));


//Mechanical
var cdMechanicalTab = element(by.xpath("//condition-disclosures-menu-item[@ng-reflect-text='Mechanical']"));

    var cdMechanicalRoofInopBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='Roof Inop']"));
    var cdMechanicalSteeringBtn = element(by.xpath("//adjustment-item[@ng-reflect-label='Steering']"));
    var cdMechanicalSuspensionBtn = element(by.xpath("//condition-disclosures-mechanical/*/adjustment-item[@ng-reflect-label='Suspension']"));
    var cdMechanicalBrakesBtn = element(by.xpath("//condition-disclosures-mechanical/*/adjustment-item[@ng-reflect-label='Brakes']"));
    var cdMechanicalExhaustBtn = element(by.xpath("//condition-disclosures-mechanical/*/adjustment-item[@ng-reflect-label='Exhaust']"));
    var cdMechanicalElectricalBtn = element(by.xpath("//condition-disclosures-mechanical/*/adjustment-item[@ng-reflect-label='Electrical']"));
    var cdMechanicalTransmissionBtn = element(by.xpath("//condition-disclosures-mechanical/*/adjustment-item[@ng-reflect-label='Transmission']"));
    var cdMechanicalACBtn = element(by.xpath("//condition-disclosures-mechanical/*/adjustment-item[@ng-reflect-label='AC']"));
    var cdMechanicalOilLeakBtn = element(by.xpath("//condition-disclosures-mechanical/*/adjustment-item[@ng-reflect-label='Oil Leak']"));
    var cdMechanicalHeadGasketBtn = element(by.xpath("//condition-disclosures-mechanical/*/adjustment-item[@ng-reflect-label='Head Gasket']"));
    var cdMechanicalCatalyticConverterBtn = element(by.xpath("//condition-disclosures-mechanical/*/adjustment-item[@ng-reflect-label='Catalytic Converter']"));
    var cdMechanicalTimingChainBtn = element(by.xpath("//condition-disclosures-mechanical/*/adjustment-item[@ng-reflect-label='Timing Chain']"));
    var cdMechanicalTopEndNoiseBtn = element(by.xpath("//condition-disclosures-mechanical/*/adjustment-item[@ng-reflect-label='Top End Noise']"));
    var cdMechanicalTurboBtn = element(by.xpath("//condition-disclosures-mechanical/*/adjustment-item[@ng-reflect-label='Turbo']"));

    this.isDisabledCDMechanicalRoofInopBtn = async function(){
        return await cdMechanicalRoofInopBtn.getAttribute("ng-reflect-read-only");
    }

    this.isDisabledCDMechanicalSteeringBtn = async function(){
        return await cdMechanicalSteeringBtn.getAttribute("ng-reflect-read-only");
    }

    this.clickCDMechanicalRoofInopBtn = async function(){
        await cdMechanicalRoofInopBtn.click();
    }

    this.clickCDMechanicalSteeringBtn = async function(){
        await cdMechanicalSteeringBtn.click();
    }
    
//Aftermarket
var cdAfterMarketTab = element(by.xpath("//condition-disclosures-menu-item[@ng-reflect-text='Aftermarket']"));

    var cdAfterMarketStereoBtn = element(by.xpath("//condition-disclosures-aftermarket/*/adjustment-item[@ng-reflect-label='Stereo']"));
    var cdAfterMarketPerformanceBtn = element(by.xpath("//condition-disclosures-aftermarket/*/adjustment-item[@ng-reflect-label='Performance']"));
    var cdAfterMarketWheelBtn = element(by.xpath("//condition-disclosures-aftermarket/*/adjustment-item[@ng-reflect-label='Wheel/Tire']"));
    var cdAfterMarketSuspensionRaisedBtn = element(by.xpath("//condition-disclosures-aftermarket/*/adjustment-item[@ng-reflect-label='Suspension Raised']"));
    var cdAfterMarketSuspensionLoweredBtn = element(by.xpath("//condition-disclosures-aftermarket/*/adjustment-item[@ng-reflect-label='Suspension Lowered']"));
    var cdAfterMarketSunroofBtn = element(by.xpath("//condition-disclosures-aftermarket/*/adjustment-item[@ng-reflect-label='Sunroof/Moonroof']"));
    var cdAfterMarketTintBtn = element(by.xpath("//condition-disclosures-aftermarket/*/adjustment-item[@ng-reflect-label='Aftermarket Tint']"));
    var cdAfterMarketExhaustBtn = element(by.xpath("//condition-disclosures-aftermarket/*/adjustment-item[@ng-reflect-label='Exhaust']"));
    var cdAfterMarketSpoilerBtn = element(by.xpath("//condition-disclosures-aftermarket/*/adjustment-item[@ng-reflect-label='Spoiler']"));
    var cdAfterMarketPhotoBtn = element(by.xpath("//aftermarket-disclosures/photo-set[@ng-reflect-type='aftermarket']/button"));

//Other
var cdOtherTab = element(by.xpath("//condition-disclosures-menu-item[@ng-reflect-text='Other']"));

    var cdOtherPreviousCanadianBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='Previous Canadian']"));
    var cdOtherSmokeOdorBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='Smoke/Odor']"));
    var cdOtherAirbagBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='Airbag Previously Deployed']"));
    var cdOtherOpenRecallsBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='Open Recalls']"));
    var cdOtherPreviousRentalBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='Previous Rental/Fleet']"));
    var cdOtherPreviousLiveryBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='Previous Livery']"));
    var cdOtherSoldAuction45DaysBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='Sold at auction in last 45 day']"));
    var cdOtherPreviouslyArbitratedBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='Previously Arbitrated']"));
    var cdOtherSalvageBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='Salvage']"));
    var cdOtherLemonLawsBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='Lemon Laws']"));
    var cdOtherWaterDamageBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='Water Damge']"));
    var cdOtherFireDamageBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='Fire Damage']"));
    var cdOtherStolenRecoveredBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='Stolen/Recovered']"));
    var cdOtherHailDamageBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='Hail Damage']"));
    var cdOtherAirbagDeployedBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='Airbag Currently Deployed']"));
    var cdOtherTMUBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='TMU']"));
    var cdOtherLightRustBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='Light Rust']"));
    var cdOtherMediumRustBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='Medium Rust']"));
    var cdOtherHeavyRustBtn = element(by.xpath("//condition-disclosures-other/*/adjustment-item[@ng-reflect-label='Heavy Rust']"));
    
    var cdDamageFirstListItemInput = element(by.xpath("//damage-list-item[1]/*/input"));
    var cdDamageFirstListItemInputLabel = element(by.xpath("//damage-list-item[1]/*/input/preceding-sibling::div"));
    var cdDamageListItemInput = element(by.xpath("//damage-list-item/*/input"));
    var cdDamageListItemInputLabel = element(by.xpath("//damage-list-item/*/input/preceding-sibling::div"));


    this.isPresentCDBodyTab = async function(){
        return await cdBodyTab.isPresent();
    }

    this.getVehicleDataYMMWebElement = function(){
        return appraisalVehicleDataYMM;
    }

    this.getCDDamageFirstListItemInputValue = async function(){
        return await cdDamageFirstListItemInput.getAttribute("ng-reflect-model");
    }

    this.getCDDamageFirstListItemInputLabel = async function(){
        return await cdDamageFirstListItemInputLabel.getText();
    }

    this.clickBackArrowBtn = async function(){
        await backArrowBtn.click();
    }

    this.isPresentGroundedAppraisalLabel = async function(){
        return await groundedAppraisalLabel.isPresent();
    }

    this.isPresentGroundedCountdownTimer = async function(){
        return await groundedCountdownTimer.isPresent();
    }

    this.isPresentGroundedMsg = async function(){
        return await groundedMsg.isPresent();
    }

    this.getOfferValuePriceBar = async function(){
        return await offerPricePB.getAttribute("ng-reflect-price");
    }

    this.getTargetTradeValuePriceBar = async function(){
        return await targetTradePB.getAttribute("ng-reflect-price");
    }

    this.getTargetAuctionValuePriceBar = async function(){
        return await targetAuctionPB.getAttribute("ng-reflect-price");
    }

    this.getTargetRetailValuePriceBar = async function(){
        return await targetRetailPB.getAttribute("ng-reflect-price");
    }

    this.getTargetTradeTextPriceBar = async function(){
        return await targetTradeTextPB.getText();
    }

    this.getTargetAuctionTextPriceBar = async function(){
        return await targetAuctionTextPB.getText();
    }

    this.getTargetRetailTextPriceBar = async function(){
        return await targetRetailTextPB.getText();
    }

    this.isPresentPriceBarBar = async function(){
        return await priceBar.isPresent();
    }

    this.isPresentConsumerPriceBarBar = async function(){
        return await consumerPriceBar.isPresent();
    }

    this.isPresentCustomerDetailPanel = async function(){
        return await customerDetailPanel.isPresent();
    }

    this.isPresentAssignedToModify = async function(){
        return await assignedToModify.isPresent();
    }
    
    this.isPresentAssignedToDealershipPersonName = async function(){
        return await assignedToDealershipPersonName.isPresent();
    }
    
    this.isPresentAssignedToDealershipName = async function(){
        return await assignedToDealershipName.isPresent();
    }
    
    // this.isPresentAppraisalMenuEmail = async function(){
    //     return await emailAppraisalMenu.isPresent();
    // }
    
    this.isPresentConsumerAppraisalMenuItem = async function(){
        return await consumerAppraisalMenuItem.isPresent();
    }
    
    this.isPresentDealershipAppraisalMenuItem = async function(){
        return await dealerAppraisalMenuItem.isPresent();
    }
    
    this.isPresentCustomerInfoMenuItem = async function(){
        return await customerInfoMenuItem.isPresent();
    }

    this.isPresentGuidebookAppraisalMenuItem = async function(){
        return await guidebookAppraisalMenuItem.isPresent();
    }

    this.isPresentScorecardAppraisalMenuItem = async function(){
        return await scorecardAppraisalMenuItem.isPresent();
    }

    this.isPresentLocalMarketAppraisalMenuItem = async function(){
        return await localMarketAppraisalMenuItem.isPresent();        
    }

    this.isPresentPhotoGalleryAppraisalMenuItem = async function(){
        return await photoGalleryAppraisalMenuItem.isPresent();        
    }

    this.isPresentRecallNotesAppraisalMenuItem = async function(){
        return await recallNotesAppraisalMenuItem.isPresent();        
    }
    
    this.isPresentAppraisalNotesMenuItem = async function(){
        return await appraisalNotesMenuItem.isPresent();
    }
    
    this.isPresentUnitHistoryMenuItem = async function(){
        return await unitHistoryMenuItem.isPresent();
    }
    
    this.isPresentCopyAppraisalMenuItem = async function(){
        return await copyAppraisalMenuItem.isPresent();
    }
    
    this.isPresentAppraisalMenuEmail = async function(){
        return await shareEmail.isPresent();
    }
    
    this.isPresentAppraisalMenuSMS = async function(){
        return await shareSMS.isPresent();
    }

    this.isPresentCarfaxAppraisalMenuItem = async function(){
        return await carfaxAppraisalMenuItem.isPresent();
    }

    this.isPresentAutocheckAppraisalMenuItem = async function(){
        return await autocheckAppraisalMenuItem.isPresent();
    }

    this.isPresentFeedbackAppraisalMenuItem = async function(){
        return await giveFeedback.isPresent();
    }
    
    this.isPresentGoogleVIN = async function(){
        return await googleVIN.isPresent();
    }
    
    this.isPresentCopyVIN = async function(){
        return await copyVIN.isPresent();
    }

    this.clickCopyVIN = async function(){
        await copyVIN.click();
    }
    
    this.isPresentOpenMMR = async function(){
        return await openMMR.isPresent();
    }

    this.isPresentAftermarketPhotoButton = async function(){
        return await cdAfterMarketPhotoBtn.isPresent();
    }

    this.clickAftermarketPhotoButton = async function(){
        await cdAfterMarketPhotoBtn.click();
    }

    this.clickFeedbackAppraisalMenuItem = async function(){
        await giveFeedback.click();
    }
    
    this.clickConsumerAppraisalMenuItem = async function(){
        await consumerAppraisalMenuItem.click();
    }
    
    this.clickDealerAppraisalMenuItem = async function(){
        await dealerAppraisalMenuItem.click();
    }

    this.clickCarfaxAppraisalMenuItem = async function(){
        await carfaxAppraisalMenuItem.click();
    }

    this.clickGuidebookAppraisalMenuItem = async function(){
        await guidebookAppraisalMenuItem.click();
    }

    this.clickScorecardAppraisalMenuItem = async function(){
        await scorecardAppraisalMenuItem.click();
    }

    this.clickLocalMarketAppraisalMenuItem = async function(){
        await localMarketAppraisalMenuItem.click();        
    }

    this.clickPhotoGalleryAppraisalMenuItem = async function(){
        await photoGalleryAppraisalMenuItem.click();        
    }

    this.clickRecallNotesAppraisalMenuItem = async function(){
        await recallNotesAppraisalMenuItem.click();        
    }

    this.clickAutocheckAppraisalMenuItem = async function(){
        await autocheckAppraisalMenuItem.click();
    }
    
    this.clickCustomerInfoMenuItem = async function(){
        await customerInfoMenuItem.click();
    }
    
    this.clickAppraisalNotesMenuItem = async function(){
        await appraisalNotesMenuItem.click();
    }
    
    this.clickUnitHistoryMenuItem = async function(){
        await unitHistoryMenuItem.click();
    }
    
    this.clickCopyAppraisalMenuItem = async function(){
        await copyAppraisalMenuItem.click();
    }
    
    this.isPresentFirstNameLabelCustomerInfo = async function(){
        return await customerFirstNameLabel.isPresent();
    }

    this.isPresentFirstNameInputCustomerDetail = async function(){
        return await firstNameCustomerDetail.isPresent();
    }


    this.setFirstNameCustomerInfo = async function(firstname){
        await firstNameInputCustomerInfo.clear();
        await firstNameInputCustomerInfo.sendKeys(firstname);
    }

    this.getFirstNameCustomerInfo = async function(){
        return await firstNameInputCustomerInfo.getAttribute("ng-reflect-model");
    }

    this.isDisabledFirstNameCustomerInfo = async function(){
        return await firstNameInputCustomerInfo.getAttribute("disabled");
    }

    this.setLastNameCustomerInfo = async function(lastname){
        await lastNameInputCustomerInfo.clear();
        await lastNameInputCustomerInfo.sendKeys(lastname);
    }

    this.getLastNameCustomerInfo = async function(){
        return await lastNameInputCustomerInfo.getAttribute("ng-reflect-model");
    }

    this.isDisabledLastNameCustomerInfo = async function(){
        return await lastNameInputCustomerInfo.getAttribute("disabled");
    }

    this.setZipCodeCustomerInfo = async function(zipcode){
        await zipCodeCustomerInfo.clear();
        await zipCodeCustomerInfo.sendKeys(zipcode);
    }

    this.getZipCodeCustomerInfo = async function(){
        return await zipCodeCustomerInfo.getAttribute("ng-reflect-model");
    }

    this.isDisabledZipCodeCustomerInfo = async function(){
        return await zipCodeCustomerInfo.getAttribute("disabled");
    }

    this.setPrimaryPhoneCustomerInfo = async function(primaryphone){
        await primaryPhoneCustomerInfo.clear();
        await primaryPhoneCustomerInfo.sendKeys(primaryphone);
    }

    this.getPrimaryPhoneCustomerInfo = async function(){
        return await primaryPhoneCustomerInfo.getAttribute("ng-reflect-model");
    }

    this.isDisabledPrimaryPhoneCustomerInfo = async function(){
        return await primaryPhoneCustomerInfo.getAttribute("disabled");
    }


    this.setEmailAddressCustomerInfo = async function(emailaddress){
        await emailAddressCustomerInfo.clear();
        await emailAddressCustomerInfo.sendKeys(emailaddress)
    }

    this.getEmailAddressCustomerInfo = async function(){
        return await emailAddressCustomerInfo.getAttribute("ng-reflect-model");
    }

    this.isDisabledEmailAddressCustomerInfo = async function(){
        return await emailAddressCustomerInfo.getAttribute("disabled");
    }

    this.setPriceDealerPurchasedFromCustomerInfo = async function(price){
        await priceDealerPurchasedFromCustomerInfo.clear();
        await priceDealerPurchasedFromCustomerInfo.sendKeys(price);
    }

    this.getPriceDealerPurchasedFromCustomerInfo = async function(){
        return await priceDealerPurchasedFromCustomerInfo.getAttribute("ng-reflect-model");
    }

    this.isDisabledPriceDealerPurchasedFromCustomerInfo = async function(){
        return await priceDealerPurchasedFromCustomerInfo.getAttribute("disabled");
    }

    this.setDealerOfferCustomerInfo = async function(dealeroffer){
        await dealerOfferCustomerInfo.clear();
        await dealerOfferCustomerInfo.sendKeys(dealeroffer);
    }

    this.getDealerOfferCustomerInfo = async function(){
        return await dealerOfferCustomerInfo.getAttribute("ng-reflect-model");
    }

    this.isDisabledDealerOfferCustomerInfo = async function(){
        return await dealerOfferCustomerInfo.getAttribute("disabled");
    }

    this.setRedemptionCodeCustomerInfo = async function(code){
        await redemptionCodeCustomerInfo.clear();
        await redemptionCodeCustomerInfo.sendKeys(code);
    }

    this.getRedemptionCodeCustomerInfo = async function(){
        return await redemptionCodeCustomerInfo.getAttribute("ng-reflect-model");
    }

    this.isDisabledRedemptionCodeCustomerInfo = async function(){
        return await redemptionCodeCustomerInfo.getAttribute("disabled");
    }


    this.getMaxLengthRedemptionCodeCustomerInfo = async function(){
        return await redemptionCodeCustomerInfo.getAttribute("maxlength");
    }

    this.setStatusCustomerInfo = async function(status){
        switch(status){
            case 'Open':
            case 'open':
            case 'OPEN':    
                await openStatusBtnCustomerInfo.click();
                break;
            case 'Won':
            case 'won':
            case 'WON':        
                await wonStatusBtnCustomerInfo.click();
                break;
            case 'Lost':
            case 'lost':
            case 'LOST':        
                await lostStatusBtnCustomerInfo.click();
                break;        
        }
    }

    this.isSelectedOpenStatusBtnCustomerInfo = async function(){
        return (await openStatusBtnCustomerInfo.getAttribute("class") == "selected" ? true : false);
    }

    this.isSelectedWonStatusBtnCustomerInfo = async function(){
        return (await wonStatusBtnCustomerInfo.getAttribute("class") == "selected" ? true : false);
    }

    this.isSelectedLostStatusBtnCustomerInfo = async function(){
        return (await lostStatusBtnCustomerInfo.getAttribute("class") == "selected" ? true : false);
    }

    this.setLostReasonCustomerInfo = async function(reason){
        await utils.logInfo("Inside setLostReasonCustomerInfo("+reason+")");
        switch(reason){
            case "Closed after 30 days":
                await utils.logInfo("Inside case:("+reason+")");
                await lostReasonCustomerInfo.$('[value="1"]').click();
                break;
            case "Appraisal too low":
                await utils.logInfo("Inside case:("+reason+")");
                await lostReasonCustomerInfo.$('[value="2"]').click();
                break;
            case "Negative Equity":
                await utils.logInfo("Inside case:("+reason+")");
                await lostReasonCustomerInfo.$('[value="3"]').click();
                break;
            case "No Approval":
                await utils.logInfo("Inside case:("+reason+")");
                await lostReasonCustomerInfo.$('[value="4"]').click();
                break;
            case "Sold Dealer":
                await utils.logInfo("Inside case:("+reason+")");
                await lostReasonCustomerInfo.$('[value="5"]').click();
                break;
            case "Sold Private":
                await utils.logInfo("Inside case:("+reason+")");
                await lostReasonCustomerInfo.$('[value="6"]').click();
                break;
            case "Undecided":
                await utils.logInfo("Inside case:("+reason+")");
                await lostReasonCustomerInfo.$('[value="7"]').click();
                break;
            case "Other":
                await utils.logInfo("Inside case:("+reason+")");
                await lostReasonCustomerInfo.$('[value="8"]').click();
                break;
            case "Archived by user":
                await utils.logInfo("Inside case:("+reason+")");
                await lostReasonCustomerInfo.$('[value="9"]').click();
                break;            
            default:
                await utils.logInfo("The setLostReasonCustomerInfo() function parameter: '"+reason+"' is invalid");    
            } //switch
    }

    this.getLostReasonCustomerInfo = async function(){
        return await lostReasonCustomerInfo.$('option:checked').getText();
    }

    this.isDisabledLostReasonCustomerInfo = async function(){
        return await lostReasonCustomerInfo.getAttribute("disabled");
    }

    this.closeCustomerInfoScreen = async function(){
        await closeBtnCustomerInfo.click();
    }

    
    this.isPresentAppraisalNotesHeader = async function(){
        return await appraisalNotestHeader.isPresent();
    }
    
    this.isPresentUnitHistoryHeader = async function(){
        return await unitHistoryHeader.isPresent();
    }

    this.isPresentFeedbackScreen = async function(){
        return await feedbackTitle.isPresent();
    }

    this.isPresentCarFaxReportScreen = async function(){
        return await carFaxReportTitle.isPresent();
    }

    this.closeCarFaxReportScreen = async function(){
        await carFaxReportCloseBtn.click();
    }

    this.getVINCarFaxReport = async function(){

        var fullVIN = await vinCarFaxReport.getText();
        var onlyVIN = utils.splitInToTwoReturnSecondPart(fullVIN,":");
        var onlyVIN = onlyVIN.trim();

        return onlyVIN;
    }

    this.closeAutoCheckReportScreen = async function(){
        await autoCheckReportCloseBtn.click();
    }


    this.isPresentAutoCheckReportScreen = async function(){
        return await autoCheckReportTitle.isPresent();
    }

    this.getVINAutoCheckReport = async function(){
        return await vinAutoCheckReport.getText();
    }

    this.isPresentGuideBooksScreen = async function(){
        return await guideBooksScreenTitle.isPresent();
    }
    
    this.isPresentScorecardScreen = async function(){
        return await scorecardScreenTitle.isPresent();
    }
    
    this.isPresentLocalMarketScreen = async function(){
        return await localMarketScreenTitle.isPresent();
    }
    
    this.isPresentGalleryScreen = async function(){
        return await galleryScreenTitle.isPresent();
    }
    
    this.isPresentRecallsScreen = async function(){
        return await recallsScreenTitle.isPresent();
    }

    this.clickRecallCloseBtn = async function(){
        await recallCloseBtn.click();
    }
    
    this.clickLeftPhotoGalleryBtn = async function(){
        await leftPhotoGalleryBtn.click();
    }
    
    this.setFeedbackMsg = async function(msg){
        await feebackInput.sendKeys(msg);
    }

    this.clickSendFeedbackBtn = async function(){
        await sendFeedbackBtn.click();
    }

    this.isPresentFeedbackSuccessMsg = async function(){
        return await successFeedbackMsgPart1.isPresent() && await successFeedbackMsgPart2.isPresent();
    }

    this.clickGetAccutradeInstantOfferBtn = async function(){
        await getAccutradeInstantOfferBtn.click();
    }

    this.isPresentGetAccutradeInstantOfferBtn = async function(){
        return await getAccutradeInstantOfferBtn.isPresent();
    }

    this.clickGetInstantCashOfferBtn = async function(){
        await getInstantCashOfferBtn.click();
    }
    
    this.isPresentGetOfferTermsConditionsLink = async function(){
        return await getOfferTermsConditionsLink.isPresent();
    }

    this.clickGetOfferTermsConditionsLink = async function(){
        await getOfferTermsConditionsLink.click();
    }

    this.getOfferTermsConditionsLinkText = async function(){
        return await getOfferTermsConditionsLink.getText();
    }

    this.isPresentGetOfferArbitrationLink = async function(){
        return await getOfferArbitrationLink.isPresent();
    }

    this.clickGetOfferArbitrationLink = async function(){
        await getOfferArbitrationLink.click();
    }

    this.getOfferArbitrationLinkText = async function(){
        return await getOfferArbitrationLink.getText();
    }

    this.clickGetOfferCheckBox = async function(){
        await getOfferCheckBox.click();
    }
    
    this.clickGetAccutradeInstantOfferSubmitBtn = async function(){
        await getOfferSubmitBtn.click();
    }

    this.clickGetOfferSubmitBtn = async function(){
        await getOfferSubmitBtn.click();
    }

    this.isGetOfferSubmitButtonDisabled = async function(){
        return await getOfferSubmitBtn.getAttribute("ng-reflect-disabled");
    }
    
    this.isPresentGetAccutradeInstantOfferSuccessMsg = async function(){
        return await getAccutradeInstantOfferSuccessMsg.isPresent();
    }

    this.isPresentGetAccutradeInstantOfferSuccessDescriptionMsg = async function(){
        return await getAccutradeInstantOfferSuccessDescriptionMsg.isPresent();
    }

    this.isPresentGetOfferSuccessMsg = async function(){
        return await getOfferSuccessMsg.isPresent();
    }

    this.isPresentGetOfferSuccessDescriptionMsg = async function(){
        return await getOfferSuccessDescriptionMsg.isPresent();
    }

    this.getOfferSuccessDescriptionMsg = async function(){
        return await getOfferSuccessDescriptionMsg.getText();
    }

    this.clickGetOfferBackBtn = async function(){
        await getOfferBackBtn.click();
    }

    this.isPresentGetAccutradeInstantOfferPendingMsg = async function(){
        return await getAccutradeInstantOfferPendingMsg.isPresent();
    }

    this.isPresentGetOfferAppraisalLabel = async function(){
        return await getOfferAppraisalLabel.isPresent();
    }
    
    this.clickIncreaseOfferBtn = async function(){
        await increaseOfferBtn.click();
    }
    
    this.enterIncreaseOfferAmount = async function(amount){
        await increaseOfferAmountInput.clear();
        await increaseOfferAmountInput.sendKeys(amount);
    }
    
    this.enterIncreaseOfferExpiresInput = async function(days){
        await increaseOfferExpiresInput.clear();
        await increaseOfferExpiresInput.sendKeys(days);
    }
    
    this.selectIncreaseOfferAgreementCheckBox = async function(){
        await increaseOfferAgreementCheckBox.click();
    }

    this.clickIncreaseOfferYesBtn = async function(){
        await increaseOfferYesBtn.click();
    }
    
    this.clickIncreaseOfferNextBtn = async function(){
        await increaseOfferNextBtn.click();
    }

    this.clickIncreaseOfferSendBtn = async function(){
        await increaseOfferSendBtn.click();
    }
    
    this.clickIncreaseOfferDoneBtn = async function(){
        await increaseOfferDoneBtn.click();
    }
    
    this.isPresentIncreaseOfferConfirmationMsg = async function(){
        return await increaseOfferConfirmationMsg.isPresent();
    }
        
    this.increaseOffer = async function(amount, expiresInDays){
        await utils.logInfo("Click on Increase Offer Button");
        await this.clickIncreaseOfferBtn();
        await utils.logInfo("Enter Increase Offer Amount of $"+amount);
        await this.enterIncreaseOfferAmount(amount);
        await utils.logInfo("Enter Increase Offer Expires in "+expiresInDays+" days");
        await this.enterIncreaseOfferExpiresInput(expiresInDays);
        await utils.logInfo("Click on Yes on Agreement");
        await this.clickIncreaseOfferYesBtn();
        await utils.logInfo("Click on Increase Offer Next Button");
        await this.clickIncreaseOfferNextBtn();
        await utils.logInfo("Click on Increase Offer Next Button");
        await this.clickIncreaseOfferNextBtn(); 
        await utils.logInfo("Verify Increase Offer Confirmation Message");
        expect(await this.isPresentIncreaseOfferConfirmationMsg()).toBeTruthy(); //Assertion
        await utils.logInfo("Click on Increase Offer Done Button");
        await this.clickIncreaseOfferDoneBtn();

    }

    this.getAccutradeInstantOffer = async function(){
        await utils.logInfo("Click on GetAccutradeInstantOffer Button");
        await this.clickGetAccutradeInstantOfferBtn();
        await utils.logInfo("Click on GetAccutradeInstantOffer Screen checkbox");
        await this.clickGetOfferCheckBox();
        await utils.logInfo("Click on GetAccutradeInstantOffer Screen Submit Button");
        await this.clickGetAccutradeInstantOfferSubmitBtn();
        await browser.waitForAngularEnabled(true);
        await utils.logInfo("Assertion: Verify Instant Offer Submission Success Message");
        expect(await this.isPresentGetAccutradeInstantOfferSuccessMsg).toBeTruthy();
    }

    this.clickAppraisalConsumerDealerMode = async function(){
        await appraisalPersonIcon.click();
    }

    //this.scrollTo
    this.selectCDBodyTab = async function(){
        await utils.logInfo("Scrolling to Body Tab");
        browser.executeScript('arguments[0].scrollIntoView()', optionsLabel.getWebElement());
        await utils.logInfo("Click to Body Tab");
        //await cdBodyTab.click();
    }

    this.selectCDGlassTab = async function(){
        await utils.logInfo("Scrolling to Glass Tab");
        //browser.executeScript('arguments[0].scrollIntoView()', cdGlassTab.getWebElement());
        //browser.executeScript('arguments[0].scrollIntoView()', odometerText.getWebElement());
        await utils.logInfo("Click to Glass Tab");
        await cdGlassTab.click();
    }

    this.selectCDInteriorTab = async function(){
        await utils.logInfo("Scrolling to Interior Tab");
        //browser.executeScript('arguments[0].scrollIntoView()', cdInteriorTab.getWebElement());
        browser.executeScript('arguments[0].scrollIntoView()', optionsLabel.getWebElement());
        await utils.logInfo("Click to Interior Tab");
        await cdInteriorTab.click();
    }

    this.selectCDTireWheelTab = async function(){
        await utils.logInfo("Scrolling to Tire/Wheel Tab");
        //browser.executeScript('arguments[0].scrollIntoView()', cdTireWheelTab.getWebElement());
        browser.executeScript('arguments[0].scrollIntoView()', optionsLabel.getWebElement());
        await utils.logInfo("Click to Tire/Wheel Tab");
        expect(await cdTireWheelTab.getAttribute("ng-reflect-text")).toBe("Tire/Wheel","Verify Conditional Disclosure Tire Tab text")
        await cdTireWheelTab.click();
    }

    this.selectCDLightsTab = async function(){
        await utils.logInfo("Scrolling to Lights Tab");
        //browser.executeScript('arguments[0].scrollIntoView()', cdLightsTab.getWebElement());
        browser.executeScript('arguments[0].scrollIntoView()', optionsLabel.getWebElement());
        await utils.logInfo("Click to Lights Tab");
        await cdLightsTab.click();
    }

    this.selectCDMechanicalTab = async function(){
        await utils.logInfo("Scrolling to Mechanical Tab");
        browser.executeScript('arguments[0].scrollIntoView()', optionsLabel.getWebElement());
        await utils.logInfo("Click to Mechanical Tab");
        await cdMechanicalTab.click();
    }

    this.selectCDAfterMarketTab = async function(){
        await utils.logInfo("Scrolling to AfterMarket Tab");
        browser.executeScript('arguments[0].scrollIntoView()', optionsLabel.getWebElement());
        await utils.logInfo("Click to AfterMarket Tab");
        await cdAfterMarketTab.click();
    }

    this.selectCDOtherTab = async function(){
        await utils.logInfo("Scrolling to Other Tab");
        browser.executeScript('arguments[0].scrollIntoView()', optionsLabel.getWebElement());
        await utils.logInfo("Click to Other Tab");
        await cdOtherTab.click();
    }

    this.getCDAfterMarketPhotosCount = async function(){
        return await element.all(by.xpath("//aftermarket-disclosures/photo-set/div[@class='image-container']/mat-icon[text()='cancel']")).count();
    }

    this.selectAdjustmentAS = async function(adjustmentWebElement, mainadjustment,adjustment){
        await utils.logInfo("Scrolling to Adjustment");
        //browser.executeScript('arguments[0].scrollIntoView()', adjustmentWebElement.getWebElement());
        await utils.logInfo("Select adjustment");
        // if(mainadjustment == "Original Owner" || mainadjustment == "Owner(s)"){
        //     await this.selectOwnersAppraisalPage(adjustment);
        // }
        // else{
            await adjustmentWebElement.click();

        // }
    }

    this.selectAdjustmentCategoryAS = async function(categoryWebElement, mainadjustment,adjustment){

        await utils.logInfo("Scrolling to Adjustment category");
        //browser.executeScript('arguments[0].scrollIntoView()', categoryWebElement.getWebElement());
        await utils.logInfo("Select adjustment category");

        if(mainadjustment == "Original Owner" || mainadjustment == "Owner(s)"){
            await this.selectOwnersAppraisalPage(adjustment);
        }
        else if(mainadjustment == "Odometer"){
            await this.setOdometer(adjustment);
        }
        else{
            await categoryWebElement.click();
        }
        
    }


    this.selectAdjustmentSubCategoryAS = async function(subCategoryWebElement){
        await utils.logInfo("Scrolling to Adjustment subcategory");
        //browser.executeScript('arguments[0].scrollIntoView()', subCategoryWebElement.getWebElement());
        await utils.logInfo("Select adjustment subcategory");
        await subCategoryWebElement.click();
    }
    
    this.generateXpathWebElement = function(locator){
        webElem = element(by.xpath(locator));
        return webElem;
    }

    this.assertAppraisalScreenValues = async function(mainadjustment,adjustment,category,subcategory,vin, offerprice, targetauction, targetretail, adjustmentvalue, finalofferprice, finaltargetauction, finaltargetretail){
        utils.logInfo("Inside function assertAppraisalScreenValues()");

        var tabLocator = "//condition-disclosures-menu-item[@ng-reflect-text='"+mainadjustment+"']";
        // if(mainadjustment == "Tire/Wheel"){
        //     tabLocator = "//condition-disclosures-menu-item[@ng-reflect-text='Tires']";
        // }
        utils.logInfo("Value of tabLocator is "+tabLocator);

        var tabWebElement = element(by.xpath(tabLocator));

        var panelLocator = "started";
        var panelAppraisalWebElement = "started";
        var panelAdjustmentValue = "started";


        switch(mainadjustment){
            case 'Body':
            case 'Glass':
            case 'Interior':
                var listItemCount = this.getCDDamageListItemCount();
                await utils.logInfo("List Item Count is "+listItemCount);
                await utils.logInfo("Verify Damage list count is 1");
                expect(listItemCount).toBe(1,"Verify "+mainadjustment+" Damage list count is 1");

                var firstListItemLabel = await this.getCDDamageFirstListItemInputLabel();
                await utils.logInfo("List Item: "+firstListItemLabel);
                //expect(firstListItemLabel).toBe();

                var firstListItemValue = await this.getCDDamageFirstListItemInputValue();
                await utils.logInfo("List Item Value: "+firstListItemValue);
                await utils.logInfo("Verify Damage list adjustment value is "+adjustmentvalue);
                expect(firstListItemValue).toBe(adjustmentvalue,"Verify "+mainadjustment+"Damage list adjustment value");

            case 'Lights':
            case 'Mechanical':
            case 'Aftermarket':
            case 'Other':
                var tabValue = await tabWebElement.getAttribute("ng-reflect-adjustment");
                var tabCount = await tabWebElement.getAttribute("ng-reflect-count");
                await utils.logInfo("Value of "+mainadjustment+" Tab is "+tabValue);
                await utils.logInfo("Verify "+mainadjustment+" Tab value is "+adjustmentvalue);
                expect(tabValue).toBe(adjustmentvalue,"Verify Conditional Disclosures Tab '"+mainadjustment+"' value matches expected value");
                await utils.logInfo("Count of "+mainadjustment+" Tab is "+tabCount);
                await utils.logInfo("Verify "+mainadjustment+" Tab count value is 1");
                expect(tabCount).toBe("1","Verify Conditional Disclosures Tab '"+mainadjustment+"' Count value matches expected value");
                break;
            case 'Tire/Wheel':
                var tireTreadExpectedValue = utils.splitInToTwoReturnFirstPart(adjustmentvalue,":");
                var tireConditionExpectedValue = utils.splitInToTwoReturnSecondPart(adjustmentvalue,":");
                adjustmentvalue = parseInt(tireTreadExpectedValue)+parseInt(tireConditionExpectedValue);
                adjustmentvalue = adjustmentvalue.toString();
                //-575//*[text()='Rear Right']/following-sibling::formatted-price
                // "//*[text()='"+adjustment+"']/following-sibling::formatted-price"
                
                //-75//*[text()='Rear Right']/following-sibling::formatted-price/../../div[@class='tire-sizes']/adjustment-item[@ng-reflect-label='4/32 - 7/32']
                // "//*[text()='"+adjustment+"']/following-sibling::formatted-price/../../div[@class='tire-sizes']/adjustment-item[@ng-reflect-label='"+category+"']"                
                
                //-500//*[text()='Rear Right']/following-sibling::formatted-price/../../div[@class='tire-sizes']/adjustment-item[@ng-reflect-label='4/32 - 7/32']/../../div[@class='adjustment-items']/adjustment-item[@ng-reflect-label='replace wheel']
                // "//*[text()='"+adjustment+"']/following-sibling::formatted-price/../../div[@class='tire-sizes']/adjustment-item[@ng-reflect-label='"+category+"']/../../div[@class='adjustment-items']/adjustment-item[@ng-reflect-label='"+subcategory+"']"
                var tireTreadConditionLocator = "//*[text()='"+adjustment+"']/following-sibling::formatted-price";
                var tireTreadLocator = "//*[text()='"+adjustment+"']/following-sibling::formatted-price/../../div[@class='tire-sizes']/adjustment-item[@ng-reflect-label='"+category+"']";
                var tireConditionLocator = "//*[text()='"+adjustment+"']/following-sibling::formatted-price/../../div[@class='tire-sizes']/adjustment-item[@ng-reflect-label='"+category+"']/../../div[@class='adjustment-items']/adjustment-item[@ng-reflect-label='"+subcategory+"']";                
                var tireTreadWebElement = element(by.xpath(tireTreadLocator));
                var tireConditionWebElement = element(by.xpath(tireConditionLocator));
                var tireTreadConditionWebElement = element(by.xpath(tireTreadConditionLocator));

                await utils.logInfo("tireTreadLocator is "+tireTreadLocator);
                await utils.logInfo("tireConditionLocator is "+tireConditionLocator);
                await utils.logInfo("tireTreadConditionLocator is "+tireTreadConditionLocator);

                await utils.logInfo("tireTreadLocator amount value is "+await tireTreadWebElement.getAttribute("ng-reflect-value"));
                await utils.logInfo("tireConditionLocator amount value is "+await tireConditionWebElement.getAttribute("ng-reflect-value"));
                await utils.logInfo("tireTreadConditionLocator amount value is "+await tireTreadConditionWebElement.getAttribute("ng-reflect-price"));

                expect(await tireTreadWebElement.getAttribute("ng-reflect-value")).toBe(tireTreadExpectedValue,"Verify Tire Tread '"+category+"' Adjustment Value in Conditional Disclosures section of Appraisal screen");
                expect(await tireConditionWebElement.getAttribute("ng-reflect-value")).toBe(tireConditionExpectedValue,"Verify Tire Condition '"+subcategory+"' Adjustment Value in Conditional Disclosures section of Appraisal screen");
                expect(await tireTreadConditionWebElement.getAttribute("ng-reflect-price")).toBe(adjustmentvalue,"Verify Tire aggregate Tread & Condition Adjustment Value in Conditional Disclosures section of Appraisal screen");

                var tabValue = await tabWebElement.getAttribute("ng-reflect-adjustment");
                var tabCount = await tabWebElement.getAttribute("ng-reflect-count");
                await utils.logInfo("Value of "+mainadjustment+" Tab is "+tabValue);
                await utils.logInfo("Verify "+mainadjustment+" Tab value is "+adjustmentvalue);
                expect(tabValue).toBe(adjustmentvalue,"Verify Conditional Disclosures Tab '"+mainadjustment+"' value matches expected value");
                await utils.logInfo("Count of "+mainadjustment+" Tab is "+tabCount);
                await utils.logInfo("Verify "+mainadjustment+" Tab count value is 2");
                expect(tabCount).toBe("2","Verify Conditional Disclosures Tab '"+mainadjustment+"' Count value matches expected value");
                break;
            case 'Vehicle History':
            case 'Options':
            case 'Service Status':
            case 'Odometer':
            case 'Colors':
            case 'Colours':
            case 'Keys':
                await browser.sleep(browser.params.sleep.sleep10);        
                panelLocator = "//panel-header[@ng-reflect-title='"+mainadjustment+"']";
                await utils.logInfo("Value of Panel Locator is "+panelLocator);
                panelAppraisalWebElement = element(by.xpath(panelLocator));
                panelAdjustmentValue = await panelAppraisalWebElement.getAttribute("ng-reflect-price");
                await utils.logInfo("Value of "+mainadjustment+" panel adjustment value is "+panelAdjustmentValue);
                await utils.logInfo("Verify that "+mainadjustment+" panel adjustment value is "+adjustmentvalue);
                expect(panelAdjustmentValue).toBe(adjustmentvalue,"Verify "+mainadjustment+" panel adjustment value");
                break;
            case 'Owner(s)':
            case 'Original Owner':
                mainadjustment = "Owner(s)";        
                panelLocator = "//panel-header[@ng-reflect-title='"+mainadjustment+"']";
                panelAppraisalWebElement = element(by.xpath(panelLocator));
                panelAdjustmentValue = await panelAppraisalWebElement.getAttribute("ng-reflect-price");
                await utils.logInfo("Value of "+mainadjustment+" panel adjustment value is "+panelAdjustmentValue);
                await utils.logInfo("Verify that "+mainadjustment+" panel adjustment value is "+adjustmentvalue);
                expect(panelAdjustmentValue).toBe(adjustmentvalue,"Verify "+mainadjustment+" panel adjustment value");

                break;
        } //switch        
    } // function assertAppraisalScreenValues

    this.assertReviewSendScreen = async function(mainadjustment,adjustment,category,subcategory,vin, offerprice, targetauction, targetretail, adjustmentexpectedvalue, finalofferprice, finaltargetauction, finaltargetretail){
        await utils.logInfo("Inside appraisalPage.assertReviewSendScreen()");
        var mainAdjustmentLocator ="//dock-list[@ng-reflect-title='"+mainadjustment+"']";
        var adjustmentLocator = "started";
        var conditionLocator = "//mat-icon/following-sibling::*[text()='Condition Disclosures']";
        var tireTreadExpectedValue = "started";
        var tireConditionExpectedValue = "started";
        var conditionWebElement = element(by.xpath(conditionLocator));
        var keysWebElement = element(by.xpath("//*[@ng-reflect-title='Keys']"));
        var originalOwnerWebElement = element(by.xpath("//*[@ng-reflect-title='Original Owner']"));


            switch(mainadjustment){
                case 'Odometer':
                    adjustmentLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-value='"+adjustment+" Mi']";
                    break;
                case 'Options':
                    adjustmentLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-value='"+adjustment+"']";
                    break;
                case 'Color':
                    adjustmentLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-title='"+adjustment+"' and @ng-reflect-value='"+category+"']";
                    break;
                case 'Colour':
                    adjustmentLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-title='"+adjustment+"' and @ng-reflect-value='"+category+"']";
                    break;    
                case 'Keys':
                    adjustmentLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-value='"+adjustment+"']";
                    break;    
                case 'Vehicle History':
                    adjustmentLocator ="//*[@ng-reflect-title='"+adjustment+"']";
                    break;  
                case 'Original Owner':
                    if (adjustment == "1"){
                        adjustment = "Yes";
                    }
                    else{
                        adjustment = "No";
                    }
                    adjustmentLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-value='"+adjustment+"']";
                    break;                                
                case 'Owner(s)':
                    if (adjustment == "1"){
                        adjustment = "Yes";
                    }
                    else{
                        adjustment = "No";
                    }
                    adjustmentLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-value='"+adjustment+"']";
                    break;  
                case 'Service Status':
                    adjustmentLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-value='"+adjustment+"']";
                    break;  
                case 'Body':
                    adjustmentLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-title='"+adjustment+" "+"' and @ng-reflect-value='"+category+" - "+subcategory+"']";
                    await utils.logInfo("Click on Condition Disclosures");
                    await conditionWebElement.click();
                    break;
                case 'Glass':
                    adjustmentLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-title='"+adjustment+" "+"' and @ng-reflect-value='"+category+"']";
                    await utils.logInfo("Click on Condition Disclosures");
                    await conditionWebElement.click();
                    break;    
                case 'Interior':
                    utils.logInfo("Interior: Value of adjustment before replace is "+adjustment);
                    adjustment = utils.replaceOneValueInString(adjustment,"-"," ");
                    utils.logInfo("Interior: Value of adjustment after replace is "+adjustment);
                    adjustmentLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-title='"+adjustment+"' and @ng-reflect-value='"+category+"']";
                    await utils.logInfo("Click on Condition Disclosures");
                    await conditionWebElement.click();
                    browser.executeScript('arguments[0].scrollIntoView()', originalOwnerWebElement.getWebElement());
                    break;  
                case 'Tire/Wheel':
                    tireTreadExpectedValue = utils.splitInToTwoReturnFirstPart(adjustmentexpectedvalue,":");
                    tireConditionExpectedValue = utils.splitInToTwoReturnSecondPart(adjustmentexpectedvalue,":");
                    adjustmentexpectedvalue = parseInt(tireTreadExpectedValue)+parseInt(tireConditionExpectedValue);
                    adjustmentexpectedvalue = adjustmentexpectedvalue.toString();

                    adjustmentLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-title='"+adjustment+"' and @ng-reflect-value='"+category+"']";
                    await utils.logInfo("Click on Condition Disclosures");
                    await conditionWebElement.click();
                    break;  
                case 'Warning Lights':
                    adjustmentLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-value='"+adjustment+"']";
                    await utils.logInfo("Click on Condition Disclosures");
                    await conditionWebElement.click();
                    break;                                
                case 'Mechanical':
                    adjustmentLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-value='"+adjustment+"']";
                    await utils.logInfo("Click on Condition Disclosures");
                    await conditionWebElement.click();
                    break;              
                case 'Aftermarket':
                    adjustmentLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-value='"+adjustment+"']";
                    await utils.logInfo("Click on Condition Disclosures");
                    await conditionWebElement.click();
                    break;  
                case 'Other':
                    mainadjustment='Disclosures';
                    mainAdjustmentLocator ="//dock-list[@ng-reflect-title='"+mainadjustment+"']";
                    adjustmentLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-value='"+adjustment+"']";
                    await utils.logInfo("Click on Condition Disclosures");
                    await conditionWebElement.click();
                    break;  
                case 'Disclosures':
                    adjustmentLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-value='"+adjustment+"']";
                    await utils.logInfo("Click on Condition Disclosures");
                    await conditionWebElement.click();
                    break;                                    
                case 'Inventory Consultant Adjustments':
                    adjustmentLocator = "//*[@ng-reflect-title='Inventory Consultant Adjustmen']";
                    break;                                      
            } 

        await utils.logInfo("Main Adjustment Locator is "+mainAdjustmentLocator);
        await utils.logInfo("Adjustment Locator is "+adjustmentLocator);

        var mainAdjustmentWebElement = element(by.xpath(mainAdjustmentLocator));
        var adjustmentWebElement = element(by.xpath(adjustmentLocator));
        var adjustmentValue = "started";
        var mainadjustmentValue = "started";

        if(mainadjustment == "Vehicle History"){
            await utils.logInfo("inside if(mainadjustment == 'Vehicle History')");
            adjustmentValue = await adjustmentWebElement.getAttribute("ng-reflect-adjustment");
            await utils.logInfo("Adjustment "+adjustment+" Value is "+adjustmentValue);
            expect(adjustmentValue).toBe(adjustmentexpectedvalue,"Verify individual adjustment value '"+adjustmentLocator+"' in Review & Send Screen");
        }
        else{ //if(mainadjustment != "Vehicle History")
            await utils.logInfo("if(mainadjustment != 'Vehicle History')");
            if(mainadjustment == "Original Owner" && adjustment != "Unknown"){
                utils.logInfo("if(mainadjustment == 'Original Owner' && adjustment != 'Unknown')");
                await utils.logInfo("Click on mainAdjustmentWebElement: "+mainadjustment);
                await mainAdjustmentWebElement.click();

                mainadjustmentValue = await mainAdjustmentWebElement.getAttribute("ng-reflect-adjustment");
                await utils.logInfo("Main Adjustment "+mainadjustment+" Value is "+mainadjustmentValue);
                expect(mainadjustmentValue).toBe(adjustmentexpectedvalue);

                adjustmentValue = await adjustmentWebElement.getAttribute("ng-reflect-adjustment");
                await utils.logInfo("Individual Adjustment '"+adjustmentLocator+"' Value is "+adjustmentValue);
                expect(adjustmentValue).toBe(adjustmentexpectedvalue,"Verify individual adjustment value '"+adjustmentLocator+"' in Review & Send Screen");

                //await utils.logInfo("Adjustment "+adjustment+" Value is "+await adjustmentWebElement.getAttribute("ng-reflect-adjustment"));
            }
            else{ //if(mainadjustment != 'Original Owner')

                utils.logInfo("if(mainadjustment != 'Original Owner'");
                mainadjustmentValue = await mainAdjustmentWebElement.getAttribute("ng-reflect-adjustment");
                await utils.logInfo("Main Adjustment "+mainadjustment+" Value is "+mainadjustmentValue);
                //await utils.logInfo("Verify mainadjustment value in Review and Send Screen is "+adjustment);
                expect(mainadjustmentValue).toBe(adjustmentexpectedvalue,"Verify Aggregrate main adjustment value of '"+mainadjustment+"' in Review & Send Screen");

                await utils.logInfo("Click on mainAdjustmentWebElement: "+mainadjustment);
                await mainAdjustmentWebElement.click();
                adjustmentValue = await adjustmentWebElement.getAttribute("ng-reflect-adjustment");

                if(mainadjustment == "Tire/Wheel"){
                    
                    var tireTreadLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-title='"+adjustment+"' and @ng-reflect-value='"+category+"']";
                    var tireConditionLocator = "//*[@ng-reflect-title='"+mainadjustment+"']/*[@ng-reflect-title='"+adjustment+"' and @ng-reflect-value='"+subcategory+"']";
                    var tireTreadWebElement = element(by.xpath(tireTreadLocator));
                    var tireConditionWebElement = element(by.xpath(tireConditionLocator));
                    await utils.logInfo("Value of Tire Tread Adjustment value in Review & Send Screen is "+await tireTreadWebElement.getAttribute("ng-reflect-adjustment"));
                    await utils.logInfo("Value of Tire Condition Adjustment value in Review & Send Screen is "+await tireConditionWebElement.getAttribute("ng-reflect-adjustment"));

                    expect(await tireTreadWebElement.getAttribute("ng-reflect-adjustment")).toBe(tireTreadExpectedValue,"Verify the Value of Tire Tread Adjustment value in Review & Send Screen");
                    expect(await tireConditionWebElement.getAttribute("ng-reflect-adjustment")).toBe(tireConditionExpectedValue,"Verify Value of Tire Condition Adjustment value in Review & Send Screen");

                }
                else{
                    await utils.logInfo("Indiviual Adjustment '"+adjustmentLocator+"' Value is "+adjustmentValue);
                    expect(adjustmentValue).toBe(adjustmentexpectedvalue,"Verify individual adjustment value of '"+adjustmentLocator+"' in Review & Send Screen");

                }
            }
        }
    }


    this.selectAdjustmentAppraisalScreen = async function(mainadjustment,adjustment,category,subcategory){
        var interior = "no";
        var tirewheel = "no"
        var lightsMechanicalAfterMarketOthers = "no";
        var optionsServiceStatusKeysVehicleHistory = "no";
        await utils.logInfo("Starting selectAdjustmentAppraisalScreen("+mainadjustment+","+adjustment+","+category+","+subcategory+","+")");
        switch(mainadjustment){
            case 'Body':
                // Do nothing as default tab is body tab              
                break;
            case 'Glass':
                await this.selectCDGlassTab();
                break;
            case 'Interior':
                await this.selectCDInteriorTab();
                utils.logInfo("Interior: Value of adjustment before splitInToTwoReturnFirstPart is "+adjustment);
                interior = utils.splitInToTwoReturnSecondPart(adjustment,'-');//side setting for Interior
                adjustment = utils.splitInToTwoReturnFirstPart(adjustment,'-');
                utils.logInfo("Interior: Value of adjustment after splitInToTwoReturnFirstPart is "+adjustment);
                utils.logInfo("Interior: Value of adjustment after splitInToTwoReturnSecondPart is "+interior);

                break;
            case 'Tire/Wheel':
                await utils.logInfo("Inside Tire/Wheel case before selectCDTireWheelTab()");
                await this.selectCDTireWheelTab();
                await utils.logInfo("Inside Tire/Wheel case after selectCDTireWheelTab()");
                tirewheel = "yes";
                //*[text()='Front Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='4/32 - 7/32']
                break;
            case 'Warning Lights':
                lightsMechanicalAfterMarketOthers = "yes";
                await this.selectCDLightsTab();
                break;
            case 'Mechanical':
                lightsMechanicalAfterMarketOthers = "yes";
                await this.selectCDMechanicalTab();
                break;
            case 'Aftermarket':
                lightsMechanicalAfterMarketOthers = "yes";
                await this.selectCDAfterMarketTab();
                break;
            case 'Other': 
                lightsMechanicalAfterMarketOthers = "yes";
                await this.selectCDOtherTab();
                break;       
            case 'Options':
                optionsServiceStatusKeysVehicleHistory ="yes";
                break;
            case 'Service Status':
                optionsServiceStatusKeysVehicleHistory ="yes";
                break;
            case 'Keys':
                optionsServiceStatusKeysVehicleHistory ="yes";
                break;                        
            case 'Original Owner':
                optionsServiceStatusKeysVehicleHistory ="yes";
                mainadjustment = "Owner(s)";
                break;
            case 'Owner(s)':
                optionsServiceStatusKeysVehicleHistory ="yes";
                //mainadjustment = "Owner(s)";
                break;      
            case 'Vehicle History':
                optionsServiceStatusKeysVehicleHistory ="yes";
                break;
            // case 'Service Status':
            //     optionsServiceStatusKeysVehicleHistory ="yes";
            //     break;
            case 'Odometer':
                //input[@ng-reflect-name='odometer']
                //await this.setOdometer(adjustment);
                break;
            case 'Color':
                adjustment = utils.splitInToTwoReturnFirstPart(adjustment," ");
                break;
            case 'Colour':
                adjustment = utils.splitInToTwoReturnFirstPart(adjustment," ");
                break;                       
        }//switch

        var adjustmentWebElement = await this.generateXpathWebElement("//*[@type='"+adjustment+"']");

        if (tirewheel != "no" || lightsMechanicalAfterMarketOthers != "no" || optionsServiceStatusKeysVehicleHistory != "no" || mainadjustment == "Odometer"){//if yes
            //do nothing
        }
        else if (mainadjustment == "Color" || mainadjustment == "Colour"){
            adjustmentWebElement = await this.generateXpathWebElement("//*[@ng-reflect-label='"+adjustment+"']");
            await utils.logInfo("Select adjustment button: "+adjustment);
            await utils.logInfo("Going into selectAdjustmentAS()");
            await this.selectAdjustmentAS(adjustmentWebElement, mainadjustment,adjustment); //selectAdjustmentAS
        }
        else{
            await utils.logInfo("Select adjustment button: "+adjustment);
            await utils.logInfo("Going into selectAdjustmentAS()");
            await this.selectAdjustmentAS(adjustmentWebElement, mainadjustment,adjustment); //selectAdjustmentAS
        }

        if (lightsMechanicalAfterMarketOthers != "no" || optionsServiceStatusKeysVehicleHistory != "no" || mainadjustment == "Odometer"){
            category = adjustment;
        }
        
        if(category != 'none'){
            var categoryWebElement = await this.generateXpathWebElement("//*[@ng-reflect-label='"+category+"']");
            
            if(tirewheel != "no"){//if yes
                await utils.logInfo("if Interior is yes then category web element is : "+"//*[text()='"+adjustment+"']/../following-sibling::div/adjustment-item[@ng-reflect-label='"+category+"']");
                categoryWebElement = await this.generateXpathWebElement("//*[text()='"+adjustment+"']/../following-sibling::div/adjustment-item[@ng-reflect-label='"+category+"']");
                //*[text()='Front Left']/../following-sibling::div/adjustment-item[@ng-reflect-label='4/32 - 7/32']
            }
            else if(mainadjustment == "Color" || mainadjustment == "Colour"){
                //*[text()='Black']/preceding-sibling::div
                categoryWebElement = await this.generateXpathWebElement("//*[text()='"+category+"']/preceding-sibling::div");
            }

            await utils.logInfo("Select category button: "+category);
            await this.selectAdjustmentCategoryAS(categoryWebElement,mainadjustment,adjustment);//selectAdjustmentCategoryAS
        }

        if(subcategory != 'none'){
            var subCategoryWebElement = await this.generateXpathWebElement("//*[@ng-reflect-label='"+subcategory+"']");

            if(tirewheel != "no"){
                await utils.logInfo("if Interior is yes then subcategory web element is : "+"//*[text()='"+adjustment+"']/../following-sibling::div[2]/adjustment-item[@ng-reflect-label='"+subcategory+"']");
                subCategoryWebElement = await this.generateXpathWebElement("//*[text()='"+adjustment+"']/../following-sibling::div[2]/adjustment-item[@ng-reflect-label='"+subcategory+"']");
                //*[text()='Front Left']/../following-sibling::div[2]/adjustment-item[@ng-reflect-label='replace wheel']
            }

            await utils.logInfo("Select subcategory button: "+subcategory);
            await this.selectAdjustmentSubCategoryAS(subCategoryWebElement);//selectAdjustmentSubCategoryAS
            //await utils.logInfo("testing");
        }
    }

    this.getCDBodyTabWebElement = function(){
        return cdBodyTab;
    }

    this.clickCDBodyExtRightBackDoorBtn = async function(){
        browser.executeScript('arguments[0].scrollIntoView()', cdBodyExtRightBackDoorBtn.getWebElement());
        await cdBodyExtRightBackDoorBtn.click();
    }

    this.clickCDBodyChippedDamageTypeBtn = async function(){
        browser.executeScript('arguments[0].scrollIntoView()', cdBodyChippedDamageTypeBtn.getWebElement());
        await browser.sleep(browser.params.sleep.sleep5);
        await cdBodyChippedDamageTypeBtn.click();
    }

    this.clickCDBodyPrevReplacementDamageTypeBtn = async function(){
        //browser.executeScript('arguments[0].scrollIntoView()', cdBodyChippedDamageTypeBtn.getWebElement());
        //await browser.sleep(browser.params.sleep.sleep5);
        await cdBodyPrevReplacementDamageTypeBtn.click();
    }

    this.clickCDBodyPrevReplacementWetSandDamageTypeBtn = async function(){
        //browser.executeScript('arguments[0].scrollIntoView()', cdBodyChippedDamageTypeBtn.getWebElement());
        //await browser.sleep(browser.params.sleep.sleep5);
        await cdBodyPrevReplacementWetSandDamageTypeBtn.click();
    }


    this.getCDBodyTotalAdjustmentAmount = async function(){
        //browser.executeScript('arguments[0].scrollIntoView()', cdBodyTab.getWebElement());
        return await cdBodyTab.getAttribute("ng-reflect-adjustment");
    }
    
    this.getCDGlassTotalAdjustmentAmount = async function(){
        return await cdGlassTab.getAttribute("ng-reflect-adjustment");
    }

    this.getCDInteriorTotalAdjustmentAmount = async function(){
        return await cdInteriorTab.getAttribute("ng-reflect-adjustment");
    }

    this.getCDTireWheelTotalAdjustmentAmount = async function(){
        return await cdTireWheelTab.getAttribute("ng-reflect-adjustment");
    }

    this.getCDLightsTotalAdjustmentAmount = async function(){
        return await cdLightsTab.getAttribute("ng-reflect-adjustment");
    }

    this.getCDMechanicalTotalAdjustmentAmount = async function(){
        return await cdMechanicalTab.getAttribute("ng-reflect-adjustment");
    }

    this.getCDAfterMarketTotalAdjustmentAmount = async function(){
        return await cdAfterMarketTab.getAttribute("ng-reflect-adjustment");
    }

    this.getCDOtherTotalAdjustmentAmount = async function(){
        return await cdOtherTab.getAttribute("ng-reflect-adjustment");
    }

    this.getCDBodyTabCount = async function(){
        //browser.executeScript('arguments[0].scrollIntoView()', cdBodyTab.getWebElement());
        return await cdBodyTab.getAttribute("ng-reflect-count");
    }

    this.getCDBodyTabValue = async function(){
        //browser.executeScript('arguments[0].scrollIntoView()', cdBodyTab.getWebElement());
        return await cdBodyTab.getAttribute("ng-reflect-adjustment");
    }

    this.getCDGlassTabCount = async function(){
        //browser.executeScript('arguments[0].scrollIntoView()', cdGlassTab.getWebElement());
        return await cdGlassTab.getAttribute("ng-reflect-count");
    }

    this.getCDGlassTabValue = async function(){
        //browser.executeScript('arguments[0].scrollIntoView()', cdGlassTab.getWebElement());
        return await cdGlassTab.getAttribute("ng-reflect-adjustment");
    }

    this.getCDInteriorTabCount = async function(){
        browser.executeScript('arguments[0].scrollIntoView()', cdGlassTab.getWebElement());
        return await cdInteriorTab.getAttribute("ng-reflect-count");
    }

    this.getCDTireWheelTabCount = async function(){
        //browser.executeScript('arguments[0].scrollIntoView()', cdGlassTab.getWebElement());
        return await cdTireWheelTab.getAttribute("ng-reflect-count");
    }
    
    this.getCDLightsTabCount = async function(){
        //browser.executeScript('arguments[0].scrollIntoView()', cdGlassTab.getWebElement());
        return await cdLightsTab.getAttribute("ng-reflect-count");
    }

    this.getCDMechanicalTabCount = async function(){
        //browser.executeScript('arguments[0].scrollIntoView()', cdGlassTab.getWebElement());
        return await cdMechanicalTab.getAttribute("ng-reflect-count");
    }

    this.getCDAfterMarketTabCount = async function(){
        //browser.executeScript('arguments[0].scrollIntoView()', cdGlassTab.getWebElement());
        return await cdAfterMarketTab.getAttribute("ng-reflect-count");
    }

    this.getCDOtherTabCount = async function(){
        //browser.executeScript('arguments[0].scrollIntoView()', cdGlassTab.getWebElement());
        return await cdOtherTab.getAttribute("ng-reflect-count");
    }

    this.getServiceStatusAmountValue = async function(){
        return await serviceStatusAmountValue.getText();
    }

    this.getOptionsAmountValue = async function(){
        return await optionsAmountValue.getText();
    }

    this.getCDDamageListItemCount = async function(){
        //damage-list/damage-list-item[1]/*/input
        return await element.all(by.xpath("//damage-list-item")).count();
    }

    this.getCDDamageListItemValue = async function(){
    }

    this.setOdometer = async function(miles){
        await odometerText.clear();
        await odometerText.sendKeys(miles);
    }

    this.clickSetToBaseOdometer = async function(){
        await setToBaseOdometerLink.click();
    }

    this.getBaseOdometer = async function(){
        var base = await baseOdometerReading.getText();
        base = utils.splitInToTwoReturnSecondPart(base,":");
        base = utils.splitInToTwoReturnFirstPart(base,"/");
        return base.trim();
    }

    this.getLowMileageAlertLabel = async function(){
        return await lowMileageAlertLabel.getText();
    }

    this.getLowMileageAlertDesc = async function(){
        return await lowMileageAlertDesc.getText();
    }

    this.isPresentLowMileageAlert = async function(){
        return await lowMileageAlertDesc.isPresent();
    }

    this.getMileage = async function(){
        return await appraisalMileage.getText();
    }


    this.clickScorecardBar = async function(){
        await scorecardBar.click();
    }

    this.isScoreCardBarPresent = async function(){
        return await scorecardBar.isPresent();
    }

    this.setKeys = async function(keys){
        switch(miles) {
            case "0":
                await keysZeroBtn.click();  
                break;
            case "1":
                await keysOneBtn.click(); 
                break;
            case "2":
                await keysTwoBtn.click(); 
                break;
            default:
                await keysThreeBtn.click();
          }        
    }

    this.setInteriorColor = async function(color){

    }

    this.isSelectedBadVHR = async function(){
        return await badVHRBtn.getAttribute("ng-reflect-checked");
    }

    this.getBadVHRValue = async function(){
        return await badVHRBtn.getAttribute("ng-reflect-value");
    }

    this.clickBadVHR = async function(){
        await badVHRBtn.click();
    }

    this.setVehicleHistory = async function(vhsoption){
        switch(vhsoption){
            case "bad vhr":
                await badVHRBtn.click();
                break;
            case "frame damage":
                await badFrameDamageBtn.click();
                break;
            case "both":
                await badVHRBtn.click();
                await badFrameDamageBtn.click();
                break;
            default:
                //do nothing         
        }
    }

    this.setOwners = async function(numowners){
        switch(numowners){
            case "1":
                //
                break;
            case "2+":
                //
                break;    
            case "unknown":
                //
                break;
            default :
                //
                break;
        }//switch

    }//setOwners function



    this.setOptions = async function(option){
        switch(option){
            case "4 WHEEL DRIVE":
                await options4WheelDriveBtn.click();
                break;
            case "POWER WINDOWS":
                await optionsPowerWindowBtn.click();
                break;  
            default:
                await utils.logInfo("The setOptions() function parameter: '"+option+"' is invalid");    

        }//switch

    }//function

    this.isSelectedOptions4WheelDrive = async function(){
        return await options4WheelDriveBtn.getAttribute("ng-reflect-checked");
    }

    this.isSelectedOEMCertifiedServiceStatus = async function(){
        return await serviceStatusOEMBtn.getAttribute("ng-reflect-checked");
    }

    this.isDisabledOEMCertifiedServiceStatusBtn = async function(){
        return await serviceStatusOEMBtn.getAttribute("ng-reflect-read-only");
    }

    this.setServiceStatus = async function(status){
        //browser.executeScript('arguments[0].scrollIntoView()', serviceStatusAmountValue.getWebElement());
        switch(status){
            case "OEM CERTIFIED":
                await serviceStatusOEMBtn.click();
                break;
            case "AS TRADED":
                await serviceStatusAsTradedBtn.click();
                break;
            case "FLUNKED SHOP":
                await serviceStatusFlunkedShopBtn.click();
                break;
            case "SERVICE RECORDS":
                await serviceStatusRecordsBtn.click();
                break;
            default:
                await utils.logInfo("The setServiceStatus() function parameter: '"+status+"' is invalid");    
        }//switch        

    }//function

    this.setConditionDisclosures = async function(){

    }

    this.clickReviewSend = async function(){
        await reviewSendBtn.click();
    }

    this.getOfferAmountReviewSendScreen = async function(){
        return await offerAmountReviewSendScreen.getText();
    }

    this.getBasePriceReviewSendScreen = async function(){
        return await basePriceReviewSendScreen.getText();
    }

    this.clickConditionReportReviewSendScreen = async function(){
        await conditionReportReviewSendScreen.click();
    }

    this.clickProspectStartBtn = async function(){
        await prospectStartBtn.click();
    }

    this.clickGroundVehicleBtn = async function(){
        await groundVehicleBtn.click();
    }

    this.groundVehicle = async function(){
        await utils.logInfo("Click on Ground Vehicle Button");
        await this.clickGroundVehicleBtn();
        await utils.logInfo("Click on Confirm Button of Disclosure Confirmation Screen");
        await this.clickDisclosureCofirmBtn();
    }

    this.isPresentGroundVehicleBtn   = async function(){
        return await groundVehicleBtn.isPresent();
    }

    this.isPresentHVMSBtn   = async function(){
        return await sendToHVMSBtn.isPresent();
    }

    this.isPresentIASBtn   = async function(){
        return await sendToIASBtn.isPresent();
    }
    
    this.isPresentCRMBtn   = async function(){
        return await sendToCRMBtn.isPresent();
    }
    
    this.isPresentIncreaseOfferBtn   = async function(){
        return await increaseOfferBtn.isPresent();
    }

    this.clickDisclosureCofirmBtn = async function(){
        await disclosureConfirmationBtn.click();
    }

    this.isDisclosureConfirmationAlertPresent = async function(){
        return await disclosureConfirmationAlert.isPresent();
    }

    this.getAppraisalVIN = async function(){
        var vinMileage = await appraisalVIN.getText();
        await utils.logInfo("Value of VINMileage is "+vinMileage);
        var vin = utils.splitInToTwoReturnFirstPart(vinMileage,"|");
        vin = vin.trim();
        return vin;
    }

    this.getAppraisalYMM = async function(){
        return await appraisalVehicleDataYMM.getText();
    }

    this.getAppraisalTrim = async function(){
        if(await appraisalVehicleDataTrim.isPresent()){
            return await appraisalVehicleDataTrim.$('option:checked').getText();
        }
        else {
            return await this.getAppraisalSingleTrim();
        }
    }

    this.selectAppraisalTrim = async function(sTrim){
        await appraisalVehicleDataTrim.element(by.cssContainingText('option',sTrim)).click();
    }

    this.isPresentTrimDropDown = async function(){
        return await appraisalVehicleDataTrim.isPresent();
    }

    this.getAppraisalSingleTrim = async function(){
        return await appraisalVehicleDataSingleTrim.getText();
    }

    this.clickExteriorColorBtn = async function(){
        await browser.actions().mouseMove(extColorBtn).perform();
        await extColorBtn.click();

    }

    this.clickExteriorBlackColorBtn = async function(){
        await extBlackBtn.click();
    }

    this.clickInteriorColorBtn = async function(){
        //browser.executeScript('arguments[0].scrollIntoView()', intColorBtn.getWebElement());
        await browser.actions().mouseMove(intColorBtn).perform();
        await intColorBtn.click();
    }

    this.clickInteriorBlackColorBtn = async function(){
        await intBlackBtn.click();
    }

    this.navigateToTop = async function(){
        browser.executeScript("window.scrollTo(0, 0);");
    }

    this.scrollToBodyTab = async function(whichelement){
        browser.executeScript('arguments[0].scrollIntoView()', cdBodyTab.getWebElement());
    }

    this.scrollToFirstNameCustomerDetail = async function(){
        browser.executeScript('arguments[0].scrollIntoView()', firstNameCustomerDetail.getWebElement());
    }

    this.navigateToCommonProblems = async function(){
        //commonProblemsLabel
        browser.executeScript('arguments[0].scrollIntoView()', commonProblemsLabel.getWebElement());
    }

    this.navigateToColorButton = async function(){
        browser.executeScript('arguments[0].scrollIntoView()', extColorBtn.getWebElement());
    }

    this.navigateToOdometerInput = async function(){
        browser.executeScript('arguments[0].scrollIntoView()', odometerText.getWebElement());
    }

    this.getAppraisalID = async function(){
        var appraisalStr = await appraisalID.getText();
        return utils.splitInToTwoReturnSecondPart(appraisalStr,":")
    }

    this.getAppraisalMenu = async function(){
        await appraisalToolsMenu.click();
    }

    this.getAppraisalIDFromAppraisalMenu = async function(){
        await this.getAppraisalMenu();
        var appraisalID = await appraisalIDLabel.getText();
        //await browser.refresh();
        return appraisalID; 
    }

    this.getAppraisalByID = async function(appraisalID){
        await browser.get(browser.params.env.url+"/report/active/"+appraisalID); 
    } 

    this.clickShareEmail = async function(){
        browser.executeScript('arguments[0].scrollIntoView()', shareEmail.getWebElement());
        await shareEmail.click();
    }

    this.clickShareSMSText = async function(){
        browser.executeScript('arguments[0].scrollIntoView()', shareSMS.getWebElement());
        await shareSMS.click();
    }

    this.uploadImage = async function(filename){
        var currentPath = path.resolve("./");
        await utils.logInfo("Current File Path is : "+currentPath);

        await utils.logInfo("Upload Photos");
        var dirpath = currentPath+"/data/images/";
        await utils.logInfo("Current Dir Path is : "+dirpath);

        var filePath = dirpath+filename;

        var absolutepath = path.resolve(__dirname,filePath);
        $('input[type="file"]').sendKeys(absolutepath);
        $('#uploadButton').click();
    }

    this.uploadImages = async function(){
        
        var currentPath = path.resolve("./");
        await utils.logInfo("Current File Path is : "+currentPath);

        await utils.logInfo("click on image button");
        await uploadImageBtn.click();

        await utils.logInfo("click again on image button");
        //await addPhotosBtn.click(); // ** Not Required

        var dirpath = currentPath+"/data/images/";
        await utils.logInfo("Current Dir Path is : "+dirpath);

        var filePath = dirpath+"car-1.jpg"+"\n"+
                    dirpath+"car-2.jpg"+"\n"+
                    dirpath+"car-3.jpg"+"\n"+
                    dirpath+"car-4.jpg"+"\n"+
                    dirpath+"car-5.jpg"+"\n"+
                    dirpath+"car-6.jpg"+"\n"+
                    dirpath+"car-7.jpg"+"\n"+
                    dirpath+"car-8.jpg"+"\n"+
                    dirpath+"car-9.jpg"+"\n"+
                    dirpath+"car-10.jpg"+"\n"+
                    dirpath+"car-11.jpg";

        var absolutepath = path.resolve(__dirname,filePath);
        $('input[type="file"]').sendKeys(absolutepath);
        $('#uploadButton').click();
    }


    this.clickPriceBar = async function(){
        await priceBar.click();
    }

    this.isDisabledGuideBookTrimDropdown = async function(){
        return await guidebookTrimDropdown.getAttribute("ng-reflect-is-disabled");
    }

    this.selectGuidebookTab = async function(){
        await guidebookTab.click();
    }

    this.selectGuidebookTrimDropdown = async function(trim){
        switch(trim){
            case "XLT Reg Cab":
                await guidebookTrimDropdown.$('[value="XLT Reg Cab"]').click();
                break;
            case "XL Reg Cab":
                await guidebookTrimDropdown.$('[value="XL Reg Cab"]').click();
                break;
            default:
                await utils.logInfo("The selectGuidebookTrimDropdown() function parameter: '"+trim+"' is invalid");    
            } //switch

    }//selectGuidebookTrimDropdown() function

    this.selectGuidebookRegionDropdown = async function(region){
        switch(region){
            case "Texas":
                await guidebookRegionDropdown.$('[value="TX"]').click();
                break;
            case "California":
                await guidebookRegionDropdown.$('[value="CA"]').click();
                break;
            default:
                await utils.logInfo("The selectGuidebookRegionDropdown() function parameter: '"+region+"' is invalid");    
            } //switch
    }//selectGuidebookTrimDropdown() function

    this.selectGuidebookConditionDropdown = async function(condition){
        switch(condition){
            case "Rough":
                await guidebookConditionDropdown.$('[value="Rough"]').click();
                break;
            case "Average":
                await guidebookConditionDropdown.$('[value="Average"]').click();
                break;
            case "Clean":
                await guidebookConditionDropdown.$('[value="Clean"]').click();
                break;    
            case "X-Clean":
                await guidebookConditionDropdown.$('[value="X-Clean"]').click();
                break;    
            default:
                await utils.logInfo("The selectGuidebookConditionDropdown() function parameter: '"+condition+"' is invalid");    
            } //switch
    }//selectGuidebookConditionDropdown() function

    this.clickGuidebookOptionsEditDropdown = async function(){
        await guidebookOptionsEditDropdown.click();
    }

    this.getGuidebookSelectedOptions = async function(){
        return await guidebookSelectedOptions.getText();
    }

    this.selectGuidbook18InchWheelsOption = async function(){
        await guidbook18InchWheelsOption.click();
    }


    this.getGuidebookSelectedTrim = async function(){
        return await guidebookTrimDropdown.getAttribute("ng-reflect-model");
    }

    this.getGuidebookSelectedRegion = async function(){
        return await guidebookRegionDropdown.getAttribute("ng-reflect-model");
    }

    this.getGuidebookSelectedCondition = async function(){
        return await guidebookConditionDropdown.getAttribute("ng-reflect-model");
    }

    this.getVINScoreCard = async function(){
        var sVin = await vinScoreCard.getText();
        sVin = await utils.splitInToTwoReturnFirstPart(sVin,"|");
        return sVin.trim();
    }

    this.isReadOnlyAppraisal = async function(){
        return await readOnlyHeader.isPresent();
    }

    this.isPresentAddImageBtn = async function(){
        return await addImageBtn.isPresent();
    }

    this.clickAddImageBtn = async function(){
        await addImageBtn.click();
    }

    this.isPresentDeleteIconPhotoGallery = async function(){
        return await deleteIconPhotoGallery.isPresent();
    }

    this.selectOwnersAppraisalPage = async function(ownernumber){
        await utils.logInfo("Inside selectOwnersAppraisalPage("+ownernumber+")");
        switch(ownernumber){
            case "1":
            await utils.logInfo("Inside case:("+ownernumber+")");
            await ownersDropdown.$('[value="1"]').click();
            break;
            case "2+":
                await utils.logInfo("Inside case:("+ownernumber+")");
                await ownersDropdown.$('[value="0"]').click();
                break;
            case "Unknown":
                await utils.logInfo("Inside case:("+ownernumber+")");
                await ownersDropdown.$('[value="null"]').click();
                break;     
            default:
                await utils.logInfo("The selectOwnersAppraisalPage() function parameter: '"+ownernumber+"' is invalid");    
            } //switch

    }


}

module.exports = new appraisalpage();
