'use strict';
var HtmlReporter = require('protractor-beautiful-reporter');
var log4js = require('log4js');

exports.config = {
    framework: 'jasmine2',
    SELENIUM_PROMISE_MANAGER: false,

    //getPageTimeout: Time to wait for the page to load
    //Default page timeout is 10 seconds. I deliberately added here incase we need to change globally in future
    getPageTimeout: 30000,

    //Time to wait for page to synchronize. More information on timeouts can be found in Protractor’s wiki.
    allScriptsTimeout: 120000,

    seleniumAddress: 'http://selenium-hub:4444/wd/hub',
    specs: ['spec.js'],
    suites: {
        all: ['../specs/smoke.spec.js','../specs/conditions.reviewsend.spec.js','../specs/appraisalmenu.header.spec.js','../specs/appraisals.spec.js'],
        //all: '../specs/*.spec.js',
        smoke: '../specs/smoke.spec.js',
        conditionsreviewsend: '../specs/conditions.reviewsend.spec.js',
        appraisalmenuheader: '../specs/appraisalmenu.header.spec.js',
        appraisals: '../specs/appraisals.spec.js',
        branding: '../specs/branding.spec.js',
        pricing: '../specs/pricing.spec.js',
        scorecard: '../specs/scorecard.spec.js',
        test: '../specs/test.spec.js',
        multi: '../specs/multiwindows.spec.js'

    },
    capabilities: {
        directConnect: true,
        browserName: 'chrome',
        chromeOptions: {
            args: ["--headless", "--disable-gpu", "--window-size=1920,1080"]
        }
    },

    jasmineNodeOpts: {

        showColors: true, // Use colors in the command line report.
        defaultTimeoutInterval: 600000 //Default time out is 30 seconds.
    },

    params: {
        login: {
            validuser: 'amit+TrueCarUSSA@accu-trade.com',
            validpassword: 'Test777',
            invaliduser: 'invaliduser@accu-trade.com',
            invalidpassword: 'WrongPassword',
            errormessage: 'Wrong email or password.',
            superadminuser: 'amit+ATUSSA@accu-trade.com',
            superadminpassword: 'Test777',
            superadminfname: 'Amit',
            superadminlname: 'ATUSSA',
            basicadminuser: 'amit+ATUSBA@accu-trade.com',
            basicadminpassword: 'Test777',
            basicuser: 'amit+ATUSBU@accu-trade.com',
            basicuserpassword: 'Test777',
            bdcmanageruser: 'amit+ATUSBDCM@accu-trade.com',
            bdcmanagerpassword: 'Test777',
            salesmanageruser: 'amit+ATUSSM@accu-trade.com',
            salesmanagerpassword: 'Test777',
            acquisitionuser: 'amit+ATUSAU@accu-trade.com',
            acquisitionuserpassword: 'Test777',
            acquisitionmanageruser: 'amit+ATUSAM@accu-trade.com',
            acquisitionmanagerpassword: 'Test777'
        },
        vin: {
            validvin: '4T1B11HK7JU037859',
            validvinoptions: '1FTBF2A6XDEB44895',
            validlandrovervin: 'SALGR2FV2HA357908',
            norecallvin: 'WDBNG70J6YA130257',
            goodcarfaxautocheck: 'JF1SG63645G733373',
            badcarfaxautocheck: '3D7UT2CL3AG121957'
        },
        edituser: {
            firstname: 'AA',
            lastname: 'User'
        },
        dealer: {
            atdealername: 'Amit Accu-Trade USSA Dealership',
            truecardealername: 'Amit TrueCar USSA Dealership'
        },
        sleep: {
            sleep2: 2000,
            sleep5: 5000,
            sleep10: 10000,
            sleep20: 20000,
            sleep30: 30000,
            sleep50: 50000
        },
        env: {
            url: 'https://hercules-qa-testing.accu-trade.com'
            //url: 'https://hercules-qa.accu-trade.com'
        },
        email: {
            address: 'amit+automated@accu-trade.com'
        },
        phone: {
            number: '5129204311'
        },
        photos: {
            car: "../data/images/car-*.jpg"
        },
    },

    beforeLaunch: function () {
        //if (fs.existsSync('./logs/ExecutionLog.log')) {
        //    fs.unlink('./logs/ExecutionLog.log')
        //}
        log4js.configure({
            appenders: {
                fileLog: { type: 'file', filename: './logs/ExecutionLog.log' },
                console: { type: 'log4js-protractor-appender' }
            },
            categories: {
                file: { appenders: ['fileLog'], level: 'error' },
                another: { appenders: ['console'], level: 'trace' },
                default: { appenders: ['console', 'fileLog'], level: 'trace' }
            }
        });
    },
    onPrepare: function () {

        // browser.controlKey = protractor.Key.CONTROL; //browser.controlKey is a global variable and can be accessed anywhere in the test specs
        // browser.getCapabilities().then(function(capabilities){
        //     //if(capabilities.caps_.platform === "MAC"){
        //     if(capabilities.platform === "MAC"){
        //         browser.controlKey = protractor.Key.COMMAND;
        //     }
        // });

        browser.logger = log4js.getLogger(); //log4js

        // Add a screenshot reporter and store screenshots to `/tmp/screenshots`:
        jasmine.getEnv().addReporter(new HtmlReporter({
            baseDirectory: 'herc-test-reports/screenshots',
            preserveDirectory: false,
            takeScreenShotsOnlyForFailedSpecs: false,
            gatherBrowserLogs: false,
            docTitle: 'Hercules Test Results',
            clientDefaults: {
                searchSettings: {
                    allselected: true,
                    passed: true,
                    failed: true,
                    pending: true,
                    withLog: true
                },
                columnSettings: {
                    displayTime: true,
                    displayBrowser: true,
                    displaySessionId: true,
                    inlineScreenshots: true
                }
            }
        }).getJasmine2Reporter());
    }

};