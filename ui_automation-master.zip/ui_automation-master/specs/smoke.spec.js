var loginpage = require('../pages/login.page');
var verifymobilenumberpage = require('../pages/verifymobilenumber.page');
var homepage = require('../pages/home.page');
var myaccountpage = require('../pages/myaccount.page');
var myprofilepage = require('../pages/myprofile.page');
var appraisalpage = require('../pages/appraisal.page');
var usermgmtpage = require('../pages/usermanagement.page');
var edituserpage = require('../pages/edituser.usermgmt.page');
var dealerconsolepage = require('../pages/dealer.console.page');
var dealershippage = require('../pages/dealership.page');
var recommenderpage = require('../pages/recommender.page');
var dealershippage = require('../pages/dealership.page');
var crpage = require('../pages/cr.page');
var utils = require('../utilities/utils');
var testdata = require('../data/test.data.js');
var using = require('jasmine-data-provider');

describe('Smoke Authentication Test Suite', function () { // ********************** Describe1 *******************************
    var count = 0;
    beforeEach(async function () {
        await utils.logInfo("Start beforEach():loginpage.get() - Navigate to Login page");
        await loginpage.get();
        await browser.getCurrentUrl().then(async function (url) {
            if (url != await loginpage.getForceURL()) {
                await homepage.navigateThroughMenu("Log Out");
                await loginpage.get();
            }
        });

        await utils.logInfo("End beforEach():loginpage.get() - Navigate to Login page");
        await browser.waitForAngularEnabled(true);
    });

    afterEach(async function () {
        await utils.logInfo("Start afterEach():navigateThroughMenu('Log Out')");
        await homepage.navigateThroughMenu("Log Out");
        await utils.logInfo("End afterEach():navigateThroughMenu('Log Out')");
    });


    using(testdata.adminusers, function (data, description) {
        it('Verify log on/out/on by ' + description + ':' + data.user, async function () {
            utils.logInfo("***** TEST CASE : Verify log on/out/on by "+data.user+" *****");

            await utils.logInfo("Set Valid User Name: " + data.user);
            await loginpage.setUsername(data.user);

            await utils.logInfo("Set Valid Password: " + data.password);
            await loginpage.setPassword(data.password);

            await utils.logInfo("Click SignIn Button");
            await loginpage.clickSignIn();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            });

            if(count == 0){
                await homepage.closeAllWalkme();
                count = 1;
            }//if count

            await browser.sleep(browser.params.sleep.sleep5);
            //await browser.waitForAngularEnabled(false); //changed

            expect(await homepage.isPresentStartAppraisalBtn()).toBeTruthy("Verify the Start Appraisal button is present"); // *** Assertion 


            await browser.sleep(browser.params.sleep.sleep5);
            await browser.waitForAngularEnabled(true);

            await utils.logInfo("Navigate to My Account Page");
            await homepage.navigateThroughMenu("My Account");

            await browser.sleep(browser.params.sleep.sleep5);
            await browser.waitForAngularEnabled(false);

            utils.logInfo("Verifying user email in My Account Page");
            var emailMyAccountPage = await myaccountpage.getEmail();
            await expect(emailMyAccountPage.toLowerCase()).toContain(data.user.toLowerCase(),"Verify the email address in My Account page");
            //await browser.sleep(browser.params.sleep.sleep5);
            await browser.waitForAngularEnabled(true);

        });//it
    }); //using

    using(testdata.nonadminusers, function (data, description) {
        it('Verify log on/out/on by ' + description + ':' + data.user, async function () {
            utils.logInfo("***** TEST CASE : Verify log on/out/on by "+data.user+" *****");

            await utils.logInfo("Set Valid User Name: " + data.user);
            await loginpage.setUsername(data.user);

            await utils.logInfo("Set Valid Password: " + data.password);
            await loginpage.setPassword(data.password);

            await utils.logInfo("Click SignIn Button");
            await loginpage.clickSignIn();

            await browser.waitForAngular();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            });

            if(count == 0){
                await homepage.closeAllWalkme();
                count = 1;
            }//if count

            await browser.sleep(browser.params.sleep.sleep5);
            //await browser.waitForAngularEnabled(false); //changed

            expect(await homepage.isPresentStartAppraisalBtn()).toBeTruthy("Verify the Start Appraisal button is present"); // *** Assertion         
            await browser.sleep(browser.params.sleep.sleep5);
            await browser.waitForAngularEnabled(true);

            await utils.logInfo("Navigate to My Account Page");
            await homepage.navigateThroughMenu("My Account");


            await browser.sleep(browser.params.sleep.sleep5);
            await browser.waitForAngularEnabled(false);

            var emailMyAccountPage = await myaccountpage.getEmail();
            await expect(emailMyAccountPage.toLowerCase()).toContain(data.user.toLowerCase(),"Verify the email address in My Account page");

            //await browser.sleep(browser.params.sleep.sleep5);
            await browser.waitForAngularEnabled(true);

        });//it
    }); //using

    using(testdata.adminusers, function (data, description) {
        it('**** Verify Create appraisal: by each admin user role: ' + data.user, async function () {
            utils.logInfo("***** TEST CASE : Verify Create appraisal: by each admin user role: "+data.user+" *****");

            await utils.logInfo("Set Valid User Name: " + data.user);
            await loginpage.setUsername(data.user);

            await utils.logInfo("Set Valid Password: " + data.password);
            await loginpage.setPassword(data.password);
            await utils.logInfo("Click SignIn Button");
            await loginpage.clickSignIn();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            })

            if(count == 0){
                await homepage.closeAllWalkme();
                count = 1;
            }//if count

            await browser.sleep(browser.params.sleep.sleep5);
            //await browser.waitForAngularEnabled(false); //changed

            expect(await homepage.isPresentStartAppraisalBtn()).toBeTruthy("Verify the Start Appraisal button is present"); // *** Assertion       
            await browser.sleep(browser.params.sleep.sleep5);
            await browser.waitForAngularEnabled(true);


            await browser.refresh();
            await utils.logInfo("Click Start Apprisal Button");
            await homepage.clickStartAppraisalBtn();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            });

            await homepage.clickNewAppraisalVINTab();
            await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

            var EC = protractor.ExpectedConditions;
            browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
            await homepage.setVin(browser.params.vin.validvin);
            await utils.logInfo("Click on the VIN Search button");
            await homepage.clickVinSearch();

            await utils.logInfo("Click on First Trim");
            await homepage.clickFirstTrim();

            await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
            await browser.sleep(browser.params.sleep.sleep10);

            await utils.logInfo("Disable Wait for Angular");
            await browser.waitForAngularEnabled(false); // *** Angular Enabled False

            await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
            var sVIN = await homepage.getAppraisalVIN();

            await utils.logInfo("Enable Wait for Angular");
            await browser.waitForAngularEnabled(true); // *** Angular Enabled True

            await utils.logInfo("Value of Appraisal VIN is " + sVIN);
            await utils.logInfo("Verify Appraisal VIN matching expected VIN");
            await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/

        }); //it
    }); //using

    using(testdata.nonadminusers, function (data, description) {
       it('**** Verify Create appraisal: by each non-admin user role: ' + data.user, async function () {
            utils.logInfo("***** TEST CASE : Verify Create appraisal: by each non-admin user role: "+data.user+" *****");

            await utils.logInfo("Set Valid User Name: " + data.user);
            await loginpage.setUsername(data.user);

            await utils.logInfo("Set Valid Password: " + data.password);
            await loginpage.setPassword(data.password);
            await utils.logInfo("Click SignIn Button");
            await loginpage.clickSignIn();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            })

            if(count == 0){
                await homepage.closeAllWalkme();
                count = 1;
            }//if count

            await browser.sleep(browser.params.sleep.sleep5);
            //await browser.waitForAngularEnabled(false); //changed

            expect(await homepage.isPresentStartAppraisalBtn()).toBeTruthy("Verify the Start Appraisal button is present"); // *** Assertion         
            await browser.sleep(browser.params.sleep.sleep5);
            await browser.waitForAngularEnabled(true);

            //await browser.get(browser.params.env.url + "/report/active");
            await browser.refresh();

            await utils.logInfo("Click Start Apprisal Button");
            await homepage.clickStartAppraisalBtn();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            });

            await homepage.clickNewAppraisalVINTab();
            await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

            var EC = protractor.ExpectedConditions;
            browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
            await homepage.setVin(browser.params.vin.validvin);
            await utils.logInfo("Click on the VIN Search button");
            await homepage.clickVinSearch();

            await utils.logInfo("Click on First Trim");
            await homepage.clickFirstTrim();

            await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
            await browser.sleep(browser.params.sleep.sleep10);

            await utils.logInfo("Disable Wait for Angular");
            await browser.waitForAngularEnabled(false); // *** Angular Enabled False

            await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
            var sVIN = await homepage.getAppraisalVIN();

            await utils.logInfo("Enable Wait for Angular");
            await browser.waitForAngularEnabled(true); // *** Angular Enabled True

            await utils.logInfo("Value of Appraisal VIN is " + sVIN);
            await utils.logInfo("Verify Appraisal VIN matching expected VIN");
            await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/

        }); //it
    }); //using

    using(testdata.allusertypes, function (data, description) {
        it('**** Verify Create New Appraisal: by TrueCar, Trader, AT account: ' + data.user, async function () {
            utils.logInfo("***** TEST CASE : Verify Create New Appraisal by TrueCar, Trader, AT account: "+data.user+" *****");

            await utils.logInfo("Set Valid User Name: " + data.user);
            await loginpage.setUsername(data.user);

            await utils.logInfo("Set Valid Password: " + data.password);
            await loginpage.setPassword(data.password);
            await utils.logInfo("Click SignIn Button");
            await loginpage.clickSignIn();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            })

            if(count == 0){
                await homepage.closeAllWalkme();
                count = 1;
            }//if count

            await browser.sleep(browser.params.sleep.sleep5);
            //await browser.waitForAngularEnabled(false); //changed

            expect(await homepage.isPresentStartAppraisalBtn()).toBeTruthy("Verify the Start Appraisal button is present"); // *** Assertion          
            await browser.sleep(browser.params.sleep.sleep5);
            await browser.waitForAngularEnabled(true);

            //await browser.get(browser.params.env.url + "/report/active");
            await browser.refresh();

            await utils.logInfo("Click Start Apprisal Button");
            await homepage.clickStartAppraisalBtn();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            });

            await browser.sleep(browser.params.sleep.sleep5);

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            })
            
            await browser.sleep(browser.params.sleep.sleep5);

            await homepage.clickNewAppraisalVINTab();
            await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

            var EC = protractor.ExpectedConditions;
            browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
            await homepage.setVin(browser.params.vin.validvin);
            await utils.logInfo("Click on the VIN Search button");
            await homepage.clickVinSearch();

            await utils.logInfo("Click on First Trim");
            await homepage.clickFirstTrim();

            await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
            await browser.sleep(browser.params.sleep.sleep10);

            await utils.logInfo("Disable Wait for Angular");
            await browser.waitForAngularEnabled(false); // *** Angular Enabled False

            await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
            var sVIN = await homepage.getAppraisalVIN();

            await utils.logInfo("Enable Wait for Angular");
            await browser.waitForAngularEnabled(true); // *** Angular Enabled True

            await utils.logInfo("Value of Appraisal VIN is " + sVIN);
            await utils.logInfo("Verify Appraisal VIN matching expected VIN");
            await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/

        }); //it
    }); //using

    using(testdata.ymmttestdata, function (data, description) {
        it('**** Verify Create New appraisal by YMMT', async function () {
            utils.logInfo("***** TEST CASE : Verify Create New appraisal by YMMT : testdata.ymmttestdata *****");

            await utils.logInfo("Set Valid User Name: " + browser.params.login.superadminuser);
            await loginpage.setUsername(browser.params.login.superadminuser);
            await utils.logInfo("Set Valid Password: " + browser.params.login.superadminpassword);
            await loginpage.setPassword(browser.params.login.superadminpassword);
            await utils.logInfo("Click SignIn Button");
            await loginpage.clickSignIn();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                } //if
            }) //getCurrentURL

            if(count == 0){
                await homepage.closeAllWalkme();
                count = 1;
            }//if count

            await browser.sleep(browser.params.sleep.sleep5);
            //await browser.waitForAngularEnabled(false); //changed

            expect(await homepage.isPresentStartAppraisalBtn()).toBeTruthy("Verify the Start Appraisal button is present"); // *** Assertion        
            await browser.sleep(browser.params.sleep.sleep5);
            await browser.waitForAngularEnabled(true);
            await homepage.createNewAppraisalYMMT(data.year,data.make,data.model,data.trim); 
            
            await browser.waitForAngularEnabled(false);

            await utils.logInfo("Verify Appraisal Year Make Model matching expected YMM");
            expect(await appraisalpage.getAppraisalYMM()).toContain(data.year+" "+data.make+" "+data.model,"Verify Appraisal Year Make Model matching expected YMM on Appraisal Page"); //*** Assertion ***/
            
            await utils.logInfo("Verify Appraisal Trim matching expected trim");
            expect(await appraisalpage.getAppraisalTrim()).toContain(data.trim,"Verify Appraisal Trim matching expected trim on Appraisal Page"); //*** Assertion ***/

        }); //it
    });//using

}); //describe 1


describe('Smoke User Management Test Suite', function () { // ********************** Describe 2 *******************************
    browser.manage().timeouts().implicitlyWait(5000);
    browser.driver.manage().window().maximize();
    utils.logInfo("Smoke User Management Test Suite");
    var count = 0;
    
    beforeEach(async function () {
        await utils.logInfo("Getting Home Page")
        await homepage.get();
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.getCurrentUrl().then(async function (url) {
            await utils.logInfo("Before each : Current Url is "+url);
            await browser.sleep(browser.params.sleep.sleep5);

            if (url == await loginpage.getURL()) {
                utils.logInfo("Sign in since current page is Login page")
                await loginpage.signIn(browser.params.login.superadminuser, browser.params.login.superadminpassword);
                await browser.getCurrentUrl().then(async function (url) {
                    if (url == await verifymobilenumberpage.getUrl()) {
                        await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                        await verifymobilenumberpage.clickRemindme();
                    }//if
                })//then
            }//if
            else if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
            await browser.waitForAngularEnabled(true);

        });

        if(count == 0){
            await homepage.closeAllWalkme();
            count = 1;
        }//if count

    }); //beforeEach


   it('*** Add User Management', async function(){
        utils.logInfo("***** TEST CASE : Add User Management *****");
        var EC = protractor.ExpectedConditions;
        await browser.refresh();

        await utils.logInfo("Navigate to User Management Page");
        await homepage.navigateThroughMenu("User Management");

        var randVal = Date.now();
        var emaildata = "aa"+randVal+"@aa.com";
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.waitForAngularEnabled(false); 
        
        await usermgmtpage.addUser(emaildata); //** Add User **/
        await browser.sleep(browser.params.sleep.sleep10);


        await utils.logInfo("Checking if Add Users button enable again after adding a user");
        browser.wait(EC.presenceOf(usermgmtpage.getAddUserButton(), 10000));       
        
        var useremail = element.all(by.css('.email'));
        await utils.logInfo("useremail.getText() = "+ await useremail.getText());

        expect(await useremail.getText()).toContain(emaildata,"Verify newly added user showing up in User Management Page");

        browser.wait(EC.presenceOf(usermgmtpage.getAddUserButton(), 10000));

        var locator = "//*[text()='"+emaildata+"']";
        utils.logInfo("locator is "+locator);
        var email = element(by.xpath(locator));

        utils.logInfo("Click on user");

        await email.click();
        
        utils.logInfo("Set First Name to "+browser.params.edituser.firstname);
        await edituserpage.setFirstName(browser.params.edituser.firstname);

        utils.logInfo("Set Last Name to "+browser.params.edituser.lastname);
        await edituserpage.setLastName(browser.params.edituser.lastname);

        utils.logInfo("Edit Role");
        await edituserpage.selectRole("Acquisition Manager");

        utils.logInfo("Click on Update Button");
        await edituserpage.clickUpdateAccountBtn();

        await browser.waitForAngularEnabled(true);

        utils.logInfo("Verify added user is present");

        var status = await usermgmtpage.isPresentUser(browser.params.edituser.firstname+" "+browser.params.edituser.lastname, emaildata);
        utils.logInfo("usermgmtpage.isPresentUser() is "+status);
        expect(status).toBeTruthy("Verify newly added user '"+browser.params.edituser.firstname+" "+browser.params.edituser.lastname+"' is present in User Management page");



    });//it


    it('*** Verify edit to 1 book selection', async function () {
        utils.logInfo("***** TEST CASE : Verify edit to 1 book selection *****");

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
                await utils.logInfo("After Click Remind me on Verify Mobile Number Page");

            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvinoptions + " into New Appraisal Window");
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvinoptions);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();
 
        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();
 
        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);
 
        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False
 
        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();
        var appraisalID = await appraisalpage.getAppraisalID();
 
        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True
 
        await utils.logInfo("Value of Appraisal ID is " + appraisalID);
        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvinoptions,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        await utils.logInfo("Open Appraisal Tools Menu");
        await appraisalpage.getAppraisalMenu();

        await utils.logInfo("Click on Guidebook Appraisal Tools menu item");
        await appraisalpage.clickGuidebookAppraisalMenuItem();

        //Edit Trim
        await utils.logInfo("Select Trim Dropdown: XLT Reg Cab");
        await appraisalpage.selectGuidebookTrimDropdown("XLT Reg Cab");
        await browser.sleep(browser.params.sleep.sleep5);


        //Edit Region
        await utils.logInfo("Select Region Dropdown: Texas");
        await appraisalpage.selectGuidebookRegionDropdown("Texas");
        await browser.sleep(browser.params.sleep.sleep5);


        //Edit Condition
        await utils.logInfo("Select Condition Dropdown: Average");
        await appraisalpage.selectGuidebookConditionDropdown("Average");
        await browser.sleep(browser.params.sleep.sleep5);

        
        //Edit Options
        await utils.logInfo("Select an Option: 18 Inch Wheels");
        await appraisalpage.clickGuidebookOptionsEditDropdown();
        await appraisalpage.selectGuidbook18InchWheelsOption();
        await appraisalpage.clickGuidebookOptionsEditDropdown();
        await browser.sleep(browser.params.sleep.sleep5);
        await appraisalpage.clickBackArrowBtn();

        await browser.waitForAngularEnabled(true); // *** Angular Disabled

        //Refresh Browser
        await browser.refresh();

        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        await utils.logInfo("Open Appraisal Tools Menu");
        await appraisalpage.getAppraisalMenu();

        await utils.logInfo("Click on Guidebook Appraisal Tools menu item");
        await appraisalpage.clickGuidebookAppraisalMenuItem();

        //Verify all Edits persist
        await utils.logInfo("Verifying the selected option is 18-Inch Wheels");
        expect(await appraisalpage.getGuidebookSelectedOptions()).toContain("18-Inch Wheels","Verifying the selected option is '18-Inch Wheels' in Guidebook for appraisal ID "+appraisalID);

        await utils.logInfo("Verifying the selected trim is XLT Reg Cab");
        expect(await appraisalpage.getGuidebookSelectedTrim()).toBe("XLT Reg Cab","Verifying the selected trim is 'XLT Reg Cab' in Guidebook for appraisal ID "+appraisalID);

        await utils.logInfo("Verifying the selected Region is Texas");
        expect(await appraisalpage.getGuidebookSelectedRegion()).toBe("TX","Verifying the selected Region is 'Texas' in Guidebook for appraisal ID "+appraisalID);

        await utils.logInfo("Verifying the selected Condition is Average");
        expect(await appraisalpage.getGuidebookSelectedCondition()).toBe("Average","Verifying the selected Condition is 'Average' in Guidebook for appraisal ID "+appraisalID);

        await browser.waitForAngularEnabled(true); // *** Angular Disabled
        //await browser.sleep(browser.params.sleep.sleep5);

    });

    it('*** Verify Create appraisal with Condition Disclosures, Options, Service Status: 1 for each section', async function () {
        utils.logInfo("***** TEST CASE : Verify Create appraisal with Condition Disclosures, Options, Service Status: 1 for each section *****");
        await browser.refresh();

        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvinoptions + " into New Appraisal Window");
 
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvinoptions);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();
 
        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();
 
        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);
 
        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False
 
        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();
 
        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True
 
        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvinoptions,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);
 
        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        // Select Options
        await appraisalpage.setOptions("4 WHEEL DRIVE");
        expect(await appraisalpage.getOptionsAmountValue()).toBe("+$900","Verify '4 WHEEL DRIVE' Option adjustment value");

        //Select Service Status
        await appraisalpage.setServiceStatus("OEM CERTIFIED");
        expect(await appraisalpage.getServiceStatusAmountValue()).toBe("+$300","Verify 'OEM CERTIFIED' Service Status adjustment value");

        // Select Conditional Disclosure
        await appraisalpage.clickCDBodyExtRightBackDoorBtn();
        await appraisalpage.clickCDBodyPrevReplacementDamageTypeBtn();
        await appraisalpage.clickCDBodyPrevReplacementWetSandDamageTypeBtn();
        expect(await appraisalpage.getCDDamageListItemCount()).toBe(1,"Verify Damage list count");
        browser.executeScript('arguments[0].scrollIntoView()', appraisalpage.getCDBodyTabWebElement().getWebElement());
        expect(await appraisalpage.getCDBodyTotalAdjustmentAmount()).toBe("-400","Verify Body Total Adjustment value");
        
        await browser.waitForAngularEnabled(true); // *** Angular Disabled

    });

    it('*** Verify Edit existing appraisal: Update Photo, Color, Mileage, Option, Service Status, Disclosures', async function () {
        utils.logInfo("***** TEST CASE : Verify Edit existing appraisal: Update Photo, Color, Mileage, Option, Service Status, Disclosures *****");

        await browser.refresh();

        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvinoptions + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvinoptions);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvinoptions,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        //var appraisalID = await appraisalpage.getAppraisalIDFromAppraisalMenu();

        var appraisalID = await appraisalpage.getAppraisalID();
        await browser.waitForAngularEnabled(true); // *** Angular Disabled
        
        //Get Homepage
        await utils.logInfo("Getting home page");
        await homepage.get();
        
        //Search Appraisal ID
        await utils.logInfo("Search Appraisal by Appraisal ID");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep5);

        //Open Searched Appraisal
        await utils.logInfo("Open Searched Appraisal");
        await homepage.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep10);
        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        // Edit Options
        await utils.logInfo("Edit Option to include 4 WHEEL DRIVE");
        await appraisalpage.setOptions("4 WHEEL DRIVE");

        await utils.logInfo("Verify the amount adjustment for added option");
        expect(await appraisalpage.getOptionsAmountValue()).toBe("+$900","Verify '4 WHEEL DRIVE' Option adjustment value");

        //Edit Service Status
        await utils.logInfo("Edit the Service Status to include OEM CERTIFIED");
        await appraisalpage.setServiceStatus("OEM CERTIFIED");
        await utils.logInfo("Verify the amount adjustment for the added service status");
        expect(await appraisalpage.getServiceStatusAmountValue()).toBe("+$300","Verify 'OEM CERTIFIED' Service Status adjustment value");

        // Edit Conditional Disclosure
        await utils.logInfo("Edit the Body Conditional Disclosure and select Right Back Door");
        await appraisalpage.clickCDBodyExtRightBackDoorBtn();
        await utils.logInfo("Edit the Conditional Disclosure>Right Back Door>Prev Replace");
        await appraisalpage.clickCDBodyPrevReplacementDamageTypeBtn();
        await utils.logInfo("Edit the Conditional Disclosure>Right Back Door>Prev Replace>Wet Sand Damage Type");
        await appraisalpage.clickCDBodyPrevReplacementWetSandDamageTypeBtn();
        await utils.logInfo("Verify the Damage List item added at the bottom");
        expect(await appraisalpage.getCDDamageListItemCount()).toBe(1,"Verify Damage List Count");
        browser.executeScript('arguments[0].scrollIntoView()', appraisalpage.getCDBodyTabWebElement().getWebElement());
        await utils.logInfo("Verify the Conditional Disclosure Body Total Adjusted Amount");
        expect(await appraisalpage.getCDBodyTotalAdjustmentAmount()).toBe("-400","Verify Body Total Adjustment value");
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.waitForAngularEnabled(true); // *** Angular Disabled

        //Get Homepage
        await utils.logInfo("Getting home page");
        await homepage.get();
                
        //Search Appraisal ID
        await utils.logInfo("Search Appraisal by Appraisal ID");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep5);

        //Open Searched Appraisal
        await utils.logInfo("Open Seached Appraisal");
        await homepage.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep10);
        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        await utils.logInfo("Verify edited value in Searched Appraisal");
        expect(await appraisalpage.getOptionsAmountValue()).toBe("+$900","Verify '4 WHEEL DRIVE' Option adjustment value");
        expect(await appraisalpage.getServiceStatusAmountValue()).toBe("+$300","Verify 'OEM CERTIFIED' Service Status adjustment value");
        browser.executeScript('arguments[0].scrollIntoView()', appraisalpage.getCDBodyTabWebElement().getWebElement());
        expect(await appraisalpage.getCDBodyTotalAdjustmentAmount()).toBe("-400","Verify Body Total Adjustment value");

        await browser.sleep(browser.params.sleep.sleep5);

        await browser.waitForAngularEnabled(true); // *** Angular Disabled

    });

    it('***Verify Create New appraisal. Increase Offer. Ground. Accept Offer', async function () {        
        utils.logInfo("***** TEST CASE : Verify Create New appraisal. Increase Offer. Ground. Accept Offer *****");
        await browser.refresh();

        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");
 
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();
 
        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();
 
        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);
 
        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False
 
        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);
 
        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True
 
        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);
 
        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        //Select Interior and Exterior Color
        //await appraisalpage.navigateToCommonProblems();
        await utils.logInfo("Click Exterior Color Button");
        await appraisalpage.clickExteriorColorBtn();
 
        await utils.logInfo("Select Black Exterior Color");
        await appraisalpage.clickExteriorBlackColorBtn();
 
        await utils.logInfo("Click Interior Color Button");
        await appraisalpage.clickInteriorColorBtn();
  
        await utils.logInfo("Selct Black Interior Color");
        await appraisalpage.clickInteriorBlackColorBtn();
        await browser.sleep(browser.params.sleep.sleep5);
 
        //Upload Photos
        await utils.logInfo("Upload Images");
        await appraisalpage.uploadImages();
        await browser.sleep(browser.params.sleep.sleep30);
        await utils.logInfo("Click on left photo gallery button");
        await appraisalpage.clickLeftPhotoGalleryBtn();

        //Increase Offer
        expect(await appraisalpage.isPresentIncreaseOfferBtn()).toBeTruthy("Verify Increase Offer options is present");
        await utils.logInfo("Click on Increase Offer Button");
        await appraisalpage.clickIncreaseOfferBtn();
        await utils.logInfo("Enter Increase Offer Amount of $1000");
        await appraisalpage.enterIncreaseOfferAmount("1000");
        await utils.logInfo("Enter Increase Offer Expires in 3 days");
        await appraisalpage.enterIncreaseOfferExpiresInput("3");
        
        await utils.logInfo("Select Increase Offer Agreement checkbox");
        await appraisalpage.selectIncreaseOfferAgreementCheckBox();

        await utils.logInfo("Click on Increase Offer Next Button");
        await appraisalpage.clickIncreaseOfferNextBtn();

        await utils.logInfo("Click on Increase Offer Send Button");
        await appraisalpage.clickIncreaseOfferSendBtn(); 

        expect(await appraisalpage.isPresentIncreaseOfferBtn()).toBeFalsy("Verify Increase Offer options is not present after Increase Offer Successful Submission");
    
        var elem = element(by.xpath("//*[text()='Offer increased by $1,000']"));
        await utils.logInfo("Verify Increase Offer amount visible on Appraisal screen");
        expect(await elem.isPresent()).toBeTruthy("Verify Increase Offer amount visible on Appraisal screen");

        await browser.sleep(browser.params.sleep.sleep5);
 
        //Click on Ground Vehicle
        expect(await appraisalpage.isPresentGroundVehicleBtn()).toBeTruthy("Verify Ground option is present under Select Action");
        await appraisalpage.clickGroundVehicleBtn();
        await appraisalpage.clickGroundAppraisalTrimCheckBox();
        await appraisalpage.clickGroundAppraisalOdometerCheckBox();
        await appraisalpage.clickGroundAppraisalConditionDisclosuresCheckBox();
        await appraisalpage.clickGroundAppraisalConfirmAndGroundBtn();
        // await browser.sleep(browser.params.sleep.sleep10);

        // if(await appraisalpage.isPresentWalkMeAlreadyGroundedMsgDialog()){
        //     await appraisalpage.closeWalkMeAlreadyGroundedMsgDialog();
        // }

        // if(await appraisalpage.isPresentWalkMeGroundMsgDialog()){
        //     await appraisalpage.closeWalkMeGroundMsgDialog();
        // }
        await browser.sleep(browser.params.sleep.sleep2);

        await utils.logInfo("Is Successfully Grounded message present "+await appraisalpage.isPresentGroundAppraisalSuccessMessage());
        await utils.logInfo("Vehicle was Grounded message present "+await appraisalpage.isPresentGroundAppraisalSuccessDateMessage());
        expect(await appraisalpage.isPresentGroundAppraisalSuccessMessage()).toBeTruthy("Verify Vehicle Successful Grounded message is present");
        expect(await appraisalpage.isPresentGroundAppraisalSuccessDateMessage()).toBeTruthy("Verify Vehicle Successful Grounded date message is present");
        expect(await appraisalpage.getGroundAppraisalSuccessMessageValue()).toContain("Successfully Grounded","Verify Vehicle Successful Grounded message value");
        expect(await appraisalpage.getGroundAppraisalSuccessDateMessageValue()).toContain("This vehicle was Grounded on "+utils.getCurrentDateMonthYear()+".","Verify Vehicle Successful Grounded Date message value");
        
        await appraisalpage.clickGroundAppraisalBackBtn();

        await utils.logInfo("Verify Grounded text visible on Appraisal screen underneath Price Bar");
        expect(await appraisalpage.isPresentGroundedMsg()).toBeTruthy("Verify 'Grounded' text visible on Appraisal screen underneath Price Bar");
        expect(await appraisalpage.isPresentGroundedAppraisalLabel()).toBeTruthy("Verify 'Grounded' text visible at top center of Appraisal page");
        expect(await appraisalpage.isPresentGroundedCountdownTimer()).toBe(true,"Verify Grounded Countdown timer visible on Appraisal screen underneath Price Bar ");
        expect(await appraisalpage.isPresentGroundVehicleBtn()).toBeFalsy("Verify Ground option is not present after vehicle is grounded");

        //Instant Offer
        await utils.logInfo("Is Present Accutrade Instant Offer Btn : "+await appraisalpage.isPresentGetAccutradeInstantOfferBtn());
        expect(await appraisalpage.isPresentGetAccutradeInstantOfferBtn()).toBeTruthy("Verify the availability of Accutrade Instant Offer Btn");
        
        await utils.logInfo("Click on Instant Offer Link");
        await appraisalpage.clickGetAccutradeInstantOfferBtn();

        //Verify Submit button is Grayed out (disabled)
        await utils.logInfo("appraisalpage.isGetOfferSubmitButtonDisabled() = "+await appraisalpage.isGetOfferSubmitButtonDisabled());
        expect(await appraisalpage.isGetOfferSubmitButtonDisabled()).toBe('true',"Verify Submit(Confirm & Get Offer) Button is Disabled until CheckBox is Selected");

        //Click on Checkbox
        await utils.logInfo("Click on Checkbox");
        await appraisalpage.clickGetOfferCheckBox();

        //Verify Submit button is Enabled
        await utils.logInfo("appraisalpage.isGetOfferSubmitButtonDisabled() = "+await appraisalpage.isGetOfferSubmitButtonDisabled());
        expect(await appraisalpage.isGetOfferSubmitButtonDisabled()).toBe('false',"Verify Submit(Confirm & Get Offer) Button is Enabled when CheckBox is Selected");
        
        await utils.logInfo("Click on GetAccutradeInstantOffer Screen Submit Button");
        await appraisalpage.clickGetOfferSubmitBtn();

        await utils.logInfo("Is Successful Msg present : "+await appraisalpage.isPresentGetAccutradeInstantOfferSuccessMsg());
        expect(await appraisalpage.isPresentGetAccutradeInstantOfferSuccessMsg()).toBeTruthy("Verify Instant Offer is Successfully Submit by Showing 'Successully Submitted' message");

        await utils.logInfo("Is Successful Descripton Msg present : "+ await appraisalpage.isPresentGetAccutradeInstantOfferSuccessDescriptionMsg());
        expect(await appraisalpage.isPresentGetAccutradeInstantOfferSuccessDescriptionMsg()).toBeTruthy("Verify Instant Offer is Successfully Submit by Showing 'This vehicle was submitted for Accu-Trade Instant Offer on mm/dd/yyyy' message");

        await appraisalpage.clickGetOfferBackBtn();
        await utils.logInfo("Is Pending Offer status bar present : "+await appraisalpage.isPresentGetAccutradeInstantOfferPendingMsg());
        expect(await appraisalpage.isPresentGetAccutradeInstantOfferPendingMsg()).toBeTruthy("Verify Appraisal Page showing status bar with text 'Accu-Trade Instant Offer Pending'");

        await utils.logInfo("Is Offer present at the top-center of Appraisal screen : "+await appraisalpage.isPresentGetOfferAppraisalLabel());
        expect(await appraisalpage.isPresentGetOfferAppraisalLabel()).toBeTruthy("Verify Appraisal page showing 'Offer' at the top-middle of the screen above Apprsial ID");

        expect(await appraisalpage.isPresentGetAccutradeInstantOfferBtn()).toBeFalsy("Verify Accutrade Instant Offer button is not present after Offer is successfully submitted");

        //Get An appraisal ID
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);

        await browser.waitForAngularEnabled(true); // *** Angular Enabled

        //Click on Offers list view
        await homepage.get();
        await homepage.clickOffersAppraisalList();
        await utils.logInfo("Verify Offers Appraisals list tab is selected when click on Offers list view");
        expect(await homepage.isOffersAppraisalListTabSelected()).toBeTruthy();

        //Search for an appraisal ID
        await homepage.searchAppraisalList(appraisalID);

        //Verify the Appraisal Should display
        expect(await homepage.getAppraisalsRowCount()).toBe(1,"Verify Appraisal now display under Offers list view");
 
    });

    //}); // **Authentication IT cases
    it('Verify Create new VIN appraisal. Ground. Accept Offer', async function () {
        utils.logInfo("***** TEST CASE : Verify Create new VIN appraisal. Ground. Accept Offer *****");

        await browser.refresh();

        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");
 
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();
 
        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();
 
        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);
 
        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False
 
        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();
 
        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True
 
        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);
 
        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        //Select Interior and Exterior Color
        //await appraisalpage.navigateToCommonProblems();
        await utils.logInfo("Click Exterior Color Button");
        await appraisalpage.clickExteriorColorBtn();
 
        await utils.logInfo("Select Black Exterior Color");
        await appraisalpage.clickExteriorBlackColorBtn();
 
        await utils.logInfo("Click Interior Color Button");
        await appraisalpage.clickInteriorColorBtn();
  
        await utils.logInfo("Selct Black Interior Color");
        await appraisalpage.clickInteriorBlackColorBtn();
        await browser.sleep(browser.params.sleep.sleep5);
 
        //Upload Photos
        await utils.logInfo("Upload Images");
        await appraisalpage.uploadImages();
        await browser.sleep(browser.params.sleep.sleep30);
        await utils.logInfo("Click on left photo gallery button");
        await appraisalpage.clickLeftPhotoGalleryBtn();        
        await browser.sleep(browser.params.sleep.sleep5);
 
        //Click on Ground Vehicle
        await appraisalpage.clickGroundVehicleBtn();
        await appraisalpage.clickGroundAppraisalTrimCheckBox();
        await appraisalpage.clickGroundAppraisalOdometerCheckBox();
        await appraisalpage.clickGroundAppraisalConditionDisclosuresCheckBox();
        await appraisalpage.clickGroundAppraisalConfirmAndGroundBtn();
        // await browser.sleep(browser.params.sleep.sleep10);

        // if(await appraisalpage.isPresentWalkMeAlreadyGroundedMsgDialog()){
        //     await appraisalpage.closeWalkMeAlreadyGroundedMsgDialog();
        // }

        // if(await appraisalpage.isPresentWalkMeGroundMsgDialog()){
        //     await appraisalpage.closeWalkMeGroundMsgDialog();
        // }
        await browser.sleep(browser.params.sleep.sleep2);

        await utils.logInfo("Is Successfully Grounded message present "+await appraisalpage.isPresentGroundAppraisalSuccessMessage());
        await utils.logInfo("Vehicle was Grounded message present "+await appraisalpage.isPresentGroundAppraisalSuccessDateMessage());
        expect(await appraisalpage.isPresentGroundAppraisalSuccessMessage()).toBeTruthy("Verify Vehicle Successful Grounded message is present");
        expect(await appraisalpage.isPresentGroundAppraisalSuccessDateMessage()).toBeTruthy("Verify Vehicle Successful Grounded date message is present");
        expect(await appraisalpage.getGroundAppraisalSuccessMessageValue()).toContain("Successfully Grounded","Verify Vehicle Successful Grounded message value");
        expect(await appraisalpage.getGroundAppraisalSuccessDateMessageValue()).toContain("This vehicle was Grounded on "+utils.getCurrentDateMonthYear(),"Verify Vehicle Successful Grounded Date message value");
        
        await appraisalpage.clickGroundAppraisalBackBtn();

        await utils.logInfo("Verify Grounded text visible on Appraisal screen underneath Price Bar");
        expect(await appraisalpage.isPresentGroundedMsg()).toBeTruthy("Verify 'Grounded' text visible on Appraisal screen underneath Price Bar");
        expect(await appraisalpage.isPresentGroundedAppraisalLabel()).toBeTruthy("Verify 'Grounded' text visible at top center of Appraisal page");
        expect(await appraisalpage.isPresentGroundedCountdownTimer()).toBe(true,"Verify Grounded Countdown timer visible on Appraisal screen underneath Price Bar ");

        await utils.logInfo("Is Present Accutrade Instant Offer Btn : "+await appraisalpage.isPresentGetAccutradeInstantOfferBtn());
        expect(await appraisalpage.isPresentGetAccutradeInstantOfferBtn()).toBeTruthy("Verify the availability of Accutrade Instant Offer Btn");

        //Click on Get Accu-Trade Instant Offer Button
        await utils.logInfo("Is Present Accutrade Instant Offer Btn : "+await appraisalpage.isPresentGetAccutradeInstantOfferBtn());
        expect(await appraisalpage.isPresentGetAccutradeInstantOfferBtn()).toBeTruthy("Verify the availability of Accutrade Instant Offer Btn");
        await utils.logInfo("Click on GetAccutradeInstantOffer Button");
        await appraisalpage.clickGetAccutradeInstantOfferBtn();

        //Click CheckBox
        await utils.logInfo("Click on GetAccutradeInstantOffer Screen checkbox");
        await appraisalpage.clickGetOfferCheckBox();

        //Click on Submit Button
        await utils.logInfo("Click on GetAccutradeInstantOffer Screen Submit Button");
        await appraisalpage.clickGetOfferSubmitBtn();

        await utils.logInfo("Is Successful Msg present : "+await appraisalpage.isPresentGetAccutradeInstantOfferSuccessMsg());
        expect(await appraisalpage.isPresentGetAccutradeInstantOfferSuccessMsg()).toBeTruthy("Verify Instant Offer is Successfully Submit by Showing 'Successully Submitted' message");

        await utils.logInfo("Is Successful Descripton Msg present : "+ await appraisalpage.isPresentGetAccutradeInstantOfferSuccessDescriptionMsg());
        expect(await appraisalpage.isPresentGetAccutradeInstantOfferSuccessDescriptionMsg()).toBeTruthy("Verify Instant Offer is Successfully Submit by Showing 'This vehicle was submitted for Accu-Trade Instant Offer on mm/dd/yyyy' message");

        await appraisalpage.clickGetOfferBackBtn();
        await utils.logInfo("Is Pending Offer status bar present : "+await appraisalpage.isPresentGetAccutradeInstantOfferPendingMsg());
        expect(await appraisalpage.isPresentGetAccutradeInstantOfferPendingMsg()).toBeTruthy("Verify Appraisal Page showing status bar with text 'Accu-Trade Instant Offer Pending'");

        await utils.logInfo("Is Offer present at the top-center of Appraisal screen : "+await appraisalpage.isPresentGetOfferAppraisalLabel());
        expect(await appraisalpage.isPresentGetOfferAppraisalLabel()).toBeTruthy("Verify Appraisal page showing 'Offer' at the top-middle of the screen above Apprsial ID");
        
        //Get An appraisal ID
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);

        await browser.waitForAngularEnabled(true); // *** Angular Enabled

        //Click on Offers list view
        await homepage.get();
        await homepage.clickOffersAppraisalList();
        await utils.logInfo("Verify Offers Appraisals list tab is selected when click on Offers list view");
        expect(await homepage.isOffersAppraisalListTabSelected()).toBeTruthy();

        //Search for an appraisal ID
        await homepage.searchAppraisalList(appraisalID);

        //Verify the Appraisal Should display
        expect(await homepage.getAppraisalsRowCount()).toBe(1,"Verify Appraisal now display under Offers list view");
    

    }); //it



   it('*** Verify Appraisal tools menu links: all links function & direct to correct location', async function () {
        utils.logInfo("***** TEST CASE : Verify Appraisal Menu links: all links function & direct to correct location *****");
        
        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/  
        await browser.sleep(browser.params.sleep.sleep10);

        //Get Appraisal Menu
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        var appraisalURL = await browser.getCurrentUrl(); 

        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("After Get Appraisal Menu");

        //HEADER
        await utils.logInfo("Verify 'Email' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentAppraisalMenuEmail()).toBeTruthy("Verify 'Email' Menu item present in Appraisal Menu");

        await utils.logInfo("Verify 'SMS' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentAppraisalMenuSMS()).toBeTruthy("Verify 'SMS' Menu item present in Appraisal Menu");

        await utils.logInfo("Verify 'Feedback' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentFeedbackAppraisalMenuItem()).toBeTruthy("Verify 'Feedback' Menu item present in Appraisal Menu");

        //CUSTOMER
        await utils.logInfo("Verify 'Customer Information' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentCustomerInfoMenuItem()).toBeTruthy("Verify 'Customer Information' Menu item present in Appraisal Menu");

        //REPORTS
        await utils.logInfo("Verify 'Consumer Appraisal Report' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentConsumerAppraisalMenuItem()).toBeTruthy("Verify 'Consumer Appraisal Report' Menu item present in Appraisal Menu");

        await utils.logInfo("Verify 'Dealer Condition Report' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentDealershipAppraisalMenuItem()).toBeTruthy("Verify 'Dealer Condition Report' Menu item present in Appraisal Menu");

        await utils.logInfo("Verify 'Carfax Report' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentCarfaxAppraisalMenuItem()).toBeTruthy("Verify 'Carfax Report' Menu item present in Appraisal Menu");

        await utils.logInfo("Verify 'Autocheck Report' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentAutocheckAppraisalMenuItem()).toBeTruthy("Verify 'Autocheck Report' Menu item present in Appraisal Menu");

        //TOOLS
        await utils.logInfo("Verify 'Guidebooks' Menu item present in Appraisal Menu");
        expect(appraisalpage.isPresentGuidebookAppraisalMenuItem()).toBeTruthy("Verify 'Guidebooks' Menu item present in Appraisal Menu");

        await utils.logInfo("Verify 'Scorecard' Menu item present in Appraisal Menu");
        expect(appraisalpage.isPresentScorecardAppraisalMenuItem()).toBeTruthy("Verify 'Scorecard' Menu item present in Appraisal Menu");

        await utils.logInfo("Verify 'Local Market' Menu item present in Appraisal Menu");
        expect(appraisalpage.isPresentLocalMarketAppraisalMenuItem()).toBeTruthy("Verify 'Local Market' Menu item present in Appraisal Menu");

        await utils.logInfo("Verify 'Unit History' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentUnitHistoryMenuItem()).toBeTruthy("Verify 'Unit History' Menu item present in Appraisal Menu");

        await utils.logInfo("Verify 'Photo Gallery' Menu item present in Appraisal Menu");
        expect(appraisalpage.isPresentPhotoGalleryAppraisalMenuItem()).toBeTruthy("Verify 'Photo Gallery' Menu item present in Appraisal Menu");

        await utils.logInfo("Verify 'Recall Notes' Menu item present in Appraisal Menu");
        expect(appraisalpage.isPresentRecallNotesAppraisalMenuItem()).toBeTruthy("Verify 'Recall Notes' Menu item present in Appraisal Menu");

        await utils.logInfo("Verify 'Appraisal Notes' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentAppraisalNotesMenuItem()).toBeTruthy("Verify 'Appraisal Notes' Menu item present in Appraisal Menu");

        //************* HEADER *************
        //Email
        await browser.get(appraisalURL);
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Click on Email Header menu item");
        await appraisalpage.clickShareEmail();
        await browser.sleep(browser.params.sleep.sleep10);
        expect(await crpage.isPresentEmailInput()).toBeTruthy("Verify Share CR Report screen displayed with Email Address Input field when user click on Email under Apraisal Tools Menu");

        //SMS
        await browser.get(appraisalURL);
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Click on SMS Header menu item");
        await appraisalpage.clickShareSMSText();
        await browser.sleep(browser.params.sleep.sleep10);
        expect(await crpage.isPresentSMSInput()).toBeTruthy("Verify Share CR Report screen displayed with Phone Number Input field when user click on SMS under Apraisal Tools Menu");


        //Feedback
        await browser.get(appraisalURL);
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Click on Feedback menu item");
        await appraisalpage.clickFeedbackAppraisalMenuItem();
        await browser.sleep(browser.params.sleep.sleep5);
        expect(await appraisalpage.isPresentFeedbackScreen()).toBeTruthy("Verify Feedbac screen displayed when user click on Feeback under Appraisal Tools Menu");

        //************* REPORTS *************

        //Consumer Appraisal Report
        await browser.waitForAngularEnabled(true); // *** Angular Enabled
        await browser.get(appraisalURL);
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Click on Customer Appraisal Report menu item");
        await appraisalpage.clickConsumerAppraisalMenuItem();
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await browser.sleep(browser.params.sleep.sleep10);
        expect(await browser.getCurrentUrl()).toContain("/report?type=consumer","Verify Consumer CR displayed when user click on Consumer Appraisal Report under Appraisal Tools Menu");//Assertion

        //Dealer Condition Report
        await browser.waitForAngularEnabled(true); // *** Angular Enabled
        await browser.get(appraisalURL);
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Click on Dealer Condition Report menu item");
        await appraisalpage.clickDealerAppraisalMenuItem();
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await browser.sleep(browser.params.sleep.sleep10);
        expect(await browser.getCurrentUrl()).toContain("/report?type=dealer","Verify Dealer CR displayed when user click on Dealer Condition Report under Appraisal Tools Menu"); //Assertion

        //Carfax Report
        await browser.waitForAngularEnabled(true); // *** Angular Enabled
        await browser.get(appraisalURL);
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Click on Carfax Report menu item");
        await appraisalpage.clickCarfaxAppraisalMenuItem();
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await browser.sleep(browser.params.sleep.sleep10);
        expect(await appraisalpage.isPresentCarFaxReportScreen()).toBeTruthy("Verify Carfax screen displayed when user click on Carfax Report under Appraisal Tools Menu");
        
        browser.switchTo().frame(element(by.xpath("//iframe[contains(@srcdoc, 'SafeValue')]")).getWebElement());
        await utils.logInfo("Switched to iFrame");
        await browser.sleep(browser.params.sleep.sleep5);
        await utils.logInfo("Value of VIN in CarFax Report is "+ await appraisalpage.getVINCarFaxReport());
        expect(await appraisalpage.getVINCarFaxReport()).toBe(browser.params.vin.validvin,"Verify CARFAX Report showing correct VIN");
        browser.switchTo().defaultContent();
        await browser.sleep(browser.params.sleep.sleep5);
        await utils.logInfo("Close Carfax Report Screen");
        await appraisalpage.closeCarFaxReportScreen();


        //Autocheck Report
        await browser.waitForAngularEnabled(true); // *** Angular Enabled
        await browser.get(appraisalURL);
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("After Get Appraisal Menu");
        await utils.logInfo("Click on Autocheck Report menu item");
        await appraisalpage.clickAutocheckAppraisalMenuItem();
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await browser.sleep(browser.params.sleep.sleep10);
        expect(await appraisalpage.isPresentAutoCheckReportScreen()).toBeTruthy("Verify Autocheck screen displayed when user click on Autocheck Report under Appraisal Tools Menu");

        browser.switchTo().frame(element(by.xpath("//iframe[contains(@srcdoc, 'SafeValue')]")).getWebElement());
        await utils.logInfo("Switched to iFrame");
        await browser.sleep(browser.params.sleep.sleep5);
        await utils.logInfo("Value of VIN in Autocheck Report is "+ await appraisalpage.getVINAutoCheckReport());
        expect(await appraisalpage.getVINAutoCheckReport()).toBe(browser.params.vin.validvin,"Verify AutoCheck Report showing correct VIN");
        browser.switchTo().defaultContent();
        await browser.sleep(browser.params.sleep.sleep5);
        await utils.logInfo("Close Auto Check Report Screen");
        await appraisalpage.closeAutoCheckReportScreen();

        //************* CUSTOMER *************

        //Customer Information
        await browser.get(appraisalURL);
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("After Get Appraisal Menu");
        await utils.logInfo("Click on Customer Information menu item");
        await appraisalpage.clickCustomerInfoMenuItem();
        expect(await appraisalpage.isPresentFirstNameLabelCustomerInfo()).toBeTruthy("Verify Customer Information screen displayed when user click on Customer Information link under Appraisal Tools Menu");
        
        //************* TOOLS *************

        //Guidebook
        await browser.get(appraisalURL);
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("After Get Appraisal Menu");
        await utils.logInfo("Click on Guidebook menu item");
        await appraisalpage.clickGuidebookAppraisalMenuItem();
        expect(await appraisalpage.isPresentGuideBooksScreen()).toBeTruthy("Verify Guidebooks screen displayed when user click on Guidebooks link under Appraisal Tools Menu");

        //Scorecard
        await browser.get(appraisalURL);
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("After Get Appraisal Menu");
        await utils.logInfo("Click on Scorecard menu item");
        await appraisalpage.clickScorecardAppraisalMenuItem();
        expect(await appraisalpage.isPresentScorecardScreen()).toBeTruthy("Verify Scorecard screen displayed when user click on Scorecard link under Appraisal Tools Menu");
        expect(await appraisalpage.getVINScoreCard()).toBe(browser.params.vin.validvin,"Verify correct VIN is shown on ScoreCard Screen");

        //Local Market
        await browser.get(appraisalURL);
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("After Get Appraisal Menu");
        await utils.logInfo("Click on Local Market menu item");
        await appraisalpage.clickLocalMarketAppraisalMenuItem();
        expect(await appraisalpage.isPresentLocalMarketScreen()).toBeTruthy("Verify Local Market screen displayed when user click on Local Market link under Appraisal Tools Menu");

        //Unit History
        await browser.get(appraisalURL);
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("After Get Appraisal Menu");
        await utils.logInfo("Click on Unit History menu item");
        await appraisalpage.clickUnitHistoryMenuItem();
        await browser.sleep(browser.params.sleep.sleep5);
        expect(await appraisalpage.isPresentUnitHistoryHeader()).toBeTruthy("Verify Unit History screen displayed when user click on Unit History link under Appraisal Tools Menu");

        //Photo Gallery
        await browser.get(appraisalURL);
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("After Get Appraisal Menu");
        await utils.logInfo("Click on Photo Gallery menu item");
        await appraisalpage.clickPhotoGalleryAppraisalMenuItem();
        expect(await appraisalpage.isPresentGalleryScreen()).toBeTruthy("Verify Photo Gallery screen displayed when user click on Photo Gallery link under Appraisal Tools Menu");

        //Recall Notes
        await browser.get(appraisalURL);
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("After Get Appraisal Menu");
        await utils.logInfo("Click on Recall Notes menu item");
        await appraisalpage.clickRecallNotesAppraisalMenuItem();
        expect(await appraisalpage.isPresentRecallsScreen()).toBeTruthy("Verify Recalls screen displayed when user click on Recall Notes link under Appraisal Tools Menu");

        //Appraisal Notes
        await browser.get(appraisalURL);
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("After Get Appraisal Menu");
        await utils.logInfo("Click on Appraisal Notes menu item");
        await appraisalpage.clickAppraisalNotesMenuItem();
        expect(await appraisalpage.isPresentAppraisalNotesHeader()).toBeTruthy("Verify Appraisal Notes screen displayed when user click on Appraisal Notes link under Appraisal Tools Menu");
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   


    }); //it

   it('*** Verify Share CR by Email', async function () {
        utils.logInfo("***** TEST CASE : Verify Share CR by Email *****");

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);

        //Get Appraisal Menu
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("After Get Appraisal Menu");

        await browser.sleep(browser.params.sleep.sleep10);
        await utils.logInfo("After Sleep");

        //Share Email
        await utils.logInfo("Click on Share Email");
        await appraisalpage.clickShareEmail();
        await utils.logInfo("After Click on Share Email");

        //Add Verify email code


        await utils.logInfo("Click on Share CR");
        //await crpage.clickShareCR();

        await utils.logInfo("enter email address " + browser.params.email.address);
        await crpage.enterEmailAddressShareReport(browser.params.email.address);

        await utils.logInfo("Enter email message in Share Dealer Condition Report");
        await crpage.enterMsgShareReport("Email Automated Message");

        await utils.logInfo("Waiting for 'Send Email' button to be clickable");
        // var EC = protractor.ExpectedConditions;
        // browser.wait(EC.elementToBeClickable(crpage.getSendEmailBtnWebElement()), 15000);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Click on 'Send Email' Button");
        await crpage.clickSendEmailBtnShareReport();

        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Verify Email Success Message");
        expect(await crpage.isPresentEmailSuccessMsg()).toBeTruthy("Verify Email Sent Success Message");
        await browser.sleep(browser.params.sleep.sleep2);

        await crpage.closeShareReportScreen();

        await browser.waitForAngularEnabled(true); // *** Angular Enabled
        //await browser.sleep(browser.params.sleep.sleep10);

    }); //it

    it('*** Verify Share CR by Text', async function () {
        utils.logInfo("***** TEST CASE : Verify Share CR by Text *****");

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));

        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);

        //Get Appraisal Menu
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("After Get Appraisal Menu");

        await browser.sleep(browser.params.sleep.sleep10);
        await utils.logInfo("After Sleep");

        //Share SMS Text
        await utils.logInfo("Click on Share SMS Text Link");
        await appraisalpage.clickShareSMSText();

        //Add Verify email code

        await utils.logInfo("Click on Share CR");
        //await crpage.clickShareCR();

        await utils.logInfo("Enter Phone Number " + browser.params.phone.number);
        await crpage.enterPhoneShareReport(browser.params.phone.number);

        await utils.logInfo("Enter SMS message in Share Dealer Condition Report");
        await crpage.enterMsgShareReport("SMS Automated Message");

        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Click on 'Send Text' Button");
        await crpage.clickSendTextBtnShareReport();

        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Verify SMS Text Success Message");
        expect(await crpage.isPresentTextSuccessMsg()).toBeTruthy("Verify SMS Text Sent Success Message");

        await browser.sleep(browser.params.sleep.sleep2);

        await utils.logInfo("Close the Share Report Screen");
        await crpage.closeShareReportScreen();

        await browser.waitForAngularEnabled(true); // *** Angular Enabled

    }); //it

    it('*** Verify Consumer CR loads', async function () {
        utils.logInfo("***** TEST CASE : Verify Consumer CR loads*****");

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));

        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);

        //Get Appraisal Menu
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Verify 'Consumer Appraisal Report' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentConsumerAppraisalMenuItem()).toBeTruthy("Verify 'Consumer Appraisal Report' Menu item present in Appraisal Menu"); //Assertion
        
        //Get Consumer CR
        await utils.logInfo("Click on Customer Appraisal Report menu item");
        await appraisalpage.clickConsumerAppraisalMenuItem();
        await browser.sleep(browser.params.sleep.sleep10);
        await utils.logInfo("Verifying the loaded page is Consumer CR");
        expect(await browser.getCurrentUrl()).toContain("/report?type=consumer","Verifying Consumer CR Page Loads");//Assertion
        
        await browser.sleep(browser.params.sleep.sleep5);
        var crVehicleInfo = await crpage.getCRVehicleInfo();
        await utils.logInfo("CR Vehicle Info is" + crVehicleInfo);
        await browser.sleep(browser.params.sleep.sleep5);
        await expect(await crVehicleInfo).toContain("2018 TOYOTA CAMRY","Verify Consumer CR Page shows correct vehicle details"); //*** Assertion ***/
        
        //Download PDF
        // await utils.logInfo("Waiting for Generate PDF button to be enabled");
        // await crpage.waitForWebElementToBeVisible("Generate PDF");
        // await utils.logInfo("Click on Generate PDF");
        
        // await crpage.clickGeneratePDF();
        // await utils.logInfo("Waiting for Download PDF button to be enabled");
        // await crpage.waitForWebElementToBeVisible("Download PDF");
        // await utils.logInfo("Seleeping for 10 seconds");
        // await browser.sleep(browser.params.sleep.sleep10);
        // await utils.logInfo("Click on Download PDF");
        // await crpage.clickDownloadPDF();
        // await utils.logInfo("Enable Angular");
        // await browser.waitForAngularEnabled(true); // *** Angular Enable True

    }); //it

    it('*** Verify Dealer CR loads', async function () {
        utils.logInfo("***** TEST CASE : Verify Dealer CR loads *****");

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));

        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);

        //Get Appraisal Menu
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();        
        await utils.logInfo("Verify 'Dealership Appraisal' Menu item present in Appraisal Tools Menu");
        expect(await appraisalpage.isPresentDealershipAppraisalMenuItem()).toBeTruthy("Verify 'Dealership Appraisal' Menu item present in Appraisal Tools Menu");
        
        //Get Dealer CR                
        await utils.logInfo("Click on Dealer Condition Report menu item");
        await appraisalpage.clickDealerAppraisalMenuItem();
        await browser.sleep(browser.params.sleep.sleep10);
        await utils.logInfo("Verifying the loaded page is Dealer CR");
        expect(await browser.getCurrentUrl()).toContain("/report?type=dealer","Verifying the loaded page is Dealer CR"); //Assertion
                
        await browser.sleep(browser.params.sleep.sleep5);
        var crVehicleInfo = await crpage.getCRVehicleInfo();
        await utils.logInfo("CR Vehicle Info is" + crVehicleInfo);
        await browser.sleep(browser.params.sleep.sleep5);
        await expect(await crVehicleInfo).toContain("2018 TOYOTA CAMRY","Verify Dealer CR Page shows correct vehicle details"); //*** Assertion ***/
        
        // //Download PDF
        // await utils.logInfo("Waiting for Generate PDF button to be enabled");
        // await crpage.waitForWebElementToBeVisible("Generate PDF");
        // await utils.logInfo("Click on Generate PDF");
        
        // await crpage.clickGeneratePDF();
        // await utils.logInfo("Waiting for Download PDF button to be enabled");
        // await crpage.waitForWebElementToBeVisible("Download PDF");
        // await utils.logInfo("Seleeping for 10 seconds");
        // await browser.sleep(browser.params.sleep.sleep10);
        // await utils.logInfo("Click on Download PDF");
        // await crpage.clickDownloadPDF();
        // expect(await browser.getCurrentUrl()).toContain(".pdf");//assertion
        // await utils.logInfo("Enable Angular");
        // await browser.waitForAngularEnabled(true); // *** Angular Enable True

    }); //it

    it('*** Verify Admin Menu links: all links function & direct to correct location', async function () {
        utils.logInfo("***** TEST CASE : Verify Admin Menu links: all links function & direct to correct location *****");

        await browser.refresh();
        await utils.logInfo("Open Admin Man Menu ");
        await homepage.openAdminMenu();
        await utils.logInfo("Verify My Account Menu Item  is present under Admin Menu");
        expect(await homepage.isPresentMyAccountMenuItem()).toBeTruthy("Verify 'My Account' Menu Item  is present under Admin Menu");
        await utils.logInfo("Click on My Account Menu Item under Admin Menu");
        await homepage.navigateThroughMenu("My Account");

        await browser.waitForAngularEnabled(false);
        expect(await browser.getCurrentUrl()).toBe(await myaccountpage.getUrl(),"Verify 'My Account' page loads when user click on My Account menu item under Admin Menu");
        await browser.waitForAngularEnabled(true);

        await browser.sleep(browser.params.sleep.sleep10);

        await browser.refresh();
        await utils.logInfo("Open Admin Man Menu ");
        await homepage.openAdminMenu();
        await utils.logInfo("Verify User Management Menu Item  is present under Admin Menu");
        await expect(await homepage.isPresentUserManagementMenuItem()).toBeTruthy("Verify 'User Management' Menu Item  is present under Admin Menu");
        await utils.logInfo("Click on User Management Menu Item under Admin Menu");
        await homepage.navigateThroughMenu("User Management");
        await browser.waitForAngularEnabled(false);
        expect(await browser.getCurrentUrl()).toBe(await usermgmtpage.getUrl(),"Verify 'User Management' page loads when user click on User Management menu item under Admin Menu");
        await browser.waitForAngularEnabled(true);


        await browser.refresh();
        await utils.logInfo("Open Admin Man Menu ");
        await homepage.openAdminMenu();
        utils.logInfo("Verify 'Dealer Console' Menu Item  is present under Admin Menu");
        expect(await homepage.isPresentDealerConsoleMenuItem()).toBeTruthy("Verify 'Dealer Console' Menu Item  is present under Admin Menu");
        await utils.logInfo("Click on Dealer Console Menu Item under Admin Menu");
        await homepage.navigateThroughMenu("Dealer Console");
        await browser.waitForAngularEnabled(false);
        expect(await browser.getCurrentUrl()).toBe(await dealerconsolepage.getUrl(),"Verify Dealer Console page loads when user click on Dealer Console menu item under Admin Menu");
        await browser.waitForAngularEnabled(true);

        await browser.refresh();
        await utils.logInfo("Open Admin Man Menu ");
        await homepage.openAdminMenu();
        utils.logInfo("Verify 'Recommender' Menu Item  is present under Admin Menu");
        expect(await homepage.isPresentRecommenderMenuItem()).toBeTruthy("Verify 'Recommender' Menu Item  is present under Admin Menu");
        await utils.logInfo("Click on Recommender Menu Item under Admin Menu");
        await homepage.navigateThroughMenu("Recommender");
        await browser.waitForAngularEnabled(false);
        expect(await browser.getCurrentUrl()).toBe(await recommenderpage.getUrl(),"Verify Recommender page loads when user click on Recommender menu item under Admin Menu");
        await browser.waitForAngularEnabled(true);

        await browser.refresh();
        await utils.logInfo("Open Admin Man Menu ");
        await homepage.openAdminMenu();
        utils.logInfo("Verify Log Out Menu Item  is present under Admin Menu");
        expect(await homepage.isPresentLogOutMenuItem()).toBeTruthy("Verify Log Out Menu Item is present under Admin Menu");

    }); //it

    it('*** Verify All lists load and Pagination Count: Prospects, Active, Grounded, Offers, Archived, All', async function () {
        utils.logInfo("***** TEST CASE : Verify All lists load and Pagination Count: Prospects, Active, Grounded, Offers, Archived, All *****");
    
        var rowcount = -1;
        var tabcount = '-1';
        var newtabcount = '-1';
        var paginatorRange = 'none';

        //Default Active Appraisal List
        await browser.refresh();

        await utils.logInfo("Verify Active Appraisal list tab is selected by default");
        expect(await homepage.isActiveAppraisalListTabSelected()).toBeTruthy("Verify Active Appraisal list tab is selected by default");

        paginatorRange = await homepage.getPaginatorRange();
        paginatortotalcount = utils.paginatorTotalCount(paginatorRange);
        paginatorrowcount = utils.paginatotRowCount(paginatorRange);

        rowcount = await homepage.getAppraisalsRowCount();
        tabcount = await homepage.getActiveAppraisalsTabCount();

        await utils.logInfo("Verify value of Default Active Appraisals Table row count is " + rowcount);
        await utils.logInfo("Value of Active Appraisals Tab count is " + tabcount);
        await utils.logInfo("Value of Active Appraisals Paginator Range is " + paginatorRange);
        expect(paginatortotalcount).toBe(tabcount,"Verify Pagination total count is matching the selected default tab count");
        expect(parseInt(paginatorrowcount)).toBe(rowcount,"Verify number of appraisals in Appraisal List Table matching the Pagination row count");

        newtabcount = (parseInt(tabcount) > 50) ? '50' : tabcount;
        expect(rowcount).toEqual(parseInt(newtabcount));

        //Active Appraisal List (Click on Active List)
        await utils.logInfo("Click on Active Appraisal List");
        await homepage.clickActiveAppraisalList();

        await utils.logInfo("Verify Active Appraisal list tab is selected when click on Active Appraisal List Tab");
        expect(await homepage.isActiveAppraisalListTabSelected()).toBeTruthy();

        paginatorRange = await homepage.getPaginatorRange();
        paginatortotalcount = utils.paginatorTotalCount(paginatorRange);
        paginatorrowcount = utils.paginatotRowCount(paginatorRange);

        rowcount = await homepage.getAppraisalsRowCount();
        tabcount = await homepage.getActiveAppraisalsTabCount();
        await utils.logInfo("Verify value of Default Active Appraisals Table row count is " + rowcount);
        await utils.logInfo("Value of Active Appraisals Tab count is " + tabcount);
        await utils.logInfo("Value of Active Appraisals Paginator Range is " + paginatorRange);
        expect(paginatortotalcount).toContain(tabcount);
        expect(parseInt(paginatorrowcount)).toBe(rowcount);

        newtabcount = (parseInt(tabcount) > 50) ? '50' : tabcount;
        expect(rowcount).toEqual(parseInt(newtabcount));


        //Prospects Appraisal List
        await utils.logInfo("Click on Prospects List");
        await homepage.clickProspectsAppraisalList();

        await utils.logInfo("Verify Prospects Appraisals list tab is selected when click on Prospects Appraisals List Tab");
        expect(await homepage.isProspectsAppraisalListTabSelected()).toBeTruthy();
        paginatorRange = await homepage.getPaginatorRange();
        paginatortotalcount = utils.paginatorTotalCount(paginatorRange);
        paginatorrowcount = utils.paginatotRowCount(paginatorRange);

        rowcount = await homepage.getAppraisalsRowCount();
        tabcount = await homepage.getProspectsAppraisalsTabCount();
        await utils.logInfo("Verify value of Prospects Appraisals Table row count is " + rowcount);
        await utils.logInfo("Value of Prospects Appraisals Tab count is " + tabcount);
        await utils.logInfo("Value of Prospects Appraisals Paginator Range is " + paginatorRange);
        expect(paginatortotalcount).toContain(tabcount);
        expect(parseInt(paginatorrowcount)).toBe(rowcount);

        newtabcount = (parseInt(tabcount) > 50) ? '50' : tabcount;
        expect(rowcount).toEqual(parseInt(newtabcount));

        //Grounded Appraisal List
        await utils.logInfo("Click on Grounded Appraisal List");
        await homepage.clickGroundedAppraisalList();

        await utils.logInfo("Verify Grounded Appraisals list tab is selected when click on Grounded Appraisals List Tab");
        expect(await homepage.isGroundedAppraisalListTabSelected()).toBeTruthy();
        paginatorRange = await homepage.getPaginatorRange();
        paginatortotalcount = utils.paginatorTotalCount(paginatorRange);
        paginatorrowcount = utils.paginatotRowCount(paginatorRange);

        rowcount = await homepage.getAppraisalsRowCount();
        tabcount = await homepage.getGroundedAppraisalsTabCount();
        await utils.logInfo("Verify value of Grounded Appraisals Table row count is " + rowcount);
        await utils.logInfo("Value of Grounded Appraisals Tab count is " + tabcount);
        await utils.logInfo("Value of Grounded Appraisals Paginator Range is " + paginatorRange);
        expect(paginatortotalcount).toContain(tabcount);
        expect(parseInt(paginatorrowcount)).toBe(rowcount);

        newtabcount = (parseInt(tabcount) > 50) ? '50' : tabcount;
        expect(rowcount).toEqual(parseInt(newtabcount));

        //Offers Appraisal List
        await utils.logInfo("Click on Offers Appraisal List");
        await homepage.clickOffersAppraisalList();

        await utils.logInfo("Verify Offers Appraisals list tab is selected when click on Offers Appraisals List Tab");
        expect(await homepage.isOffersAppraisalListTabSelected()).toBeTruthy();
        paginatorRange = await homepage.getPaginatorRange();
        paginatortotalcount = utils.paginatorTotalCount(paginatorRange);
        paginatorrowcount = utils.paginatotRowCount(paginatorRange);

        rowcount = await homepage.getAppraisalsRowCount();
        tabcount = await homepage.getOffersAppraisalsTabCount();
        await utils.logInfo("Verify value of Offers Appraisals Table row count is " + rowcount);
        await utils.logInfo("Value of Offers Appraisals Tab count is " + tabcount);
        await utils.logInfo("Value of Offers Appraisals Paginator Range is " + paginatorRange);
        expect(paginatortotalcount).toContain(tabcount);
        expect(parseInt(paginatorrowcount)).toBe(rowcount);

        newtabcount = (parseInt(tabcount) > 50) ? '50' : tabcount;
        expect(rowcount).toEqual(parseInt(newtabcount));

        //Archived Appraisal List
        await utils.logInfo("Click on Archived Appraisal List");
        await homepage.clickArchivedAppraisalList();

        await utils.logInfo("Verify Archived Appraisals list tab is selected when click on Archived Appraisals List Tab");
        expect(await homepage.isArchivedAppraisalListTabSelected()).toBeTruthy();
        paginatorRange = await homepage.getPaginatorRange();
        paginatortotalcount = utils.paginatorTotalCount(paginatorRange);
        paginatorrowcount = utils.paginatotRowCount(paginatorRange);

        rowcount = await homepage.getAppraisalsRowCount();
        tabcount = await homepage.getArchivedAppraisalsTabCount();
        await utils.logInfo("Verify value of Archived Appraisals Table row count is " + rowcount);
        await utils.logInfo("Value of Archived Appraisals Tab count is " + tabcount);
        await utils.logInfo("Value of Archived Appraisals Paginator Range is " + paginatorRange);
        expect(paginatortotalcount).toContain(tabcount);
        expect(parseInt(paginatorrowcount)).toBe(rowcount);

        newtabcount = (parseInt(tabcount) > 50) ? '50' : tabcount;
        expect(rowcount).toEqual(parseInt(newtabcount));

        //All Appraisal List
        // await homepage.clickAllAppraisals();
        // paginatorRange = await homepage.getPaginatorRange();
        // rowcount = await homepage.getAppraisalsRowCount();
        // await utils.logInfo("Verify value of All Appraisals Table row count is "+rowcount);
        // await utils.logInfo("Value of All Appraisals Paginator Range is "+paginatorRange);
        // expect(paginatortotalcount).toContain(rowcount);

    });//it


    xit('Verify user is able to edit dealership and its employee: 1 edit for each tab', async function(){
        await utils.logInfo("***** TEST CASE : Verify user is able to edit dealership and its employee: 1 edit for each tab *****");
        await browser.refresh();
        //await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Navigate to Dealer Console"); //**** Navigate to Dealer Console ****/
        await homepage.navigateThroughMenu("Dealer Console");
        await utils.logInfo("Outside Dealer Console");

        browser.driver.sleep(browser.params.sleep.sleep10);

        //var el= element(by.xpath("//iframe[contains(@src,'https://lyra-qa.accu-trade.com')]")).getWebElement();
        //browser.switchTo().frame(el);
        browser.switchTo().frame(0);
        await utils.logInfo("Switched to iFrame");

        await browser.waitForAngularEnabled(false);

        await utils.logInfo("Search Dealership");
        await dealerconsolepage.searchDealership("Amit Accu-Trade USSA Dealership");
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Get number of dealers");
        await utils.logInfo(await dealerconsolepage.getDealershipRowCount());

        await utils.logInfo("Select first Dealership");
        await dealerconsolepage.selectFirstDealership();
        
        await utils.logInfo("Click on Dealership Edit Button");
        await dealerconsolepage.editDealership();

        //**** Verify General Tab ****//
        await utils.logInfo("Verify General tab is present in Dealership");
        await utils.logInfo("Is General tab present: "+await dealershippage.isGeneralTabPresent());
        expect(await dealershippage.isGeneralTabPresent()).toBeTruthy("Verify General tab is present in Dealership"); //Assertion
        await dealershippage.clickGeneralTab();
        await utils.logInfo("Is Dealership Name Textfield present in General Tab: "+await dealershippage.isPresentDealershipNameGeneralTab());
        expect(await dealershippage.isPresentDealershipNameGeneralTab()).toBeTruthy("Verify Dealership Name is present under General tab of Dealership");

        //**** Edit Address in General Tab ****//
        var beforeaddress = await dealershippage.getAddressGeneralTab();
        await utils.logInfo("Edit Address in General Tab to be '"+beforeaddress+" edited"+"'");
        await dealershippage.setAddressGeneralTab(beforeaddress+" edited");
        await utils.logInfo("Click Save Button in General Tab");
        await dealershippage.clickGeneralSaveBtn();
        browser.sleep(browser.params.sleep.sleep10);

        //**** Edit in Accutrade Tab ****//
        await utils.logInfo("Edit Accu-trade Tab");
        //await utils.logInfo("Verify Accu-trade tab is present in Dealership");
        await utils.logInfo("Is Accu-trade tab present: "+await dealershippage.isAccutradeTabPresent());
        expect(await dealershippage.isAccutradeTabPresent()).toBeTruthy("Verify Accutrade tab is present in Dealership");
        await dealershippage.clickAccutradeTab();
        await utils.logInfo("Is Guaranteed Price Label present in Accutrade Tab: "+await dealershippage.isPresentGuaranteedPriceAccutradeTab());
        expect(await dealershippage.isPresentGuaranteedPriceAccutradeTab()).toBeTruthy("Verify Guaranteed Price is present in Accutrade tab of Dealership");
        var beforeAppointmentContact = await dealershippage.getAppointmentContactAccutradeTab();
        await utils.logInfo("Edit the Appointment Contact");
        if(beforeAppointmentContact == ""){
            await dealershippage.setAppointmentContactAccutradeTab("edited");
        }
        else{
            await utils.logInfo("Edit 'Appointment Contact' value in Accutrade tab from "+beforeAppointmentContact+" to "+beforeAppointmentContact+" edited");
            await dealershippage.setAppointmentContactAccutradeTab(beforeAppointmentContact+" edited");
        }
        await utils.logInfo("Click Save Button in Accutrade Tab");
        await dealershippage.clickAccutradeSaveBtn();
        browser.sleep(browser.params.sleep.sleep10);

        //**** Edit in Customization Tab ****//
        await utils.logInfo("Edit Customization Tab");
        await utils.logInfo("Is Customization tab present: "+await dealershippage.isCustomizationTabPresent());
        await dealershippage.clickCustomizationTab();
        await utils.logInfo("Is Banner URL present in Customization Tab: "+await dealershippage.isPresentBannerURLCustomizationTab());

        var beforeLogoUrl = await dealershippage.getLogoUrlCustomizationTab();

        if(beforeLogoUrl == ""){
            await dealershippage.setLogoUrlCustomizationTab("edited");
        }
        else{
            await dealershippage.setLogoUrlCustomizationTab(beforeLogoUrl+" edited");
        }

        await dealershippage.setLogoUrlCustomizationTab(beforeLogoUrl+" edited");

        await utils.logInfo("Click Save Button in Customization Tab");
        await dealershippage.clickCustomizationSaveBtn();
        browser.sleep(browser.params.sleep.sleep10);

        //**** Edit CRM Email in Advanced Tab ****//
        await utils.logInfo("Edit Advanced Tab");
        await utils.logInfo("Is Advanced tab present: "+await dealershippage.isAdvancedTabPresent());
        await dealershippage.clickAdvancedTab();
        await utils.logInfo("Is Allow Chrome Lookup present in Advanced Tab: "+await dealershippage.isPresentAllowChromeLookupAdvancedTab());
        var beforecrmemailname = await dealershippage.getCRMEmailNameAdvancedTab();
        await dealershippage.setCRMEmailNameAdvancedTab(beforecrmemailname+" edited");
        await utils.logInfo("Click Save Button in Advanced Tab");
        await dealershippage.clickAdvancedSaveBtn();
        browser.driver.sleep(browser.params.sleep.sleep10);

        //**** Edit employee last name in Employees Tab ****//
        await utils.logInfo("Edit Employees Tab");
        await utils.logInfo("Is Employees tab present: "+await dealershippage.isEmployeeTabPresent());

        await utils.logInfo("Click on Employees Tab");        
        await dealershippage.clickEmployeesTab();
        await utils.logInfo("After Click on Employees Tab");        

        await utils.logInfo("Is Employee Table present in Employees Tab: "+await dealershippage.isPresentEmployeeTableEmployeesTab());

        await utils.logInfo("Select first checkbox for Employee table");
        await dealershippage.selectFirstCheckBoxEmployeeTable();

        await utils.logInfo("Click on Edit Button of the selected Employee");
        await dealershippage.clickEditButton();

        var beforelastname = await dealershippage.getlastNameEmployeeTab();
        await utils.logInfo("Set last name into Last Name text field");
        await dealershippage.setlastNameEmployeeTab(beforelastname+" edited");

        await utils.logInfo("Click Save Button in Employees Tab");
        await dealershippage.clickEmployeeSaveBtn();

        await browser.waitForAngularEnabled(true);
        await homepage.get();

        await utils.logInfo("Navigate to Dealer Console"); //**** Navigate to Dealer Console ****/
        await homepage.navigateThroughMenu("Dealer Console");
        browser.driver.sleep(browser.params.sleep.sleep10);

        browser.switchTo().frame(0);
        await utils.logInfo("Switched to iFrame");

        await browser.waitForAngularEnabled(false);

        await utils.logInfo("Search Dealership");
        await dealerconsolepage.searchDealership("Amit Accu-Trade USSA Dealership");
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Select first Dealership");
        await dealerconsolepage.selectFirstDealership();
        
        await utils.logInfo("Click on Dealership Edit Button");
        await dealerconsolepage.editDealership();

        //**** Verify General Tab ****//
        await utils.logInfo("Click on General Tab");
        await dealershippage.clickGeneralTab();
        var afteraddress = await dealershippage.getAddressGeneralTab();
        expect(afteraddress).toBe(beforeaddress+" edited", "Verify Address in General Tab of Dealer Console Edited Successfully");
        //Teardown
        await utils.logInfo("Reset Address in General Tab to "+beforeaddress);
        await dealershippage.setAddressGeneralTab(beforeaddress);
        await utils.logInfo("Click Save Button in General Tab");
        await dealershippage.clickGeneralSaveBtn();
        browser.sleep(browser.params.sleep.sleep10);

        //**** Verify Accutrade Tab ****//
        await utils.logInfo("Click on Accutrade Tab");
        await dealershippage.clickAccutradeTab();
        var afterAppointmentContact = await dealershippage.getAppointmentContactAccutradeTab();
        
        if(beforeAppointmentContact == ""){
            expect(afterAppointmentContact).toBe(beforeAppointmentContact+"edited","Verify Appointment Contact in Accutrade Tab of Dealer Console Edited Successfully");
        }
        else{
            expect(afterAppointmentContact).toBe(beforeAppointmentContact+" edited","Verify Appointment Contact in Accutrade Tab of Dealer Console Edited Successfully");
        }
        
        //Teardown
        await utils.logInfo("Reset the Appointment Contact in Accutrade Tab to "+beforeAppointmentContact);
        await dealershippage.setAppointmentContactAccutradeTab(beforeAppointmentContact);
        await utils.logInfo("Click Save Button in Accutrade Tab");
        await dealershippage.clickAccutradeSaveBtn();
        browser.sleep(browser.params.sleep.sleep10);

        //**** Verify Customization Tab ****//
        await utils.logInfo("Click on Customization Tab");
        await dealershippage.clickCustomizationTab();
        var afterLogoUrl = await dealershippage.getLogoUrlCustomizationTab();

        if(beforeLogoUrl == ""){
            expect(afterLogoUrl).toBe(beforeLogoUrl+"edited","Verify Logo URL in Customization Tab of Dealer Console Edited Successfully");
        }
        else{
            expect(afterLogoUrl).toBe(beforeLogoUrl+" edited","Verify Logo URL in Customization Tab of Dealer Console Edited Successfully");
        }

        //Teardown
        await utils.logInfo("Reset the Logo URL in Customization Tab to "+beforeLogoUrl);
        await dealershippage.setLogoUrlCustomizationTab(beforeLogoUrl);
        await utils.logInfo("Click Save Button in Customization Tab");
        await dealershippage.clickCustomizationSaveBtn();
        browser.sleep(browser.params.sleep.sleep10);

        //**** Verify Advanced Tab ****//
        await utils.logInfo("Click on Advanced Tab");
        await dealershippage.clickAdvancedTab();
        var aftercrmemailname = await dealershippage.getCRMEmailNameAdvancedTab();
        expect(aftercrmemailname).toBe(beforecrmemailname+" edited","Verify CRM Email Name in Advanced Tab of Dealer Console edited Successfully");
        //Teardown
        await utils.logInfo("Reset the CRM Email in Advanced Tab to "+beforecrmemailname);
        await dealershippage.setCRMEmailNameAdvancedTab(beforecrmemailname);
        await utils.logInfo("Click Save Button in Advanced Tab");
        await dealershippage.clickAdvancedSaveBtn();
        browser.driver.sleep(browser.params.sleep.sleep10);

        //**** Verify Employee Tab ****//  
        await utils.logInfo("Click on Employees Tab");        
        await dealershippage.clickEmployeesTab();
        await utils.logInfo("After Click on Employees Tab");        
        await utils.logInfo("Is Employee Table present in Employees Tab: "+await dealershippage.isPresentEmployeeTableEmployeesTab());
        await utils.logInfo("Select first checkbox for Employee table");
        await dealershippage.selectFirstCheckBoxEmployeeTable();
        await utils.logInfo("Click on Edit Button of the selected Employee");
        await dealershippage.clickEditButton();
        var afterlastname = await dealershippage.getlastNameEmployeeTab();
        expect(afterlastname).toBe(beforelastname+" edited","Verify CRM Last Name in Employee Tab of Dealer Console edited Successfully");
        //Teardown
        await utils.logInfo("Reset last name into Last Name text field");
        await dealershippage.setlastNameEmployeeTab(beforelastname);
        await utils.logInfo("Click Save Button in Employees Tab");
        await dealershippage.clickEmployeeSaveBtn();
        browser.driver.sleep(browser.params.sleep.sleep10);
        await browser.waitForAngularEnabled(true);

    });//it



    it('**** Verify Edit Profile: edit name, office phone, mobile phone', async function () {
        utils.logInfo("***** TEST CASE : Verify Edit Profile: edit name, office phone, mobile phone *****");

        await utils.logInfo("Verify edit user: edit name, office phone, mobile phone");
        await browser.refresh();

        await utils.logInfo("Navigate to My Account Page");
        await homepage.navigateThroughMenu("My Account");

        await utils.logInfo("Before Click on Edit Profile Link");
        await myaccountpage.clickEditProfileLink();
        await utils.logInfo("After Click on Edit Profile Link");

        var firstnamebeforeedit = await myprofilepage.getFirstName();
        await utils.logInfo("first name before edit is " + firstnamebeforeedit);
        var officephonebeforeedit = await myprofilepage.getOfficePhone();
        await utils.logInfo("office phone before edit is " + officephonebeforeedit);

        var mobilephonebeforeedit = await myprofilepage.getMobilePhone();
        await utils.logInfo("mobile phone before edit is " + mobilephonebeforeedit);

        await browser.sleep(browser.params.sleep.sleep5);


        await utils.logInfo("Edit the First Name");
        await myprofilepage.setFirstName(firstnamebeforeedit + " edited");
        await utils.logInfo("first name after edit is " + firstnamebeforeedit + " edited");

        //await myprofilepage.setLastName(browser.params.login.superadminlname+" edited");

        await utils.logInfo("Edit the Office Phone");
        await myprofilepage.setOfficePhone(officephonebeforeedit + "0");
        await utils.logInfo("office phone after edit is " + officephonebeforeedit + "0");

        //await utils.logInfo("Edit the Mobile Phone");
        //await myprofilepage.setMobilePhone(mobilephonebeforeedit + "0");
        //await utils.logInfo("mobile phone after edit is " + mobilephonebeforeedit + "0");

        await utils.logInfo("Click on Update Button");
        await myprofilepage.clickUpdate();
        //await browser.waitForAngularEnabled(false);
        await browser.sleep(browser.params.sleep.sleep10);

        // await utils.logInfo("Check if current page is Verify Mobile Number page");
        // await utils.logInfo("verifymobilenumberpage.getUrl(): " + await verifymobilenumberpage.getUrl());

        // await browser.get(browser.params.env.url + "/auth/signup/verify-cellphone");
        // await utils.logInfo("Got page: " + browser.params.env.url + "/auth/signup/verify-cellphone");

        // utils.logInfo(await verifymobilenumberpage.getMobileNumber());

        // await browser.getCurrentUrl().then(async function (url) {
        //     utils.logInfo("****************** Inside ***********************");
        //     utils.logInfo("browser.getCurrentUrl(): " + await browser.getCurrentUrl());
        //     utils.logInfo("verifymobilenumberpage.getUrl(): " + await verifymobilenumberpage.getUrl());

        //     if (url == await verifymobilenumberpage.getUrl()) {
        //         //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
        //         await utils.logInfo("Click Remind me on Verify Mobile Number Page");
        //         await browser.sleep(browser.params.sleep.sleep5);
        //         await verifymobilenumberpage.clickRemindme();
        //     }
        // })

        // //await browser.waitForAngularEnabled(true);
        // await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Navigate to My Account Page");
        await homepage.navigateThroughMenu("My Account");

        await utils.logInfo("Click on Edit Profile Link");
        await myaccountpage.clickEditProfileLink();
        await browser.sleep(browser.params.sleep.sleep5);

        // *** first name
        var firstnameafteredit = await myprofilepage.getFirstName();
        await utils.logInfo("value of fname after edit is: " + firstnameafteredit);
        //await browser.sleep(browser.params.sleep.sleep10);
        expect(firstnameafteredit).toBe(firstnamebeforeedit + " edited","Verify First Name edited Successfully in Edit Profile"); //*** Assertion ***/
        //await browser.sleep(browser.params.sleep.sleep10);

        // *** Office Phone
        var officephoneafteredit = await myprofilepage.getOfficePhone();
        await utils.logInfo("value of office phone after edit is: " + officephoneafteredit);
        //await browser.sleep(browser.params.sleep.sleep10);
        expect(officephoneafteredit).toBe(officephonebeforeedit + "0","Verify Office Phone edited Successfully in Edit Profile"); //*** Assertion ***/
        //await browser.sleep(browser.params.sleep.sleep10);
        //await browser.waitForAngular();
        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await browser.sleep(browser.params.sleep.sleep5);
                await verifymobilenumberpage.clickRemindme();
            }
        })
        
        // *** Mobile Phone
        // var mobilephoneafteredit = await myprofilepage.getMobilePhone();
        // await utils.logInfo("value of mobile phone after edit is: " + mobilephoneafteredit);

        // expect(mobilephoneafteredit).toBe(mobilephonebeforeedit + "0","Verify Mobile Phone edited Successfully in Edit Profile"); //*** Assertion ***/

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await browser.sleep(browser.params.sleep.sleep5);
                await verifymobilenumberpage.clickRemindme();
            }
        })

        //teardown
        await utils.logInfo("Reseting first Name to " + firstnamebeforeedit);
        await myprofilepage.setFirstName(firstnamebeforeedit);

        await utils.logInfo("Reseting Office Phone to " + officephonebeforeedit);
        await myprofilepage.setOfficePhone(officephonebeforeedit);

        // await utils.logInfo("Reseting Mobile Phone to " + mobilephonebeforeedit);
        // await myprofilepage.setMobilePhone(mobilephonebeforeedit);

        await utils.logInfo("Click On update");
        await myprofilepage.clickUpdate();

        await browser.sleep(browser.params.sleep.sleep10);

        //await browser.get(browser.params.env.url + "/report/active");
        await browser.refresh();
        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await browser.sleep(browser.params.sleep.sleep5);
                await verifymobilenumberpage.clickRemindme();
                await browser.sleep(browser.params.sleep.sleep5);

            }
        })


    }); //it




}); //describe 2