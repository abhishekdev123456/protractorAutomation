var loginpage = require('../pages/login.page');
var verifymobilenumberpage = require('../pages/verifymobilenumber.page');
var homepage = require('../pages/home.page');
var myaccountpage = require('../pages/myaccount.page');
var myprofilepage = require('../pages/myprofile.page');
var appraisalpage = require('../pages/appraisal.page');
var usermgmtpage = require('../pages/usermanagement.page');
var edituserpage = require('../pages/edituser.usermgmt.page');
var dealerconsolepage = require('../pages/dealer.console.page');
var dealershippage = require('../pages/dealership.page');
var recommenderpage = require('../pages/recommender.page');
var dealershippage = require('../pages/dealership.page');
var crpage = require('../pages/cr.page');
var utils = require('../utilities/utils');
var testdata = require('../data/test.data.js');
var using = require('jasmine-data-provider');
var path = require("path");

describe('Appraisal Menu & Header Test Suite', function () { // ********************** Describe1 *******************************
    browser.manage().timeouts().implicitlyWait(5000);
    browser.driver.manage().window().maximize();
    utils.logInfo("Appraisal Menu & Header Test Suite");
    utils.logInfo("TEST RUN : "+"https://autodevteam.testrail.net/index.php?/runs/view/866&group_by=cases:section_id&group_order=asc");
    var count = 0;
    
    beforeEach(async function () {
        await utils.logInfo("Getting Home Page")
        await homepage.get();
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.getCurrentUrl().then(async function (url) {
            await utils.logInfo("Before each : Current Url is "+url);
            await browser.sleep(browser.params.sleep.sleep5);

            if (url == await loginpage.getURL()) {
                utils.logInfo("Sign in since current page is Login page")
                await loginpage.signIn(browser.params.login.superadminuser, browser.params.login.superadminpassword);
                await browser.getCurrentUrl().then(async function (url) {
                    if (url == await verifymobilenumberpage.getUrl()) {
                        await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                        await verifymobilenumberpage.clickRemindme();
                    }//if
                })//then
            }//if
            else if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
            await browser.waitForAngularEnabled(true);

        });

        if(count == 0){
            await homepage.closeAllWalkme();
            count = 1;
        }//if count

    }); //beforeEach    

    afterEach(async function () {
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True
    });    

    xit('*** Email icon: Send email (Covered in Smoke Test)', async function () {
        utils.logInfo("***** TEST CASE : Email icon: Send email  *****");
        utils.logInfo("Enhanced Smoke automated Test to cover this scenario");
    }); 

    xit('*** Share: SMS Text: send text(Covered in Smoke Test)', async function () {
        utils.logInfo("***** TEST CASE : Share: SMS Text: send text *****");
        utils.logInfo("Enhanced Smoke automated Test to cover this scenario");
    });

    it('*** Share: Email: Copy Link: correctly copies the url & display confirmation ', async function () {
        utils.logInfo("***** TEST CASE : Share: Email: Copy Link: correctly copies the url & display confirmation  *****");

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   

        //Get Appraisal Menu
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await utils.logInfo("Open Appraisal Tools Menu");
        await appraisalpage.getAppraisalMenu();

        //Share Email
        await utils.logInfo("Click on Email icon");
        await appraisalpage.clickShareEmail();

        await browser.sleep(browser.params.sleep.sleep20);

        if(! await crpage.isPresentCopyLinkWebElement()){
            await browser.sleep(browser.params.sleep.sleep20);
        }

        await utils.logInfo("Is Copy Link Present : "+await crpage.isPresentCopyLinkWebElement());
        expect(await crpage.isPresentCopyLinkWebElement()).toBeTruthy("Verify Copy Link is present on Share Report screen after link generation");

        var expectedGeneratedLink = await crpage.getGeneratedLinkShareReport();
        await utils.logInfo("Value of generated report link is '"+expectedGeneratedLink+"'");    

        await utils.logInfo("Click on Copy Link");
        await crpage.clickCopyLinkShareReport();

        await utils.logInfo("Verify 'Link Copied' Notification Message Display");
        await utils.logInfo("Notification Msg:"+await crpage.isPresentLinkCopiedNotificationMsg());
        expect(await crpage.isPresentLinkCopiedNotificationMsg()).toBeTruthy("Verify 'Link Copied' Notification Message is Present");

        await utils.pasteFromClipboardToWebElement(crpage.getMsgShareReportWebElement());

        var copiedLink = await crpage.getMsgContentShareReport();

        await utils.logInfo("Verify Pasted link to Message text area matches the pdf report url");
        expect(expectedGeneratedLink).toContain(copiedLink, "Verify Link Copied successfully and matching generated report link");

        await utils.logInfo("Close the Share Report Screen");
        await crpage.closeShareReportScreen();

        await browser.waitForAngularEnabled(true); // *** Angular Enabled

    }); //it
    
    
    it('*** Give Feedback', async function () {
        utils.logInfo("***** TEST CASE : Give Feedback *****");

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   

        //Get Appraisal Menu
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await utils.logInfo("Open Appraisal Tools Menu");
        await appraisalpage.getAppraisalMenu();

        //Feedback Screen
        await utils.logInfo("Click on Feedback menu item");
        await appraisalpage.clickFeedbackAppraisalMenuItem();
        await browser.sleep(browser.params.sleep.sleep5);
        expect(await appraisalpage.isPresentFeedbackScreen()).toBeTruthy("Verify Feedback screen displayed when user click on Feeback under Appraisal Tools Menu");

        //Enter Feedback
        await appraisalpage.setFeedbackMsg("testing message");

        //Submit
        await appraisalpage.clickSendFeedbackBtn();

        //Verify Message
        await utils.logInfo("Is Present Feedback Success Msg :"+await appraisalpage.isPresentFeedbackSuccessMsg());

        
        await browser.waitForAngularEnabled(true); // *** Angular Enabled

    }); //it  

    it('*** Scorecard: Click on link directs to Scorecard screen', async function () {
        utils.logInfo("***** TEST CASE : Scorecard: Click on link directs to Scorecard screen *****");
        utils.logInfo("Enhanced Smoke automated Test to cover this scenario");
    });

    it('*** Guidebooks: clink on link directs to Guidebook screen', async function () {
        utils.logInfo("***** TEST CASE : Guidebooks: clink on link directs to Guidebook screen *****");

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   


        //Get Appraisal Menu
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await utils.logInfo("Open Appraisal Tools Menu");
        await appraisalpage.getAppraisalMenu();

        //Guidebook
        await utils.logInfo("Click on Guidebook menu item");
        await appraisalpage.clickGuidebookAppraisalMenuItem();
        
        //Verify Guidebooks page is displayed
        expect(await appraisalpage.isPresentGuideBooksScreen()).toBeTruthy("Verify Guidebooks screen displayed when user click on Guidebooks link under Appraisal Tools Menu");

        //Click on Back Button
        await appraisalpage.clickBackArrowBtn();

        //Verify appraisal screen is displayed in dealer mode

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/  

        expect(await appraisalpage.isPresentCustomerDetailPanel()).toBeFalsy("Verify Customer Detail Panel is not present which means its in a Dealer mode");
        expect(await appraisalpage.isPresentPriceBarBar()).toBeTruthy("Verify Price Bar is present which means its in a Dealer mode");


        //Switch to Consumer Mode
        await appraisalpage.clickAppraisalConsumerDealerMode();

        //Get Appraisal Menu
        //await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await utils.logInfo("Open Appraisal Tools Menu");
        await appraisalpage.getAppraisalMenu();

        //Guidebook
        await utils.logInfo("Click on Guidebook menu item");
        await appraisalpage.clickGuidebookAppraisalMenuItem();
        
        //Verify Guidebooks page is displayed
        expect(await appraisalpage.isPresentGuideBooksScreen()).toBeTruthy("Verify Guidebooks screen displayed when user click on Guidebooks link under Appraisal Tools Menu");

        //Click on Back Button
        await appraisalpage.clickBackArrowBtn();

        //Verify appraisal screen is displayed in Consumer mode
        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   

        expect(await appraisalpage.isPresentCustomerDetailPanel()).toBeTruthy("Verify Customer Detail Panel is present which means its in a Consumer mode");
        expect(await appraisalpage.isPresentPriceBarBar()).toBeFalsy("Verify Price Bar isnot present which means its in a Consumer mode");

        //switch back to dealer mode
        await appraisalpage.clickAppraisalConsumerDealerMode();


        await browser.waitForAngularEnabled(true); // *** Angular Enabled

    }); //it

    it('*** Local Market: Click on link direct to Local Market screen', async function () {
        utils.logInfo("***** TEST CASE : Local Market: Click on link direct to Local Market screen *****");
        utils.logInfo("Enhanced Smoke automated Test to cover this scenario");
    });

    it('*** Unit History: Click on link shows historical values graph', async function () {
        utils.logInfo("***** TEST CASE : Unit History: Click on link shows historical values graph *****");
        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   


        //Get Appraisal Menu
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("After Get Appraisal Menu");
        await utils.logInfo("Click on Unit History menu item");
        await appraisalpage.clickUnitHistoryMenuItem();
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Verify Unit History screen displayed when user click on Unit History link under Appraisal Tools Menu");
        expect(await appraisalpage.isPresentUnitHistoryHeader()).toBeTruthy("Verify Unit History screen displayed when user click on Unit History link under Appraisal Tools Menu");

        await utils.logInfo("Verify Unit History Tab is selected by default");
        expect(await appraisalpage.isSelectedUnitHistoryTab()).toBeTruthy("Verify Unit History Tab is selected by default");

        await utils.logInfo("Click on VIN History Tab");
        await appraisalpage.clickVINHistoryTab();

        await utils.logInfo("Verify Chart is present when user click on VIN Histort Tab");
        expect(await appraisalpage.isPresentChartVINHistory()).toBeTruthy("Verify Chart is present when user click on VIN Histort Tab");
        
        await browser.waitForAngularEnabled(true); // *** Angular Enabled

    });

    it('*** Photo Gallery link', async function () {
        utils.logInfo("***** TEST CASE : Photo Gallery link *****");
        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   


        //Get Appraisal Menu
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("After Get Appraisal Menu");
        await utils.logInfo("Click on Photo Gallery menu item");
        await appraisalpage.clickPhotoGalleryAppraisalMenuItem();
        expect(await appraisalpage.isPresentGalleryScreen()).toBeTruthy("Verify Photo Gallery screen displayed when user click on Photo Gallery link under Appraisal Tools Menu");
        await appraisalpage.clickLeftPhotoGalleryBtn();

        //Verify Appraisal screen is displayed
        sVIN = await homepage.getAppraisalVIN();
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/ 

        //Click to Consumer Mode
        await appraisalpage.clickAppraisalConsumerDealerMode();

        //Open Photo Gallery Link
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("After Get Appraisal Menu");
        await utils.logInfo("Click on Photo Gallery menu item");
        await appraisalpage.clickPhotoGalleryAppraisalMenuItem();
        expect(await appraisalpage.isPresentGalleryScreen()).toBeTruthy("Verify Photo Gallery screen displayed when user click on Photo Gallery link under Appraisal Tools Menu");

        //Back
        await appraisalpage.clickLeftPhotoGalleryBtn();

        //Verify Appraisal screen is displayed in Consumer mode
        expect(await appraisalpage.isPresentPriceBarBar()).toBeFalsy("Verify Appraisal screen is displayed in consumer mode");

        await browser.waitForAngularEnabled(true); // *** Angular Enabled


    });

    it('*** Appraisal Notes: Comment, Recon Note, Private Note ', async function () {
        utils.logInfo("***** TEST CASE : Appraisal Notes: Comment, Recon Note, Private Note  *****");

        await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");

        //Get Appraisal Menu
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await utils.logInfo("Get an Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("After Get Appraisal Menu");
        await utils.logInfo("Click on Appraisal Notes menu item");
        await appraisalpage.clickAppraisalNotesMenuItem();
        expect(await appraisalpage.isPresentAppraisalNotesHeader()).toBeTruthy("Verify Appraisal Notes screen displayed when user click on Appraisal Notes link under Appraisal Tools Menu");

        await utils.logInfo("Add comments 'testing notes' to Appraisal Notes screen");
        await appraisalpage.setCommentAppraisalNotes("testing notes");

        await utils.logInfo("Close Appraisal Notes screen");
        await appraisalpage.clickCloseBtnAppraisalNotes();

        await browser.refresh();
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("After Get Appraisal Menu");
        await utils.logInfo("Click on Appraisal Notes menu item");
        await appraisalpage.clickAppraisalNotesMenuItem();
        expect(await appraisalpage.isPresentAppraisalNotesHeader()).toBeTruthy("Verify Appraisal Notes screen displayed when user click on Appraisal Notes link under Appraisal Tools Menu");
        expect(await appraisalpage.getCommentAppraisalNotes()).toBe("testing notes","Verify Appraisal Notes persist in Appraisal after re-opening");

        await homepage.openReadOnlyFirstArchivedAppraisal();
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("After Get Appraisal Menu");
        await utils.logInfo("Click on Appraisal Notes menu item");
        await appraisalpage.clickAppraisalNotesMenuItem();
        expect(await appraisalpage.isPresentAppraisalNotesHeader()).toBeTruthy("Verify Appraisal Notes screen displayed when user click on Appraisal Notes link under Appraisal Tools Menu");
        expect(await appraisalpage.isDisabledCommentAppraisalNotes()).toBeTruthy("Verify Appraisal Notes can't be added for Read Only Appraisals ")

        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    });

    it('*** Recall Notes: Display link if Recalls available and direct to Recall notes if clicked', async function () {
        utils.logInfo("***** TEST CASE : Recall Notes: Display link if Recalls available and direct to Recall notes if clicked *****");

        await utils.logInfo("Create an Appraisal with Recall VIN")
        await homepage.createNewAppraisalVIN(browser.params.vin.recall,"first");
    
        //Get Appraisal Menu
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await utils.logInfo("Open Appraisal Tools Menu");
        await appraisalpage.getAppraisalMenu();

        await utils.logInfo("Verify 'Recall Notes' Menu item present in Appraisal Menu");
        expect(appraisalpage.isPresentRecallNotesAppraisalMenuItem()).toBeTruthy("Verify 'Recall Notes' Menu item present in Appraisal Menu for VIN:"+browser.params.vin.recall);

        //Recall Notes
        await utils.logInfo("Click on Recall Notes menu item");
        await appraisalpage.clickRecallNotesAppraisalMenuItem();
        expect(await appraisalpage.isPresentRecallsScreen()).toBeTruthy("Verify Recalls screen displayed when user click on Recall Notes link under Appraisal Tools Menu");

        //Close it
        await appraisalpage.clickRecallCloseBtn();

        //Verify Recall Screen Closed
        expect(await appraisalpage.isPresentRecallsScreen()).toBeFalsy("Verify Recalls screen closed when user click on close button of Recalls screen");
        
        await browser.waitForAngularEnabled(true); // *** Angular Enabled
        await utils.logInfo("Create an Appraisal with No Recall VIN")
        await homepage.createNewAppraisalVIN(browser.params.vin.norecall,"first");

        //Get Appraisal Menu
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await utils.logInfo("Open Appraisal Tools Menu");
        await appraisalpage.getAppraisalMenu();

        await utils.logInfo("Verify 'Recall Notes' Menu item is not present in Appraisal Menu");
        expect(appraisalpage.isPresentRecallNotesAppraisalMenuItem()).toBeFalsy("Verify 'Recall Notes' Menu item is not present in Appraisal Menu");

        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    }); //it

    it('*** Reports: Dealer Condition and Consumer appraisal Report links', async function () {
        utils.logInfo("***** TEST CASE : Reports: Dealer Condition and Consumer appraisal Report links *****");

        await utils.logInfo("Create an Appraisal with VIN :"+browser.params.vin.validvin);
        await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");
    
        //Consumer Appraisal Report
        await browser.waitForAngularEnabled(true); // *** Angular Enabled
        await browser.refresh();
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Click on Customer Appraisal Report menu item");
        await appraisalpage.clickConsumerAppraisalMenuItem();
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await browser.sleep(browser.params.sleep.sleep5);
        expect(await browser.getCurrentUrl()).toContain("/report?type=consumer","Verify Consumer CR displayed when user click on Consumer Appraisal Report under Appraisal Tools Menu");//Assertion
        expect(await crpage.getVINCR()).toBe(browser.params.vin.validvin,"Verify correct VIN number on Consumer CR");

        await crpage.clickBackToAppraisalLink();

        //Dealer Condition Report
        await browser.waitForAngularEnabled(true); // *** Angular Enabled
        await browser.refresh();
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Click on Dealer Condition Report menu item");
        await appraisalpage.clickDealerAppraisalMenuItem();
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await browser.sleep(browser.params.sleep.sleep5);
        expect(await browser.getCurrentUrl()).toContain("/report?type=dealer","Verify Dealer CR displayed when user click on Dealer Condition Report under Appraisal Tools Menu"); //Assertion
        expect(await crpage.getVINCR()).toBe(browser.params.vin.validvin,"Verify correct VIN number on Dealer CR");

        
        await browser.waitForAngularEnabled(true); // *** Angular Enabled

    }); //it


it('*** Lists: VHR Column: YMMT Appraisal with Bad VHR will display No Carfax No Autocheck  ', async function () {
    utils.logInfo("***** TEST CASE : Lists: VHR Column: YMMT Appraisal with Bad VHR will display No Carfax No Autocheck  *****");

    await utils.logInfo("Create new Appraisal using YMMT (2018 AUDI A3 PREMIUM 4 DOOR SEDAN 2.0L 4 CYL TURBO) and Verify it Created successfully");
    await homepage.createNewAppraisalYMMT("2018", "AUDI","A3","PREMIUM 4 DOOR SEDAN 2.0L 4 CYL TURBO");

    await browser.waitForAngularEnabled(false); // *** Angular Enabled

    var appraisalID = await appraisalpage.getAppraisalID();

    await utils.logInfo("Select Bad VHR in Appraisal");
    await appraisalpage.setVehicleHistory("bad vhr");
    expect(await appraisalpage.isSelectedBadVHR()).toBeTruthy("Verify Bad VHR is selected");

    await utils.logInfo("Click on Back Arrow Button");
    await appraisalpage.clickBackArrowBtn();
    await browser.refresh();

    await browser.waitForAngularEnabled(true); // *** Angular Enabled

    // Set History Settings to ON
    await utils.logInfo("Click Settings in Appraisal List");
    await homepage.clickSettingsAppraisalList();
    await utils.logInfo("Select History Checkbox to ON");
    await homepage.setHistoryCheckboxSettingsAppraisalList("ON");
    await utils.logInfo("Click on Update Button");
    await homepage.clickUpdateBtnSettingsAppraisalList();
    await browser.sleep(browser.params.sleep.sleep10);

    //Search Appraisal
    await utils.logInfo("Search Appraisal on Appraisal List");
    await homepage.searchAppraisalList(appraisalID);
    await browser.sleep(browser.params.sleep.sleep10);

    //Verify
    expect(await homepage.isPresentCarFaxGrayIconAppraisalList()).toBeTruthy("Verify Carfax gray icon present on History Column of Appraisal List");
    expect(await homepage.isPresentAutoCheckGrayIconAppraisalList()).toBeTruthy("Verify Autocheck gray icon present on History Column of Appraisal List");
    expect(await homepage.isPresentBadVHRRedIconAppraisalList()).toBeTruthy("Verify Bad VHR red icon present on History Column of Appraisal List");

    await browser.waitForAngularEnabled(true); // *** Angular Enabled

    });//it


    it('*** Carfax: Verify good/bad carfax ', async function () {
        utils.logInfo("***** TEST CASE : Carfax: Verify good/bad carfax  *****");

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter Good Carfax VIN " + browser.params.vin.goodcarfaxautocheck + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.goodcarfaxautocheck);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.goodcarfaxautocheck,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/  
        
        await browser.waitForAngularEnabled(false); // *** Angular Enabled false

        expect(await appraisalpage.isPresentGoodCarFaxImage()).toBeTruthy("Verify Good Carfax image present on Appraisal page for VIN : "+browser.params.vin.goodcarfaxautocheck);
        expect(await appraisalpage.isPresentGoodAutoCheckImage()).toBeTruthy("Verify Good Auto Check image present on Appraisal page for VIN : "+browser.params.vin.goodcarfaxautocheck);

        //Carfax
        await utils.logInfo("Click on Carfax Image");
        await appraisalpage.clickCarFaxImage();
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Carfax and Autocheck screen opens up
        expect(await appraisalpage.isPresentCarFaxReportScreen()).toBeTruthy("Verify Carfax screen display when click on Carfax good image");

        browser.switchTo().frame(element(by.xpath("//iframe[contains(@srcdoc, 'SafeValue')]")).getWebElement());
        await utils.logInfo("Switched to iFrame");
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Value of GOOD VIN in CarFax Report is "+ await appraisalpage.getVINCarFaxReport());
        expect(await appraisalpage.getVINCarFaxReport()).toBe(browser.params.vin.goodcarfaxautocheck,"Verify CARFAX Report showing correct VIN");

        browser.switchTo().defaultContent();
        await browser.sleep(browser.params.sleep.sleep5);


        await utils.logInfo("Close Carfax Report Screen");
        await appraisalpage.closeCarFaxReportScreen();

        //AutoCheck
        await utils.logInfo("Click on Auto Check Image");
        await appraisalpage.clickAutoCheckImage();
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Carfax and Autocheck screen opens up
        expect(await appraisalpage.isPresentAutoCheckReportScreen()).toBeTruthy("Verify Auto Check screen display when click on Autocheck good image");

        browser.switchTo().frame(element(by.xpath("//iframe[contains(@srcdoc, 'SafeValue')]")).getWebElement());
        await utils.logInfo("Switched to iFrame");
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Value of GOOD VIN in Autocheck Report is "+ await appraisalpage.getVINAutoCheckReport());
        expect(await appraisalpage.getVINAutoCheckReport()).toBe(browser.params.vin.goodcarfaxautocheck,"Verify AutoCheck Report showing correct VIN");

        browser.switchTo().defaultContent();
        await browser.sleep(browser.params.sleep.sleep5);
        
        await utils.logInfo("Close Auto Check Report Screen");
        await appraisalpage.closeAutoCheckReportScreen();

        // ******************  BAD VIN *************************
        await browser.waitForAngularEnabled(true); // *** Angular Enabled true
        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter Bad Carfax VIN " + browser.params.vin.badcarfaxautocheck + " into New Appraisal Window");

        EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.badcarfaxautocheck);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.badcarfaxautocheck,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/  
        
        await browser.waitForAngularEnabled(false); // *** Angular Enabled false

        expect(await appraisalpage.isPresentBadCarFaxImage()).toBeTruthy("Verify Bad Carfax image present on Appraisal page for VIN : "+browser.params.vin.badcarfaxautocheck);
        expect(await appraisalpage.isPresentBadAutoCheckImage()).toBeTruthy("Verify Bad Auto Check image present on Appraisal page for VIN : "+browser.params.vin.badcarfaxautocheck);

        //CARFAX
        await utils.logInfo("Click on Carfax Image");
        await appraisalpage.clickCarFaxImage();
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Carfax and Autocheck screen opens up
        expect(await appraisalpage.isPresentCarFaxReportScreen()).toBeTruthy("Verify Carfax screen display when click on Carfax image");

        browser.switchTo().frame(element(by.xpath("//iframe[contains(@srcdoc, 'SafeValue')]")).getWebElement());
        await utils.logInfo("Switched to iFrame");
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Value of BAD VIN in CarFax Report is "+ await appraisalpage.getVINCarFaxReport());
        expect(await appraisalpage.getVINCarFaxReport()).toBe(browser.params.vin.badcarfaxautocheck,"Verify CARFAX Report showing correct VIN");

        browser.switchTo().defaultContent();
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Close Carfax Report Screen");
        await appraisalpage.closeCarFaxReportScreen();

        //AutoCheck
        await utils.logInfo("Click on Auto Check Image");
        await appraisalpage.clickAutoCheckImage();
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Carfax and Autocheck screen opens up
        expect(await appraisalpage.isPresentAutoCheckReportScreen()).toBeTruthy("Verify Auto Check screen display when click on Autocheck good image");
        
        browser.switchTo().frame(element(by.xpath("//iframe[contains(@srcdoc, 'SafeValue')]")).getWebElement());
        await utils.logInfo("Switched to iFrame");
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Value of BAD VIN in Autocheck Report is "+ await appraisalpage.getVINAutoCheckReport());
        expect(await appraisalpage.getVINAutoCheckReport()).toBe(browser.params.vin.badcarfaxautocheck,"Verify AutoCheck Report showing correct VIN");

        browser.switchTo().defaultContent();
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Close Auto Check Report Screen");
        await appraisalpage.closeAutoCheckReportScreen();


    });//it


    it('*** Repossessed vehicle shows bad Carfax & Autocheck', async function () {
        utils.logInfo("***** TEST CASE : Repossessed vehicle shows bad Carfax & Autocheck  *****");

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter Repossessed Vehicle VIN " + browser.params.vin.repossessedvehicle + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.repossessedvehicle);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.repossessedvehicle,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/  
        
        await browser.waitForAngularEnabled(false); // *** Angular Enabled false

        expect(await appraisalpage.isPresentBadCarFaxImage()).toBeTruthy("Verify Bad Carfax image present on Appraisal page for VIN : "+browser.params.vin.repossessedvehicle);
        expect(await appraisalpage.isPresentBadAutoCheckImage()).toBeTruthy("Verify Bad Auto Check image present on Appraisal page for VIN : "+browser.params.vin.repossessedvehicle);
        
        await browser.waitForAngularEnabled(true); // *** Angular Enabled true


    });//it    

    it('*** Carfax: "Possible odometer rollback" is flagged bad Carfax', async function () {
        utils.logInfo("***** TEST CASE : //Carfax: 'Possible odometer rollback' is flagged bad Carfax  *****");

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter Odometer Rollback VIN " + browser.params.vin.odometerrollback + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.odometerrollback);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.odometerrollback,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/  
        
        await browser.waitForAngularEnabled(false); // *** Angular Enabled false

        expect(await appraisalpage.isPresentBadCarFaxImage()).toBeTruthy("Verify Bad Carfax image present on Appraisal page for VIN : "+browser.params.vin.odometerrollback);
        expect(await appraisalpage.isPresentBadAutoCheckImage()).toBeTruthy("Verify Bad Auto Check image present on Appraisal page for VIN : "+browser.params.vin.odometerrollback);

        //CARFAX
        await utils.logInfo("Click on Carfax Image");
        await appraisalpage.clickCarFaxImage();
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Carfax and Autocheck screen opens up
        expect(await appraisalpage.isPresentCarFaxReportScreen()).toBeTruthy("Verify Carfax screen display when click on Carfax image");

        browser.switchTo().frame(element(by.xpath("//iframe[contains(@srcdoc, 'SafeValue')]")).getWebElement());
        await utils.logInfo("Switched to iFrame");
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Value of BAD VIN in CarFax Report is "+ await appraisalpage.getVINCarFaxReport());
        expect(await appraisalpage.getVINCarFaxReport()).toBe(browser.params.vin.odometerrollback,"Verify CARFAX Report showing correct VIN");

        var odometerRollbackText = element(by.xpath("//*[text()='Potential odometer rollback indicated']"));
        expect(await odometerRollbackText.isPresent()).toBeTruthy("Verify message -'Potential odometer rollback indicated' included in Carfax Report");

        browser.switchTo().defaultContent();
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Close Carfax Report Screen");
        await appraisalpage.closeCarFaxReportScreen();

        //AutoCheck
        await utils.logInfo("Click on Auto Check Image");
        await appraisalpage.clickAutoCheckImage();
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Carfax and Autocheck screen opens up
        expect(await appraisalpage.isPresentAutoCheckReportScreen()).toBeTruthy("Verify Auto Check screen display when click on Autocheck good image");
        
        browser.switchTo().frame(element(by.xpath("//iframe[contains(@srcdoc, 'SafeValue')]")).getWebElement());
        await utils.logInfo("Switched to iFrame");
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Value of BAD VIN in Autocheck Report is "+ await appraisalpage.getVINAutoCheckReport());
        expect(await appraisalpage.getVINAutoCheckReport()).toBe(browser.params.vin.odometerrollback,"Verify AutoCheck Report showing correct VIN");

        odometerRollbackText = element(by.xpath("//*[text()[normalize-space()='Odometer Problem(s) Reported']]"));
        expect(await odometerRollbackText.isPresent()).toBeTruthy("Verify message -'Potential odometer rollback indicated' included in AutoCheck Report");
        
        browser.switchTo().defaultContent();
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Close Auto Check Report Screen");
        await appraisalpage.closeAutoCheckReportScreen();

        await browser.waitForAngularEnabled(true); // *** Angular Enabled true

    });//it


    it('*** Carfax/Autocheck bad credentials should prevent their respective icon from showing on Appraisal', async function () {
        utils.logInfo("***** TEST CASE : Carfax/Autocheck bad credentials should prevent their respective icon from showing on Appraisal  *****");

        //Add Code to Remove Carfax and Autocheck credentials under My Account
        await browser.refresh();

        await utils.logInfo("Navigate to My Account Page");
        await homepage.navigateThroughMenu("My Account");

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Click on CarFax Account Link");
        await myaccountpage.clickCarFaxAccountLink();

        if(await myaccountpage.isPresentCarFaxRemoveBtn() == false){
            await myaccountpage.setCarFaxCredentials("C431907","35391");
            await browser.sleep(browser.params.sleep.sleep10);    }

        await utils.logInfo("Click on CarFax Remove button");
        await myaccountpage.clickCarFaxRemoveBtn();
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Click on Left Arrow button");
        await myaccountpage.clickLeftArrowBtn();

        await utils.logInfo("Click on AutoCheck Account Link");
        await myaccountpage.clickAutoCheckAccountLink();

        if(await myaccountpage.isPresentCarFaxRemoveBtn() == false){
            await myaccountpage.setAutoCheckCredentials("BFGR0024","rhas1373");
            await browser.sleep(browser.params.sleep.sleep10);    }

        await utils.logInfo("Click on AutoCheck Remove button");
        await myaccountpage.clickAutoCheckRemoveBtn();
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(true); // *** Angular Enabled False

        await homepage.get();

        //await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter Good Carfax VIN " + browser.params.vin.goodcarfaxautocheck + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.goodcarfaxautocheck);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.goodcarfaxautocheck,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/  
        
        await browser.waitForAngularEnabled(false); // *** Angular Enabled false

        expect(await appraisalpage.isPresentGoodCarFaxImage()).toBeFalsy("Verify good Carfax image is not present on Appraisal page After removing Carfax credentials for VIN : "+browser.params.vin.goodcarfaxautocheck);
        expect(await appraisalpage.isPresentGoodAutoCheckImage()).toBeFalsy("Verify good Auto Check image is not present on Appraisal page after removing Autocheck credentials for VIN : "+browser.params.vin.goodcarfaxautocheck);
        expect(await appraisalpage.isPresentBadCarFaxImage()).toBeFalsy("Verify bad Carfax image is not present on Appraisal page After removing Carfax credentials for VIN : "+browser.params.vin.goodcarfaxautocheck);
        expect(await appraisalpage.isPresentBadAutoCheckImage()).toBeFalsy("Verify bad Auto Check image is not present on Appraisal page after removing Autocheck credentials for VIN : "+browser.params.vin.goodcarfaxautocheck);

        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Navigate to My Account Page");
        await homepage.navigateThroughMenu("My Account");

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Click on CarFax Account Link");
        await myaccountpage.clickCarFaxAccountLink();

        await myaccountpage.setCarFaxCredentials("C431907","35391");
        await browser.sleep(browser.params.sleep.sleep5);

        await myaccountpage.clickLeftArrowBtn();
        await myaccountpage.clickAutoCheckAccountLink();

        await myaccountpage.setAutoCheckCredentials("BFGR0024","rhas1373");
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.waitForAngularEnabled(true); // *** Angular Enabled True


    });//it

    it('*** Appraisal: Read Only:  Customer data can not be added to Appraisals in read only mode ', async function () {
        utils.logInfo("***** TEST CASE : Appraisal: Read Only:  Customer data can not be added to Appraisals in read only mode *****");

        await browser.refresh();

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);

        await appraisalpage.clickBackArrowBtn();
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.refresh();

        await utils.logInfo("Archive Appraisal By ID");
        await homepage.archiveAppraisalByID(appraisalID);
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Open Archived Appraisal By ID");
        await homepage.openArchivedAppraisalByID(appraisalID);

        await browser.sleep(browser.params.sleep.sleep10);
        expect(await appraisalpage.isReadOnlyAppraisal()).toBeTruthy("Verify Appraisal '"+appraisalID+"' is Read Only");


        await browser.sleep(browser.params.sleep.sleep10);

        //Get Appraisal Menu
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await utils.logInfo("Open Appraisal Tools Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Verify 'Customer Information' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentCustomerInfoMenuItem()).toBeTruthy("Verify 'Customer Information' Menu item present in Appraisal Menu");

        //Customer Information
        await utils.logInfo("Click on Customer Information menu item");
        await appraisalpage.clickCustomerInfoMenuItem();
        expect(await appraisalpage.isPresentFirstNameLabelCustomerInfo()).toBeTruthy("Verify Customer Information screen displayed when user click on Customer Information link under Appraisal Tools Menu");

        expect(await appraisalpage.isDisabledFirstNameCustomerInfo()).toBeTruthy("Verify 'First Name' field is disabled in Customer Information screen");
        expect(await appraisalpage.isDisabledLastNameCustomerInfo()).toBeTruthy("Verify 'Last Name' field is disabled in Customer Information screen");
        expect(await appraisalpage.isDisabledZipCodeCustomerInfo()).toBeTruthy("Verify 'Zip Code' field is disabled in Customer Information screen");
        expect(await appraisalpage.isDisabledPrimaryPhoneCustomerInfo()).toBeTruthy("Verify 'Primary Phone' field is disabled in Customer Information screen");
        expect(await appraisalpage.isDisabledEmailAddressCustomerInfo()).toBeTruthy("Verify 'Email Address' field is disabled in Customer Information screen");
        expect(await appraisalpage.isDisabledPriceDealerPurchasedFromCustomerInfo()).toBeTruthy("Verify 'Price Dealer Purchased from Customer' field is disabled in Customer Information screen");
        expect(await appraisalpage.isDisabledDealerOfferCustomerInfo()).toBeTruthy("Verify 'Dealer Offer' field is disabled in Customer Information screen");
        expect(await appraisalpage.isDisabledRedemptionCodeCustomerInfo()).toBeTruthy("Verify 'Redemption Code' field is disabled in Customer Information screen");
        expect(await appraisalpage.isDisabledLostReasonCustomerInfo()).toBeTruthy("Verify 'Loast Reason' field is disabled in Customer Information screen");


    });//it

    it('*** Status - Update Status for each: Won, Open, Lost', async function () {
        utils.logInfo("***** TEST CASE : Status - Update Status for each: Won, Open, Lost  *****");
    
        await utils.logInfo("Create new Appraisal using YMMT (2018 AUDI A3 PREMIUM 4 DOOR SEDAN 2.0L 4 CYL TURBO) and Verify it Created successfully");
        await homepage.createNewAppraisalYMMT("2018", "AUDI","A3","PREMIUM 4 DOOR SEDAN 2.0L 4 CYL TURBO");
    
        await browser.waitForAngularEnabled(false); // *** Angular Enabled
    
        var appraisalID = await appraisalpage.getAppraisalID();

        //Click on Back Arrow button to go to Appraisal List
        await utils.logInfo("Click on Back Arrow Button");
        await appraisalpage.clickBackArrowBtn();

        await browser.waitForAngularEnabled(true); // *** Angular Enabled
        await browser.refresh();
    
        //Search Appraisal
        await utils.logInfo("Search Appraisal on Appraisal List");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);
    
        //Verify Disposition Color and Value - Open/Blue
        expect(await homepage.getDispositionValueAppraisalList()).toBe("open");
        expect(await homepage.getDispositionColorAppraisalList()).toBe("blue");
            
        //Open Appraisal Again
        await utils.logInfo("Open First Appraisal");
        await homepage.clickFirstAppraisal();

        await browser.waitForAngularEnabled(false); // *** Angular Enabled

        //Select Lost Reason - Won
        await utils.logInfo("Open Appraisal Tools Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Verify 'Customer Information' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentCustomerInfoMenuItem()).toBeTruthy("Verify 'Customer Information' Menu item present in Appraisal Menu");

        //Customer Information
        await utils.logInfo("Click on Customer Information menu item");
        await appraisalpage.clickCustomerInfoMenuItem();
        expect(await appraisalpage.isPresentFirstNameLabelCustomerInfo()).toBeTruthy("Verify Customer Information screen displayed when user click on Customer Information link under Appraisal Tools Menu");

        //Enter Lost Reason Status)
        await utils.logInfo("Enter 'Status' in Customer Information screen");
        await appraisalpage.setStatusCustomerInfo("WON");

        //Close the Customer Information
        await utils.logInfo("Close the Customer Information screen");
        await appraisalpage.closeCustomerInfoScreen();
    
        //Click on Back Arrow button to go to Appraisal List
        await utils.logInfo("Click on Back Arrow Button");
        await appraisalpage.clickBackArrowBtn();
        await browser.refresh();
    
        await browser.waitForAngularEnabled(true); // *** Angular Enabled
    
        //Search Appraisal
        await utils.logInfo("Search Appraisal on Appraisal List");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);
    
        //Verify Disposition Color and Value - Won
        expect(await homepage.getDispositionValueAppraisalList()).toBe("won");
        expect(await homepage.getDispositionColorAppraisalList()).toBe("green");
    
        //Open Appraisal Again
        await utils.logInfo("Open First Appraisal");
        await homepage.clickFirstAppraisal();

        await browser.waitForAngularEnabled(false); // *** Angular Enabled

        //Select Lost Reason - Won
        await utils.logInfo("Open Appraisal Tools Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Verify 'Customer Information' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentCustomerInfoMenuItem()).toBeTruthy("Verify 'Customer Information' Menu item present in Appraisal Menu");

        //Customer Information
        await utils.logInfo("Click on Customer Information menu item");
        await appraisalpage.clickCustomerInfoMenuItem();
        expect(await appraisalpage.isPresentFirstNameLabelCustomerInfo()).toBeTruthy("Verify Customer Information screen displayed when user click on Customer Information link under Appraisal Tools Menu");

        //Enter Lost Reason Status)
        await utils.logInfo("Enter 'Status' in Customer Information screen");
        await appraisalpage.setStatusCustomerInfo("LOST");

        //Close the Customer Information
        await utils.logInfo("Close the Customer Information screen");
        await appraisalpage.closeCustomerInfoScreen();
    
        //Click on Back Arrow button to go to Appraisal List
        await utils.logInfo("Click on Back Arrow Button");
        await appraisalpage.clickBackArrowBtn();
        await browser.refresh();
    
        await browser.waitForAngularEnabled(true); // *** Angular Enabled
    
        //Search Appraisal
        await utils.logInfo("Search Appraisal on Appraisal List");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);
    
        //Verify Disposition Color and Value - Won
        expect(await homepage.getDispositionValueAppraisalList()).toBe("lost");
        expect(await homepage.getDispositionColorAppraisalList()).toBe("red");


        await browser.waitForAngularEnabled(true); // *** Angular Enabled
    
        });//it


    it('*** Customer Details: Verify display of dynamic fields for "Payments" and "voi"', async function () {
        utils.logInfo("***** TEST CASE : Customer Details: Verify display of dynamic fields for Payments and voi *****");

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   

        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        await utils.logInfo("Click to the Consumer Mode Button");
        await appraisalpage.clickAppraisalConsumerDealerMode();
        await appraisalpage.scrollToFirstNameCustomerDetail();
        //await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Enter First Name into Customer Detail Screen");
        await appraisalpage.setFirstNameConsumerModeCustomerDetail("Jason");
        await utils.logInfo("Enter Last Name into Customer Detail Screen");
        await appraisalpage.setLastNameConsumerModeCustomerDetail("Bland");
        await utils.logInfo("Enter Zip Code into Customer Detail Screen");
        await appraisalpage.setZipCodeConsumerModeCustomerDetail("78641");
        await utils.logInfo("Enter Phone Number into Customer Detail Screen");
        await appraisalpage.setPhoneConsumerModeCustomerDetail("5123334444");
        await utils.logInfo("Enter Email Address into Customer Detail Screen");
        await appraisalpage.setEmailConsumerModeCustomerDetail("fakeemail@accu-trade.com");

        expect(await appraisalpage.isSelectedPaymentYesBtnCustomerDetail()).toBeFalsy("Verify Payment Yes Button is not selected by default in Customer Detail Screen");
        expect(await appraisalpage.isSelectedPaymentNoBtnCustomerDetail()).toBeTruthy("Verify Payment No Button is selected by default in Customer Detail Screen");
        expect(await appraisalpage.isSelectedReplacementVehicleYesBtnCustomerDetail()).toBeFalsy("Verify Replacement Vehicle Yes Button is not selected by default in Customer Detail Screen");
        expect(await appraisalpage.isSelectedReplacementVehicleNoBtnCustomerDetail()).toBeTruthy("Verify Replacement vehicle No Button is selected by default in Customer Detail Screen");

        await browser.sleep(browser.params.sleep.sleep5);

        //Verify on Customer Details
        await appraisalpage.getAppraisalMenu();
        await appraisalpage.clickCustomerInfoMenuItem();
        expect(await appraisalpage.getFirstNameCustomerInfo()).toBe("Jason","Verify 'First Name' persist in Customer Information screen from what user entered in Customer Detail Screen");
        expect(await appraisalpage.getLastNameCustomerInfo()).toBe("Bland","Verify 'Last Name' persist in Customer Information screen from what user entered in Customer Detail Screen");
        expect(await appraisalpage.getZipCodeCustomerInfo()).toBe("78641","Verify 'Zip Code' persist in Customer Information screen from what user entered in Customer Detail Screen");
        expect(await appraisalpage.getPrimaryPhoneCustomerInfo()).toBe("5123334444","Verify 'Phoner Number' persist in Customer Information screen from what user entered in Customer Detail Screen");
        expect(await appraisalpage.getEmailAddressCustomerInfo()).toBe("fakeemail@accu-trade.com","Verify 'Email Address' persist in Customer Information screen from what user entered in Customer Detail Screen");
        await utils.logInfo("Close the Customer Information Screen");
        await appraisalpage.closeCustomerInfoScreen();

        expect(await appraisalpage.isSelectedPaymentYesBtnCustomerDetail()).toBeFalsy("Verify Payment Yes Button is not selected by default in Customer Detail Screen");
        expect(await appraisalpage.isSelectedPaymentNoBtnCustomerDetail()).toBeTruthy("Verify Payment No Button is selected by default in Customer Detail Screen");
        expect(await appraisalpage.isSelectedReplacementVehicleYesBtnCustomerDetail()).toBeFalsy("Verify Replacement Vehicle Yes Button is not selected by default in Customer Detail Screen");
        expect(await appraisalpage.isSelectedReplacementVehicleNoBtnCustomerDetail()).toBeTruthy("Verify Replacement vehicle No Button is selected by default in Customer Detail Screen");

        await utils.logInfo("Click on Still Making Payment 'No' button in Customer Detail");
        await appraisalpage.clickPaymentNoBtnCustomerDetail();
        expect(await appraisalpage.isPresentLoanRadioBtnCustomerDetail()).toBeFalsy("Verify 'Loan' Radio button is not present when select 'No' to Still making payments");
        expect(await appraisalpage.isPresentLeaseRadioBtnCustomerDetail()).toBeFalsy("Verify 'Lease' Radio button is not present when select 'No' to Still making payments");
        expect(await appraisalpage.isPresentLoanAmountRemainingCustomerDetail()).toBeFalsy("Verify 'Amount Remaining' Text Field is not present when select 'No' to Still making payments");

        await utils.logInfo("Click on Still Making Payment 'Yes' button in Customer Detail");
        await appraisalpage.clickPaymentYesBtnCustomerDetail();
        expect(await appraisalpage.isPresentLoanRadioBtnCustomerDetail()).toBeTruthy("");
        expect(await appraisalpage.isPresentLeaseRadioBtnCustomerDetail()).toBeTruthy("");
        expect(await appraisalpage.isPresentLoanAmountRemainingCustomerDetail()).toBeTruthy("");

        await utils.logInfo("Click on Interested in Replacement Vehicle 'No' button in Customer Detail");
        await appraisalpage.clickReplacementVehicleNoBtnCustomerDetail();
        expect(await appraisalpage.isPresentNewPurchaseRadioBtnCustomerDetail()).toBeFalsy("Verify 'New' Radio Button is not present when selected 'No' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentUsedPurchaseRadioBtnCustomerDetail()).toBeFalsy("Verify 'Used' Radio Button is not present when selected 'No' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentCPOPurchaseRadioBtnCustomerDetail()).toBeFalsy("Verify 'CPO' Radio Button is not present when selected 'No' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentNotSurePurchasedRadioBtnCustomerDetail()).toBeFalsy("Verify 'Not Sure' Radio Button is not present when selected 'No' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentYearInputCustomerDetail()).toBeFalsy("Verify Year Input field is not present when selected 'No' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentMakeInputCustomerDetail()).toBeFalsy("Verify Year Input field is not present when selected 'No' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentModelInputCustomerDetail()).toBeFalsy("Verify Year Input field is not present when selected 'No' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentTrimInputCustomerDetail()).toBeFalsy("Verify Year Input field is not present when selected 'No' to Interested in Replacement Vehicle Button");

        await utils.logInfo("Click on Interested in Replacement Vehicle 'Yes' button in Customer Detail");
        await appraisalpage.clickReplacementVehicleYesBtnCustomerDetail();
        await appraisalpage.scrollToFirstNameCustomerDetail();
        expect(await appraisalpage.isPresentNewPurchaseRadioBtnCustomerDetail()).toBeTruthy("Verify 'New' Radio Button is present when selected 'Yes' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentUsedPurchaseRadioBtnCustomerDetail()).toBeTruthy("Verify 'Used' Radio Button is present when selected 'Yes' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentCPOPurchaseRadioBtnCustomerDetail()).toBeTruthy("Verify 'CPO' Radio Button is present when selected 'Yes' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentNotSurePurchasedRadioBtnCustomerDetail()).toBeTruthy("Verify 'Not Sure' Radio Button is present when selected 'Yes' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentYearInputCustomerDetail()).toBeTruthy("Verify Year Input field is present when selected 'Yes' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentMakeInputCustomerDetail()).toBeTruthy("Verify Make Input field is present when selected 'Yes' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentModelInputCustomerDetail()).toBeTruthy("Verify Model Input field is present when selected 'Yes' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentTrimInputCustomerDetail()).toBeTruthy("Verify Trim Input field is present when selected 'Yes' to Interested in Replacement Vehicle Button");

        await utils.logInfo("Select 'CPO' Purchase Radion button in Customer Detail");
        await appraisalpage.selectCPOPurchaseRadioBtnCustomerDetail();
        expect(await appraisalpage.isPresentYearInputCustomerDetail()).toBeTruthy("Verify Year Input field is present when selected 'CPO' Radio Button");
        expect(await appraisalpage.isPresentMakeInputCustomerDetail()).toBeTruthy("Verify Make Input field is present when selected 'CPO' Radio Button");
        expect(await appraisalpage.isPresentModelInputCustomerDetail()).toBeTruthy("Verify Model Input field is present when selected 'CPO' Radio Button");
        expect(await appraisalpage.isPresentTrimInputCustomerDetail()).toBeTruthy("Verify Trim Input field is present when selected 'CPO' Radio Button");

        await utils.logInfo("Enter Year in Customer Detail screen");
        await appraisalpage.setYearInputCustomerDetail("2017");
        await utils.logInfo("Enter Make in Customer Detail screen");
        await appraisalpage.setMakeInputCustomerDetail("ACURA");
        await utils.logInfo("Enter Model in Customer Detail screen");
        await appraisalpage.setModelInputCustomerDetail("MDX");
        await utils.logInfo("Enter Trim in Customer Detail screen");
        await appraisalpage.setTrimInputCustomerDetail("ADVANCE 2WD 4 Door SUV 3.5L V6");

        await utils.logInfo("Select 'New' Purchase Radion button in Customer Detail");
        await appraisalpage.selectNewPurchaseRadioBtnCustomerDetail();
        expect(await appraisalpage.isPresentYearInputCustomerDetail()).toBeFalsy("Verify Year Input field is not present when selected 'New' Radio Button");
        expect(await appraisalpage.isPresentMakeInputCustomerDetail()).toBeTruthy("Verify Make Input field is present when selected 'New' Radio Button");
        expect(await appraisalpage.isPresentModelInputCustomerDetail()).toBeTruthy("Verify Model Input field is present when selected 'New' Radio Button");
        expect(await appraisalpage.isPresentTrimInputCustomerDetail()).toBeTruthy("Verify Trim Input field is present when selected 'New' Radio Button");
        expect(await appraisalpage.getMakeInputCustomerDetail()).toBe("ACURA","Verify Make value persist when select 'New' radion button");
        expect(await appraisalpage.getModelInputCustomerDetail()).toBe("MDX","Verify Model value persist when select 'New' radion button");
        expect(await appraisalpage.getTrimInputCustomerDetail()).toBe("ADVANCE 2WD 4 Door SUV 3.5L V6","Verify Trim value persist when select 'New' radion button");

        await utils.logInfo("Select 'Used' Purchase Radion button in Customer Detail");
        await appraisalpage.selectUsedPurchaseRadioBtnCustomerDetail();
        expect(await appraisalpage.isPresentYearInputCustomerDetail()).toBeTruthy("Verify Year Input field is present when selected 'Used' Radio Button");
        expect(await appraisalpage.isPresentMakeInputCustomerDetail()).toBeTruthy("Verify Make Input field is present when selected 'Used' Radio Button");
        expect(await appraisalpage.isPresentModelInputCustomerDetail()).toBeTruthy("Verify Model Input field is present when selected 'Used' Radio Button");
        expect(await appraisalpage.isPresentTrimInputCustomerDetail()).toBeTruthy("Verify Trim Input field is present when selected 'Used' Radio Button");
        expect(await appraisalpage.getYearInputCustomerDetail()).toBe("2017","Verify Year value persist when select 'Used' radion button");
        expect(await appraisalpage.getMakeInputCustomerDetail()).toBe("ACURA","Verify Make value persist when select 'Used' radion button");
        expect(await appraisalpage.getModelInputCustomerDetail()).toBe("MDX","Verify Model value persist when select 'Used' radion button");
        expect(await appraisalpage.getTrimInputCustomerDetail()).toBe("ADVANCE 2WD 4 Door SUV 3.5L V6","Verify Trim value persist when select 'Used' radion button");

        await appraisalpage.selectNotSurePurchaseRadioBtnCustomerDetail();
        expect(await appraisalpage.isPresentYearInputCustomerDetail()).toBeFalsy("Verify Year Input field is not present when selected 'Not Sure' Radio Button");
        expect(await appraisalpage.isPresentMakeInputCustomerDetail()).toBeFalsy("Verify Make Input field is not present when selected 'Not Sure' Radio Button");
        expect(await appraisalpage.isPresentModelInputCustomerDetail()).toBeFalsy("Verify Model Input field is not present when selected 'Not Sure' Radio Button");
        expect(await appraisalpage.isPresentTrimInputCustomerDetail()).toBeFalsy("Verify Trim Input field is not present when selected 'Not Sure' Radio Button");

        await utils.logInfo("Click on Replacement Vehicle 'No' Button");
        await appraisalpage.clickReplacementVehicleNoBtnCustomerDetail();

        await utils.logInfo("Click on Replacement Vehicle 'Yes' Button");
        await appraisalpage.clickReplacementVehicleYesBtnCustomerDetail();

        expect(await appraisalpage.getYearInputCustomerDetail()).toBe(null,"Verify 'Year' value doesn't persist when select Replacement Vehicle 'No' button and then 'Yes' again in Customer Detail Screen");
        expect(await appraisalpage.getMakeInputCustomerDetail()).toBe(null,"Verify 'Make' value doesn't persist when select Replacement Vehicle 'No' button and then 'Yes' again in Customer Detail Screen");
        expect(await appraisalpage.getModelInputCustomerDetail()).toBe(null,"Verify 'Model' value doesn't persist when select Replacement Vehicle 'No' button and then 'Yes' again in Customer Detail Screen");
        expect(await appraisalpage.getTrimInputCustomerDetail()).toBe(null,"Verify 'Trim' value doesn't persist when select Replacement Vehicle 'No' button and then 'Yes' again in Customer Detail Screen");

        await browser.waitForAngularEnabled(true); // *** Angular Disabled

    });//it    

    it('*** Customer Detail is not populated on newly created appraisals', async function () {
        utils.logInfo("***** TEST CASE : Customer Detail is not populated on newly created appraisals *****");

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   

        //Get Appraisal Menu
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await utils.logInfo("Open Appraisal Tools Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Verify 'Customer Information' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentCustomerInfoMenuItem()).toBeTruthy("Verify 'Customer Information' Menu item present in Appraisal Menu");

        //Customer Information
        await utils.logInfo("Click on Customer Information menu item");
        await appraisalpage.clickCustomerInfoMenuItem();
        expect(await appraisalpage.isPresentFirstNameLabelCustomerInfo()).toBeTruthy("Verify Customer Information screen displayed when user click on Customer Information link under Appraisal Tools Menu");
        
        expect(await appraisalpage.getFirstNameCustomerInfo()).toBe("","Verify First Name input is empty in Customer Information screen when creating new apprasial");
        expect(await appraisalpage.getLastNameCustomerInfo()).toBe("","Verify Last Name input is empty in Customer Information screen when creating new apprasial");
        expect(await appraisalpage.getZipCodeCustomerInfo()).toBe(null,"Verify Zip Code input is empty in Customer Information screen when creating new apprasial");
        expect(await appraisalpage.getPrimaryPhoneCustomerInfo()).toBe(null,"Verify Primary Phone input is empty in Customer Information screen when creating new apprasial");
        expect(await appraisalpage.getEmailAddressCustomerInfo()).toBe(null,"Verify Email Address input is empty in Customer Information screen when creating new apprasial");
        expect(await appraisalpage.getPriceDealerPurchasedFromCustomerInfo()).toBe("0","Verify 'Price Dealer Purchased from' input is empty in Customer Information screen when creating new apprasial");
        expect(await appraisalpage.getDealerOfferCustomerInfo()).toBe(null,"Verify 'Dealer Offer' input is empty in Customer Information screen when creating new apprasial");
        expect(await appraisalpage.getRedemptionCodeCustomerInfo()).toBe(null,"Verify 'Redemption Code' input is empty in Customer Information screen when creating new apprasial");
        expect(await appraisalpage.isSelectedOpenStatusBtnCustomerInfo()).toBeTruthy("Verify 'Open' status button is selected by default in Customer Information screen when creating new apprasial");
        expect(await appraisalpage.isSelectedWonStatusBtnCustomerInfo()).toBeFalsy("Verify 'Won' status button is not selected by default in Customer Information screen when creating new apprasial");
        expect(await appraisalpage.isSelectedLostStatusBtnCustomerInfo()).toBeFalsy("Verify 'Lost' status button is not selected by default in Customer Information screen when creating new apprasial");
        await browser.sleep(browser.params.sleep.sleep5);


    });//it    


    
    it('*** Customer Information/Details(2 test cases covered): all fields display and text can be entered/saved ', async function () {
        utils.logInfo("***** TEST CASE#1 : Customer Information: all fields display and text can be entered/saved *****");
        utils.logInfo("***** TEST CASE#2 : Appraisal Able to add & update Customer Info and all values are saved *****");
        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();
        var appraisalID = await appraisalpage.getAppraisalID();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   

        //Get Appraisal Menu
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await utils.logInfo("Open Appraisal Tools Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Verify 'Customer Information' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentCustomerInfoMenuItem()).toBeTruthy("Verify 'Customer Information' Menu item present in Appraisal Menu");

        //Customer Information
        await utils.logInfo("Click on Customer Information menu item");
        await appraisalpage.clickCustomerInfoMenuItem();
        expect(await appraisalpage.isPresentFirstNameLabelCustomerInfo()).toBeTruthy("Verify Customer Information screen displayed when user click on Customer Information link under Appraisal Tools Menu");

        //Enter numbers, letters and symbols in each field. (price fields only allow numbers, but all other fields allow anything to be entered)
        await utils.logInfo("Enter First Name in Customer Information screen");
        await appraisalpage.setFirstNameCustomerInfo("James");
        await utils.logInfo("Enter Last Name in Customer Information screen");
        await appraisalpage.setLastNameCustomerInfo("Bond");
        await utils.logInfo("Enter Zip Code in Customer Information screen");
        await appraisalpage.setZipCodeCustomerInfo("78758");
        await utils.logInfo("Enter Primary Phone in Customer Information screen");
        await appraisalpage.setPrimaryPhoneCustomerInfo("5123334444");
        await utils.logInfo("Enter Email Address in Customer Information screen");
        await appraisalpage.setEmailAddressCustomerInfo("jamesbond@accu-trade.com");
        await utils.logInfo("Enter 'Price Dealer Purchased From Customer' in Customer Information screen");
        await appraisalpage.setPriceDealerPurchasedFromCustomerInfo("price dealer purchase from customer");
        await utils.logInfo("Enter 'Dealer Offer' in Customer Information screen");
        await appraisalpage.setDealerOfferCustomerInfo("dealer offer price");
        await utils.logInfo("Enter 'Redemption Code' in Customer Information screen");
        await appraisalpage.setRedemptionCodeCustomerInfo("RC12345678901234567890123456789012345678901234567890");
        await utils.logInfo("Enter 'Status' in Customer Information screen");
        await appraisalpage.setStatusCustomerInfo("LOST");
        await utils.logInfo("Enter 'Lost Reason' in Customer Information screen");
        await appraisalpage.setLostReasonCustomerInfo("Sold Dealer");

        await utils.logInfo("Close the Customer Information screen");
        await appraisalpage.closeCustomerInfoScreen();
        
        await browser.waitForAngularEnabled(true); // *** Angular Enabled
        await utils.logInfo("Refresh Browser");
        await browser.refresh();
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        
        //Customer Information
        await utils.logInfo("Open Appraisal Tools Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Verify 'Customer Information' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentCustomerInfoMenuItem()).toBeTruthy("Verify 'Customer Information' Menu item present in Appraisal Menu");

        //Customer Information
        await utils.logInfo("Click on Customer Information menu item");
        await appraisalpage.clickCustomerInfoMenuItem();
        expect(await appraisalpage.isPresentFirstNameLabelCustomerInfo()).toBeTruthy("Verify Customer Information screen displayed when user click on Customer Information link under Appraisal Tools Menu");

        expect(await appraisalpage.getFirstNameCustomerInfo()).toBe("James","Verify First Name in Customer Information Screen");
        expect(await appraisalpage.getLastNameCustomerInfo()).toBe("Bond","Verify Last Name in Customer Information Screen");
        expect(await appraisalpage.getZipCodeCustomerInfo()).toBe("78758","Verify Zip Code in Customer Information Screen");
        expect(await appraisalpage.getPrimaryPhoneCustomerInfo()).toBe("5123334444","Verify Primary Phone Number in Customer Information Screen");
        expect(await appraisalpage.getEmailAddressCustomerInfo()).toBe("jamesbond@accu-trade.com","Verify Email Address in Customer Information Screen");
        expect(await appraisalpage.getPriceDealerPurchasedFromCustomerInfo()).toBe("0","Verify 'Price Dealer Purchased from Customer' in Customer Information Screen");
        expect(await appraisalpage.getDealerOfferCustomerInfo()).toBe(null,"Verify Dealer Offer Name in Customer Information Screen");
        expect(await appraisalpage.getRedemptionCodeCustomerInfo()).toContain("RC1234567890123456789012345678","Verify Redemption Code in Customer Information Screen");
        expect(await appraisalpage.getMaxLengthRedemptionCodeCustomerInfo()).toBe("50","Verify maximum length of Redemption Code in Customer Information Screen");
        expect(await appraisalpage.isSelectedOpenStatusBtnCustomerInfo()).toBeFalsy("Verify Open Status button selection in Customer Information Screen");
        expect(await appraisalpage.isSelectedWonStatusBtnCustomerInfo()).toBeFalsy("Verify Won Status button selection in Customer Information Screen");
        expect(await appraisalpage.isSelectedLostStatusBtnCustomerInfo()).toBeTruthy("Verify Lost Status button selection in Customer Information Screen");
        expect(await appraisalpage.getLostReasonCustomerInfo()).toBe("Sold Dealer","Verify Lost Reason in Customer Information Screen");
        await browser.sleep(browser.params.sleep.sleep5);

        //Edit
        await utils.logInfo("Enter First Name in Customer Information screen");
        await appraisalpage.setFirstNameCustomerInfo("Amit");
        await utils.logInfo("Enter Last Name in Customer Information screen");
        await appraisalpage.setLastNameCustomerInfo("Bhardwaj");
        await utils.logInfo("Enter Zip Code in Customer Information screen");
        await appraisalpage.setZipCodeCustomerInfo("78641");
        await utils.logInfo("Enter Primary Phone in Customer Information screen");
        await appraisalpage.setPrimaryPhoneCustomerInfo("5124445555");
        await utils.logInfo("Enter Email Address in Customer Information screen");
        await appraisalpage.setEmailAddressCustomerInfo("amit@accu-trade.com");
        await utils.logInfo("Enter 'Price Dealer Purchased From Customer' in Customer Information screen");
        await appraisalpage.setPriceDealerPurchasedFromCustomerInfo("13000");
        await utils.logInfo("Enter 'Dealer Offer' in Customer Information screen");
        await appraisalpage.setDealerOfferCustomerInfo("15000");
        await utils.logInfo("Enter 'Redemption Code' in Customer Information screen");
        await appraisalpage.setRedemptionCodeCustomerInfo("RC100");
        await utils.logInfo("Enter 'Status' in Customer Information screen");
        await appraisalpage.setStatusCustomerInfo("LOST");
        await utils.logInfo("Enter 'Lost Reason' in Customer Information screen");
        await appraisalpage.setLostReasonCustomerInfo("Sold Private");
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Close the Customer Information screen");
        await appraisalpage.closeCustomerInfoScreen();

        await browser.waitForAngularEnabled(true); // *** Angular Enabled
        await utils.logInfo("Refresh Browser");
        await browser.refresh();
        await browser.waitForAngularEnabled(false); // *** Angular Disabled
        
        //Customer Information
        await utils.logInfo("Open Appraisal Tools Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Verify 'Customer Information' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentCustomerInfoMenuItem()).toBeTruthy("Verify 'Customer Information' Menu item present in Appraisal Menu");

        //Customer Information
        await utils.logInfo("Click on Customer Information menu item");
        await appraisalpage.clickCustomerInfoMenuItem();
        expect(await appraisalpage.isPresentFirstNameLabelCustomerInfo()).toBeTruthy("Verify Customer Information screen displayed when user click on Customer Information link under Appraisal Tools Menu");

        expect(await appraisalpage.getFirstNameCustomerInfo()).toBe("Amit","Verify First Name in Customer Information");
        expect(await appraisalpage.getLastNameCustomerInfo()).toBe("Bhardwaj","Verify Last Name in Customer Information");
        expect(await appraisalpage.getZipCodeCustomerInfo()).toBe("78641","Verify Zip Code in Customer Information");
        expect(await appraisalpage.getPrimaryPhoneCustomerInfo()).toBe("5124445555","Verify Primary Phone in Customer Information");
        expect(await appraisalpage.getEmailAddressCustomerInfo()).toBe("amit@accu-trade.com","Verify Email Address in Customer Information");
        expect(await appraisalpage.getPriceDealerPurchasedFromCustomerInfo()).toBe("13000","Verify 'Price Dealer Purchased from Customer' in Customer Information");
        expect(await appraisalpage.getDealerOfferCustomerInfo()).toBe("15000","Verify 'Dealer Offer' in Customer Information screen");
        expect(await appraisalpage.getRedemptionCodeCustomerInfo()).toContain("RC100","Verify 'Redemption Code' in Customer Information screen");
        expect(await appraisalpage.getMaxLengthRedemptionCodeCustomerInfo()).toBe("50","Verify Maximum length of Redemption Code in Customer Information screen");
        expect(await appraisalpage.isSelectedOpenStatusBtnCustomerInfo()).toBeFalsy("Verify Open button status in Customer Information screen");
        expect(await appraisalpage.isSelectedWonStatusBtnCustomerInfo()).toBeFalsy("Verify Won button status in Customer Information screen");
        expect(await appraisalpage.isSelectedLostStatusBtnCustomerInfo()).toBeTruthy("Verify Lost button status in Customer Information screen");
        expect(await appraisalpage.getLostReasonCustomerInfo()).toBe("Sold Private","Verify Lost Reason in Customer Information screen");

        await utils.logInfo("Close the Customer Information screen");
        await appraisalpage.closeCustomerInfoScreen();

        //Consumer Mode
        await utils.logInfo("Click on Consumer mode button on Appraisal Page");
        await appraisalpage.clickAppraisalConsumerDealerMode();

        expect(await appraisalpage.getFirstNameConsumerModeCustomerDetail()).toBe("Amit","Verify First Name in Customer Detail section on Appraisal in Consumer mode");
        expect(await appraisalpage.getLastNameConsumerModeCustomerDetail()).toBe("Bhardwaj","Verify Last Name in Customer Detail section on Appraisal in Consumer mode");
        expect(await appraisalpage.getPhoneConsumerModeCustomerDetail()).toBe("5124445555","Verify Phone Number in Customer Detail section on Appraisal in Consumer mode");
        expect(await appraisalpage.getZipCodeConsumerModeCustomerDetail()).toBe("78641","Verify Zip Code in Customer Detail section on Appraisal in Consumer mode");
        expect(await appraisalpage.getEmailConsumerModeCustomerDetail()).toBe("amit@accu-trade.com","Verify Email Address in Customer Detail section on Appraisal in Consumer mode");

        await browser.waitForAngularEnabled(true); // *** Angular Enabled
        await utils.logInfo("Refresh Browser");
        await browser.refresh();
        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        await utils.logInfo("Click on Consumer mode button on Appraisal Page");
        await appraisalpage.clickAppraisalConsumerDealerMode();
        
        expect(await appraisalpage.getFirstNameConsumerModeCustomerDetail()).toBe("Amit","Verify First Name in Customer Detail section on Appraisal in Consumer mode");
        expect(await appraisalpage.getLastNameConsumerModeCustomerDetail()).toBe("Bhardwaj","Verify Last Name in Customer Detail section on Appraisal in Consumer mode");
        expect(await appraisalpage.getPhoneConsumerModeCustomerDetail()).toBe("5124445555","Verify Phone Number in Customer Detail section on Appraisal in Consumer mode");
        expect(await appraisalpage.getZipCodeConsumerModeCustomerDetail()).toBe("78641","Verify Zip Code in Customer Detail section on Appraisal in Consumer mode");
        expect(await appraisalpage.getEmailConsumerModeCustomerDetail()).toBe("amit@accu-trade.com","Verify Email Address in Customer Detail section on Appraisal in Consumer mode");

        //Edit
        await appraisalpage.setFirstNameConsumerModeCustomerDetail("AmitEdited");
        await appraisalpage.setLastNameConsumerModeCustomerDetail("BhardwajEdited");
        await appraisalpage.setPhoneConsumerModeCustomerDetail("1234567890");
        await appraisalpage.setZipCodeConsumerModeCustomerDetail("20165");
        await appraisalpage.setEmailConsumerModeCustomerDetail("amitedited@accu-trade.com");
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.waitForAngularEnabled(true); // *** Angular Enabled
        await utils.logInfo("Refresh Browser");
        await browser.refresh();
        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        await utils.logInfo("Click on Consumer mode button on Appraisal Page");
        await appraisalpage.clickAppraisalConsumerDealerMode();

        expect(await appraisalpage.getFirstNameConsumerModeCustomerDetail()).toBe("AmitEdited","Verify First Name in Customer Detail section on Appraisal in Consumer mode");
        expect(await appraisalpage.getLastNameConsumerModeCustomerDetail()).toBe("BhardwajEdited","Verify Last Name in Customer Detail section on Appraisal in Consumer mode");
        expect(await appraisalpage.getPhoneConsumerModeCustomerDetail()).toBe("1234567890","Verify Phone Number in Customer Detail section on Appraisal in Consumer mode");
        expect(await appraisalpage.getZipCodeConsumerModeCustomerDetail()).toBe("20165","Verify Zip Code in Customer Detail section on Appraisal in Consumer mode");
        expect(await appraisalpage.getEmailConsumerModeCustomerDetail()).toBe("amitedited@accu-trade.com","Verify Email Address in Customer Detail section on Appraisal in Consumer mode");
        await browser.sleep(browser.params.sleep.sleep5);

        //Customer Information
        await utils.logInfo("Open Appraisal Tools Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Verify 'Customer Information' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentCustomerInfoMenuItem()).toBeTruthy("Verify 'Customer Information' Menu item present in Appraisal Menu");

        //Customer Information
        await utils.logInfo("Click on Customer Information menu item");
        await appraisalpage.clickCustomerInfoMenuItem();
        expect(await appraisalpage.isPresentFirstNameLabelCustomerInfo()).toBeTruthy("Verify Customer Information screen displayed when user click on Customer Information link under Appraisal Tools Menu");

        expect(await appraisalpage.getFirstNameCustomerInfo()).toBe("AmitEdited","Verify First Name in Customer Information");
        expect(await appraisalpage.getLastNameCustomerInfo()).toBe("BhardwajEdited","Verify Last Name in Customer Information");
        expect(await appraisalpage.getZipCodeCustomerInfo()).toBe("20165","Verify Zip Code in Customer Information");
        expect(await appraisalpage.getPrimaryPhoneCustomerInfo()).toBe("1234567890","Verify Primary Phone in Customer Information");
        expect(await appraisalpage.getEmailAddressCustomerInfo()).toBe("amitedited@accu-trade.com","Verify Email Address in Customer Information");
        expect(await appraisalpage.getPriceDealerPurchasedFromCustomerInfo()).toBe("13000","Verify 'Price Dealer Purchased from Customer' in Customer Information");
        expect(await appraisalpage.getDealerOfferCustomerInfo()).toBe("15000","Verify 'Dealer Offer' in Customer Information");
        expect(await appraisalpage.getRedemptionCodeCustomerInfo()).toContain("RC100","Verify 'Redemption Code' in Customer Information");
        expect(await appraisalpage.getMaxLengthRedemptionCodeCustomerInfo()).toBe("50","Verify maximum legth of Redemption Code in Customer Information");
        expect(await appraisalpage.isSelectedOpenStatusBtnCustomerInfo()).toBeFalsy("Verify Open button status in Customer Information");
        expect(await appraisalpage.isSelectedWonStatusBtnCustomerInfo()).toBeFalsy("Verify Won button status in Customer Information");
        expect(await appraisalpage.isSelectedLostStatusBtnCustomerInfo()).toBeTruthy("Verify Lost button status in Customer Information");
        expect(await appraisalpage.getLostReasonCustomerInfo()).toBe("Sold Private","Verify 'Lost Reason' in Customer Information");

        await utils.logInfo("Close the Customer Information screen");
        await appraisalpage.closeCustomerInfoScreen();

        await browser.waitForAngularEnabled(true); // *** Angular Disabled
        
        //Get Homepage
        await utils.logInfo("Getting home page");
        await homepage.get();
        
        //Search Appraisal ID
        await utils.logInfo("Search Appraisal by Appraisal ID");
        await homepage.searchAppraisalList(appraisalID);
        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        await browser.sleep(browser.params.sleep.sleep5);
        //await browser.waitForAngularEnabled(false); // *** Angular Disabled

        expect(await homepage.getDispositionValueAppraisalList()).toBe("lost","Verify Disposition value is Lost");
        expect(await homepage.getDispositionColorAppraisalList()).toBe("red","Verify Disposition color is Red");

        //appraisalID

        await browser.waitForAngularEnabled(true); // *** Angular Enabled

    }); //it


}); //describe    