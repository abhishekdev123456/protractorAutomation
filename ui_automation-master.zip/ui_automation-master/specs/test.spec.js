var loginpage = require('../pages/login.page');
var verifymobilenumberpage = require('../pages/verifymobilenumber.page');
var homepage = require('../pages/home.page');
var myaccountpage = require('../pages/myaccount.page');
var myprofilepage = require('../pages/myprofile.page');
var appraisalpage = require('../pages/appraisal.page');
var usermgmtpage = require('../pages/usermanagement.page');
var edituserpage = require('../pages/edituser.usermgmt.page');
var dealerconsolepage = require('../pages/dealer.console.page');
var dealershippage = require('../pages/dealership.page');
var recommenderpage = require('../pages/recommender.page');
var dealershippage = require('../pages/dealership.page');
var crpage = require('../pages/cr.page');
var utils = require('../utilities/utils');
var testdata = require('../data/test.data.js');
var using = require('jasmine-data-provider');

describe('Smoke Authentication Test Suite', function () { // ********************** Describe *******************************
    beforeAll(function(){
        utils.logInfo("ENVIRONMENT IS "+browser.params.env.url);

    });

    var count = 0;
    beforeEach(async function () {
        //await utils.logInfo("Start beforEach():loginpage.get() - Navigate to Login page");
        await loginpage.get();
        await browser.getCurrentUrl().then(async function (url) {
            if (url != await loginpage.getForceURL()) {
                await homepage.navigateThroughMenu("Log Out");
                await loginpage.get();
            }
        });

        //await utils.logInfo("End beforEach():loginpage.get() - Navigate to Login page");
        await browser.waitForAngularEnabled(true);
    });

    afterEach(async function () {
        //await utils.logInfo("Start afterEach():navigateThroughMenu('Log Out')");
        await homepage.navigateThroughMenu("Log Out");
        //await utils.logInfo("End afterEach():navigateThroughMenu('Log Out')");
    });


    it('Verify log on/out/on by :' + browser.params.login.superadminuser, async function () {
        utils.logInfo("PLATFORM IS "+await utils.getPlatformName());

        // browser.getCapabilities().then(function(c) {
        //     utils.logInfo("Platform is c.get('platformName') = "+c.get('platformName'));
        //     utils.logInfo("Platform2 is c.get('platform') = "+c.get('platform'));

        //     console.log(c);
        // });

        utils.logInfo("***** TEST CASE : Verify log on/out/on by "+browser.params.login.superadminuser+" *****");

        await utils.logInfo("Set Valid User Name: " + browser.params.login.superadminuser);
        await loginpage.setUsername(browser.params.login.superadminuser);

        await utils.logInfo("Set Valid Password: " + browser.params.login.superadminpassword);
        await loginpage.setPassword(browser.params.login.superadminpassword);

        await utils.logInfo("Click SignIn Button");
        await loginpage.clickSignIn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        if(count == 0){
            await homepage.closeAllWalkme();
            count = 1;
        }//if count

        await browser.sleep(browser.params.sleep.sleep5);
        //await browser.waitForAngularEnabled(false); //changed

        expect(await homepage.isPresentStartAppraisalBtn()).toBeTruthy("Verify the Start Appraisal button is present"); // *** Assertion 


        await browser.sleep(browser.params.sleep.sleep5);
        await browser.waitForAngularEnabled(true);

        await utils.logInfo("Navigate to My Account Page");
        await homepage.navigateThroughMenu("My Account");

        await browser.sleep(browser.params.sleep.sleep5);
        await browser.waitForAngularEnabled(false);

        utils.logInfo("Verifying user email in My Account Page");
        var emailMyAccountPage = await myaccountpage.getEmail();
        await expect(emailMyAccountPage.toLowerCase()).toContain(browser.params.login.superadminuser.toLowerCase(),"Verify the email address in My Account page");
        //await browser.sleep(browser.params.sleep.sleep5);
        await browser.waitForAngularEnabled(true);

    });//it

}); //describe