

var loginpage = require('../pages/login.page');
var verifymobilenumberpage = require('../pages/verifymobilenumber.page');
var homepage = require('../pages/home.page');
var utils = require('../utilities/utils');

describe('Login',function(){

    beforeEach(async function() {
        await utils.logInfo("Navigate to Login page");
        await loginpage.get();
    });
    
    xit('With Valid Username and Invalid Password',async function(){
        await utils.logInfo("Set Valid User Name: "+browser.params.login.validuser);
        await loginpage.setUsername(browser.params.login.validuser);
        
        await utils.logInfo("Set Invalid Password: "+browser.params.login.invalidpassword);
        await loginpage.setPassword(browser.params.login.invalidpassword);
        
        await utils.logInfo("Click Sigin Button");
        await loginpage.clickSignIn();

        await utils.logInfo("Validate an error message for Invalid password");
        await expect(loginpage.getLoginError()).toBe(browser.params.login.errormessage);
    });

    xit('With Invalid Username and Valid Password',async function(){
        await utils.logInfo("Set Invalid User Name: "+browser.params.login.invaliduser);
        await loginpage.setUsername(browser.params.login.validuser);
        
        await utils.logInfo("Set Valid Password: "+browser.params.login.validpassword);
        await loginpage.setPassword(browser.params.login.invalidpassword);
        
        await utils.logInfo("Click SigIn Button");
        await loginpage.clickSignIn();

        await utils.logInfo("Validate an error message for Invalid user");
        await expect(loginpage.getLoginError()).toBe(browser.params.login.errormessage);
    });


    xit('With Valid Username and Password',async function(){
        await utils.logInfo("Set Valid User Name: "+browser.params.login.validuser);
        await loginpage.setUsername(browser.params.login.validuser);

        await utils.logInfo("Set Valid Password: "+browser.params.login.validpassword);
        await loginpage.setPassword(browser.params.login.validpassword);
        
        await utils.logInfo("Click SignIn Button");
        await loginpage.clickSignIn();

        await browser.waitForAngular();

        
        await browser.getCurrentUrl().then(async function(url){
            if(url == await verifymobilenumberpage.getUrl()){
                await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        })

        await browser.waitForAngular();        
        
        await utils.logInfo("Click Start Apprisal Button");
        await homepage.clickStartAppraisalBtn();
        
        await utils.logInfo("Enter VIN "+browser.params.vin.validvin+" into New Appraisal Window");
        await homepage.setVin(browser.params.vin.validvin);
        
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();
       
        await utils.logInfo("Before WaitforAngular");

        await utils.logInfo("Sleeping for "+browser.params.sleep.sleep10);       
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");        
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is "+sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin); //*** Assertion ***/
    });

    
    
    xit('Go to My Account',async function(){
        await utils.logInfo("Navigate to Home Page");
        await homepage.get();

        await utils.logInfo("Navigate to My Account Page");
        await homepage.getMyAccount();

        await browser.sleep(browser.params.sleep.sleep10);
    });

    xit('With Another Valid Username and Password',async function(){
        //await utils.logInfo("Set Valid User Name: "+browser.params.login.validuser);
        //await loginpage.setUsername(browser.params.login.validuser);

        //await utils.logInfo("Set Valid Password: "+browser.params.login.validpassword);
        //await loginpage.setPassword(browser.params.login.validpassword);
        
        //await utils.logInfo("Click SignIn Button");
        //await loginpage.clickSignIn();

        //await browser.waitForAngular();

        
        // await browser.getCurrentUrl().then(async function(url){
        //     if(url == await verifymobilenumberpage.getUrl()){
        //         await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
        //         await utils.logInfo("Click Remind me on Verify Mobile Number Page");
        //         await verifymobilenumberpage.clickRemindme();
        //     }
        // })

        //await browser.waitForAngular();        
        
        await utils.logInfo("Click Start Apprisal Button");
        await homepage.clickStartAppraisalBtn();
        
        await utils.logInfo("Enter VIN "+browser.params.vin.validvin+" into New Appraisal Window");
        await homepage.setVin(browser.params.vin.validvin);
        
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();
       
        await utils.logInfo("Before WaitforAngular");

        await utils.logInfo("Sleeping for "+browser.params.sleep.sleep10);       
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");        
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is "+sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin); //*** Assertion ***/

    });

    xit('With Another Valid Username and Password',async function(){
        await utils.logInfo("Navigate to Home Page");        
        //await homepage.get();
        //await browser.get("https://hercules-qa.accu-trade.com/auth/login?force=true");

        await utils.logInfo("Click Start Apprisal Button");
        await homepage.clickStartAppraisalBtn();

        await utils.logInfo("Before Sleep");                
        await browser.sleep(browser.params.sleep.sleep20);
        await utils.logInfo("After Sleep");                


        await utils.logInfo("Disable Angular");                
        await browser.waitForAngular(false);
        //await browser.sleep(browser.params.sleep.sleep10);
        //expect(await homepage.getAllAppraisalsLabel()).toEqual('All Appraisals');//*** Assertion ***/
        
        //await homepage.clickStartAppraisalBtn();
        //await browser.sleep(browser.params.sleep.sleep10);

        //await utils.logInfo("Disable Wait for Angular");
        //await browser.waitForAngularEnabled(false); // *** Angular Enabled False
        
        
        //await browser.waitForAngular();
        //await utils.logInfo("Before Sleep!!!");
        //await browser.sleep(browser.params.sleep.sleep10);
        //await utils.logInfo("After Sleep!!!");
        
        //await utils.logInfo(await browser.driver.switchTo().activeElement().getText());
        //await browser.driver.switchTo().defaultContent();
        //await utils.logInfo("After default content!!!");
        //await utils.logInfo(await browser.driver.switchTo().activeElement().getText());

        //var tx = element(by.xpath("//input[@formcontrolname='vinInput']"));
        //await utils.logInfo(await tx.isPresent());
        //await utils.logInfo("After Clicking Start Appraisal Button");


        
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Enter VIN "+browser.params.vin.validvin+" into New Appraisal Window");
        await homepage.setVin(browser.params.vin.validvin);

        await browser.sleep(browser.params.sleep.sleep10);
        
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();
       

        await utils.logInfo("Sleeping for "+browser.params.sleep.sleep10);       
        await browser.sleep(browser.params.sleep.sleep10);

        //await utils.logInfo("Disable Wait for Angular");
        //await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");        
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is "+sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin); //*** Assertion ***/
        
    });

});