var loginpage = require('../pages/login.page');
var verifymobilenumberpage = require('../pages/verifymobilenumber.page');
var homepage = require('../pages/home.page');
var myaccountpage = require('../pages/myaccount.page');
var myprofilepage = require('../pages/myprofile.page');
var appraisalpage = require('../pages/appraisal.page');
var usermgmtpage = require('../pages/usermanagement.page');
var edituserpage = require('../pages/edituser.usermgmt.page');
var dealerconsolepage = require('../pages/dealer.console.page');
var dealershippage = require('../pages/dealership.page');
var recommenderpage = require('../pages/recommender.page');
var dealershippage = require('../pages/dealership.page');
var crpage = require('../pages/cr.page');
var utils = require('../utilities/utils');
var testdata = require('../data/test.data.js');
var using = require('jasmine-data-provider');
var path = require("path");

describe('Pricing Test Suite', function () { // ********************** Describe1 *******************************
    browser.manage().timeouts().implicitlyWait(5000);
    browser.driver.manage().window().maximize();
    utils.logInfo("Pricing Test Suite");
    var count = 0;
    
    beforeEach(async function () {
        await utils.logInfo("Getting Home Page")
        await homepage.get();
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.getCurrentUrl().then(async function (url) {
            await utils.logInfo("Before each : Current Url is "+url);
            await browser.sleep(browser.params.sleep.sleep5);

            if (url == await loginpage.getURL()) {
                utils.logInfo("Sign in since current page is Login page")
                await loginpage.signIn(browser.params.login.superadminuser, browser.params.login.superadminpassword);
                await browser.getCurrentUrl().then(async function (url) {
                    if (url == await verifymobilenumberpage.getUrl()) {
                        await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                        await verifymobilenumberpage.clickRemindme();
                    }//if
                })//then
            }//if
            else if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
            await browser.waitForAngularEnabled(true);

        });

        if(count == 0){
            await homepage.closeAllWalkme();
            count = 1;
        }//if count

    }); //beforeEach    

    afterEach(async function () {
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True
    });    

    using(testdata.pricing, function (data, description) {
        var symmt = data.year+"-"+data.make+"-"+data.model+"-"+data.trim;
        it('Verify Pricing for '+description+'::'+data.mainadjustment+':'+data.adjustment+':'+data.category+':'+data.subcategory+':'+data.vin+':'+symmt, async function () {
            utils.logInfo('***** TEST CASE : Verify Pricing for ' +data.mainadjustment+':'+data.adjustment+':'+data.category+':'+data.subcategory);
            await browser.refresh();
            await utils.logInfo("Click Start Appraisal Button");
            await homepage.clickStartAppraisalBtn();
            
            await browser.getCurrentUrl().then(async function (url) {
                await utils.logInfo("Before each : Current Url is "+url);
                await browser.sleep(browser.params.sleep.sleep5);
    
                if (url == await verifymobilenumberpage.getUrl()) {
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            });

            if(data.appraisal == 'ymmt'){
                await browser.waitForAngularEnabled(false);

                await utils.logInfo("Click new Appraisal YMMT Tab");
                await homepage.clickNewAppraisalYMMT();
    
                //await browser.sleep(browser.params.sleep.sleep5);
                await utils.logInfo("Select Year in YMMT Tab");
                await homepage.selectYearNewAppraisalYMMT(data.year);
                //await browser.sleep(browser.params.sleep.sleep5);
                //await browser.waitForAngularEnabled(false);
                await utils.logInfo("Select Make in YMMT Tab");
                await homepage.selectMakeNewAppraisalYMMT(data.make);
    
                //await browser.sleep(browser.params.sleep.sleep5);
                await utils.logInfo("Select Model in YMMT Tab");
                await homepage.selectModelNewAppraisalYMMT(data.model);
    
                //await browser.sleep(browser.params.sleep.sleep5);
                await utils.logInfo("Select Trim in YMMT Tab");
                await homepage.selectTrimNewAppraisalYMMT(data.trim);
    
                await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
                await browser.sleep(browser.params.sleep.sleep10);
    
                await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
                var sYMM = await appraisalpage.getAppraisalYMM();
                var sTrim = await appraisalpage.getAppraisalTrim();
                var expectedYMM = data.year+" "+data.make+" "+data.model;
    
                //await utils.logInfo("Enable Wait for Angular");
                //await browser.waitForAngularEnabled(true); // *** Angular Enabled True
                await utils.logInfo("Value of new Appraisal Year Make Model is " + sYMM);
                await utils.logInfo("Value of new Appraisal Trim is " + sTrim);
                await utils.logInfo("Value of expected YMM is " + expectedYMM);

                await utils.logInfo("Verify Appraisal Year Make Model matching expected YMM");
                await expect(await sYMM).toContain(expectedYMM,"Verify Appraisal Year Make Model matching expected YMM on Appraisal Page"); //*** Assertion ***/
                await utils.logInfo("Verify Appraisal Trim matching expected trim");
                await expect(await sTrim).toContain(data.trim,"Verify Appraisal Trim matching expected trim on Appraisal Page"); //*** Assertion ***/
            }
            else{
                await homepage.clickNewAppraisalVINTab();
                await utils.logInfo("Enter VIN " + data.vin + " into New Appraisal Window");
                var EC = protractor.ExpectedConditions;
                browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
                await homepage.setVin(data.vin);
                await utils.logInfo("Click on the VIN Search button");
                await homepage.clickVinSearch();
         
                await utils.logInfo("Click on First Trim");
                await homepage.clickFirstTrim();
                await browser.sleep(browser.params.sleep.sleep10);
    
                await utils.logInfo("Disable Wait for Angular");
                await browser.waitForAngularEnabled(false); // *** Angular Enabled False
    
    
                await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
                var sVIN = await homepage.getAppraisalVIN();
         
                await utils.logInfo("Value of Appraisal VIN is " + sVIN);
                await utils.logInfo("Verify Appraisal VIN matching expected VIN");
                expect(sVIN).toContain(data.vin,"Verify VIN value on Appraisal page matches expected VIN from test data"); //*** Assertion ***/
    
            }

            var appraisalYMM = await appraisalpage.getAppraisalYMM();
            await utils.logInfo("Value of Appraisal YMM is " + appraisalYMM);
            await utils.logInfo("After YMMT validation ");
            await browser.sleep(browser.params.sleep.sleep10);

            utils.logInfo("Appraisal Offer Price value without adjustment is "+await appraisalpage.getOfferValuePriceBar());
            utils.logInfo("Appraisal Target Auction value without adjustment is "+await appraisalpage.getTargetAuctionValuePriceBar());
            utils.logInfo("Appraisal Target Retail value without adjustment is "+await appraisalpage.getTargetRetailValuePriceBar());
            expect(await appraisalpage.getOfferValuePriceBar()).toBe(data.offerprice,"Verify Offer Price on Appraisal page Price Bar matches expected value 'Before Adjustment'");
            expect(await appraisalpage.getTargetAuctionValuePriceBar()).toBe(data.targetauction,"Verify Target Auction value on Appraisal page Price Bar matches expected value 'Before Adjustment'");
            expect(await appraisalpage.getTargetRetailValuePriceBar()).toBe(data.targetretail,"Verify Traget Retail value on Appraisal page Price Bar matches expected value 'Before Adjustment'");

            //Select Adjustment Appraisal Screen
            await appraisalpage.selectAdjustmentAppraisalScreen(data.mainadjustment,data.adjustment,data.category,data.subcategory);
            
            //Assert Adjustment Appraisal Screen
            await utils.logInfo("Before assertAppraisalScreenValues");
            await appraisalpage.assertAppraisalScreenValues(data.mainadjustment,data.adjustment,data.category,data.subcategory,data.vin, data.offerprice, data.targetauction, data.targetretail, data.adjustmentvalue, data.finalofferprice, data.finaltargetauction, data.finaltargetretail);
            await utils.logInfo("After assertAppraisalScreenValues");
    
            await browser.sleep(browser.params.sleep.sleep10);

            await utils.logInfo("Appraisal Base Offer Price value is "+await appraisalpage.getOfferValuePriceBar());
            await utils.logInfo("Appraisal Target Auction value is "+await appraisalpage.getTargetAuctionValuePriceBar());
            await utils.logInfo("Appraisal Target Retail value is "+await appraisalpage.getTargetRetailValuePriceBar());
            expect(await appraisalpage.getOfferValuePriceBar()).toBe(data.finalofferprice,"Verify Base Price on Appraisal page matches expected value 'After Adjustment' selection of '"+description+"'");
            expect(await appraisalpage.getTargetAuctionValuePriceBar()).toBe(data.finaltargetauction,"Verify Target Auction Value on Appraisal page matches expected value 'After Adjustment' selection of '"+description+"'");
            expect(await appraisalpage.getTargetRetailValuePriceBar()).toBe(data.finaltargetretail,"Verify Traget Retail Value on Appraisal page matches expected value 'After Adjustment' selection of '"+description+"'");

            //Get Consumer CR Through Appraisal Menu
            await utils.logInfo("Get Appraisal Menu");
            await appraisalpage.getAppraisalMenu();
            await utils.logInfo("Verify 'Consumer Appraisal' Menu item present in Appraisal Menu");
            expect(await appraisalpage.isPresentConsumerAppraisalMenuItem()).toBeTruthy("Verify 'Consumer Appraisal' Menu item present in Appraisal Menu"); //Assertion
            
            await utils.logInfo("Click on Consumer Appraisal Report menu item");
            await appraisalpage.clickConsumerAppraisalMenuItem();
            await browser.sleep(browser.params.sleep.sleep10);
            await utils.logInfo("Verifying the loaded page is Consumer CR");
            expect(await browser.getCurrentUrl()).toContain("/report?type=consumer","Verify clicking on Consumer Appraisal Report link under Appraisal menu opens the Consumer CR page");//Assertion

            await browser.sleep(browser.params.sleep.sleep5);
            var crVehicleInfo = await crpage.getCRVehicleInfo();
            await utils.logInfo("CR Vehicle Info is " + crVehicleInfo);
            await browser.sleep(browser.params.sleep.sleep5);
            expect(await crVehicleInfo).toContain(appraisalYMM,"Verify Appraisal YMM in Consumer CR matches with YMM listed on Appraisal Page"); //*** Assertion ***/
            
            //Assert Consumer CR
            await crpage.assertCR('consumer',data.mainadjustment,data.adjustment,data.category,data.subcategory,data.vin, data.offerprice, data.targetauction, data.targetretail, data.adjustmentvalue, data.finalofferprice, data.finaltargetauction, data.finaltargetretail);
            await utils.logInfo("Value of CR Consumer Offer price is "+await crpage.getConsumerCROfferValue());
            await utils.logInfo("crpage.getConsumerCROfferValue() = "+await crpage.getConsumerCROfferValue());
            var crOfferValue = await crpage.getConsumerCROfferValue();
            crOfferValue = utils.replaceDollarCommaInString(crOfferValue);
            expect(crOfferValue).toBe(data.finalofferprice,"Verify Consumer CR page Offer Price matches expected value 'After Adjustment'");

            //Back to Appraisal
            await utils.logInfo("Click on Back to Appraisal Link");
            await crpage.clickBackToAppraisalLink();
            await browser.sleep(browser.params.sleep.sleep5);

            //Get Dealer CR Through Appraisal Menu
            await utils.logInfo("Get Appraisal Menu");
            await appraisalpage.getAppraisalMenu();        
            await utils.logInfo("Verify 'Dealership Appraisal' Menu item present in Appraisal Menu");
            expect(await appraisalpage.isPresentDealershipAppraisalMenuItem()).toBeTruthy("Verify 'Dealer Condition Report' Menu item present in Appraisal Menu");
            
            await utils.logInfo("Click on Dealer Condition Report menu item");
            await appraisalpage.clickDealerAppraisalMenuItem();
            await browser.sleep(browser.params.sleep.sleep10);
            await utils.logInfo("Verifying the loaded page is Dealer CR");
            expect(await browser.getCurrentUrl()).toContain("/report?type=dealer","Verify clicking on Dealer Condition Report link under Appraisal menu opens the Dealer CR page"); //Assertion
                    
            await browser.sleep(browser.params.sleep.sleep5);
            var crVehicleInfo = await crpage.getCRVehicleInfo();
            await utils.logInfo("CR Vehicle Info is " + crVehicleInfo);
            await browser.sleep(browser.params.sleep.sleep5);
            expect(await crVehicleInfo).toContain(appraisalYMM,"Verify Appraisal YMM in Dealer CR matches with YMM listed on Appraisal Page"); //*** Assertion ***/

            await utils.logInfo("Value of CR Dealer Offer price is "+await crpage.getDealerCROfferValue());
            await crpage.assertCR('dealer',data.mainadjustment,data.adjustment,data.category,data.subcategory,data.vin, data.offerprice, data.targetauction, data.targetretail, data.adjustmentvalue, data.finalofferprice, data.finaltargetauction, data.finaltargetretail);

            await utils.logInfo("Verify the Dealer Offer value is "+data.finalofferprice);
            expect(await crpage.getDealerCROfferValue()).toBe(data.finalofferprice,"Verify Dealer CR page Offer Price matches expected value 'After Adjustment'");
            await utils.logInfo("Verify the Dealer Auction value is "+data.finaltargetauction);
            expect(await crpage.getDealerCRAuctionValue()).toBe(data.finaltargetauction,"Verify Dealer CR page Auction value matches expected value 'After Adjustment'");
            await utils.logInfo("Verify the Dealer Retail value is "+data.finaltargetretail);
            expect(await crpage.getDealerCRRetailValue()).toBe(data.finaltargetretail,"Verify Dealer CR page Target Retail value matches expected value 'After Adjustment'");

            //Back to Appraisal
            await utils.logInfo("Click on Back to Appraisal link");
            await crpage.clickBackToAppraisalLink();
            await browser.sleep(browser.params.sleep.sleep5);

            //Get Appraisal ID and then get Appraisal Screen
            var appraisalID = await appraisalpage.getAppraisalID();
            await utils.logInfo("Appraisal page Appraisal ID is "+appraisalID);
            await browser.waitForAngularEnabled(true); // *** Angular Enabled True
            await appraisalpage.getAppraisalByID(appraisalID);
            await browser.waitForAngularEnabled(false); // *** Angular Enabled False

            //Get Review and Send
            await utils.logInfo("Collapse 'Select Action'");
            await appraisalpage.clickSelectAction();

            await utils.logInfo("Value of Base Amount in Review & Send section is "+await appraisalpage.getBasePriceReviewSendScreen());
            await utils.logInfo("Value of Offer Amount in Review & Send section is "+await appraisalpage.getOfferAmountReviewSendScreen());
            var basePriceReviewSend = await appraisalpage.getBasePriceReviewSendScreen();
            basePriceReviewSend = utils.replaceDollarCommaInString(basePriceReviewSend);

            var offerAmountReviewSend = await appraisalpage.getOfferAmountReviewSendScreen();
            offerAmountReviewSend = utils.replaceDollarCommaInString(offerAmountReviewSend);

            expect(basePriceReviewSend).toBe(data.baseprice,"Verify Review & Send section Base price matches expected value 'After Adjustment'") ;
            expect(offerAmountReviewSend).toBe(data.finalofferprice,"Verify Review & Send section Offer price matches expected value 'After Adjustment'");

            await utils.logInfo("assertReviewSendScreen");
            await appraisalpage.assertReviewSendScreen(data.mainadjustment,data.adjustment,data.category,data.subcategory,data.vin, data.offerprice, data.targetauction, data.targetretail, data.adjustmentvalue, data.finalofferprice, data.finaltargetauction, data.finaltargetretail);

            await utils.logInfo("Click on View Condition Report in Review and Send Screen");
            await appraisalpage.clickConditionReportReviewSendScreen();

            await browser.getCurrentUrl().then(async function (url) {
                await utils.logInfo("Current Url is "+url);
                await browser.sleep(browser.params.sleep.sleep5);
                if (url == await verifymobilenumberpage.getUrl()) {
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }    
            });
            

            await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        });//it
    }); //using        
    
}); //describe    