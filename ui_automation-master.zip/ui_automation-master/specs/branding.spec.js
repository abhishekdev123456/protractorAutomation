var loginpage = require('../pages/login.page');
var verifymobilenumberpage = require('../pages/verifymobilenumber.page');
var homepage = require('../pages/home.page');
var myaccountpage = require('../pages/myaccount.page');
var myprofilepage = require('../pages/myprofile.page');
var appraisalpage = require('../pages/appraisal.page');
var usermgmtpage = require('../pages/usermanagement.page');
var edituserpage = require('../pages/edituser.usermgmt.page');
var dealerconsolepage = require('../pages/dealer.console.page');
var dealershippage = require('../pages/dealership.page');
var recommenderpage = require('../pages/recommender.page');
var dealershippage = require('../pages/dealership.page');
var crpage = require('../pages/cr.page');
var perseuspage = require('../pages/perseus.page');
var utils = require('../utilities/utils');
var testdata = require('../data/test.data.js');
var using = require('jasmine-data-provider');
var path = require("path");
var faker = require("faker");

// describe('Branding Test Suite', function () { // ********************** Describe1 *******************************
//     browser.manage().timeouts().implicitlyWait(5000);
//     browser.driver.manage().window().maximize();
//     utils.logInfo("TEST SUITE: Branding");
//     utils.logInfo("TEST RUN : "+"https://autodevteam.testrail.net/index.php?/runs/view/883&group_by=cases:section_id&group_order=asc");
//     var count = 0;
    
//     beforeEach(async function () {
//         await utils.logInfo("Getting Home Page")
//         await homepage.get();
//         await browser.sleep(browser.params.sleep.sleep5);

//         await browser.getCurrentUrl().then(async function (url) {
//             await utils.logInfo("Before each : Current Url is "+url);
//             await browser.sleep(browser.params.sleep.sleep5);

//             if (url == await loginpage.getURL()) {
//                 utils.logInfo("Sign in since current page is Login page")
//                 await loginpage.signIn(browser.params.login.superadminuser, browser.params.login.superadminpassword);
//                 await browser.getCurrentUrl().then(async function (url) {
//                     if (url == await verifymobilenumberpage.getUrl()) {
//                         await utils.logInfo("Click Remind me on Verify Mobile Number Page");
//                         await verifymobilenumberpage.clickRemindme();
//                     }//if
//                 })//then
//             }//if
//             else if (url == await verifymobilenumberpage.getUrl()) {
//                 await utils.logInfo("Click Remind me on Verify Mobile Number Page");
//                 await verifymobilenumberpage.clickRemindme();
//             }

//         });//browser.getCurrentUrl()

//         if(await homepage.isPresentCancelSearchAppraisalListBtn()){
//             await homepage.clickCancelSearchAppraisalListBtn();
//             await browser.sleep(browser.params.sleep.sleep5);
//         }

//         await browser.waitForAngularEnabled(true);


//         // if(count == 0){
//         //     await homepage.closeAllWalkme();
//         //     count = 1;
//         // }//if count

//     }); //beforeEach    

//     afterEach(async function () {
//         await browser.waitForAngularEnabled(true); // *** Angular Enabled True
//     });    



//     xit('*** Verify the text below the Generate appraisal report button is branded', async function () {
//         utils.logInfo("*****  TEST CASE : Verify the text below the Generate appraisal report button is branded   *****");

//         var expectedGenerateAppraisalReportBtnDescription = "Print the Instant Offer for the Customer using the appraisal.";
//         await browser.refresh();
//         await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");

//         //Get Appraisal Menu
//         await browser.waitForAngularEnabled(false); // *** Angular Disabled
//         await utils.logInfo("Switch to Consumer Mode");
//         await appraisalpage.clickAppraisalConsumerDealerMode();

//         utils.logInfo("Value of Appraisal Report is '"+await appraisalpage.getGenerateAppraisalReportDesc()+"'");
//         expect(await appraisalpage.getGenerateAppraisalReportDesc()).toBe(expectedGenerateAppraisalReportBtnDescription,"Verify Generate Appraisal Report Button Branding");

//         await utils.logInfo("Sleeping for 10 seconds");
//         await browser.sleep(browser.params.sleep.sleep10);

//     });    

//     xit('*** Branding  ', async function () {
//         utils.logInfo("***** TEST CASE : Branding   *****");
//         vin = "2GNALDEK1D6209782";
//         await perseuspage.createBasicProspectWithRandomVIN(vin,"Amit","Prospect");
//     }); //it




// }); //describe   


describe('Branding Test Suite', function () { // ********************** Describe2 *******************************
    browser.manage().timeouts().implicitlyWait(5000);
    browser.driver.manage().window().maximize();
    utils.logInfo("TEST SUITE: Branding");
    utils.logInfo("TEST RUN : "+"https://autodevteam.testrail.net/index.php?/runs/view/883&group_by=cases:section_id&group_order=asc");
    //var count = 0;
    beforeEach(async function () {
        await loginpage.get();
        await browser.getCurrentUrl().then(async function (url) {
            if (url != await loginpage.getForceURL()) {
                await homepage.navigateThroughMenu("Log Out");
                await loginpage.get();
            }
        });
        await browser.waitForAngularEnabled(true);
    });

    afterEach(async function () {
        await homepage.navigateThroughMenu("Log Out");
    });

    //DONE
    using(testdata.brandingappraisalreportbtn, function (data, description) {
        it('***** Verify the text below the Generate appraisal report button is branded: User- '+data.user+' [testdata.brandingappraisalreportbtn]', async function () {
            utils.logInfo("***** TEST CASE : Verify the text below the Generate appraisal report button is branded: User- '"+data.user+"' *****");

            await utils.logInfo("Set Valid User Name: " + data.user);
            await loginpage.setUsername(data.user);

            await utils.logInfo("Set Valid Password: " + data.password);
            await loginpage.setPassword(data.password);

            await utils.logInfo("Click SignIn Button");
            await loginpage.clickSignIn();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            });

            await browser.sleep(browser.params.sleep.sleep5);

            //Create New Appraisal using VIN
            await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");
            var appraisalID = await appraisalpage.getAppraisalID();
            await utils.logInfo("Value of Appraisal ID is "+appraisalID);

            await browser.waitForAngularEnabled(false); // *** Angular Disabled
            await utils.logInfo("Switch to Consumer Mode");
            await appraisalpage.clickAppraisalConsumerDealerMode();
    
            utils.logInfo("Value of Appraisal Report is '"+await appraisalpage.getGenerateAppraisalReportDesc()+"'");
            expect(await appraisalpage.getGenerateAppraisalReportDesc()).toBe(data.brandvintext,"Verify Generate Appraisal Report Button Branding for VIN Appraisal user - "+data.user);
            
            await browser.waitForAngularEnabled(true); // *** Angular Disabled

            await homepage.createNewAppraisalYMMT(browser.params.ymmt.year,browser.params.ymmt.make,browser.params.ymmt.model,browser.params.ymmt.trim);
            appraisalID = await appraisalpage.getAppraisalID();
            await utils.logInfo("Value of Appraisal ID is "+appraisalID);

            await browser.waitForAngularEnabled(false); // *** Angular Disabled
            await utils.logInfo("Switch to Consumer Mode");
            await appraisalpage.clickAppraisalConsumerDealerMode();
    
            utils.logInfo("Value of Appraisal Report is '"+await appraisalpage.getGenerateAppraisalReportDesc()+"'");
            expect(await appraisalpage.getGenerateAppraisalReportDesc()).toBe(data.brandymmttext,"Verify Generate Appraisal Report Button Branding for YMMT appraisal user - "+data.user);


            await utils.logInfo("Sleeping for 10 seconds");
            await browser.sleep(browser.params.sleep.sleep10);


        }); //it
    }); //using

    //DONE
    using(testdata.branding, function (data, description) {
        it('*** Verify that in chat window, Accu-Trade logo displays: User - '+data.user+' [testdata.branding] ', async function () {
            utils.logInfo("***** TEST CASE : Verify that in chat window, Accu-Trade logo displays  *****");

            await utils.logInfo("Set Valid User Name: " + data.user);
            await loginpage.setUsername(data.user);

            await utils.logInfo("Set Valid Password: " + data.password);
            await loginpage.setPassword(data.password);

            await utils.logInfo("Click SignIn Button");
            await loginpage.clickSignIn();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            });

            await browser.sleep(browser.params.sleep.sleep5);

            //Create New Appraisal using VIN
            await utils.logInfo("Create a new Appraisal for VIN: "+browser.params.vin.validvin);
            await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");

            var appraisalID = await appraisalpage.getAppraisalID();
            await utils.logInfo("Value of Appraisal ID is "+appraisalID);

            var appraisalVIN = await appraisalpage.getAppraisalVIN();
            await utils.logInfo("Value of Appraisal VIN is "+appraisalVIN);

            expect(appraisalVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/

            await appraisalpage.openChatWindow();

            expect(await appraisalpage.isPresentAccutradeLogoOnChatWindow()).toBeTruthy("Verify Accutrade Logo present on Appraisal Chat Window for user :"+data.user);

            //await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        }); //it
    }); //using    

    //DONE
    using(testdata.brandingprospect, function (data, description) {
        it('***** Verify in Prospect List the correct Pricing label is displayed in the Pricing Column (i.e. TCO, ICO) (Desktop): User- '+data.user+' [testdata.brandingprospect]', async function () {
            utils.logInfo("***** TEST CASE : Verify in Prospect List the correct Pricing label is displayed in the Pricing Column (i.e. TCO, ICO) (Desktop): User- '"+data.user+"' *****");

            await utils.logInfo("Value of Description is : " + description);

            await utils.logInfo("Set Valid User Name: " + data.user);
            await loginpage.setUsername(data.user);

            await utils.logInfo("Set Valid Password: " + data.password);
            await loginpage.setPassword(data.password);

            await utils.logInfo("Click SignIn Button");
            await loginpage.clickSignIn();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            });

            await browser.sleep(browser.params.sleep.sleep5);

            var fname = "Automated";//"amit";
            var lname = faker.name.lastName();//"kumaar";
            var url = data.perseusurl;
            var zip = data.zip;

            await perseuspage.createBasicProspectWithRandomVIN(description,url,fname,lname,zip);
            await homepage.get();
            await homepage.clickProspectsAppraisalList();
            await browser.refresh();
        
            await browser.waitForAngularEnabled(true); // *** Angular Enabled
        
            // Set Pricing Settings to ON
            await utils.logInfo("Click Settings in Appraisal List");
            await homepage.clickSettingsAppraisalList();
            await utils.logInfo("Select Pricing Checkbox to ON");
            await homepage.setPricingCheckboxSettingsAppraisalList("ON");
            await utils.logInfo("Click on Update Button");
            await homepage.clickUpdateBtnSettingsAppraisalList();
            await browser.sleep(browser.params.sleep.sleep10);

            //Verify Appraisal available in Appraisals List
            await utils.logInfo("Search Appraisal on Appraisal List");
            await homepage.searchAppraisalList(lname);
            await browser.sleep(browser.params.sleep.sleep10);

            //Verify Search Results in Appraisal List
            // expect(await homepage.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
            expect(await homepage.getSearchResultSearchTerm()).toBe(lname,"Verify Search results showing serached term at the bottom of Appraisal List");

            var locator = "//tbody/tr/td[9]";
            var pricingElement = element(by.xpath(locator));

            utils.logInfo("Value of pricing is "+await pricingElement.getText());
            expect(await pricingElement.getText()).toBe(data.brandprospecttext,"Verify Pricing value on Appraisal List");

            // await homepage.clickFirstAppraisal();
            // await browser.sleep(browser.params.sleep.sleep5);

            // await browser.waitForAngularEnabled(false); // *** Angular Disabled

            // //Click on Start Button
            // await appraisalpage.clickProspectStartBtn();
            // expect(await appraisalpage.isPresentGroundVehicleBtn()).toBeTruthy("Verify Ground option is present under Select Action");

            // //Select Interior and Exterior Color
            // await utils.logInfo("Click Exterior Color Button");
            // await appraisalpage.clickExteriorColorBtn();
    
            // await utils.logInfo("Select Black Exterior Color");
            // await appraisalpage.clickExteriorBlackColorBtn();
    
            // await utils.logInfo("Click Interior Color Button");
            // await appraisalpage.clickInteriorColorBtn();
    
            // await utils.logInfo("Selct Black Interior Color");
            // await appraisalpage.clickInteriorBlackColorBtn();
            // await browser.sleep(browser.params.sleep.sleep5);
    
            // //Upload Photos
            // await utils.logInfo("Upload Images");
            // await appraisalpage.uploadImages();
            // await browser.sleep(browser.params.sleep.sleep20);
            // await utils.logInfo("Click on left photo gallery button");
            // await appraisalpage.clickLeftPhotoGalleryBtn();

            // //Ground Vehicle
            // await appraisalpage.clickGroundVehicleBtn();
            // await appraisalpage.clickGroundAppraisalTrimCheckBox();
            // await appraisalpage.clickGroundAppraisalOdometerCheckBox();
            // await appraisalpage.clickGroundAppraisalConditionDisclosuresCheckBox();
            // await appraisalpage.clickGroundAppraisalConfirmAndGroundBtn();
            // await browser.sleep(browser.params.sleep.sleep10);

            // await utils.logInfo("Is Successfully Grounded message present "+await appraisalpage.isPresentGroundAppraisalSuccessMessage());
            // await utils.logInfo("Vehicle was Grounded message present "+await appraisalpage.isPresentGroundAppraisalSuccessDateMessage());
            // expect(await appraisalpage.isPresentGroundAppraisalSuccessMessage()).toBeTruthy("Verify Vehicle Successful Grounded message is present");


            await utils.logInfo("Sleeping for 10 seconds");
            await browser.sleep(browser.params.sleep.sleep10);


        }); //it
    }); //using

    //DONE
    using(testdata.brandingdealerprospect, function (data, description) {
        it('***** Prospect List: correct dealer website logo in source column : User- '+data.user+' [testdata.brandingdealerprospect]', async function () {
            utils.logInfo("***** TEST CASE : Prospect List: correct dealer website logo in source column : User- '"+data.user+"' *****");

            await utils.logInfo("Value of Description is : " + description);

            await utils.logInfo("Set Valid User Name: " + data.user);
            await loginpage.setUsername(data.user);

            await utils.logInfo("Set Valid Password: " + data.password);
            await loginpage.setPassword(data.password);

            await utils.logInfo("Click SignIn Button");
            await loginpage.clickSignIn();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            });

            await browser.sleep(browser.params.sleep.sleep5);

            var fname = "Automated";//"amit";
            var lname = faker.name.lastName();//"kumaar";
            var url = data.perseusurl;
            var zip = data.zip;

            await perseuspage.createBasicProspectWithRandomVIN(description,url,fname,lname,zip);
            await homepage.get();
            await homepage.clickProspectsAppraisalList();
            await browser.refresh();
        
            await browser.waitForAngularEnabled(true); // *** Angular Enabled
        
            // Set Pricing Settings to ON
            await utils.logInfo("Click Settings in Appraisal List");
            await homepage.clickSettingsAppraisalList();
            await utils.logInfo("Select Pricing Checkbox to ON");
            await homepage.setPricingCheckboxSettingsAppraisalList("ON");
            await utils.logInfo("Click on Update Button");
            await homepage.clickUpdateBtnSettingsAppraisalList();
            await browser.sleep(browser.params.sleep.sleep10);

            //Verify Appraisal available in Appraisals List
            await utils.logInfo("Search Appraisal on Appraisal List");
            await homepage.searchAppraisalList(lname);
            await browser.sleep(browser.params.sleep.sleep10);

            //Verify Search Results in Appraisal List
            // expect(await homepage.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
            expect(await homepage.getSearchResultSearchTerm()).toBe(lname,"Verify Search results showing serached term at the bottom of Appraisal List");

            var locator = "//tbody/tr/td[9]";
            var pricingElement = element(by.xpath(locator));

            utils.logInfo("Value of pricing is "+await pricingElement.getText());
            expect(await pricingElement.getText()).toBe(data.brandprospecttext,"Verify Pricing value on Appraisal List");

            locator = "//tbody/tr/td[2]"
            var sourceElement = element(by.xpath(locator));

            utils.logInfo("Value of Source is "+await sourceElement.getText());
            expect(await sourceElement.getText()).toBe(data.brandprospectsourcetext,"Verify Pricing value on Appraisal List");

        }); //it
    }); //using

    //DONE
    using(testdata.brandingmaster, function (data, description) {
        it('*** Appraisal Branding : User - '+description+':'+data.user+' [testdata.brandingmaster]', async function () {
            utils.logInfo("***** TEST CASE : Appraisal Branding for User - "+description+":"+data.user+"  *****");

            await utils.logInfo("Set Valid User Name: " + data.user);
            await loginpage.setUsername(data.user);

            await utils.logInfo("Set Valid Password: " + data.password);
            await loginpage.setPassword(data.password);

            await utils.logInfo("Click SignIn Button");
            await loginpage.clickSignIn();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            });

            await browser.sleep(browser.params.sleep.sleep5);

            //Create New Appraisal using VIN
            await utils.logInfo("Create a new Appraisal for VIN: "+browser.params.vin.validvin);
            await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");

            var appraisalID = await appraisalpage.getAppraisalID();
            await utils.logInfo("Value of Appraisal ID is "+appraisalID);

            var appraisalVIN = await appraisalpage.getAppraisalVIN();
            await utils.logInfo("Value of Appraisal VIN is "+appraisalVIN);

            expect(appraisalVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/

            await browser.waitForAngularEnabled(false); // *** Angular Disabled

            //******************** CONSUMER ********************
            await utils.logInfo("Switch to Consumer Mode");
            await appraisalpage.clickAppraisalConsumerDealerMode();

            //brandLogoLeftSection //img[@class='consumer-mode-image'] //src=assets/images/logos/accutrade-appraiser-white.png
            await utils.logInfo("");
            expect(await appraisalpage.isPresentBrandLogoLeftSection()).toBeTruthy("Verify Brand Logo is present on Left section in Appraisal Consumer mode");
            expect(await appraisalpage.getBrandLogoLeftSectionImgSrc()).toBe(data.screen.consumerappraisal.leftsectionbrandlogo,"Verify Brand Logo Image Src on Left section in Appraisal Consumer mode");

            //consumer-price-bar/brand-image/img //src=assets/images/logos/accutrade-appraiser-dark.png
            await utils.logInfo("");
            expect(await appraisalpage.isPresentBrandLogoPriceBar()).toBeTruthy("Verify Brand Logo on Price Bar is in Appraisal Consumer mode");
            expect(await appraisalpage.getBrandLogoPriceBarImgSrc()).toBe(data.screen.consumerappraisal.pricebarbrandlogo,"Verify Brand Logo Image Src on Price Bar is in Appraisal Consumer mode");

            //offerPriceLabelConsumerPriceBar //consumer-price-bar/brand-image/following-sibling::div[1] //getText()=Accu-Trade Instant Offer
            await utils.logInfo("");
            expect(await appraisalpage.isPresentOfferPriceLabelConsumerPriceBar()).toBeTruthy("Verify Offer Price Label is present on Price Bar in Appraisal Consumer mode");
            expect(await appraisalpage.getOfferPriceLabelConsumerPriceBar()).toBe(data.screen.consumerappraisal.offerpricebarlabel,"Verify Offer Price Label on Price Bar in Appraisal Consumer mode");

            //instantOfferPriceLabelReviewSend //trade-desk-dock-list/following-sibling::div/div[1] //getText()=Accu-Trade Instant Offer
            await utils.logInfo("");
            expect(await appraisalpage.isPresentOfferPriceLabelReviewSend()).toBeTruthy("Verify Offer Price Label is present on Review & Send section in Appraisal Consumer mode");
            expect(await appraisalpage.getOfferPriceLabelReviewSend()).toBe(data.screen.consumerappraisal.offerpricereviewsend,"Verify Offer Price Label on Review & Send section in Appraisal Consumer mode");

            //******************** CONSUMER REPORT ********************

            await utils.logInfo("Get Appraisal Menu");
            await appraisalpage.getAppraisalMenu();
            await utils.logInfo("Click on Consumer CR menu item");
            await appraisalpage.clickConsumerAppraisalMenuItem();
            await browser.sleep(browser.params.sleep.sleep5);


            //brandLogoLeftSection //img[@class='consumer-mode-image'] //src=assets/images/logos/accutrade-appraiser-white.png
            await utils.logInfo("");
            expect(await crpage.isPresentBrandLogoLeftSection()).toBeTruthy("Verify Brand Logo is present on Left section of Consumer CR");
            expect(await crpage.getBrandLogoLeftSectionImgSrc()).toBe(data.screen.consumerconditionreport.leftsectionbrandlogo,"Verify Brand Logo Image Src on Left section of Consumer CR");

            //reportBrandLogo //brand-image/img //src=assets/images/logos/accutrade-appraiser-galves-dark.png
            await utils.logInfo("");
            expect(await crpage.isPresentReportBrandLogo()).toBeTruthy("Verify Report Brand Logo is present on Consumer CR");
            expect(await crpage.getReportBrandLogoImageSrc()).toBe(data.screen.consumerconditionreport.brandlogo,"Verify Report Brand Logo Image Src on Consumer CR");

            //reportPriceLabel //cr-header/div[@class='price-label-container']/label //getText()=Trade Insurance Guarantee
            await utils.logInfo("");
            expect(await crpage.isPresentConsumerReportPriceLabel()).toBeTruthy("Verify Report Price Label is present in Consumer CR");
            expect(await crpage.getConsumerReportPriceLabel()).toBe(data.screen.consumerconditionreport.offerpricelabel,"Verify Report Report Price Label in Consumer CR");


            //Back to Appraisal
            await utils.logInfo("Click on Back Arrow Button to goto Appraisal Screen from Report");
            await crpage.clickBackToAppraisalLink();

            //******************** DEALER VIEW ********************
            await utils.logInfo("Switch to Dealer Mode");
            await appraisalpage.clickAppraisalConsumerDealerMode();
            await browser.sleep(browser.params.sleep.sleep5);

            //CustomerStartAppraisalBtn
            expect(await homepage.isPresentConsumerStartAppraisalBtn()).toBeTruthy("");
            expect(await homepage.getConsumerStartAppraisalBtnText()).toContain(data.screen.dealerappraisal.customerstartappraisalbtnlabel,"Verify Customer Start Appraisal button text");

            //offerPriceLabelDealerPriceBar //price-bar/appraisal-price[1]/div[@ng-reflect-klass='label'] //getText()=Accu-Trade Instant Offer
            await utils.logInfo("");
            expect(await appraisalpage.isPresentOfferPriceLabelDealerPriceBar()).toBeTruthy("Verify Offer Price Label is present in Appraisal Dealer Mode");
            expect(await appraisalpage.getOfferPriceLabelDealerPriceBar()).toBe(data.screen.dealerappraisal.offerpricelabelpricebar,"Verify Offer Price Label in Appraisal Dealer Mode");


            //instantOfferPriceLabelReviewSend //trade-desk-dock-list/following-sibling::div/div[1] //getText()=Accu-Trade Instant Offer
            await utils.logInfo("");
            expect(await appraisalpage.isPresentOfferPriceLabelReviewSend()).toBeTruthy("Verify Offer Price Label is present on Review & Send Section in Appraisal Dealer mode");
            expect(await appraisalpage.getOfferPriceLabelReviewSend()).toBe(data.screen.dealerappraisal.offerpricereviewsend,"Verify Offer Price Label on Review & Send Section in Appraisal Dealer mode");

            //******************** DEALER REPORT ********************

            await utils.logInfo("Get Appraisal Menu");
            await appraisalpage.getAppraisalMenu();
            await utils.logInfo("Click on Dealer Condition Report menu item");
            await appraisalpage.clickDealerAppraisalMenuItem();
            await browser.sleep(browser.params.sleep.sleep5);


            //reportBrandImage //brand-image/img //src=assets/images/logos/accutrade-appraiser-galves-dark.png
            await utils.logInfo("");
            expect(await crpage.isPresentReportBrandLogo()).toBeTruthy("Verify Report Brand Logo is present on Dealer CR");
            expect(await crpage.getReportBrandLogoImageSrc()).toBe(data.screen.dealerconditionreport.brandlogo,"Verify Report Brand Logo Image Src on Dealer CR");

            //offerPriceLabelDealerPriceBar //price-bar/appraisal-price[1]/div[@ng-reflect-klass='label'] //getText()=Accu-Trade Instant Offer
            await utils.logInfo("");
            expect(await crpage.isPresentDealerReportOfferPriceLabel()).toBeTruthy("Verify Offer Price Label is present in Price Bar Dealer CR");
            expect(await crpage.getDealerReportOfferPriceLabel()).toBe(data.screen.dealerconditionreport.offerpricelabel,"Verify Report Offer Price Label in Price Bar Dealer CR");

            await utils.logInfo("Expand Report Settings in Dealer CR");
            await crpage.clickReportSettingBtn();

            //valuesFirstCheckLabelReportSettings //cr-configurator-pricebar/div/div[1]/checkbox/label //getText()=Accu-Trade Instant Offer / Target Trade
            await utils.logInfo("");
            expect(await crpage.isPresentValuesFirstCheckLabelReportSettings()).toBeTruthy("Verify Values First Checkbox Label is present in Report Settings of Dealer CR");
            expect(await crpage.getValuesFirstCheckLabelReportSettings()).toBe(data.screen.dealerconditionreport.reportsettingsvaluesfirstcheckboxlabel,"Verify Values First Checkbox Label in Report Settings of Dealer CR");

            // await browser.waitForAngularEnabled(false); // *** Angular Disabled

            //Back to Appraisal
            await crpage.clickBackToAppraisalLink();

            //Select Interior and Exterior Color
            //await appraisalpage.navigateToCommonProblems();
            await utils.logInfo("Click Exterior Color Button");
            await appraisalpage.clickExteriorColorBtn();
     
            await utils.logInfo("Select Black Exterior Color");
            await appraisalpage.clickExteriorBlackColorBtn();
     
            await utils.logInfo("Click Interior Color Button");
            await appraisalpage.clickInteriorColorBtn();
      
            await utils.logInfo("Selct Black Interior Color");
            await appraisalpage.clickInteriorBlackColorBtn();
            await browser.sleep(browser.params.sleep.sleep5);
     
            //Upload Photos
            await utils.logInfo("Upload Images");
            await appraisalpage.uploadImages();
            await browser.sleep(browser.params.sleep.sleep20);
            await utils.logInfo("Click on left photo gallery button");
            await appraisalpage.clickLeftPhotoGalleryBtn();        
            await browser.sleep(browser.params.sleep.sleep5);

            //Increase Offer
            expect(await appraisalpage.isPresentIncreaseOfferBtn()).toBeTruthy("Verify Increase Offer options is present");
            await utils.logInfo("Click on Increase Offer Button");
            await appraisalpage.clickIncreaseOfferBtn();

            expect(await appraisalpage.isPresentIncreaseOfferLabel()).toBeTruthy("Verify Increase Offer Label is Present");
            expect(await appraisalpage.getIncreaseOfferLabel()).toBe(data.screen.increaseoffer.increaseofferbtnlabel,"Verify Increase Offer Label");

            expect(await appraisalpage.isPresentIncreaseOfferDescription()).toBeTruthy("Verify Increase Offer Description is present");
            expect(await appraisalpage.getIncreaseOfferDescription()).toBe(data.screen.increaseoffer.increaseofferbtndescriptiontext,"Verify Increase Offer Description");

            expect(await appraisalpage.isPresentUpdatedOfferLabel()).toBeTruthy("Verify Updated Offer Label is present");
            expect(await appraisalpage.getUpdatedOfferLabel()).toBe(data.screen.increaseoffer.updatedofferlabel,"Verify Updated Offer Label");

            expect(await appraisalpage.isPresentUpdatedOfferAgreementText()).toBeTruthy("Verify Updated Offer Agreement is present");
            expect(await appraisalpage.getUpdatedOfferAgreementText()).toContain(data.screen.increaseoffer.updatedofferagreementtxt,"Verify Updated Offer Agreement Text");

            await utils.logInfo("Enter Increase Offer Amount of $1000");
            await appraisalpage.enterIncreaseOfferAmount("1000");
            await utils.logInfo("Enter Increase Offer Expires in 3 days");
            await appraisalpage.enterIncreaseOfferExpiresInput("3");
            
            await utils.logInfo("Select Increase Offer Agreement checkbox");
            await appraisalpage.selectIncreaseOfferAgreementCheckBox();

            await utils.logInfo("Click on Increase Offer Next Button");
            await appraisalpage.clickIncreaseOfferNextBtn();

            expect(await appraisalpage.isPresentIncreaseOfferConfirmationLabel()).toBeTruthy("Verify Increase Offer Confirmation Text present");
            expect(await appraisalpage.getIncreaseOfferConfirmationLabel()).toBe(data.screen.increaseoffer.increaseofferconfirmationlabel,"Verify Increase Offer Confirmation Label");

            await utils.logInfo("Click on Increase Offer Send Button");
            await appraisalpage.clickIncreaseOfferSendBtn(); 

            expect(await appraisalpage.isPresentIncreaseOfferBtn()).toBeFalsy("Verify Increase Offer options is not present after Increase Offer Successful Submission");
        
            var elem = element(by.xpath("//*[text()='Offer increased by $1,000']"));
            await utils.logInfo("Verify Increase Offer amount visible on Appraisal screen");
            expect(await elem.isPresent()).toBeTruthy("Verify Increase Offer amount visible on Appraisal screen");
            await browser.sleep(browser.params.sleep.sleep5);
     
            //Click on Ground Vehicle
            await appraisalpage.clickGroundVehicleBtn();
            await appraisalpage.clickGroundAppraisalTrimCheckBox();
            await appraisalpage.clickGroundAppraisalOdometerCheckBox();
            await appraisalpage.clickGroundAppraisalConditionDisclosuresCheckBox();
            await appraisalpage.clickGroundAppraisalConfirmAndGroundBtn();
            // await browser.sleep(browser.params.sleep.sleep10);
    
            // if(await appraisalpage.isPresentWalkMeAlreadyGroundedMsgDialog()){
            //     await appraisalpage.closeWalkMeAlreadyGroundedMsgDialog();
            // }
    
            // if(await appraisalpage.isPresentWalkMeGroundMsgDialog()){
            //     await appraisalpage.closeWalkMeGroundMsgDialog();
            // }
            await browser.sleep(browser.params.sleep.sleep2);

            await utils.logInfo("Is Successfully Grounded message present "+await appraisalpage.isPresentGroundAppraisalSuccessMessage());
            await utils.logInfo("Vehicle was Grounded message present "+await appraisalpage.isPresentGroundAppraisalSuccessDateMessage());
            expect(await appraisalpage.isPresentGroundAppraisalSuccessMessage()).toBeTruthy("Verify Vehicle Successful Grounded message is present");
            expect(await appraisalpage.isPresentGroundAppraisalSuccessDateMessage()).toBeTruthy("Verify Vehicle Successful Grounded date message is present");
            expect(await appraisalpage.getGroundAppraisalSuccessMessageValue()).toContain("Successfully Grounded","Verify Vehicle Successful Grounded message value");
            expect(await appraisalpage.getGroundAppraisalSuccessDateMessageValue()).toContain("This vehicle was Grounded on "+utils.getCurrentDateMonthYear(),"Verify Vehicle Successful Grounded Date message value");
            
            await appraisalpage.clickGroundAppraisalBackBtn();
    
            await utils.logInfo("Verify Grounded text visible on Appraisal screen underneath Price Bar");
            expect(await appraisalpage.isPresentGroundedMsg()).toBeTruthy("Verify 'Grounded' text visible on Appraisal screen underneath Price Bar");
            expect(await appraisalpage.isPresentGroundedAppraisalLabel()).toBeTruthy("Verify 'Grounded' text visible at top center of Appraisal page");
            expect(await appraisalpage.isPresentGroundedCountdownTimer()).toBe(true,"Verify Grounded Countdown timer visible on Appraisal screen underneath Price Bar ");
            expect(await appraisalpage.isPresentGroundVehicleBtn()).toBeFalsy("Verify Ground Vehicle Button is not present after appraisal is grounded");


            //GET OFFER
            expect(await appraisalpage.isPresentGetOfferBtn()).toBeTruthy("Verify the Get Offer button is present");
            expect(await appraisalpage.getOfferBtnText()).toBe(data.screen.getoffer.getofferbtnlabel,"Verify the Get Offer Button Text");

            expect(await appraisalpage.isPresentGetOfferBtnDescription()).toBeTruthy("Verify the Get Offer button descriptive text is present");
            expect(await appraisalpage.getOfferBtnDescription()).toBe(data.screen.getoffer.getofferbtndescriptiontxt,"Verify the Get Offer button descriptive text");
            
            await utils.logInfo("Click on Get Offer Button");
            await appraisalpage.clickGetOfferBtn();
            await utils.logInfo("After Click on Get Offer Button");

            await utils.logInfo("Before Screen Heading Assertion");
            expect(await appraisalpage.isPresentGetOfferScreenHeading()).toBeTruthy("Verify Get Offer Screen Heading is present");
            expect(await appraisalpage.getOfferScreenHeading()).toBe(data.screen.getoffer.getofferscreenheading,"Verify Get Offer Screen Heading");
            await utils.logInfo("Before Screen Title Assertion");
            expect(await appraisalpage.isPresentGetOfferScreenTitle()).toBeTruthy("Verify Get Offer Screen Title is present");
            expect(await appraisalpage.getOfferScreenTitle()).toBe(data.screen.getoffer.getofferscreentitle,"Verify Get Offer Screen Title");

            //Click CheckBox
            await utils.logInfo("Click Terms & Conditions checkbox on Get Offer Screen");
            await appraisalpage.clickGetOfferCheckBox();
    
            //Click on Submit Button
            await utils.logInfo("Click on 'Confirm & Get Offer' Button on the Get Offer Screen");
            await appraisalpage.clickGetOfferSubmitBtn();
    
            await utils.logInfo("Is Successful Msg present : "+await appraisalpage.isPresentGetOfferSuccessMsg());
            expect(await appraisalpage.isPresentGetOfferSuccessMsg()).toBeTruthy("Verify Get Offer is Successfully Submit by Showing 'Successfully Submitted' message");
    
            await utils.logInfo("Is Successful Descripton Msg present : "+ await appraisalpage.isPresentGetOfferSuccessDescriptionMsg());
            expect(await appraisalpage.isPresentGetOfferSuccessDescriptionMsg()).toBeTruthy("Verify Get Offer Successful submission descriptive message is present");
            expect(await appraisalpage.getOfferSuccessDescriptionMsg()).toContain(data.screen.getoffer.getoffersuccessdescriptionmsg,"Verify Get Offer Successful Submission descriptive message");

            await appraisalpage.clickGetOfferBackBtn();
            await utils.logInfo("Is Pending Offer status bar present : "+await appraisalpage.isPresentGetOfferPendingMsgStatusBar());
            expect(await appraisalpage.isPresentGetOfferPendingMsgStatusBar()).toBeTruthy("Verify Appraisal Page Get Offer Pending Msg on Appraisal Status bar is Present");
    
            expect(await appraisalpage.getOfferPendingMsgStatusBar()).toContain(data.screen.getoffer.getofferpendingmsgstatusbar,"Verify Appraisal page Pending Get Offer Message on Status Bar");
            
            //new
            expect(await appraisalpage.isPresentGetOfferBtn()).toBeFalsy("Verify the Get Offer button is not present when Offer is pending");
            await browser.sleep(browser.params.sleep.sleep20);


            // //Get An appraisal ID
            // var appraisalID = await appraisalpage.getAppraisalID();
            // await utils.logInfo("Value of Appraisal ID is "+appraisalID);
    
            // await browser.waitForAngularEnabled(true); // *** Angular Enabled
    
            // //Click on Offers list view
            // await homepage.get();
            // await homepage.clickOffersAppraisalList();
            // await utils.logInfo("Verify Offers Appraisals list tab is selected when click on Offers list view");
            // expect(await homepage.isOffersAppraisalListTabSelected()).toBeTruthy();
    
            // //Search for an appraisal ID
            // await homepage.searchAppraisalList(appraisalID);
    
            // //Verify the Appraisal Should display
            // expect(await homepage.getAppraisalsRowCount()).toBe(1,"Verify Appraisal now display under Offers list view");

        }); //it
    }); //using  

    //DONE
    using(testdata.brandingprospectmaster, function (data, description) {
        it('*** Prospect Branding : User - '+description+':'+data.user+' [testdata.brandingprospectmaster]', async function () {
            utils.logInfo("***** TEST CASE : Prospect Branding for User - "+description+":"+data.user+"  *****");

            if(description == "trader"){
                expect(false).toBe(true,"Can't automate Trader Prospect creation due to Phone verification. Please run this test manually");
                await element(by.xpath("Failing deliberatly as this need to run manually")).click();
            }

            await utils.logInfo("Value of Description is : " + description);

            await utils.logInfo("Set Valid User Name: " + data.user);
            await loginpage.setUsername(data.user);

            await utils.logInfo("Set Valid Password: " + data.password);
            await loginpage.setPassword(data.password);

            await utils.logInfo("Click SignIn Button");
            await loginpage.clickSignIn();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            });

            await browser.sleep(browser.params.sleep.sleep5);

            var fname = "AutomatedProspect";
            var lname = faker.name.lastName();
            var url = data.perseusurl;
            var zip = data.zip;

            await perseuspage.createBasicProspectWithRandomVIN(description,url,fname,lname,zip);
            await homepage.get();
            await homepage.clickProspectsAppraisalList();
            await browser.refresh();
        
            await browser.waitForAngularEnabled(true); // *** Angular Enabled
        
            // Set Pricing Settings to ON
            await utils.logInfo("Click Settings in Appraisal List");
            await homepage.clickSettingsAppraisalList();
            await utils.logInfo("Select Pricing Checkbox to ON");
            await homepage.setPricingCheckboxSettingsAppraisalList("ON");
            await utils.logInfo("Click on Update Button");
            await homepage.clickUpdateBtnSettingsAppraisalList();
            await browser.sleep(browser.params.sleep.sleep10);

            // Set Filter to uncheck Show CRM Only
            await homepage.unselectShowCRMFilterAppraisalList();

            //Verify Appraisal available in Appraisals List
            await utils.logInfo("Search Appraisal on Appraisal List");
            await homepage.searchAppraisalList(lname);
            await browser.sleep(browser.params.sleep.sleep10);

            //Verify Search Results in Appraisal List
            // expect(await homepage.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
            expect(await homepage.getSearchResultSearchTerm()).toBe(lname,"Verify Search results showing serached term at the bottom of Appraisal List");

            var locator = "//tbody/tr/td[9]";
            var pricingElement = element(by.xpath(locator));

            utils.logInfo("Value of pricing is "+await pricingElement.getText());
            expect(await pricingElement.getText()).toBe(data.brandprospecttext,"Verify Pricing value on Appraisal List");

            //Open first Prospect
            await utils.logInfo("Open Serached Appraisal");
            await homepage.clickFirstAppraisal();
            await browser.sleep(browser.params.sleep.sleep5);

            await browser.waitForAngularEnabled(false); // *** Angular Disabled

            await utils.logInfo("Switch to Dealer Mode");
            await appraisalpage.clickAppraisalConsumerDealerMode();

            var appraisalID = await appraisalpage.getAppraisalID();
            await utils.logInfo("Value of Prospect Appraisal ID is "+appraisalID);

            var appraisalVIN = await appraisalpage.getAppraisalVIN();
            await utils.logInfo("Value of Prospect Appraisal VIN is "+appraisalVIN);

            //******************** CONSUMER ********************
            await utils.logInfo("Switch to Consumer Mode");
            await appraisalpage.clickAppraisalConsumerDealerMode();

            //brandLogoLeftSection //img[@class='consumer-mode-image'] //src=assets/images/logos/accutrade-appraiser-white.png
            await utils.logInfo("");
            expect(await appraisalpage.isPresentBrandLogoLeftSection()).toBeTruthy("Verify Brand Logo is present on Left section in Appraisal Consumer mode");
            expect(await appraisalpage.getBrandLogoLeftSectionImgSrc()).toBe(data.screen.consumerappraisal.leftsectionbrandlogo,"Verify Brand Logo Image Src on Left section in Appraisal Consumer mode");

            //consumer-price-bar/brand-image/img //src=assets/images/logos/accutrade-appraiser-dark.png
            await utils.logInfo("");
            expect(await appraisalpage.isPresentBrandLogoPriceBar()).toBeTruthy("Verify Brand Logo on Price Bar is in Appraisal Consumer mode");
            expect(await appraisalpage.getBrandLogoPriceBarImgSrc()).toBe(data.screen.consumerappraisal.pricebarbrandlogo,"Verify Brand Logo Image Src on Price Bar is in Appraisal Consumer mode");

            //offerPriceLabelConsumerPriceBar //consumer-price-bar/brand-image/following-sibling::div[1] //getText()=Accu-Trade Instant Offer
            await utils.logInfo("");
            expect(await appraisalpage.isPresentOfferPriceLabelConsumerPriceBar()).toBeTruthy("Verify Offer Price Label is present on Price Bar in Appraisal Consumer mode");
            expect(await appraisalpage.getOfferPriceLabelConsumerPriceBar()).toBe(data.screen.consumerappraisal.offerpricebarlabel,"Verify Offer Price Label on Price Bar in Appraisal Consumer mode");

            //instantOfferPriceLabelReviewSend //trade-desk-dock-list/following-sibling::div/div[1] //getText()=Accu-Trade Instant Offer
            await utils.logInfo("");
            expect(await appraisalpage.isPresentOfferPriceLabelReviewSend()).toBeTruthy("Verify Offer Price Label is present on Review & Send section in Appraisal Consumer mode");
            expect(await appraisalpage.getOfferPriceLabelReviewSend()).toBe(data.screen.consumerappraisal.offerpricereviewsend,"Verify Offer Price Label on Review & Send section in Appraisal Consumer mode");

            //******************** CONSUMER REPORT ********************

            await utils.logInfo("Get Appraisal Menu");
            await appraisalpage.getAppraisalMenu();
            await utils.logInfo("Click on Consumer CR menu item");
            await appraisalpage.clickConsumerAppraisalMenuItem();
            await browser.sleep(browser.params.sleep.sleep5);


            //brandLogoLeftSection //img[@class='consumer-mode-image'] //src=assets/images/logos/accutrade-appraiser-white.png
            await utils.logInfo("");
            expect(await crpage.isPresentBrandLogoLeftSection()).toBeTruthy("Verify Brand Logo is present on Left section of Consumer CR");
            expect(await crpage.getBrandLogoLeftSectionImgSrc()).toBe(data.screen.consumerconditionreport.leftsectionbrandlogo,"Verify Brand Logo Image Src on Left section of Consumer CR");

            //reportBrandLogo //brand-image/img //src=assets/images/logos/accutrade-appraiser-galves-dark.png
            await utils.logInfo("");
            expect(await crpage.isPresentReportBrandLogo()).toBeTruthy("Verify Report Brand Logo is present on Consumer CR");
            expect(await crpage.getReportBrandLogoImageSrc()).toBe(data.screen.consumerconditionreport.brandlogo,"Verify Report Brand Logo Image Src on Consumer CR");

            //reportPriceLabel //cr-header/div[@class='price-label-container']/label //getText()=Trade Insurance Guarantee
            await utils.logInfo("");
            expect(await crpage.isPresentConsumerReportPriceLabel()).toBeTruthy("Verify Report Price Label is present in Consumer CR");
            expect(await crpage.getConsumerReportPriceLabel()).toBe(data.screen.consumerconditionreport.offerpricelabel,"Verify Report Report Price Label in Consumer CR");


            //Back to Appraisal
            await utils.logInfo("Click on Back Arrow Button to goto Appraisal Screen from Report");
            await crpage.clickBackToAppraisalLink();

            //******************** DEALER VIEW ********************
            await utils.logInfo("Switch to Dealer Mode");
            await appraisalpage.clickAppraisalConsumerDealerMode();
            await browser.sleep(browser.params.sleep.sleep5);

            //CustomerStartAppraisalBtn
            expect(await homepage.isPresentConsumerStartAppraisalBtn()).toBeTruthy("");
            expect(await homepage.getConsumerStartAppraisalBtnText()).toContain(data.screen.dealerappraisal.customerstartappraisalbtnlabel,"Verify Customer Start Appraisal button text");

            //offerPriceLabelDealerPriceBar //price-bar/appraisal-price[1]/div[@ng-reflect-klass='label'] //getText()=Accu-Trade Instant Offer
            await utils.logInfo("");
            expect(await appraisalpage.isPresentOfferPriceLabelDealerPriceBar()).toBeTruthy("Verify Offer Price Label is present in Appraisal Dealer Mode");
            expect(await appraisalpage.getOfferPriceLabelDealerPriceBar()).toBe(data.screen.dealerappraisal.offerpricelabelpricebar,"Verify Offer Price Label in Appraisal Dealer Mode");


            //instantOfferPriceLabelReviewSend //trade-desk-dock-list/following-sibling::div/div[1] //getText()=Accu-Trade Instant Offer
            await utils.logInfo("");
            expect(await appraisalpage.isPresentOfferPriceLabelReviewSend()).toBeTruthy("Verify Offer Price Label is present on Review & Send Section in Appraisal Dealer mode");
            expect(await appraisalpage.getOfferPriceLabelReviewSend()).toBe(data.screen.dealerappraisal.offerpricereviewsend,"Verify Offer Price Label on Review & Send Section in Appraisal Dealer mode");

            //******************** DEALER REPORT ********************

            await utils.logInfo("Get Appraisal Menu");
            await appraisalpage.getAppraisalMenu();
            await utils.logInfo("Click on Dealer Condition Report menu item");
            await appraisalpage.clickDealerAppraisalMenuItem();
            await browser.sleep(browser.params.sleep.sleep5);


            //reportBrandImage //brand-image/img //src=assets/images/logos/accutrade-appraiser-galves-dark.png
            await utils.logInfo("");
            expect(await crpage.isPresentReportBrandLogo()).toBeTruthy("Verify Report Brand Logo is present on Dealer CR");
            expect(await crpage.getReportBrandLogoImageSrc()).toBe(data.screen.dealerconditionreport.brandlogo,"Verify Report Brand Logo Image Src on Dealer CR");

            //offerPriceLabelDealerPriceBar //price-bar/appraisal-price[1]/div[@ng-reflect-klass='label'] //getText()=Accu-Trade Instant Offer
            await utils.logInfo("");
            expect(await crpage.isPresentDealerReportOfferPriceLabel()).toBeTruthy("Verify Offer Price Label is present in Price Bar Dealer CR");
            expect(await crpage.getDealerReportOfferPriceLabel()).toBe(data.screen.dealerconditionreport.offerpricelabel,"Verify Report Offer Price Label in Price Bar Dealer CR");

            await utils.logInfo("Expand Report Settings in Dealer CR");
            await crpage.clickReportSettingBtn();

            //valuesFirstCheckLabelReportSettings //cr-configurator-pricebar/div/div[1]/checkbox/label //getText()=Accu-Trade Instant Offer / Target Trade
            await utils.logInfo("");
            expect(await crpage.isPresentValuesFirstCheckLabelReportSettings()).toBeTruthy("Verify Values First Checkbox Label is present in Report Settings of Dealer CR");
            expect(await crpage.getValuesFirstCheckLabelReportSettings()).toBe(data.screen.dealerconditionreport.reportsettingsvaluesfirstcheckboxlabel,"Verify Values First Checkbox Label in Report Settings of Dealer CR");

            // await browser.waitForAngularEnabled(false); // *** Angular Disabled


            if(!description.includes("truecarpartner")){            
                // start button is unavailable for true car partner such as usaa and boost
                //Back to Appraisal
                await crpage.clickBackToAppraisalLink();
                await appraisalpage.clickProspectStartBtn();
                await browser.sleep(browser.params.sleep.sleep2);

                //Select Interior and Exterior Color
                //await appraisalpage.navigateToCommonProblems();
                // await utils.logInfo("Click Exterior Color Button");
                // await appraisalpage.clickExteriorColorBtn();
        
                // await utils.logInfo("Select Black Exterior Color");
                // await appraisalpage.clickExteriorBlackColorBtn();
        
                await utils.logInfo("Click Interior Color Button");
                await appraisalpage.clickInteriorColorBtn();
        
                await utils.logInfo("Selct Black Interior Color");
                await appraisalpage.clickInteriorBlackColorBtn();
                await browser.sleep(browser.params.sleep.sleep5);
        
                //Upload Photos
                await utils.logInfo("Upload Images");
                await appraisalpage.uploadImages();
                await browser.sleep(browser.params.sleep.sleep20);
                await utils.logInfo("Click on left photo gallery button");
                await appraisalpage.clickLeftPhotoGalleryBtn();        
                await browser.sleep(browser.params.sleep.sleep5);

                //Increase Offer
                expect(await appraisalpage.isPresentIncreaseOfferBtn()).toBeTruthy("Verify Increase Offer options is present");
                await utils.logInfo("Click on Increase Offer Button");
                await appraisalpage.clickIncreaseOfferBtn();

                expect(await appraisalpage.isPresentIncreaseOfferLabel()).toBeTruthy("Verify Increase Offer Label is Present");
                expect(await appraisalpage.getIncreaseOfferLabel()).toBe(data.screen.increaseoffer.increaseofferbtnlabel,"Verify Increase Offer Label");

                expect(await appraisalpage.isPresentIncreaseOfferDescription()).toBeTruthy("Verify Increase Offer Description is present");
                expect(await appraisalpage.getIncreaseOfferDescription()).toBe(data.screen.increaseoffer.increaseofferbtndescriptiontext,"Verify Increase Offer Description");

                expect(await appraisalpage.isPresentUpdatedOfferLabel()).toBeTruthy("Verify Updated Offer Label is present");
                expect(await appraisalpage.getUpdatedOfferLabel()).toBe(data.screen.increaseoffer.updatedofferlabel,"Verify Updated Offer Label");

                expect(await appraisalpage.isPresentUpdatedOfferAgreementText()).toBeTruthy("Verify Updated Offer Agreement is present");
                expect(await appraisalpage.getUpdatedOfferAgreementText()).toContain(data.screen.increaseoffer.updatedofferagreementtxt,"Verify Updated Offer Agreement Text");

                await utils.logInfo("Enter Increase Offer Amount of $1000");
                await appraisalpage.enterIncreaseOfferAmount("1000");
                await utils.logInfo("Enter Increase Offer Expires in 3 days");
                await appraisalpage.enterIncreaseOfferExpiresInput("3");
                
                await utils.logInfo("Select Increase Offer Agreement checkbox");
                await appraisalpage.selectIncreaseOfferAgreementCheckBox();

                await utils.logInfo("Click on Increase Offer Next Button");
                await appraisalpage.clickIncreaseOfferNextBtn();

                expect(await appraisalpage.isPresentIncreaseOfferConfirmationLabel()).toBeTruthy("Verify Increase Offer Confirmation Text present");
                expect(await appraisalpage.getIncreaseOfferConfirmationLabel()).toBe(data.screen.increaseoffer.increaseofferconfirmationlabel,"Verify Increase Offer Confirmation Label");

                await utils.logInfo("Click on Increase Offer Send Button");
                await appraisalpage.clickIncreaseOfferSendBtn(); 

                expect(await appraisalpage.isPresentIncreaseOfferBtn()).toBeFalsy("Verify Increase Offer options is not present after Increase Offer Successful Submission");
            
                var elem = element(by.xpath("//*[text()='Offer increased by $1,000']"));
                await utils.logInfo("Verify Increase Offer amount visible on Appraisal screen");
                expect(await elem.isPresent()).toBeTruthy("Verify Increase Offer amount visible on Appraisal screen");
                await browser.sleep(browser.params.sleep.sleep5);
        
                //Click on Ground Vehicle
                await appraisalpage.clickGroundVehicleBtn();
                await appraisalpage.clickGroundAppraisalTrimCheckBox();
                await appraisalpage.clickGroundAppraisalOdometerCheckBox();
                await appraisalpage.clickGroundAppraisalConditionDisclosuresCheckBox();
                await appraisalpage.clickGroundAppraisalConfirmAndGroundBtn();

                await browser.sleep(browser.params.sleep.sleep2);

                await utils.logInfo("Is Successfully Grounded message present "+await appraisalpage.isPresentGroundAppraisalSuccessMessage());
                await utils.logInfo("Vehicle was Grounded message present "+await appraisalpage.isPresentGroundAppraisalSuccessDateMessage());
                expect(await appraisalpage.isPresentGroundAppraisalSuccessMessage()).toBeTruthy("Verify Vehicle Successful Grounded message is present");
                expect(await appraisalpage.isPresentGroundAppraisalSuccessDateMessage()).toBeTruthy("Verify Vehicle Successful Grounded date message is present");
                expect(await appraisalpage.getGroundAppraisalSuccessMessageValue()).toContain("Successfully Grounded","Verify Vehicle Successful Grounded message value");
                expect(await appraisalpage.getGroundAppraisalSuccessDateMessageValue()).toContain("This vehicle was Grounded on "+utils.getCurrentDateMonthYear(),"Verify Vehicle Successful Grounded Date message value");
                
                await appraisalpage.clickGroundAppraisalBackBtn();
        
                await utils.logInfo("Verify Grounded text visible on Appraisal screen underneath Price Bar");
                expect(await appraisalpage.isPresentGroundedMsg()).toBeTruthy("Verify 'Grounded' text visible on Appraisal screen underneath Price Bar");
                expect(await appraisalpage.isPresentGroundedAppraisalLabel()).toBeTruthy("Verify 'Grounded' text visible at top center of Appraisal page");
                expect(await appraisalpage.isPresentGroundedCountdownTimer()).toBe(true,"Verify Grounded Countdown timer visible on Appraisal screen underneath Price Bar ");
                expect(await appraisalpage.isPresentGroundVehicleBtn()).toBeFalsy("Verify Ground Vehicle Button is not present after appraisal is grounded");


                //GET OFFER
                expect(await appraisalpage.isPresentGetOfferBtn()).toBeTruthy("Verify the Get Offer button is present");
                expect(await appraisalpage.getOfferBtnText()).toBe(data.screen.getoffer.getofferbtnlabel,"Verify the Get Offer Button Text");

                expect(await appraisalpage.isPresentGetOfferBtnDescription()).toBeTruthy("Verify the Get Offer button descriptive text is present");
                expect(await appraisalpage.getOfferBtnDescription()).toBe(data.screen.getoffer.getofferbtndescriptiontxt,"Verify the Get Offer button descriptive text");
                
                await utils.logInfo("Click on Get Offer Button");
                await appraisalpage.clickGetOfferBtn();
                await utils.logInfo("After Click on Get Offer Button");

                await utils.logInfo("Before Screen Heading Assertion");
                expect(await appraisalpage.isPresentGetOfferScreenHeading()).toBeTruthy("Verify Get Offer Screen Heading is present");
                expect(await appraisalpage.getOfferScreenHeading()).toBe(data.screen.getoffer.getofferscreenheading,"Verify Get Offer Screen Heading");
                await utils.logInfo("Before Screen Title Assertion");
                expect(await appraisalpage.isPresentGetOfferScreenTitle()).toBeTruthy("Verify Get Offer Screen Title is present");
                expect(await appraisalpage.getOfferScreenTitle()).toBe(data.screen.getoffer.getofferscreentitle,"Verify Get Offer Screen Title");

                //Click CheckBox
                await utils.logInfo("Click Terms & Conditions checkbox on Get Offer Screen");
                await appraisalpage.clickGetOfferCheckBox();
        
                //Click on Submit Button
                await utils.logInfo("Click on 'Confirm & Get Offer' Button on the Get Offer Screen");
                await appraisalpage.clickGetOfferSubmitBtn();
        
                await utils.logInfo("Is Successful Msg present : "+await appraisalpage.isPresentGetOfferSuccessMsg());
                expect(await appraisalpage.isPresentGetOfferSuccessMsg()).toBeTruthy("Verify Get Offer is Successfully Submit by Showing 'Successfully Submitted' message");
        
                await utils.logInfo("Is Successful Descripton Msg present : "+ await appraisalpage.isPresentGetOfferSuccessDescriptionMsg());
                expect(await appraisalpage.isPresentGetOfferSuccessDescriptionMsg()).toBeTruthy("Verify Get Offer Successful submission descriptive message is present");
                expect(await appraisalpage.getOfferSuccessDescriptionMsg()).toContain(data.screen.getoffer.getoffersuccessdescriptionmsg,"Verify Get Offer Successful Submission descriptive message");

                await appraisalpage.clickGetOfferBackBtn();
                await utils.logInfo("Is Pending Offer status bar present : "+await appraisalpage.isPresentGetOfferPendingMsgStatusBar());
                expect(await appraisalpage.isPresentGetOfferPendingMsgStatusBar()).toBeTruthy("Verify Appraisal Page Get Offer Pending Msg on Appraisal Status bar is Present");
        
                expect(await appraisalpage.getOfferPendingMsgStatusBar()).toContain(data.screen.getoffer.getofferpendingmsgstatusbar,"Verify Appraisal page Pending Get Offer Message on Status Bar");
                
                //new
                expect(await appraisalpage.isPresentGetOfferBtn()).toBeFalsy("Verify the Get Offer button is not present when Offer is pending");
                await browser.sleep(browser.params.sleep.sleep20);

            }        
        }); //it
    }); //using   

       

}); //describe