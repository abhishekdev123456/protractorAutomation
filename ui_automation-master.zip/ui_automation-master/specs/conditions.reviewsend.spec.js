var loginpage = require('../pages/login.page');
var verifymobilenumberpage = require('../pages/verifymobilenumber.page');
var homepage = require('../pages/home.page');
var myaccountpage = require('../pages/myaccount.page');
var myprofilepage = require('../pages/myprofile.page');
var appraisalpage = require('../pages/appraisal.page');
var usermgmtpage = require('../pages/usermanagement.page');
var edituserpage = require('../pages/edituser.usermgmt.page');
var dealerconsolepage = require('../pages/dealer.console.page');
var dealershippage = require('../pages/dealership.page');
var recommenderpage = require('../pages/recommender.page');
var dealershippage = require('../pages/dealership.page');
var crpage = require('../pages/cr.page');
var utils = require('../utilities/utils');
var testdata = require('../data/test.data.js');
var using = require('jasmine-data-provider');
var path = require("path");

describe('Estimate/Details Condition/Review & Send Test Suite', function () { // ********************** Describe1 *******************************
    browser.manage().timeouts().implicitlyWait(5000);
    browser.driver.manage().window().maximize();
    utils.logInfo("Estimate/Details Condition/Review & Send Test Suite");
    utils.logInfo("TEST RUN : "+"https://autodevteam.testrail.net/index.php?/runs/view/848&group_by=cases:section_id&group_order=asc");
    var count = 0;
    
    beforeEach(async function () {
        await utils.logInfo("Getting Home Page")
        await homepage.get();
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.getCurrentUrl().then(async function (url) {
            await utils.logInfo("Before each : Current Url is "+url);
            await browser.sleep(browser.params.sleep.sleep5);

            if (url == await loginpage.getURL()) {
                utils.logInfo("Sign in since current page is Login page")
                await loginpage.signIn(browser.params.login.superadminuser, browser.params.login.superadminpassword);
                await browser.getCurrentUrl().then(async function (url) {
                    if (url == await verifymobilenumberpage.getUrl()) {
                        await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                        await verifymobilenumberpage.clickRemindme();
                    }//if
                })//then
            }//if
            else if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
            await browser.waitForAngularEnabled(true);

        });

        if(count == 0){
            await homepage.closeAllWalkme();
            count = 1;
        }//if count

    }); //beforeEach    

    afterEach(async function () {
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True
    });    


    it('Verify Condition Disclosure Damage Counts', async function () {
        utils.logInfo('***** TEST CASE : Verify Condition Disclosure Damage Counts');
        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();
        
        await browser.getCurrentUrl().then(async function (url) {
            await utils.logInfo("Before each : Current Url is "+url);
            await browser.sleep(browser.params.sleep.sleep5);

            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();
 
        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();
 
        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        expect(sVIN).toContain(browser.params.vin.validvin,"Verify VIN value on Appraisal page matches expected VIN from test data"); //*** Assertion ***/

        var appraisalYMM = await appraisalpage.getAppraisalYMM();
        await utils.logInfo("Value of Appraisal YMM is " + appraisalYMM);
        await browser.sleep(browser.params.sleep.sleep10);

        var tabCount = "0";
        // var appraisalID = "0";

        //Check Condition Disclosures Body Tab Count is 0
        tabCount = await appraisalpage.getCDBodyTabCount();
        await utils.logInfo("CD Body Tab Count is "+tabCount);
        expect(await tabCount).toBe("0","Verify Condition Disclosures Body Tab Count before any Adjustment is 0");

        //Add 1 damages to each: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other
        await utils.logInfo("Adding 1st Damage: 'Body','Roof','rust','repair'");
        await appraisalpage.selectAdjustmentAppraisalScreen("Body","Roof","rust","repair");

        //Check Condition Disclosures Body Tab Count is 1
        tabCount = await appraisalpage.getCDBodyTabCount();
        await utils.logInfo("CD Body Tab Count is "+tabCount);
        expect(await tabCount).toBe("1","Verify Condition Disclosures Body Tab Count after adding one Adjustment is 1");

        //appraisalID = await appraisalpage.getAppraisalID();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await browser.refresh();

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

        //Add 2nd damage to Body: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other 
        await utils.logInfo("Adding 2nd Damage: 'Body','Roof','scratch','paint'");
        await appraisalpage.selectAdjustmentAppraisalScreen("Body","Roof","scratch","paint");

        //Check Condition Disclosures Bday Tab Count is 2
        tabCount = await appraisalpage.getCDBodyTabCount();
        await utils.logInfo("CD Body Tab Count is "+tabCount);
        expect(await tabCount).toBe("2","Verify Condition Disclosures Body Tab Count after adding two Adjustments is 2");

        // Glass TAB ************************************************************************************************************


        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await browser.refresh();

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

        //Check Condition Disclosures Glass Tab Count is 0
        tabCount = await appraisalpage.getCDGlassTabCount();
        await utils.logInfo("CD Glass Tab Count is "+tabCount);
        expect(await tabCount).toBe("0","Verify Condition Disclosures Glass Tab Count before any Adjustment is 0");

        //Add 1 damages to each: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other
        await utils.logInfo("Adding 1st Damage: 'Glass','Rear Window','replace','none'");
        await appraisalpage.selectAdjustmentAppraisalScreen("Glass","Rear Window","replace","none");

        //Check Condition Disclosures Glass Tab Count is 1
        tabCount = await appraisalpage.getCDGlassTabCount();
        await utils.logInfo("CD Glass Tab Count is "+tabCount);
        expect(await tabCount).toBe("1","Verify Condition Disclosures Glass Tab Count after adding one Adjustment is 1");

        //appraisalID = await appraisalpage.getAppraisalID();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        //await appraisalpage.getAppraisalByID(appraisalID);
        await browser.refresh();

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

        //Add 2nd damage to Glass: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other 
        await utils.logInfo("Adding 2nd Damage: 'Glass','Rear Window','cracked','none'");
        await appraisalpage.selectAdjustmentAppraisalScreen("Glass","Rear Window","cracked","none");

        //Check Condition Disclosures Glass Tab Count is 2
        tabCount = await appraisalpage.getCDGlassTabCount();
        await utils.logInfo("CD Glass Tab Count is "+tabCount);
        expect(await tabCount).toBe("2","Verify Condition Disclosures Glass Tab Count after adding two Adjustments is 2");



    // Interior TAB ************************************************************************************************************


        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await browser.refresh();

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

        //Check Condition Disclosures Interior Tab Count is 0
        tabCount = await appraisalpage.getCDInteriorTabCount();
        await utils.logInfo("CD Interior Tab Count is "+tabCount);
        expect(await tabCount).toBe("0","Verify Condition Disclosures Interior Tab Count before any Adjustment is 0");

        //Add 1 damages to each: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other
        await utils.logInfo("Adding 1st Damage: 'Interior','Rear Door Panel-Left','scratched','none'");
        await appraisalpage.selectAdjustmentAppraisalScreen("Interior","Rear Door Panel-Left","scratched","none");

        //Check Condition Disclosures Interior Tab Count is 1
        tabCount = await appraisalpage.getCDInteriorTabCount();
        await utils.logInfo("CD Interior Tab Count is "+tabCount);
        expect(await tabCount).toBe("1","Verify Condition Disclosures Interior Tab Count after adding one Adjustment is 1");

        //appraisalID = await appraisalpage.getAppraisalID();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        //await appraisalpage.getAppraisalByID(appraisalID);
        await browser.refresh();

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

        //Add 2nd damage to Glass: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other 
        await utils.logInfo("Adding 2nd Damage: 'Interior','Rear Door Panel-Left','worn','none'");
        await appraisalpage.selectAdjustmentAppraisalScreen("Interior","Rear Door Panel-Left","worn","none");

        //Check Condition Disclosures Interior Tab Count is 2
        tabCount = await appraisalpage.getCDInteriorTabCount();
        await utils.logInfo("CD Interior Tab Count is "+tabCount);
        expect(await tabCount).toBe("2","Verify Condition Disclosures Interior Tab Count after adding two Adjustments is 2");

    // Tire/Wheel TAB ************************************************************************************************************


    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    //Check Condition Disclosures Interior Tab Count is 0
    tabCount = await appraisalpage.getCDTireWheelTabCount();
    await utils.logInfo("CD Tire/Wheel Tab Count is "+tabCount);
    expect(await tabCount).toBe("0","Verify Condition Disclosures Tire/Wheel Tab Count before any Adjustment is 0");

    //Add 1 damages to each: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other
    await utils.logInfo("Adding 1st Damage: 'Tire/Wheel','Front Right','0 - 3/32','replace wheel'");
    await appraisalpage.selectAdjustmentAppraisalScreen("Tire/Wheel","Front Right","0 - 3/32","replace wheel");
    await browser.sleep(browser.params.sleep.sleep10);        


    //Check Condition Disclosures Interior Tab Count is 1
    tabCount = await appraisalpage.getCDTireWheelTabCount();
    await utils.logInfo("CD Tire/Wheel Tab Count is "+tabCount);
    expect(await tabCount).toBe("2","Verify Condition Disclosures Tire/Wheel Tab Count after adding one Adjustment is 2");

    //appraisalID = await appraisalpage.getAppraisalID();

    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    //await appraisalpage.getAppraisalByID(appraisalID);
    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    //Add 2nd damage to Glass: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other 
    await utils.logInfo("Adding 2nd Damage: 'Tire/Wheel','Rear Right','4/32 - 7/32','oxidized'");
    await appraisalpage.selectAdjustmentAppraisalScreen("Tire/Wheel","Rear Right","4/32 - 7/32","oxidized");
    await browser.sleep(browser.params.sleep.sleep10);        


    //Check Condition Disclosures Interior Tab Count is 2
    tabCount = await appraisalpage.getCDTireWheelTabCount();
    await utils.logInfo("CD Tire/Wheel Tab Count is "+tabCount);
    expect(await tabCount).toBe("4","Verify Condition Disclosures Tire/Wheel Tab Count after adding two Adjustments is 4");

    // Lights TAB ************************************************************************************************************


    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    //Check Condition Disclosures Interior Tab Count is 0
    tabCount = await appraisalpage.getCDLightsTabCount();
    await utils.logInfo("CD Lights Tab Count is "+tabCount);
    expect(await tabCount).toBe("0","Verify Condition Disclosures Lights Tab Count before any Adjustment is 0");

    //Add 1 damages to each: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other
    await utils.logInfo("Adding 1st Damage: 'Warning Lights','Battery','none','none'");
    await appraisalpage.selectAdjustmentAppraisalScreen("Warning Lights","Battery","none","none");

    //Check Condition Disclosures Lights Tab Count is 1
    tabCount = await appraisalpage.getCDLightsTabCount();
    await utils.logInfo("CD Lights Tab Count is "+tabCount);
    expect(await tabCount).toBe("1","Verify Condition Disclosures Lights Tab Count after adding one Adjustment is 1");

    //appraisalID = await appraisalpage.getAppraisalID();

    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    //await appraisalpage.getAppraisalByID(appraisalID);
    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    //Add 2nd damage to Glass: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other 
    await utils.logInfo("Adding 2nd Damage: 'Warning Lights','Airbag/SRS','none','none'");
    await appraisalpage.selectAdjustmentAppraisalScreen("Warning Lights","Airbag/SRS","none","none");

    //Check Condition Disclosures Lights Tab Count is 2
    tabCount = await appraisalpage.getCDLightsTabCount();
    await utils.logInfo("CD Lights Tab Count is "+tabCount);
    expect(await tabCount).toBe("2","Verify Condition Disclosures Lights Tab Count after adding two Adjustments is 2");    

    // Mechanical TAB ************************************************************************************************************


    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    //Check Condition Disclosures Mechanical Tab Count is 0
    tabCount = await appraisalpage.getCDMechanicalTabCount();
    await utils.logInfo("CD Mechanical Tab Count is "+tabCount);
    expect(await tabCount).toBe("0","Verify Condition Disclosures Mechanical Tab Count before any Adjustment is 0");

    //Add 1 damages to each: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other
    await utils.logInfo("Adding 1st Damage: 'Mechanical','Oil Leak','none','none'");
    await appraisalpage.selectAdjustmentAppraisalScreen("Mechanical","Oil Leak","none","none");

    //Check Condition Disclosures Mechanical Tab Count is 1
    tabCount = await appraisalpage.getCDMechanicalTabCount();
    await utils.logInfo("CD Mechanical Tab Count is "+tabCount);
    expect(await tabCount).toBe("1","Verify Condition Disclosures Mechanical Tab Count after adding one Adjustment is 1");

    //appraisalID = await appraisalpage.getAppraisalID();

    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    //await appraisalpage.getAppraisalByID(appraisalID);
    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    //Add 2nd damage to Mechanical: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other 
    await utils.logInfo("Adding 2nd Damage: 'Mechanical','Brakes','none','none'");
    await appraisalpage.selectAdjustmentAppraisalScreen("Mechanical","Brakes","none","none");

    //Check Condition Disclosures Lights Tab Count is 2
    tabCount = await appraisalpage.getCDMechanicalTabCount();
    await utils.logInfo("CD Mechanical Tab Count is "+tabCount);
    expect(await tabCount).toBe("2","Verify Condition Disclosures Mechanical Tab Count after adding two Adjustments is 2");     
    
    
    // Aftermarket TAB ************************************************************************************************************


    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    //Check Condition Disclosures Aftermarket Tab Count is 0
    tabCount = await appraisalpage.getCDAfterMarketTabCount();
    await utils.logInfo("CD Aftermarket Tab Count is "+tabCount);
    expect(await tabCount).toBe("0","Verify Condition Disclosures Aftermarket Tab Count before any Adjustment is 0");

    //Add 1 damages to each: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other
    await utils.logInfo("Adding 1st Damage: 'Aftermarket','Stereo','none','none'");
    await appraisalpage.selectAdjustmentAppraisalScreen("Aftermarket","Stereo","none","none");

    //Check Condition Disclosures Aftermarket Tab Count is 1
    tabCount = await appraisalpage.getCDAfterMarketTabCount();
    await utils.logInfo("CD Aftermarket Tab Count is "+tabCount);
    expect(await tabCount).toBe("1","Verify Condition Disclosures Aftermarket Tab Count after adding one Adjustment is 1");

    //appraisalID = await appraisalpage.getAppraisalID();

    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    //await appraisalpage.getAppraisalByID(appraisalID);
    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    //Add 2nd damage to Aftermarket: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other 
    await utils.logInfo("Adding 2nd Damage: 'Aftermarket','Spoiler','none','none'");
    await appraisalpage.selectAdjustmentAppraisalScreen("Aftermarket","Spoiler","none","none");

    //Check Condition Disclosures Aftermarket Tab Count is 2
    tabCount = await appraisalpage.getCDAfterMarketTabCount();
    await utils.logInfo("CD Aftermarket Tab Count is "+tabCount);
    expect(await tabCount).toBe("2","Verify Condition Disclosures Aftermarket Tab Count after adding two Adjustments is 2");  
    
    
    // Other TAB ************************************************************************************************************


    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    //Check Condition Disclosures Other Tab Count is 0
    tabCount = await appraisalpage.getCDOtherTabCount();
    await utils.logInfo("CD Lights Tab Count is "+tabCount);
    expect(await tabCount).toBe("0","Verify Condition Disclosures Lights Tab Count before any Adjustment is 0");

    //Add 1 damages to each: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other
    await utils.logInfo("Adding 1st Damage: 'Other','Smoke/Odor','none','none'");
    await appraisalpage.selectAdjustmentAppraisalScreen("Other","Smoke/Odor","none","none");

    //Check Condition Disclosures Other Tab Count is 1
    tabCount = await appraisalpage.getCDOtherTabCount();
    await utils.logInfo("CD Other Tab Count is "+tabCount);
    expect(await tabCount).toBe("1","Verify Condition Disclosures Other Tab Count after adding one Adjustment is 1");

    //appraisalID = await appraisalpage.getAppraisalID();

    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    //await appraisalpage.getAppraisalByID(appraisalID);
    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    //Add 2nd damage to Other: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other 
    await utils.logInfo("Adding 2nd Damage: 'Other','Medium Rust','none','none'");
    await appraisalpage.selectAdjustmentAppraisalScreen("Other","Medium Rust","none","none");

    //Check Condition Disclosures Other Tab Count is 2
    tabCount = await appraisalpage.getCDOtherTabCount();
    await utils.logInfo("CD Other Tab Count is "+tabCount);
    expect(await tabCount).toBe("2","Verify Condition Disclosures Other Tab Count after adding two Adjustments is 2");   

    await browser.sleep(browser.params.sleep.sleep10);        

    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    });//it


    it('Verify one Alert message is displayed for multiple damages', async function () {
        utils.logInfo("***** TEST CASE : "+"Verify one Alert message is displayed for multiple damages");
        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();
        
        await browser.getCurrentUrl().then(async function (url) {
            await utils.logInfo("Before each : Current Url is "+url);
            await browser.sleep(browser.params.sleep.sleep5);

            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validlandrovervin + " into New Appraisal Window");
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validlandrovervin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        expect(sVIN).toContain(browser.params.vin.validlandrovervin,"Verify VIN value on Appraisal page matches expected VIN from test data"); //*** Assertion ***/

        var appraisalYMM = await appraisalpage.getAppraisalYMM();
        await utils.logInfo("Value of Appraisal YMM is " + appraisalYMM);
        await browser.sleep(browser.params.sleep.sleep10);

        // Adding Adjustment
        await utils.logInfo("Adding Adjustment : 'Other','Open Recalls','none','none'");
        await appraisalpage.selectAdjustmentAppraisalScreen("Other","Open Recalls","none","none");

        //Verify Alert Message Displayed
        var alertMsgStatus = await appraisalpage.isPresentAlertMsg();
        await utils.logInfo("Verify Alert Message displayed when user select 'Other - Open Recalls': "+alertMsgStatus);
        expect(alertMsgStatus).toBe(true, "Verify Alert Message is Present when user select 'Other - Open Recalls' Adjustment");

        //Verify Alert Indicator Displayed
        var alertIndicator = await appraisalpage.isPresentCDAlertIndicator();
        await utils.logInfo("Verify Red Alert Indicator (exclaimation sign) displayed next on Price Bar when user select 'Other - Open Recalls' : "+alertIndicator);
        expect(alertIndicator).toBe(true, "Verify Red Alert Indicator (exclaimation sign) displayed next on Price Bar when user select 'Other - Open Recalls' ");

        // Add Again
        await utils.logInfo("Add Adjustment : 'Other','Salvage','none','none'");
        await appraisalpage.selectAdjustmentAppraisalScreen("Other","Salvage","none","none");

        //Verify Alert Message Displayed
        var alertMsgStatus = await appraisalpage.isPresentAlertMsg();
        await utils.logInfo("Verify Alert Message displayed when user select 'Other - Salvage': "+alertMsgStatus);
        expect(alertMsgStatus).toBe(true, "Verify Alert Message is present when user select 'Other - Salvage'");
        
        //Verify only one Alert message is present
        var alertCount = await appraisalpage.getAlertMsgCount();
        await utils.logInfo("Number of Alert Message(s) : "+alertCount);
        expect(await alertCount).toBe(1,"Verify only one Alert message is present");

        // Remove Adjustment
        await utils.logInfo("Removing Adjustment : 'Other','Salvage','none','none'");
        await appraisalpage.selectAdjustmentAppraisalScreen("Other","Salvage","none","none");

        //Verify Alert Message Displayed
        var alertMsgStatus = await appraisalpage.isPresentAlertMsg();
        await utils.logInfo("Verify Alert Message still displayed when user unselect 'Other - Salvage' as 'Other - Open Recalls' is still selected : "+alertMsgStatus);
        expect(alertMsgStatus).toBe(true, "Verify Alert Message still displayed when user unselect 'Other - Salvage' as 'Other - Open Recalls' is still selected");

        //Verify Alert Indicator Displayed
        alertIndicator = await appraisalpage.isPresentCDAlertIndicator();
        await utils.logInfo("Verify Red Alert Indicator (exclaimation sign) displayed next on Price Bar when user remove one of the Alert triggering damage: "+alertIndicator);
        expect(alertIndicator).toBe(true, "Verify Red Alert Indicator (exclaimation sign) displayed next on Price Bar when user remove one of the Alert triggering damage");

        await browser.sleep(browser.params.sleep.sleep10);        
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    });//it


    using(testdata.alerts, function (data, description) {
        it('Verify Alerts for Tab : '+data.mainadjustment+'-'+JSON.stringify(data.adjustments)+'-'+data.vin+' alert message(s)', async function () {
            utils.logInfo("***** TEST CASE : "+"Verify Alerts: "+data.mainadjustment+"-"+JSON.stringify(data.adjustments)+"-"+data.vin+" alert message(s)");
            await browser.refresh();
            await utils.logInfo("Click Start Appraisal Button");
            await homepage.clickStartAppraisalBtn();
            
            await browser.getCurrentUrl().then(async function (url) {
                await utils.logInfo("Before each : Current Url is "+url);
                await browser.sleep(browser.params.sleep.sleep5);

                if (url == await verifymobilenumberpage.getUrl()) {
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            });

            await homepage.clickNewAppraisalVINTab();
            await utils.logInfo("Enter VIN " + data.vin + " into New Appraisal Window");
            var EC = protractor.ExpectedConditions;
            browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
            await homepage.setVin(data.vin);
            await utils.logInfo("Click on the VIN Search button");
            await homepage.clickVinSearch();
    
            await utils.logInfo("Click on First Trim");
            await homepage.clickFirstTrim();

            await utils.logInfo("Disable Wait for Angular");
            await browser.waitForAngularEnabled(false); // *** Angular Enabled False

            await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
            var sVIN = await homepage.getAppraisalVIN();
    
            await utils.logInfo("Value of Appraisal VIN is " + sVIN);
            await utils.logInfo("Verify Appraisal VIN matching expected VIN");
            expect(sVIN).toContain(data.vin,"Verify VIN value on Appraisal page matches expected VIN from test data"); //*** Assertion ***/

            var appraisalYMM = await appraisalpage.getAppraisalYMM();
            await utils.logInfo("Value of Appraisal YMM is " + appraisalYMM);

            var appraisalID = await appraisalpage.getAppraisalID();
            await utils.logInfo("Appraisal ID is "+appraisalID);

            for (adjustment in data.adjustments){
                utils.logInfo("Adjustment key is "+adjustment);
                utils.logInfo("data.adjustments value is "+JSON.stringify(data.adjustments));
                utils.logInfo("Adjustment value is "+data.adjustments[adjustment]);

                // Add Adjustment
                await utils.logInfo("Add Adjustment : "+data.mainadjustment+"-"+data.adjustments[adjustment]);
                await appraisalpage.selectAdjustmentAppraisalScreen(data.mainadjustment,data.adjustments[adjustment],"none","none");

                //Verify Alert Message Displayed
                var alertMsgStatus = await appraisalpage.isPresentAlertMsg();
                await utils.logInfo("Verify Alert Message displayed when user select "+data.mainadjustment+"-"+data.adjustments[adjustment]+" : "+alertMsgStatus);
                expect(alertMsgStatus).toBe(true, "Verify Alert Message displayed when user select "+data.mainadjustment+"-"+data.adjustments[adjustment]+" : "+alertMsgStatus);

                //Verify Alert Indicator Displayed
                var alertIndicator = await appraisalpage.isPresentCDAlertIndicator();
                await utils.logInfo("Verify Red Alert Indicator (exclaimation sign) displayed next on Price Bar when user select "+data.mainadjustment+"-"+data.adjustments[adjustment]+" : "+alertIndicator);
                expect(alertIndicator).toBe(true, "Verify Red Alert Indicator (exclaimation sign) displayed next on Price Bar when user select "+data.mainadjustment+"-"+data.adjustments[adjustment]+" : "+alertIndicator);

                //Verify Ground action not displayed
                var groundVehicleBtnStatus = await appraisalpage.isPresentGroundVehicleBtn();
                await utils.logInfo("Verify 'Ground' action option gets unavialble under Review & Send Disabled for "+data.mainadjustment+"-"+data.adjustments[adjustment]);
                expect(groundVehicleBtnStatus).toBe(false, "Verify 'Ground' action option gets unavialble under Review & Send Disabled for "+data.mainadjustment+"-"+data.adjustments[adjustment]);

                //Verify Chat Windows Open when click on Start Chat now
                await utils.logInfo("Click on Start Chat now link inside Alert message");
                await appraisalpage.openChatWindowFromAlertMsg();
                var chatWindowStatus = await appraisalpage.isPresentChatWindow();
                await utils.logInfo("Is present Chat Window :"+chatWindowStatus);
                expect(chatWindowStatus).toBe(true,"Verify Chat Windows Open when click on Start Chat now link inside Alert message")
                if(chatWindowStatus){
                    await appraisalpage.closeChatWindow();
                    expect(await appraisalpage.isPresentChatWindow()).toBe(false,"Verify Chat Windows gets Closed when user click on close button of Chat window");
                    expect(await appraisalpage.isPresentAlertMsg()).toBe(false,"Verify Alert Message gets closed when user click on 'start a chat now' inside Alert message")
                    expect(await appraisalpage.isPresentCDAlertIndicator()).toBe(true,"Verify Alert red exclaimation indicator continue to show when Alert Message gets closed")
                }

                // Remove Adjustment and Add Again
                await utils.logInfo("Remove Adjustment : "+data.mainadjustment+"-"+data.adjustments[adjustment]);
                await appraisalpage.selectAdjustmentAppraisalScreen(data.mainadjustment,data.adjustments[adjustment],"none","none");

                await utils.logInfo("Add Adjustment : "+data.mainadjustment+"-"+data.adjustments[adjustment]);
                await appraisalpage.selectAdjustmentAppraisalScreen(data.mainadjustment,data.adjustments[adjustment],"none","none");

                //Close the Alert Message
                await utils.logInfo("Close the Alert Message");
                await appraisalpage.closeAlertMsg();

                //Reopen the Appraisal
                await utils.logInfo("Reopens the appraisal by refreshing the browser");
                await browser.refresh();

                //Verify Alert Message still available in the Appraisal
                alertMsgStatus = await appraisalpage.isPresentAlertMsg();
                await utils.logInfo("Verify Alert Message displayed when user select "+data.mainadjustment+"-"+data.adjustments[adjustment]+" : "+alertMsgStatus);
                expect(alertMsgStatus).toBe(true, "Verify Alert Message displayed when user select "+data.mainadjustment+"-"+data.adjustments[adjustment]+" : "+alertMsgStatus);

                // Remove Adjustment
                await utils.logInfo("Remove Adjustment : "+data.mainadjustment+"-"+data.adjustments[adjustment]);
                await appraisalpage.selectAdjustmentAppraisalScreen(data.mainadjustment,data.adjustments[adjustment],"none","none");

                //Verify Alert Message not Displayed
                alertMsgStatus = await appraisalpage.isPresentAlertMsg();
                await utils.logInfo("Verify Alert Message gets disappeared when user unselect "+data.mainadjustment+"-"+data.adjustments[adjustment]+" : "+alertMsgStatus);
                expect(alertMsgStatus).toBe(false, "Verify Alert Message gets disappeared when user unselect "+data.mainadjustment+"-"+data.adjustments[adjustment]+" : "+alertMsgStatus);

                //Verify Alert Indicator not displayed
                alertIndicator = await appraisalpage.isPresentCDAlertIndicator();
                await utils.logInfo("Verify Red Alert Indicator (exclaimation sign) gets disappeared on Price Bar when user unselect "+data.mainadjustment+"-"+data.adjustments[adjustment]+" : "+alertIndicator);
                expect(alertIndicator).toBe(false, "Verify Red Alert Indicator (exclaimation sign) gets disappeared on Price Bar when user unselect "+data.mainadjustment+"-"+data.adjustments[adjustment]+" : "+alertIndicator);

                //Verify Ground action displayed
                groundVehicleBtnStatus = await appraisalpage.isPresentGroundVehicleBtn();
                await utils.logInfo("Verify 'Ground' action option gets available under Review & Send section when user unselect "+data.mainadjustment+"-"+data.adjustments[adjustment]);
                expect(groundVehicleBtnStatus).toBe(true, "Verify 'Ground' action option gets available under Review & Send section when user unselect "+data.mainadjustment+"-"+data.adjustments[adjustment]);

            }//for

            await browser.sleep(browser.params.sleep.sleep10);        
            await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        });//it
    });//using

    it('Verify user is unable to Ground appraisal with less than 11 photos & Color selection under Review & Section', async function () {
        utils.logInfo("***** TEST CASE : Verify user is unable to Ground appraisal with less than 11 photos & Color selection under Review & Section *****");

        //await browser.get(browser.params.env.url + "/report/active");
        await browser.refresh();

        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        //Click on Ground Vehicle
        await utils.logInfo("Click on Ground Vehicle Button");
        await appraisalpage.clickGroundVehicleBtn();

        // Verify Error messages displayed then vehicle can't be grounded
        var MessageWebElement1 = element(by.xpath("//*[text()='Unable to ground the vehicle until the following are completed']"));
        var MessageWebElement2 = element(by.xpath("//*[text()='Upload 11 photos']"));
        var MessageWebElement3 = element(by.xpath("//*[text()='Choose an exterior color']"));
        var MessageWebElement4 = element(by.xpath("//*[text()='Choose an interior color']"));

        expect(await MessageWebElement1.isPresent()).toBe(true,"Verify following message display - 'Unable to ground the vehicle until the following are completed'");
        expect(await MessageWebElement2.isPresent()).toBe(true,"Verify following message display - 'Upload 11 photos'");
        expect(await MessageWebElement3.isPresent()).toBe(true,"Verify following message display - 'Choose an exterior color'");
        expect(await MessageWebElement4.isPresent()).toBe(true,"Verify following message display - 'Choose an interior color'");

        //Upload Photos
        await utils.logInfo("Upload Photos");
        await appraisalpage.uploadImages();

        await browser.sleep(browser.params.sleep.sleep20);
        await appraisalpage.clickLeftPhotoGalleryBtn();
        await browser.sleep(browser.params.sleep.sleep10);

        expect(await MessageWebElement1.isPresent()).toBe(true,"Verify following message display - 'Unable to ground the vehicle until the following are completed'");
        expect(await MessageWebElement2.isPresent()).toBe(false,"Verify following message display - 'Upload 11 photos'");
        expect(await MessageWebElement3.isPresent()).toBe(true,"Verify following message display - 'Choose an exterior color'");
        expect(await MessageWebElement4.isPresent()).toBe(true,"Verify following message display - 'Choose an interior color'");

        //Select Exterior Color
        await appraisalpage.navigateToTop();
        await utils.logInfo("Click Exterior Color Button");
        await appraisalpage.clickExteriorColorBtn();

        await utils.logInfo("Select Black Exterior Color");
        await appraisalpage.clickExteriorBlackColorBtn();

        await browser.sleep(browser.params.sleep.sleep10);

        //Verify
        expect(await MessageWebElement1.isPresent()).toBe(true,"Verify following message display - 'Unable to ground the vehicle until the following are completed'");
        expect(await MessageWebElement2.isPresent()).toBe(false,"Verify following message display - 'Upload 11 photos'");
        expect(await MessageWebElement3.isPresent()).toBe(false,"Verify following message display - 'Choose an exterior color'");
        expect(await MessageWebElement4.isPresent()).toBe(true,"Verify following message display - 'Choose an interior color'");

        //Select Interior Color
        await utils.logInfo("Click Interior Color Button");
        await appraisalpage.clickInteriorColorBtn();

        await utils.logInfo("Select Black Interior Color");
        await appraisalpage.clickInteriorBlackColorBtn();

        await browser.sleep(browser.params.sleep.sleep10);

        //Verify
        expect(await MessageWebElement1.isPresent()).toBe(false,"Verify following message display - 'Unable to ground the vehicle until the following are completed'");
        expect(await MessageWebElement2.isPresent()).toBe(false,"Verify following message display - 'Upload 11 photos'");
        expect(await MessageWebElement3.isPresent()).toBe(false,"Verify following message display - 'Choose an exterior color'");
        expect(await MessageWebElement4.isPresent()).toBe(false,"Verify following message display - 'Choose an interior color'");

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True


    }); //it

    it('Aftermarket: Add Photos. Verify photos are saved and display on CR & PDF', async function () {
        utils.logInfo("***** TEST CASE : Aftermarket: Add Photos. Verify photos are saved and display on CR & PDF *****");

        //await browser.get(browser.params.env.url + "/report/active");
        await browser.refresh();

        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        //Click on Aftermarket Tab
        await appraisalpage.selectCDAfterMarketTab();
    
        //Verify 'Add Modification Photo' link is available
        var modificationPhotoBtnStatus = await appraisalpage.isPresentAftermarketPhotoButton();
        await utils.logInfo("Verify 'Add Modification Photo' link is available : "+modificationPhotoBtnStatus);
        expect(modificationPhotoBtnStatus).toBeTruthy("Verify 'Add Modification Photo' link is available");

        //Upload Modification Photos #1 to Aftermarket
        await appraisalpage.navigateToTop();
        await appraisalpage.uploadImage("car-1.jpg");

        //Verify 'Add Modification Photo' link is 'available'
        await browser.sleep(browser.params.sleep.sleep5);
        var modificationPhotoBtnStatus = await appraisalpage.isPresentAftermarketPhotoButton();
        await utils.logInfo("Verify 'Add Modification Photo' link is available : "+modificationPhotoBtnStatus);
        expect(modificationPhotoBtnStatus).toBeTruthy("Verify 'Add Modification Photo' link is available");

        //Upload Modification Photos #2 to Aftermarket
        await appraisalpage.navigateToTop();
        await appraisalpage.uploadImage("car-2.jpg");

        //Verify 'Add Modification Photo' link is 'available'
        await browser.sleep(browser.params.sleep.sleep5);
        var modificationPhotoBtnStatus = await appraisalpage.isPresentAftermarketPhotoButton();
        await utils.logInfo("Verify 'Add Modification Photo' link is available : "+modificationPhotoBtnStatus);
        expect(modificationPhotoBtnStatus).toBeTruthy("Verify 'Add Modification Photo' link is available");

        //Upload Modification Photos #3 to Aftermarket
        await appraisalpage.navigateToTop();
        await appraisalpage.uploadImage("car-3.jpg");

        //Verify 'Add Modification Photo' link is 'unavailable'
        await browser.sleep(browser.params.sleep.sleep10);
        var modificationPhotoBtnStatus = await appraisalpage.isPresentAftermarketPhotoButton();
        await utils.logInfo("Verify 'Add Modification Photo' link is unavailable : "+modificationPhotoBtnStatus);
        expect(modificationPhotoBtnStatus).toBeFalsy("Verify 'Add Modification Photo' link is unavailable");

        var noOfImages = await appraisalpage.getCDAfterMarketPhotosCount();
        await utils.logInfo("Number of Images under Aftermarket tab is "+noOfImages);
        expect(await noOfImages).toBe(3,"Verify number of Images under Aftermarket tab");

        //Get Consumer CR Through Appraisal Menu
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Verify 'Consumer Appraisal' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentConsumerAppraisalMenuItem()).toBeTruthy("Verify 'Consumer Appraisal' Menu item present in Appraisal Menu"); //Assertion
        
        await utils.logInfo("Click on Consumer Appraisal Report menu item");
        await appraisalpage.clickConsumerAppraisalMenuItem();
        await browser.sleep(browser.params.sleep.sleep10);
        await utils.logInfo("Verifying the loaded page is Consumer CR");
        expect(await browser.getCurrentUrl()).toContain("/report?type=consumer","Verify clicking on Consumer Appraisal Report link under Appraisal menu opens the Consumer CR page");//Assertion

        var crPhotosCount = await crpage.getCRPhotosCount();
        await utils.logInfo("Number of photos on CR is "+crPhotosCount);
        expect(await crPhotosCount).toBe(3,"Verify number of uploaded aftermarket photos in Consumer CR");

        //Back to Appraisal
        await utils.logInfo("Click on Back to Appraisal Link");
        await crpage.clickBackToAppraisalLink();
        await browser.sleep(browser.params.sleep.sleep5);

        //Get Dealer CR Through Appraisal Menu
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();        
        await utils.logInfo("Verify 'Dealership Appraisal' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentDealershipAppraisalMenuItem()).toBeTruthy("Verify 'Dealer Condition Report' Menu item present in Appraisal Menu");
        
        await utils.logInfo("Click on Dealer Condition Report menu item");
        await appraisalpage.clickDealerAppraisalMenuItem();
        await browser.sleep(browser.params.sleep.sleep10);
        await utils.logInfo("Verifying the loaded page is Dealer CR");
        expect(await browser.getCurrentUrl()).toContain("/report?type=dealer","Verify clicking on Dealer Condition Report link under Appraisal menu opens the Dealer CR page"); //Assertion

        crPhotosCount = await crpage.getCRPhotosCount();
        await utils.logInfo("Number of photos on CR is "+crPhotosCount);
        expect(await crPhotosCount).toBe(3,"Verify number of uploaded aftermarket photos in Dealer CR");
        
        //Back to Appraisal
        await utils.logInfo("Click on Back to Appraisal Link");
        await crpage.clickBackToAppraisalLink();
        await browser.sleep(browser.params.sleep.sleep5);

        //Click on Aftermarket Tab
        await appraisalpage.selectCDAfterMarketTab();

        //Verify 'Add Modification Photo' link is available
        var modificationPhotoBtnStatus = await appraisalpage.isPresentAftermarketPhotoButton();
        await utils.logInfo("Verify 'Add Modification Photo' link is available : "+modificationPhotoBtnStatus);
        expect(modificationPhotoBtnStatus).toBeFalsy("Verify 'Add Modification Photo' link is unavailable since already 3 photos were uploaded");

        noOfImages = await appraisalpage.getCDAfterMarketPhotosCount();
        await utils.logInfo("Number of Images under Aftermarket tab is "+noOfImages);
        expect(await noOfImages).toBe(3,"Verify number of Images under Aftermarket tab");

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    }); //it

    it('Review & Send: Verify View Condition Report link under Review & Send directs to the CR', async function () {
        utils.logInfo("***** TEST CASE : Review & Send: View Condition Report link directs to the CR *****");

        await browser.refresh();

        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        //Collapse Select Action
        await utils.logInfo("Collapse 'Select Action'");
        await appraisalpage.clickSelectAction();

        //Verify View Condition Report link available Under Review and Send Screen
        var viewCRLinkStatus = await appraisalpage.isPresentViewConditionReportLinkReviewSendScreen();
        await utils.logInfo("Verify View Condition Report link available Under Review and Send Section : "+viewCRLinkStatus);
        expect(viewCRLinkStatus).toBeTruthy("Verify View Condition Report link available Under Review and Send Section in Consumer mode")

        //Click on View Condition Report
        await appraisalpage.clickViewConditionReportLinkReviewSendScreen();

        //Verify Dealer CR Opens 
        await browser.sleep(browser.params.sleep.sleep10);
        await utils.logInfo("Verifying the loaded page is Dealer CR");
        expect(await browser.getCurrentUrl()).toContain("/report?type=dealer","Verify clicking on Dealer Condition Report link under Appraisal menu opens the Dealer CR page"); //Assertion

        //Go back to Appraisal
        await utils.logInfo("Click on Back to Appraisal Link");
        await crpage.clickBackToAppraisalLink();
        await browser.sleep(browser.params.sleep.sleep5);

        //Click on Person Icon to open Consumer Mode
        await appraisalpage.clickAppraisalConsumerDealerMode();

        //Collapse Select Action
        await utils.logInfo("Collapse 'Select Action'");
        await appraisalpage.clickSelectAction();

        //Verify View Condition Report link available Under Review and Send Screen
        viewCRLinkStatus = await appraisalpage.isPresentViewConditionReportLinkReviewSendScreen();
        await utils.logInfo("Verify View Condition Report link available Under Review and Send Section : "+viewCRLinkStatus);
        expect(viewCRLinkStatus).toBeTruthy("Verify View Condition Report link available Under Review and Send Section in Consumer mode")

        //Click on View Condition Report
        await appraisalpage.clickViewConditionReportLinkReviewSendScreen();

        //Verify Consumer CR Opens up
        await browser.sleep(browser.params.sleep.sleep10);
        await utils.logInfo("Verifying the loaded page is Consumer CR");
        expect(await browser.getCurrentUrl()).toContain("/report?type=consumer","Verify clicking on Consumer Appraisal Report link under Appraisal menu opens the Consumer CR page");//Assertion

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True
        

    }); //it

    using(testdata.branding, function (data, description) {

        it('Get Instant Offer: Verify Get True Cash Offer  (or Get Accu-Trade Instant Offer button)[testdata.branding]', async function () {
            utils.logInfo("***** TEST CASE : Get Instant Offer: Verify Get True Cash Offer  (or Get Accu-Trade Instant Offer button) *****");

            //await browser.get(browser.params.env.url + "/report/active");
            await browser.refresh();

            await utils.logInfo("Click Start Appraisal Button");
            await homepage.clickStartAppraisalBtn();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    //await expect(await url).toBe(await verifymobilenumberpage.getUrl()); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            });

            await homepage.clickNewAppraisalVINTab();
            await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

            var EC = protractor.ExpectedConditions;
            browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
            await homepage.setVin(browser.params.vin.validvin);
            await utils.logInfo("Click on the VIN Search button");
            await homepage.clickVinSearch();

            await utils.logInfo("Click on First Trim");
            await homepage.clickFirstTrim();

            await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
            await browser.sleep(browser.params.sleep.sleep10);

            await utils.logInfo("Disable Wait for Angular");
            await browser.waitForAngularEnabled(false); // *** Angular Enabled False

            await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
            var sVIN = await homepage.getAppraisalVIN();

            await utils.logInfo("Enable Wait for Angular");
            await browser.waitForAngularEnabled(true); // *** Angular Enabled True

            await utils.logInfo("Value of Appraisal VIN is " + sVIN);
            await utils.logInfo("Verify Appraisal VIN matching expected VIN");
            await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
            await browser.sleep(browser.params.sleep.sleep10);

            await browser.waitForAngularEnabled(false); // *** Angular Disabled

            //Select Interior and Exterior Color
            //await appraisalpage.navigateToCommonProblems();
            await utils.logInfo("Click Exterior Color Button");
            await appraisalpage.clickExteriorColorBtn();

            await utils.logInfo("Select Black Exterior Color");
            await appraisalpage.clickExteriorBlackColorBtn();

            await utils.logInfo("Click Interior Color Button");
            await appraisalpage.clickInteriorColorBtn();

            await utils.logInfo("Select Black Interior Color");
            await appraisalpage.clickInteriorBlackColorBtn();

            //Upload Photos
            await utils.logInfo("Upload Photos");
            await appraisalpage.uploadImages();

            await browser.sleep(browser.params.sleep.sleep20);
            await appraisalpage.clickLeftPhotoGalleryBtn();

            //Click on Ground Vehicle
            await utils.logInfo("Click on Ground Vehicle Button");
            await appraisalpage.clickGroundVehicleBtn();

            await utils.logInfo("Value of Trim is "+await appraisalpage.getGroundAppraisalTrim());
            await utils.logInfo("Value of Odometer is "+await appraisalpage.getGroundAppraisalOdometer());

            await appraisalpage.clickGroundAppraisalTrimCheckBox();
            await appraisalpage.clickGroundAppraisalOdometerCheckBox();
            await appraisalpage.clickGroundAppraisalConditionDisclosuresCheckBox();
            await appraisalpage.clickGroundAppraisalConfirmAndGroundBtn();

            await browser.sleep(browser.params.sleep.sleep2);

            await utils.logInfo("Is Successfully Grounded message present "+await appraisalpage.isPresentGroundAppraisalSuccessMessage());
            await utils.logInfo("Vehicle was Grounded message present "+await appraisalpage.isPresentGroundAppraisalSuccessDateMessage());
            expect(await appraisalpage.isPresentGroundAppraisalSuccessMessage()).toBeTruthy("Verify Vehicle Successful Grounded message is present");
            expect(await appraisalpage.isPresentGroundAppraisalSuccessDateMessage()).toBeTruthy("Verify Vehicle Successful Grounded date message is present");
            expect(await appraisalpage.getGroundAppraisalSuccessMessageValue()).toContain("Successfully Grounded","Verify Vehicle Successful Grounded message value");
            expect(await appraisalpage.getGroundAppraisalSuccessDateMessageValue()).toContain("This vehicle was Grounded on "+utils.getCurrentDateMonthYear(),"Verify Vehicle Successful Grounded Date message value");
            
            await utils.logInfo("Date is "+utils.getCurrentDateMonthYear());

            await appraisalpage.clickGroundAppraisalBackBtn();

            await utils.logInfo("Verify Grounded text visible on Appraisal screen underneath Price Bar");
            expect(await appraisalpage.isPresentGroundedMsg()).toBeTruthy("Verify 'Grounded' text visible on Appraisal screen underneath Price Bar");
            expect(await appraisalpage.isPresentGroundedAppraisalLabel()).toBeTruthy("Verify 'Grounded' text visible at top center of Appraisal page");
            expect(await appraisalpage.isPresentGroundedCountdownTimer()).toBe(true,"Verify Grounded Countdown timer visible on Appraisal screen underneath Price Bar ")

            switch(description){
                case 'Accu-Trade' :
                    //Verify 'Get Accu-Trade Instant Offer' link available under Action
                    await utils.logInfo("Is Present Accutrade Instant Offer Btn : "+await appraisalpage.isPresentGetAccutradeInstantOfferBtn());
                    expect(await appraisalpage.isPresentGetAccutradeInstantOfferBtn()).toBeTruthy("Verify the availability of Accutrade Instant Offer Btn");
                    await appraisalpage.clickGetAccutradeInstantOfferBtn();

                    //Click CheckBox
                    await appraisalpage.clickGetOfferCheckBox();

                    //Click on Submit Button
                    await appraisalpage.clickGetAccutradeInstantOfferSubmitBtn();

                    await utils.logInfo("Is Successful Msg present : "+await appraisalpage.isPresentGetAccutradeInstantOfferSuccessMsg());
                    expect(await appraisalpage.isPresentGetAccutradeInstantOfferSuccessMsg()).toBeTruthy("Verify Instant Offer is Successfully Submit by Showing 'Successully Submitted' message");

                    await utils.logInfo("Is Successful Descripton Msg present : "+ await appraisalpage.isPresentGetAccutradeInstantOfferSuccessDescriptionMsg());
                    expect(await appraisalpage.isPresentGetAccutradeInstantOfferSuccessDescriptionMsg()).toBeTruthy("Verify Instant Offer is Successfully Submit by Showing 'This vehicle was submitted for Accu-Trade Instant Offer on mm/dd/yyyy' message");

                    await appraisalpage.clickGetOfferBackBtn();
                    await utils.logInfo("Is Pending Offer status bar present : "+await appraisalpage.isPresentGetAccutradeInstantOfferPendingMsg());
                    expect(await appraisalpage.isPresentGetAccutradeInstantOfferPendingMsg()).toBeTruthy("Verify Appraisal Page showing status bar with text 'Accu-Trade Instant Offer Pending'");

                    await utils.logInfo("Is Offer present at the top-center of Appraisal screen : "+await appraisalpage.isPresentGetOfferAppraisalLabel());
                    expect(await appraisalpage.isPresentGetOfferAppraisalLabel()).toBeTruthy("Verify Appraisal page showing 'Offer' at the top-middle of the screen above Apprsial ID");
                    break;
                case 'TrueCar' :
                    //Verify 'Get Truse Car Instant Offer' link available under Action
                    break;
                case 'Trader' :
                    //Verify 'Get Instant Offer' link available under Action
                    break;
            }

            //Get An appraisal ID
            var appraisalID = await appraisalpage.getAppraisalID();
            await utils.logInfo("Value of Appraisal ID is "+appraisalID);

            await browser.waitForAngularEnabled(true); // *** Angular Enabled

            //Click on Offers list view
            await homepage.get();
            await homepage.clickOffersAppraisalList();
            await utils.logInfo("Verify Offers Appraisals list tab is selected when click on Offers list view");
            expect(await homepage.isOffersAppraisalListTabSelected()).toBeTruthy();

            //Search for an appraisal ID
            await homepage.searchAppraisalList(appraisalID);

            //Verify the Appraisal Should display
            expect(await homepage.getAppraisalsRowCount()).toBe(1,"Verify Appraisal now display under Offers list view");

        });//it
    });//using

    it('Get Instant Offer: Terms & Conditions link ', async function () {
        utils.logInfo("***** TEST CASE : Get Instant Offer: Terms & Conditions link  *****");

        await browser.refresh();

        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        //Select Interior and Exterior Color
        //await appraisalpage.navigateToCommonProblems();
        await utils.logInfo("Click Exterior Color Button");
        await appraisalpage.clickExteriorColorBtn();

        await utils.logInfo("Select Black Exterior Color");
        await appraisalpage.clickExteriorBlackColorBtn();

        await utils.logInfo("Click Interior Color Button");
        await appraisalpage.clickInteriorColorBtn();

        await utils.logInfo("Select Black Interior Color");
        await appraisalpage.clickInteriorBlackColorBtn();

        //Upload Photos
        await utils.logInfo("Upload Photos");
        await appraisalpage.uploadImages();

        await browser.sleep(browser.params.sleep.sleep20);
        await appraisalpage.clickLeftPhotoGalleryBtn();

        //Click on Ground Vehicle
        await utils.logInfo("Click on Ground Vehicle Button");
        await appraisalpage.clickGroundVehicleBtn();

        await utils.logInfo("Value of Trim is "+await appraisalpage.getGroundAppraisalTrim());
        await utils.logInfo("Value of Odometer is "+await appraisalpage.getGroundAppraisalOdometer());

        await appraisalpage.clickGroundAppraisalTrimCheckBox();
        await appraisalpage.clickGroundAppraisalOdometerCheckBox();
        await appraisalpage.clickGroundAppraisalConditionDisclosuresCheckBox();
        await appraisalpage.clickGroundAppraisalConfirmAndGroundBtn();

        await browser.sleep(browser.params.sleep.sleep2);

        await utils.logInfo("Is Successfully Grounded message present "+await appraisalpage.isPresentGroundAppraisalSuccessMessage());
        await utils.logInfo("Vehicle was Grounded message present "+await appraisalpage.isPresentGroundAppraisalSuccessDateMessage());
        expect(await appraisalpage.isPresentGroundAppraisalSuccessMessage()).toBeTruthy("Verify Vehicle Successful Grounded message is present");
        expect(await appraisalpage.isPresentGroundAppraisalSuccessDateMessage()).toBeTruthy("Verify Vehicle Successful Grounded date message is present");
        expect(await appraisalpage.getGroundAppraisalSuccessMessageValue()).toContain("Successfully Grounded","Verify Vehicle Successful Grounded message value");
        expect(await appraisalpage.getGroundAppraisalSuccessDateMessageValue()).toContain("This vehicle was Grounded on "+utils.getCurrentDateMonthYear(),"Verify Vehicle Successful Grounded Date message value");
        
        await utils.logInfo("Date is "+utils.getCurrentDateMonthYear());

        await appraisalpage.clickGroundAppraisalBackBtn();

        await utils.logInfo("Verify Grounded text visible on Appraisal screen underneath Price Bar");
        expect(await appraisalpage.isPresentGroundedMsg()).toBeTruthy("Verify 'Grounded' text visible on Appraisal screen underneath Price Bar");
        expect(await appraisalpage.isPresentGroundedAppraisalLabel()).toBeTruthy("Verify 'Grounded' text visible at top center of Appraisal page");
        expect(await appraisalpage.isPresentGroundedCountdownTimer()).toBe(true,"Verify Grounded Countdown timer visible on Appraisal screen underneath Price Bar ")

        //Verify 'Get Accu-Trade Instant Offer' link available under Action
        await utils.logInfo("Is Present Accutrade Instant Offer Btn : "+await appraisalpage.isPresentGetAccutradeInstantOfferBtn());
        expect(await appraisalpage.isPresentGetAccutradeInstantOfferBtn()).toBeTruthy("Verify the availability of Accutrade Instant Offer Btn");
        await appraisalpage.clickGetAccutradeInstantOfferBtn();

        //Verify Terms and Conditions link is present
        expect(await appraisalpage.isPresentGetOfferTermsConditionsLink()).toBeTruthy("Verify Terms and Conditions link is present on Offer Screen above Submit button");
        expect(await appraisalpage.getOfferTermsConditionsLinkText()).toBe("Terms and Conditions","Verify Terms and Condition link text is 'Terms and Conditions' under Offer Screen");

        await appraisalpage.clickGetOfferTermsConditionsLink();
        //await browser.sleep(browser.params.sleep.sleep5);


        browser.getAllWindowHandles().then(function (handles) {
            browser.switchTo().window(handles[1]).then(function (){
                expect(browser.getCurrentUrl()).toEqual('https://lyra-qa.accu-trade.com/website/terms',"Verify the Terms and Conditions link URL");
            });
            // switch back to the main window
            browser.switchTo().window(handles[0]);
        });    

        //await browser.sleep(browser.params.sleep.sleep5);
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True


    });//it

    it('Get Instant Offer: Arbitration link ', async function () {
        utils.logInfo("***** TEST CASE : Get Instant Offer: Arbitration link  *****");

        await browser.refresh();

        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        //Select Interior and Exterior Color
        //await appraisalpage.navigateToCommonProblems();
        await utils.logInfo("Click Exterior Color Button");
        await appraisalpage.clickExteriorColorBtn();

        await utils.logInfo("Select Black Exterior Color");
        await appraisalpage.clickExteriorBlackColorBtn();

        await utils.logInfo("Click Interior Color Button");
        await appraisalpage.clickInteriorColorBtn();

        await utils.logInfo("Select Black Interior Color");
        await appraisalpage.clickInteriorBlackColorBtn();

        //Upload Photos
        await utils.logInfo("Upload Photos");
        await appraisalpage.uploadImages();

        await browser.sleep(browser.params.sleep.sleep20);
        await appraisalpage.clickLeftPhotoGalleryBtn();

        //Click on Ground Vehicle
        await utils.logInfo("Click on Ground Vehicle Button");
        await appraisalpage.clickGroundVehicleBtn();

        await utils.logInfo("Value of Trim is "+await appraisalpage.getGroundAppraisalTrim());
        await utils.logInfo("Value of Odometer is "+await appraisalpage.getGroundAppraisalOdometer());

        await appraisalpage.clickGroundAppraisalTrimCheckBox();
        await appraisalpage.clickGroundAppraisalOdometerCheckBox();
        await appraisalpage.clickGroundAppraisalConditionDisclosuresCheckBox();
        await appraisalpage.clickGroundAppraisalConfirmAndGroundBtn();

        await browser.sleep(browser.params.sleep.sleep2);

        await utils.logInfo("Is Successfully Grounded message present "+await appraisalpage.isPresentGroundAppraisalSuccessMessage());
        await utils.logInfo("Vehicle was Grounded message present "+await appraisalpage.isPresentGroundAppraisalSuccessDateMessage());
        expect(await appraisalpage.isPresentGroundAppraisalSuccessMessage()).toBeTruthy("Verify Vehicle Successful Grounded message is present");
        expect(await appraisalpage.isPresentGroundAppraisalSuccessDateMessage()).toBeTruthy("Verify Vehicle Successful Grounded date message is present");
        expect(await appraisalpage.getGroundAppraisalSuccessMessageValue()).toContain("Successfully Grounded","Verify Vehicle Successful Grounded message value");
        expect(await appraisalpage.getGroundAppraisalSuccessDateMessageValue()).toContain("This vehicle was Grounded on "+utils.getCurrentDateMonthYear(),"Verify Vehicle Successful Grounded Date message value");
        
        await utils.logInfo("Date is "+utils.getCurrentDateMonthYear());

        await appraisalpage.clickGroundAppraisalBackBtn();

        await utils.logInfo("Verify Grounded text visible on Appraisal screen underneath Price Bar");
        expect(await appraisalpage.isPresentGroundedMsg()).toBeTruthy("Verify 'Grounded' text visible on Appraisal screen underneath Price Bar");
        expect(await appraisalpage.isPresentGroundedAppraisalLabel()).toBeTruthy("Verify 'Grounded' text visible at top center of Appraisal page");
        expect(await appraisalpage.isPresentGroundedCountdownTimer()).toBe(true,"Verify Grounded Countdown timer visible on Appraisal screen underneath Price Bar ");

        //Verify 'Get Accu-Trade Instant Offer' link available under Action
        await utils.logInfo("Is Present Accutrade Instant Offer Btn : "+await appraisalpage.isPresentGetAccutradeInstantOfferBtn());
        expect(await appraisalpage.isPresentGetAccutradeInstantOfferBtn()).toBeTruthy("Verify the availability of Accutrade Instant Offer Btn");
        await appraisalpage.clickGetAccutradeInstantOfferBtn();

        //Verify Arbitration link is present
        expect(await appraisalpage.isPresentGetOfferArbitrationLink()).toBeTruthy("Verify Arbitration link is present on Offer Screen above Submit button");
        expect(await appraisalpage.getOfferArbitrationLinkText()).toBe("here.","Verify Arbitration link text is 'here'");

        await appraisalpage.clickGetOfferArbitrationLink();

        browser.getAllWindowHandles().then(function (handles) {
            browser.switchTo().window(handles[1]).then(function (){
                expect(browser.getCurrentUrl()).toEqual('https://www.naaa.com/Policy/Policy_PDFs/2017_ArbitrationPolicy_Effective_4_17_17/NAAA_Arbitration_Policy_April_17_2017_FINAL.pdf',"Verify the Arbitration link URL at Get Offer Screen");
            });
            // switch back to the main window
            browser.switchTo().window(handles[0]);
        });    

        await browser.waitForAngularEnabled(true); // *** Angular Enabled True


    });//it

    it('Get Instant Offer: Submit button is disabled until checkbox selected', async function () {
        utils.logInfo("***** TEST CASE : Get Instant Offer: Submit button is disabled until checkbox selected  *****");

        await browser.refresh();

        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        //Select Interior and Exterior Color
        //await appraisalpage.navigateToCommonProblems();
        await utils.logInfo("Click Exterior Color Button");
        await appraisalpage.clickExteriorColorBtn();

        await utils.logInfo("Select Black Exterior Color");
        await appraisalpage.clickExteriorBlackColorBtn();

        await utils.logInfo("Click Interior Color Button");
        await appraisalpage.clickInteriorColorBtn();

        await utils.logInfo("Select Black Interior Color");
        await appraisalpage.clickInteriorBlackColorBtn();

        //Upload Photos
        await utils.logInfo("Upload Photos");
        await appraisalpage.uploadImages();

        await browser.sleep(browser.params.sleep.sleep20);
        await appraisalpage.clickLeftPhotoGalleryBtn();

        //Click on Ground Vehicle
        await utils.logInfo("Click on Ground Vehicle Button");
        await appraisalpage.clickGroundVehicleBtn();

        await utils.logInfo("Value of Trim is "+await appraisalpage.getGroundAppraisalTrim());
        await utils.logInfo("Value of Odometer is "+await appraisalpage.getGroundAppraisalOdometer());

        await appraisalpage.clickGroundAppraisalTrimCheckBox();
        await appraisalpage.clickGroundAppraisalOdometerCheckBox();
        await appraisalpage.clickGroundAppraisalConditionDisclosuresCheckBox();
        await appraisalpage.clickGroundAppraisalConfirmAndGroundBtn();

        await browser.sleep(browser.params.sleep.sleep2);

        await utils.logInfo("Is Successfully Grounded message present "+await appraisalpage.isPresentGroundAppraisalSuccessMessage());
        await utils.logInfo("Vehicle was Grounded message present "+await appraisalpage.isPresentGroundAppraisalSuccessDateMessage());
        expect(await appraisalpage.isPresentGroundAppraisalSuccessMessage()).toBeTruthy("Verify Vehicle Successful Grounded message is present");
        expect(await appraisalpage.isPresentGroundAppraisalSuccessDateMessage()).toBeTruthy("Verify Vehicle Successful Grounded date message is present");
        expect(await appraisalpage.getGroundAppraisalSuccessMessageValue()).toContain("Successfully Grounded","Verify Vehicle Successful Grounded message value");
        expect(await appraisalpage.getGroundAppraisalSuccessDateMessageValue()).toContain("This vehicle was Grounded on "+utils.getCurrentDateMonthYear(),"Verify Vehicle Successful Grounded Date message value");
        
        await utils.logInfo("Date is "+utils.getCurrentDateMonthYear());

        await appraisalpage.clickGroundAppraisalBackBtn();

        await utils.logInfo("Verify Grounded text visible on Appraisal screen underneath Price Bar");
        expect(await appraisalpage.isPresentGroundedMsg()).toBeTruthy("Verify 'Grounded' text visible on Appraisal screen underneath Price Bar");
        expect(await appraisalpage.isPresentGroundedAppraisalLabel()).toBeTruthy("Verify 'Grounded' text visible at top center of Appraisal page");
        expect(await appraisalpage.isPresentGroundedCountdownTimer()).toBe(true,"Verify Grounded Countdown timer visible on Appraisal screen underneath Price Bar ");

        await utils.logInfo("Is Present Accutrade Instant Offer Btn : "+await appraisalpage.isPresentGetAccutradeInstantOfferBtn());
        expect(await appraisalpage.isPresentGetAccutradeInstantOfferBtn()).toBeTruthy("Verify the availability of Accutrade Instant Offer Btn");
        
        await utils.logInfo("Click on Instant Offer Link");
        await appraisalpage.clickGetAccutradeInstantOfferBtn();

        //Verify Submit button is Grayed out (disabled)
        await utils.logInfo("appraisalpage.isGetOfferSubmitButtonDisabled() = "+await appraisalpage.isGetOfferSubmitButtonDisabled());
        expect(await appraisalpage.isGetOfferSubmitButtonDisabled()).toBe('true',"Verify Submit(Confirm & Get Offer) Button is Disabled until CheckBox is Selected");

        //Click on Checkbox
        await utils.logInfo("Click on Checkbox");
        await appraisalpage.clickGetOfferCheckBox();

        //Verify Submit button is Enabled
        await utils.logInfo("appraisalpage.isGetOfferSubmitButtonDisabled() = "+await appraisalpage.isGetOfferSubmitButtonDisabled());
        expect(await appraisalpage.isGetOfferSubmitButtonDisabled()).toBe('false',"Verify Submit(Confirm & Get Offer) Button is Enabled when CheckBox is Selected");

        await browser.waitForAngularEnabled(true); // *** Angular Enabled True


    });//it


    it('Disclosure Pop: accurately displays all damages. Cancel and then Confirm', async function () {
        utils.logInfo("***** TEST CASE : Disclosure Pop: accurately displays all damages. Cancel and then Confirm  *****");

        await browser.refresh();

        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();
        var appraisalMileage = await appraisalpage.getMileage();
        var appraisalTrim = await appraisalpage.getAppraisalTrim();

        await utils.logInfo("Value of Trim on Appraisal page is "+appraisalTrim);
        await utils.logInfo("Value of Mileage on Appraisal page is "+appraisalMileage);

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        //Select Interior and Exterior Color
        //await appraisalpage.navigateToCommonProblems();
        await utils.logInfo("Click Exterior Color Button");
        await appraisalpage.clickExteriorColorBtn();

        await utils.logInfo("Select Black Exterior Color");
        await appraisalpage.clickExteriorBlackColorBtn();

        await utils.logInfo("Click Interior Color Button");
        await appraisalpage.clickInteriorColorBtn();

        await utils.logInfo("Select Black Interior Color");
        await appraisalpage.clickInteriorBlackColorBtn();

        //Upload Photos
        await utils.logInfo("Upload Photos");
        await appraisalpage.uploadImages();

        await browser.sleep(browser.params.sleep.sleep20);
        await appraisalpage.clickLeftPhotoGalleryBtn();
        await browser.sleep(browser.params.sleep.sleep10);


        var tabCount = "0";
        // var appraisalID = "0";

        //Check Condition Disclosures Body Tab Count is 0
        tabCount = await appraisalpage.getCDBodyTabCount();
        await utils.logInfo("CD Body Tab Count is "+tabCount);
        expect(await tabCount).toBe("0","Verify Condition Disclosures Body Tab Count before any Adjustment is 0");

        //Add 1 damages to each: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other
        await utils.logInfo("Adding 1st Damage: 'Body','Roof','rust','repair'");
        await appraisalpage.selectAdjustmentAppraisalScreen("Body","Roof","rust","repair");

        //Check Condition Disclosures Body Tab Count is 1
        tabCount = await appraisalpage.getCDBodyTabCount();
        await utils.logInfo("CD Body Tab Count is "+tabCount);
        expect(await tabCount).toBe("1","Verify Condition Disclosures Body Tab Count after adding one Adjustment is 1");

        //appraisalID = await appraisalpage.getAppraisalID();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await browser.refresh();

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

        // Glass TAB ************************************************************************************************************


        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await browser.refresh();

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

        //Check Condition Disclosures Glass Tab Count is 0
        tabCount = await appraisalpage.getCDGlassTabCount();
        await utils.logInfo("CD Glass Tab Count is "+tabCount);
        expect(await tabCount).toBe("0","Verify Condition Disclosures Glass Tab Count before any Adjustment is 0");

        //Add 1 damages to each: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other
        await utils.logInfo("Adding 1st Damage: 'Glass','Rear Window','replace','none'");
        await appraisalpage.selectAdjustmentAppraisalScreen("Glass","Rear Window","replace","none");

        //Check Condition Disclosures Glass Tab Count is 1
        tabCount = await appraisalpage.getCDGlassTabCount();
        await utils.logInfo("CD Glass Tab Count is "+tabCount);
        expect(await tabCount).toBe("1","Verify Condition Disclosures Glass Tab Count after adding one Adjustment is 1");

        //appraisalID = await appraisalpage.getAppraisalID();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        //await appraisalpage.getAppraisalByID(appraisalID);
        await browser.refresh();

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False 


    // Interior TAB ************************************************************************************************************


        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await browser.refresh();

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

        //Check Condition Disclosures Interior Tab Count is 0
        tabCount = await appraisalpage.getCDInteriorTabCount();
        await utils.logInfo("CD Interior Tab Count is "+tabCount);
        expect(await tabCount).toBe("0","Verify Condition Disclosures Interior Tab Count before any Adjustment is 0");

        //Add 1 damages to each: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other
        await utils.logInfo("Adding 1st Damage: 'Interior','Rear Door Panel-Left','scratched','none'");
        await appraisalpage.selectAdjustmentAppraisalScreen("Interior","Rear Door Panel-Left","scratched","none");

        //Check Condition Disclosures Interior Tab Count is 1
        tabCount = await appraisalpage.getCDInteriorTabCount();
        await utils.logInfo("CD Interior Tab Count is "+tabCount);
        expect(await tabCount).toBe("1","Verify Condition Disclosures Interior Tab Count after adding one Adjustment is 1");

        //appraisalID = await appraisalpage.getAppraisalID();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        //await appraisalpage.getAppraisalByID(appraisalID);
        await browser.refresh();

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    // Tire/Wheel TAB ************************************************************************************************************


    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    //Check Condition Disclosures Interior Tab Count is 0
    tabCount = await appraisalpage.getCDTireWheelTabCount();
    await utils.logInfo("CD Tire/Wheel Tab Count is "+tabCount);
    expect(await tabCount).toBe("0","Verify Condition Disclosures Tire/Wheel Tab Count before any Adjustment is 0");

    //Add 1 damages to each: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other
    await utils.logInfo("Adding 1st Damage: 'Tire/Wheel','Front Right','0 - 3/32','replace wheel'");
    await appraisalpage.selectAdjustmentAppraisalScreen("Tire/Wheel","Front Right","0 - 3/32","replace wheel");
    await browser.sleep(browser.params.sleep.sleep10);        

    //Check Condition Disclosures Interior Tab Count is 1
    tabCount = await appraisalpage.getCDTireWheelTabCount();
    await utils.logInfo("CD Tire/Wheel Tab Count is "+tabCount);
    expect(await tabCount).toBe("2","Verify Condition Disclosures Tire/Wheel Tab Count after adding one Adjustment is 2");

    //appraisalID = await appraisalpage.getAppraisalID();

    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    //await appraisalpage.getAppraisalByID(appraisalID);
    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    // Lights TAB ************************************************************************************************************


    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    //Check Condition Disclosures Interior Tab Count is 0
    tabCount = await appraisalpage.getCDLightsTabCount();
    await utils.logInfo("CD Lights Tab Count is "+tabCount);
    expect(await tabCount).toBe("0","Verify Condition Disclosures Lights Tab Count before any Adjustment is 0");

    //Add 1 damages to each: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other
    await utils.logInfo("Adding 1st Damage: 'Warning Lights','Battery','none','none'");
    await appraisalpage.selectAdjustmentAppraisalScreen("Warning Lights","Battery","none","none");

    //Check Condition Disclosures Lights Tab Count is 1
    tabCount = await appraisalpage.getCDLightsTabCount();
    await utils.logInfo("CD Lights Tab Count is "+tabCount);
    expect(await tabCount).toBe("1","Verify Condition Disclosures Lights Tab Count after adding one Adjustment is 1");

    //appraisalID = await appraisalpage.getAppraisalID();

    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    //await appraisalpage.getAppraisalByID(appraisalID);
    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    // Mechanical TAB ************************************************************************************************************


    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    //Check Condition Disclosures Mechanical Tab Count is 0
    tabCount = await appraisalpage.getCDMechanicalTabCount();
    await utils.logInfo("CD Mechanical Tab Count is "+tabCount);
    expect(await tabCount).toBe("0","Verify Condition Disclosures Mechanical Tab Count before any Adjustment is 0");

    //Add 1 damages to each: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other
    await utils.logInfo("Adding 1st Damage: 'Mechanical','Oil Leak','none','none'");
    await appraisalpage.selectAdjustmentAppraisalScreen("Mechanical","Oil Leak","none","none");

    //Check Condition Disclosures Mechanical Tab Count is 1
    tabCount = await appraisalpage.getCDMechanicalTabCount();
    await utils.logInfo("CD Mechanical Tab Count is "+tabCount);
    expect(await tabCount).toBe("1","Verify Condition Disclosures Mechanical Tab Count after adding one Adjustment is 1");

    //appraisalID = await appraisalpage.getAppraisalID();

    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    //await appraisalpage.getAppraisalByID(appraisalID);
    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False     
    
    // Aftermarket TAB ************************************************************************************************************

    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    //Check Condition Disclosures Aftermarket Tab Count is 0
    tabCount = await appraisalpage.getCDAfterMarketTabCount();
    await utils.logInfo("CD Aftermarket Tab Count is "+tabCount);
    expect(await tabCount).toBe("0","Verify Condition Disclosures Aftermarket Tab Count before any Adjustment is 0");

    //Add 1 damages to each: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other
    await utils.logInfo("Adding 1st Damage: 'Aftermarket','Stereo','none','none'");
    await appraisalpage.selectAdjustmentAppraisalScreen("Aftermarket","Stereo","none","none");

    //Check Condition Disclosures Aftermarket Tab Count is 1
    tabCount = await appraisalpage.getCDAfterMarketTabCount();
    await utils.logInfo("CD Aftermarket Tab Count is "+tabCount);
    expect(await tabCount).toBe("1","Verify Condition Disclosures Aftermarket Tab Count after adding one Adjustment is 1");

    //appraisalID = await appraisalpage.getAppraisalID();

    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    //await appraisalpage.getAppraisalByID(appraisalID);
    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False
        
    
    // Other TAB ************************************************************************************************************


    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    //Check Condition Disclosures Other Tab Count is 0
    tabCount = await appraisalpage.getCDOtherTabCount();
    await utils.logInfo("CD Lights Tab Count is "+tabCount);
    expect(await tabCount).toBe("0","Verify Condition Disclosures Lights Tab Count before any Adjustment is 0");

    //Add 1 damages to each: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other
    await utils.logInfo("Adding 1st Damage: 'Other','Smoke/Odor','none','none'");
    await appraisalpage.selectAdjustmentAppraisalScreen("Other","Smoke/Odor","none","none");

    //Check Condition Disclosures Other Tab Count is 1
    tabCount = await appraisalpage.getCDOtherTabCount();
    await utils.logInfo("CD Other Tab Count is "+tabCount);
    expect(await tabCount).toBe("1","Verify Condition Disclosures Other Tab Count after adding one Adjustment is 1");

    //appraisalID = await appraisalpage.getAppraisalID();

    await utils.logInfo("Enable Wait for Angular");
    await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    //await appraisalpage.getAppraisalByID(appraisalID);
    await browser.refresh();

    await utils.logInfo("Disable Wait for Angular");
    await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

    var bodyCDAmount = await appraisalpage.getCDBodyTotalAdjustmentAmount();
    var glassCDAmount = await appraisalpage.getCDGlassTotalAdjustmentAmount();
    var interiorCDAmount = await appraisalpage.getCDInteriorTotalAdjustmentAmount();
    var tireWheelCDAmount = await appraisalpage.getCDTireWheelTotalAdjustmentAmount();
    var lightsCDAmount = await appraisalpage.getCDLightsTotalAdjustmentAmount();
    var mechanicalCDAmount = await appraisalpage.getCDMechanicalTotalAdjustmentAmount();
    var afterMarketCDAmount = await appraisalpage.getCDAfterMarketTotalAdjustmentAmount();
    var otherCDAmount = await appraisalpage.getCDOtherTotalAdjustmentAmount();



    await browser.sleep(browser.params.sleep.sleep10);        

    //Click on Ground Vehicle
    await utils.logInfo("Click on Ground Vehicle Button");
    await appraisalpage.clickGroundVehicleBtn();

    await utils.logInfo("Value of Trim on Ground Screen is "+await appraisalpage.getGroundAppraisalTrim());
    expect(await appraisalpage.getGroundAppraisalTrim()).toBe(appraisalTrim,"Verify Top right Ground screen showing correct Trim");
    
    await utils.logInfo("Value of Odometer on Ground Screen is "+await appraisalpage.getGroundAppraisalOdometer());
    expect(await appraisalpage.getGroundAppraisalOdometer()).toBe(appraisalMileage.toLowerCase(),"Verify Top right Ground screen showing correct Odometer mileage");

    expect(await appraisalpage.getGroundAppraisalBodyCDValue()).toBe(bodyCDAmount,"Verify Body Amount value in Ground Screen");
    expect(await appraisalpage.getGroundAppraisalGlassCDValue()).toBe(glassCDAmount,"Verify Glass Amount value in Ground Screen");
    expect(await appraisalpage.getGroundAppraisalInteriorCDValue()).toBe(interiorCDAmount,"Verify Interior Amount value in Ground Screen");
    expect(await appraisalpage.getGroundAppraisalTiresWheelsCDValue()).toBe(tireWheelCDAmount,"Verify Tires & Wheels Amount value in Ground Screen");
    expect(await appraisalpage.getGroundAppraisalWarningLightsCDValue()).toBe(lightsCDAmount,"Verify Warning Lights Amount value in Ground Screen");
    expect(await appraisalpage.getGroundAppraisalMechanicalCDValue()).toBe(mechanicalCDAmount,"Verify Mechanical Amount value in Ground Screen");
    expect(await appraisalpage.getGroundAppraisalAftermarketCDValue()).toBe(afterMarketCDAmount,"Verify Aftermarket Amount value in Ground Screen");
    expect(await appraisalpage.getGroundAppraisalOtherCDValue()).toBe(otherCDAmount,"Verify Disclosure Amount value in Ground Screen");

    await appraisalpage.clickGroundAppraisalCancelBtn();

    await appraisalpage.clickGroundVehicleBtn();

    await appraisalpage.clickGroundAppraisalTrimCheckBox();
    await appraisalpage.clickGroundAppraisalOdometerCheckBox();
    await appraisalpage.clickGroundAppraisalConditionDisclosuresCheckBox();
    await appraisalpage.clickGroundAppraisalConfirmAndGroundBtn();

    });    

    it('Disclosure Pop: Only if deducts are less than $300 ', async function () {
        utils.logInfo("***** TEST CASE : Disclosure Pop: Only if deducts are less than $300   *****");

        await browser.refresh();

        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();
        var appraisalMileage = await appraisalpage.getMileage();
        var appraisalTrim = await appraisalpage.getAppraisalTrim();

        await utils.logInfo("Value of Trim on Appraisal page is "+appraisalTrim);
        await utils.logInfo("Value of Mileage on Appraisal page is "+appraisalMileage);

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        //Select Interior and Exterior Color
        //await appraisalpage.navigateToCommonProblems();
        await utils.logInfo("Click Exterior Color Button");
        await appraisalpage.clickExteriorColorBtn();

        await utils.logInfo("Select Black Exterior Color");
        await appraisalpage.clickExteriorBlackColorBtn();

        await utils.logInfo("Click Interior Color Button");
        await appraisalpage.clickInteriorColorBtn();

        await utils.logInfo("Select Black Interior Color");
        await appraisalpage.clickInteriorBlackColorBtn();

        //Upload Photos
        await utils.logInfo("Upload Photos");
        await appraisalpage.uploadImages();

        await browser.sleep(browser.params.sleep.sleep20);
        await appraisalpage.clickLeftPhotoGalleryBtn();
        await browser.sleep(browser.params.sleep.sleep10);

        var tabCount = "0";
        // var appraisalID = "0";

        //Check Condition Disclosures Body Tab Count is 0
        tabCount = await appraisalpage.getCDBodyTabCount();
        await utils.logInfo("CD Body Tab Count is "+tabCount);
        expect(await tabCount).toBe("0","Verify Condition Disclosures Body Tab Count before any Adjustment is 0");

        //Add 1 damages to each: Body, Glass, Interior, Exterior, Tire/Wheels, Lights, Mechanical, Aftermarket, Other
        await utils.logInfo("Adding 1st Damage: 'Body','Roof','scratch','touchup'");
        await appraisalpage.selectAdjustmentAppraisalScreen("Body","Roof","scratch","touchup");

        //Check Condition Disclosures Body Tab Count is 1
        tabCount = await appraisalpage.getCDBodyTabCount();
        await utils.logInfo("CD Body Tab Count is "+tabCount);
        expect(await tabCount).toBe("1","Verify Condition Disclosures Body Tab Count after adding one Adjustment is 1");

        //appraisalID = await appraisalpage.getAppraisalID();

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await browser.refresh();

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False 

        var bodyCDAmount = await appraisalpage.getCDBodyTotalAdjustmentAmount();
        var glassCDAmount = await appraisalpage.getCDGlassTotalAdjustmentAmount();
        var interiorCDAmount = await appraisalpage.getCDInteriorTotalAdjustmentAmount();
        var tireWheelCDAmount = await appraisalpage.getCDTireWheelTotalAdjustmentAmount();
        var lightsCDAmount = await appraisalpage.getCDLightsTotalAdjustmentAmount();
        var mechanicalCDAmount = await appraisalpage.getCDMechanicalTotalAdjustmentAmount();
        var afterMarketCDAmount = await appraisalpage.getCDAfterMarketTotalAdjustmentAmount();
        var otherCDAmount = await appraisalpage.getCDOtherTotalAdjustmentAmount();

        await browser.sleep(browser.params.sleep.sleep10);        

        //Click on Ground Vehicle
        await utils.logInfo("Click on Ground Vehicle Button");
        await appraisalpage.clickGroundVehicleBtn();

        await utils.logInfo("Value of Trim on Ground Screen is "+await appraisalpage.getGroundAppraisalTrim());
        expect(await appraisalpage.getGroundAppraisalTrim()).toBe(appraisalTrim,"Verify Top right Ground screen showing correct Trim");
        
        await utils.logInfo("Value of Odometer on Ground Screen is "+await appraisalpage.getGroundAppraisalOdometer());
        expect(await appraisalpage.getGroundAppraisalOdometer()).toBe(appraisalMileage.toLowerCase(),"Verify Top right Ground screen showing correct Odometer mileage");

        await utils.logInfo("Verify Values of Disclosures amount");
        expect(await appraisalpage.getGroundAppraisalBodyCDValue()).toBe(bodyCDAmount,"Verify Body Amount value in Ground Screen");
        expect(await appraisalpage.getGroundAppraisalGlassCDValue()).toBe(glassCDAmount,"Verify Glass Amount value in Ground Screen");
        expect(await appraisalpage.getGroundAppraisalInteriorCDValue()).toBe(interiorCDAmount,"Verify Interior Amount value in Ground Screen");
        expect(await appraisalpage.getGroundAppraisalTiresWheelsCDValue()).toBe(tireWheelCDAmount,"Verify Tires & Wheels Amount value in Ground Screen");
        expect(await appraisalpage.getGroundAppraisalWarningLightsCDValue()).toBe(lightsCDAmount,"Verify Warning Lights Amount value in Ground Screen");
        expect(await appraisalpage.getGroundAppraisalMechanicalCDValue()).toBe(mechanicalCDAmount,"Verify Mechanical Amount value in Ground Screen");
        expect(await appraisalpage.getGroundAppraisalAftermarketCDValue()).toBe(afterMarketCDAmount,"Verify Aftermarket Amount value in Ground Screen");
        expect(await appraisalpage.getGroundAppraisalOtherCDValue()).toBe(otherCDAmount,"Verify Disclosure Amount value in Ground Screen");

        await appraisalpage.clickGroundAppraisalCancelBtn();

        await appraisalpage.clickGroundVehicleBtn();

        await appraisalpage.clickGroundAppraisalTrimCheckBox();
        await appraisalpage.clickGroundAppraisalOdometerCheckBox();
        await appraisalpage.clickGroundAppraisalConditionDisclosuresCheckBox();
        await appraisalpage.clickGroundAppraisalConfirmAndGroundBtn();

    }); //it
    
    it('Action Options: UI: All action options hidden when settings are turned OFF', async function () {
        utils.logInfo("***** TEST CASE : Action Options: UI: All action options hidden when settings are turned OFF   *****");

        await browser.refresh();

        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();
        var appraisalMileage = await appraisalpage.getMileage();
        var appraisalTrim = await appraisalpage.getAppraisalTrim();

        await utils.logInfo("Value of Trim on Appraisal page is "+appraisalTrim);
        await utils.logInfo("Value of Mileage on Appraisal page is "+appraisalMileage);

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Appraisal ID is "+appraisalID);

        // Open Dealership
        await browser.waitForAngularEnabled(true); // *** Angular Enabled
        await dealershippage.getDealer(browser.params.dealer.atdealername);
        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        // await browser.waitForAngularEnabled(true); // *** Angular Enabled
        // await browser.refresh();

        // await utils.logInfo("Navigate to Dealer Console"); //**** Navigate to Dealer Console ****/
        // await homepage.navigateThroughMenu("Dealer Console");
        
        // browser.driver.sleep(browser.params.sleep.sleep10);

        // browser.switchTo().frame(0);
        // await utils.logInfo("Switched to iFrame");

        // await browser.waitForAngularEnabled(false);

        // await utils.logInfo("Search Dealership");
        // await dealerconsolepage.searchDealership(browser.params.dealer.atdealername);
        // await browser.sleep(browser.params.sleep.sleep10);

        // await utils.logInfo("Get number of dealers : "+await dealerconsolepage.getDealershipRowCount());

        // await utils.logInfo("Select first Dealership");
        // await dealerconsolepage.selectFirstDealership();
        
        // await utils.logInfo("Click on Dealership Edit Button");
        // await dealerconsolepage.editDealership();

        //*********************************** Set 'Product Type' = Basic in General Tab *****************************************//

        await utils.logInfo("Verify General tab is present in Dealership");
        await utils.logInfo("Is General tab present: "+await dealershippage.isGeneralTabPresent());
        expect(await dealershippage.isGeneralTabPresent()).toBeTruthy("Verify General tab is present in Dealership"); //Assertion
        await utils.logInfo("Click General Tab on Dealership page");
        await dealershippage.clickGeneralTab();
        await utils.logInfo("Is Dealership Name Textfield present in General Tab: "+await dealershippage.isPresentDealershipNameGeneralTab());
        expect(await dealershippage.isPresentDealershipNameGeneralTab()).toBeTruthy("Verify Dealership Name textfield is present under General tab of Dealership");

        await utils.logInfo("Current Selected Product in General tab is '"+await dealershippage.getSelectedProductGeneralTab()+"'");

        await utils.logInfo("Set Product as 'Accu-Trade - Appraiser Basic' ")
        await dealershippage.setProductGeneralTab("Accu-Trade - Appraiser Basic");    
        
        await utils.logInfo("Selected Product in General tab is "+await dealershippage.getSelectedProductGeneralTab());
        expect(await dealershippage.getSelectedProductGeneralTab()).toBe("Accu-Trade - Appraiser Basic","Verify selected Product in General tab");
        
        await utils.logInfo("Click Save Button in General Tab");
        await dealershippage.clickGeneralSaveBtn();
        browser.sleep(browser.params.sleep.sleep20);

        //*********************************** Set HVMS, IAS and CRM EMail in Advanced Tab *****************************************//

        await utils.logInfo("Edit Advanced Tab");
        await utils.logInfo("Is Advanced tab present: "+await dealershippage.isAdvancedTabPresent());
        await dealershippage.clickAdvancedTab();
        await utils.logInfo("Is Allow Chrome Lookup present in Advanced Tab: "+await dealershippage.isPresentAllowChromeLookupAdvancedTab());

        //HVMS
        await utils.logInfo("Value of HVMS Push before toggle : "+await dealershippage.getHVMSPushStatus());
        await utils.logInfo("Toggle HVMS Push Slider Button");
        await dealershippage.toggleHVMSPush();
        await utils.logInfo("Value of HVMS Push after toggle : "+await dealershippage.getHVMSPushStatus());
        browser.driver.sleep(browser.params.sleep.sleep10);

        //IAS
        await utils.logInfo("Value of IAS Sync before toggle : "+await dealershippage.getIASSyncStatus());
        await utils.logInfo("Toggle IAS Sync Slider Button");
        await dealershippage.toggleIASSync();
        await utils.logInfo("Value of IAS Sync after toggle : "+await dealershippage.getIASSyncStatus());
        browser.driver.sleep(browser.params.sleep.sleep10);

        //CRM Email
        // var crmName = await dealershippage.getCRMName();
        // var crmEmail = await dealershippage.getCRMEmail();
        // await utils.logInfo("Value of CRM Name before Delete : "+crmName);
        // await utils.logInfo("Value of CRM Email before Delete : "+crmEmail);
        // await utils.logInfo("Delete CRM Email");
        // await dealershippage.deleteCRMNameEmail();

        await utils.logInfo("Click Save Button in Advanced Tab");
        await dealershippage.clickAdvancedSaveBtn();
        browser.sleep(browser.params.sleep.sleep20);

        //*********************************** Set Increase Offer in Employee Tab *****************************************//
        await utils.logInfo("Edit Employees Tab");
        await utils.logInfo("Is Employees tab present: "+await dealershippage.isEmployeeTabPresent());
        await utils.logInfo("Click on Employees Tab");        
        await dealershippage.clickEmployeesTab();
        await utils.logInfo("Is Employee Table present in Employees Tab: "+await dealershippage.isPresentEmployeeTableEmployeesTab());
        await utils.logInfo("Select first checkbox for Employee table");
        await dealershippage.selectFirstCheckBoxEmployeeTable();
        await utils.logInfo("Click on Edit Button of the selected Employee");
        await dealershippage.clickEditButton();

        //Enable Increase Offer
        await utils.logInfo("Value of Increase Offer before toggle : "+await dealershippage.getIncreaseOfferStatus());
        await utils.logInfo("Toggle Enable Increase Offer Slider Button");
        await dealershippage.toggleIncreaseOffer();
        await utils.logInfo("Value of Increase Offer after toggle : "+await dealershippage.getIncreaseOfferStatus());
        browser.driver.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Click Save Button in Employee Tab");
        await dealershippage.clickEmployeeSaveBtn();
        browser.sleep(browser.params.sleep.sleep20);

        //************************************** Verify Hidden options on Appraisal Page **********************************************//
        //Open an Appraisal
        await browser.waitForAngularEnabled(true);
        await utils.logInfo("Get an Appraisal by ID -'"+appraisalID+"'");
        await appraisalpage.getAppraisalByID(appraisalID);
        await browser.waitForAngularEnabled(false);

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True
        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);
        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        //Verify Ground option is not present
        expect(await appraisalpage.isPresentGroundVehicleBtn()).toBeFalsy("Verify 'Ground' Option is not present under Select Action after selecting product 'Accu-Trade - Appraiser Basic' in Dealership page");
        expect(await appraisalpage.isPresentIncreaseOfferBtn()).toBeFalsy("Verify 'Increase Offer' Option is not present under Select Action");
        expect(await appraisalpage.isPresentHVMSBtn()).toBeFalsy("Verify 'Send to HVMS' Option is not present under Select Action");
        expect(await appraisalpage.isPresentIASBtn()).toBeFalsy("Verify 'Send to IAS' Option is not present under Select Action");
        //expect(await appraisalpage.isPresentCRMBtn()).toBeFalsy("Verify 'Send to CRM' Option is not present under Select Action");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled

    }); //it


    it('Action Options: UI: All action options are prrsent when settings are turned ON', async function () {
        utils.logInfo("***** TEST CASE : Action Options: UI: All action options hidden when settings are turned OFF   *****");

        await browser.refresh();

        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();
        var appraisalMileage = await appraisalpage.getMileage();
        var appraisalTrim = await appraisalpage.getAppraisalTrim();

        await utils.logInfo("Value of Trim on Appraisal page is "+appraisalTrim);
        await utils.logInfo("Value of Mileage on Appraisal page is "+appraisalMileage);

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Appraisal ID is "+appraisalID);

        // Open Dealership
        await browser.waitForAngularEnabled(true); // *** Angular Enabled
        await dealershippage.getDealer(browser.params.dealer.atdealername);
        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        //*********************************** Revert 'Product Type' = Pro in General Tab *****************************************//

        await utils.logInfo("Verify General tab is present in Dealership");
        await utils.logInfo("Is General tab present: "+await dealershippage.isGeneralTabPresent());
        expect(await dealershippage.isGeneralTabPresent()).toBeTruthy("Verify General tab is present in Dealership"); //Assertion
        await utils.logInfo("Click General Tab on Dealership page");
        await dealershippage.clickGeneralTab();
        await utils.logInfo("Is Dealership Name Textfield present in General Tab: "+await dealershippage.isPresentDealershipNameGeneralTab());
        expect(await dealershippage.isPresentDealershipNameGeneralTab()).toBeTruthy("Verify Dealership Name textfield is present under General tab of Dealership");

        await utils.logInfo("Current Selected Product in General tab is '"+await dealershippage.getSelectedProductGeneralTab()+"'");

        await utils.logInfo("Set Product as 'Accu-Trade - Appraiser Pro' ")
        await dealershippage.setProductGeneralTab("Accu-Trade - Appraiser Pro");    
        
        await utils.logInfo("Selected Product in General tab is "+await dealershippage.getSelectedProductGeneralTab());
        expect(await dealershippage.getSelectedProductGeneralTab()).toBe("Accu-Trade - Appraiser Pro","Verify selected Product in General tab");
        
        await utils.logInfo("Click Save Button in General Tab");
        await dealershippage.clickGeneralSaveBtn();
        browser.sleep(browser.params.sleep.sleep20);

        //*********************************** Set HVMS, IAS and CRM EMail in Advanced Tab *****************************************//

        await utils.logInfo("Edit Advanced Tab");
        await utils.logInfo("Is Advanced tab present: "+await dealershippage.isAdvancedTabPresent());
        await dealershippage.clickAdvancedTab();
        await utils.logInfo("Is Allow Chrome Lookup present in Advanced Tab: "+await dealershippage.isPresentAllowChromeLookupAdvancedTab());

        //HVMS
        await utils.logInfo("Value of HVMS Push before toggle : "+await dealershippage.getHVMSPushStatus());
        await utils.logInfo("Toggle HVMS Push Slider Button");
        await dealershippage.toggleHVMSPush();
        await utils.logInfo("Value of HVMS Push after toggle : "+await dealershippage.getHVMSPushStatus());
        browser.driver.sleep(browser.params.sleep.sleep10);

        //IAS
        await utils.logInfo("Value of IAS Sync before toggle : "+await dealershippage.getIASSyncStatus());
        await utils.logInfo("Toggle IAS Sync Slider Button");
        await dealershippage.toggleIASSync();
        await utils.logInfo("Value of IAS Sync after toggle : "+await dealershippage.getIASSyncStatus());
        browser.driver.sleep(browser.params.sleep.sleep10);

        //CRM Email
        // var crmName = await dealershippage.getCRMName();
        // var crmEmail = await dealershippage.getCRMEmail();
        // await utils.logInfo("Value of CRM Name before Delete : "+crmName);
        // await utils.logInfo("Value of CRM Email before Delete : "+crmEmail);
        // await utils.logInfo("Delete CRM Email");
        // await dealershippage.deleteCRMNameEmail();

        await utils.logInfo("Click Save Button in Advanced Tab");
        await dealershippage.clickAdvancedSaveBtn();
        browser.sleep(browser.params.sleep.sleep20);

        //*********************************** Set Increase Offer in Employee Tab *****************************************//
        await utils.logInfo("Edit Employees Tab");
        await utils.logInfo("Is Employees tab present: "+await dealershippage.isEmployeeTabPresent());
        await utils.logInfo("Click on Employees Tab");        
        await dealershippage.clickEmployeesTab();
        await utils.logInfo("Is Employee Table present in Employees Tab: "+await dealershippage.isPresentEmployeeTableEmployeesTab());
        await utils.logInfo("Select first checkbox for Employee table");
        await dealershippage.selectFirstCheckBoxEmployeeTable();
        await utils.logInfo("Click on Edit Button of the selected Employee");
        await dealershippage.clickEditButton();

        //Enable Increase Offer
        await utils.logInfo("Value of Increase Offer before toggle : "+await dealershippage.getIncreaseOfferStatus());
        await utils.logInfo("Toggle Enable Increase Offer Slider Button");
        await dealershippage.toggleIncreaseOffer();
        await utils.logInfo("Value of Increase Offer after toggle : "+await dealershippage.getIncreaseOfferStatus());
        browser.driver.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Click Save Button in Employee Tab");
        await dealershippage.clickEmployeeSaveBtn();
        browser.sleep(browser.params.sleep.sleep20);

        //************************************** Verify Hidden options on Appraisal Page **********************************************//
        //Open an Appraisal
        await browser.waitForAngularEnabled(true);
        await utils.logInfo("Get an Appraisal by ID -'"+appraisalID+"'");
        await appraisalpage.getAppraisalByID(appraisalID);
        await browser.waitForAngularEnabled(false);

        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True
        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   
        await browser.sleep(browser.params.sleep.sleep10);
        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        //Verify Ground option is not present
        expect(await appraisalpage.isPresentGroundVehicleBtn()).toBeTruthy("Verify 'Ground' Option is present under Select Action after selecting product 'Accu-Trade - Appraiser Basic' in Dealership page");
        expect(await appraisalpage.isPresentIncreaseOfferBtn()).toBeTruthy("Verify 'Increase Offer' Option is present under Select Action");
        //expect(await appraisalpage.isPresentHVMSBtn()).toBeTruthy("Verify 'Send to HVMS' Option is present under Select Action");
        expect(await appraisalpage.isPresentIASBtn()).toBeTruthy("Verify 'Send to IAS' Option is present under Select Action");
        //expect(await appraisalpage.isPresentCRMBtn()).toBeFalsy("Verify 'Send to CRM' Option is present under Select Action");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled



    }); //it

    
}); //describe    