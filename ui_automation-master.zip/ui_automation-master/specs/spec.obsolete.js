

var loginpage = require('../pages.obsolete/loginpage');
var verifymobilenumberpage = require('../pages.obsolete/verify.mobile.number.page');
var homepage = require('../pages.obsolete/home.page');
var utils = require('./utils/utils');

describe('Login',function(){

    beforeEach(function() {
        loginpage.get();
    });
    
    xit('With Valid Username and Invalid Password',function(){
        utils.logInfo("Set User Name: "+browser.params.login.validuser);
        loginpage.setUsername(browser.params.login.validuser);
        
        utils.logInfo("Set Password: "+browser.params.login.invalidpassword);
        loginpage.setPassword(browser.params.login.invalidpassword);
        
        utils.logInfo("Click Sigin Button");
        loginpage.clickSignIn();
    });


    xit('With Valid Username and Password',function(){
        loginpage.setUsername(browser.params.login.validuser);
        loginpage.setPassword(browser.params.login.validpassword);
        loginpage.clickSignIn();
        browser.waitForAngular();

        browser.getCurrentUrl().then(function(url){
            if(url == verifymobilenumberpage.getUrl()){
                expect(url).toBe(verifymobilenumberpage.getUrl()); //*** Assertion ***/
                verifymobilenumberpage.clickRemindme();
                browser.waitForAngular();
            }
        })
       
        //expect(loginpage.getAllAppraisalsLabel()).toEqual('All Appraisals');//*** Assertion ***/
        browser.waitForAngular();
        
        homepage.clickStartAppraisalBtn();
        //browser.ignoreSynchronization = true; //*** Ignore Sync ***/
    
        //browser.waitForAngular();
        homepage.setVin(browser.params.vin.validvin);
        //browser.ignoreSynchronization = false; //*** Ignore Sync ***/

        homepage.clickVinSearch();

        //browser.waitForAngular();
        homepage.clickFirstTrim();

        //browser.waitForAngular();
        //browser.ignoreSynchronization = true; //*** Ignore Sync ***/
        browser.waitForAngularEnabled(false);
        
        browser.sleep(20000);
        expect(homepage.getAppraisalVIN()).toContain('4T1B11HK7JU037859'); //*** Assertion ***/    
        //browser.waitForAngular();
        //homepage.closeAppraisal();
        //browser.ignoreSynchronization = false;
        browser.waitForAngularEnabled(true);

        //homepage.clickLogout();
        //console.log("Log Out")

    });

    xit('Go to My Account',function(){
        homepage.get();
        browser.waitForAngular();
        expect(loginpage.getAllAppraisalsLabel()).toEqual('All Appraisals');//*** Assertion ***/
        browser.waitForAngular();
        //homepage.getMyProfile();
        homepage.getMyAccount();
        //browser.waitForAngular();
    });

    xit('With Valid Username and Password3',function(){
        homepage.get();
        //expect(loginpage.getAllAppraisalsLabel()).toEqual('All Appraisals');//*** Assertion ***/
        homepage.clickStartAppraisalBtn();

        //utils.logInfo("waiting for angular");

        //browser.waitForAngularEnabled(false); //*** Ignore Sync ***/
        //browser.sleep(10000);

        utils.logInfo("entering vin");

        homepage.setVin('4T1B11HK7JU037859');

        utils.logInfo("clicking search");

        homepage.clickVinSearch();
        //browser.ignoreSynchronization = false; //*** Ignore Sync ***/


        //browser.waitForAngular();
        //browser.sleep(10000);

        utils.logInfo("clicking first trim");

        homepage.clickFirstTrim();

        //browser.waitForAngular();
        //browser.ignoreSynchronization = true; //*** Ignore Sync ***/
        
        //browser.sleep(10000);

        utils.logInfo("checking for vin");

        //expect(homepage.getAppraisalVIN()).toContain('4T1B11HK7JU037859'); //*** Assertion ***/
        browser.waitForAngularEnabled(false);
        
        utils.logInfo("Before Sleep");
        browser.sleep(15000);
        utils.logInfo("After Sleep");


        homepage.getAppraisalVIN().then(function(txt){
            utils.logInfo("Vin is "+txt);
            browser.waitForAngularEnabled(true);
            utils.logInfo("waiting for angular true");
            expect(txt).toContain('4T1B11HK7JU037859');
            utils.logInfo("After Expect");


        });
        
        
        //browser.sleep(10000);
        
        //browser.waitForAngular();
        //homepage.closeAppraisal();

        //homepage.clickLogout();
        //console.log("Log Out")

    });

    xit('With Valid Username and Password4',function(){
        homepage.get();
        browser.waitForAngular();
        expect(loginpage.getAllAppraisalsLabel()).toEqual('All Appraisals');//*** Assertion ***/
        browser.waitForAngular();
        homepage.clickStartAppraisalBtn();

        browser.waitForAngular();
        homepage.setVin('4T1B11HK7JU037859');

        homepage.clickVinSearch();

        browser.waitForAngular();
        homepage.clickFirstTrim();

        //browser.waitForAngular();
        browser.ignoreSynchronization = true; //*** Ignore Sync ***/
        
        browser.sleep(10000);
        expect(homepage.getAppraisalVIN()).toContain('4T1B11HK7JU037859'); //*** Assertion ***/    
        //browser.waitForAngular();
        //homepage.closeAppraisal();
        browser.ignoreSynchronization = false;

        //homepage.clickLogout();
        //console.log("Log Out")

    });

    xit('With Valid Username and Password5',function(){
        homepage.get();
        browser.waitForAngular();
        expect(loginpage.getAllAppraisalsLabel()).toEqual('All Appraisals');//*** Assertion ***/
        browser.waitForAngular();
        homepage.clickStartAppraisalBtn();

        browser.waitForAngular();
        homepage.setVin('4T1B11HK7JU037859');

        homepage.clickVinSearch();

        browser.waitForAngular();
        homepage.clickFirstTrim();

        //browser.waitForAngular();
        browser.ignoreSynchronization = true; //*** Ignore Sync ***/
        
        browser.sleep(10000);
        //browser.ignoreSynchronization = false;

        expect(homepage.getAppraisalVIN()).toContain('4T1B11HK7JU037859'); //*** Assertion ***/    
        

        //browser.waitForAngular();
        //homepage.closeAppraisal();

        //homepage.clickLogout();
        //console.log("Log Out")





    });


    // it('With Valid Username and Valid Password',function(){
    //     loginpage.setUsername('amit+ATUSSA@accu-trade.com');
    //     loginpage.setPassword('Test777');
    //     loginpage.clickSignIn();
    //     browser.waitForAngular();
    //     expect(loginpage.getAllAppraisalsLabel()).toEqual('All Appraisals');
    //     homepage.clickStartAppraisalBtn();
    //     browser.sleep(10000);   
        

    // });

/*
    it('With Invalid Username and Valid Password',function(){
        
        userNameTxtFld.sendKeys("invalid-email@accu-trade.com");
        passwordTxtFld.sendKeys("Test777");
        signInBtn.click();
        expect(wrongCredentialsText.getText()).toEqual('Wrong email or password.');

    });  
*/












        //browser.get('https://angularjs.org');
        //element(by.model('yourName')).sendKeys("Tom");
        //var text = element(by.xpath('/html/body/div[2]/div[1]/div[2]/div[2]/div/h1'));
        //expect(text.getText()).toEqual('Hello Tom!!!');







});