var loginpage = require('../pages/login.page');
var verifymobilenumberpage = require('../pages/verifymobilenumber.page');
var homepage = require('../pages/home.page');
var appraisalpage = require('../pages/appraisal.page');
var utils = require('../utilities/utils');

describe('Scorecard Test Suite', function () { // ********************** Describe1 *******************************
    // browser.manage().timeouts().implicitlyWait(5000);
    // browser.driver.manage().window().maximize();
    utils.logInfo("TEST SUITE: Scorecard");
    utils.logInfo("TEST RUN : "+"https://autodevteam.testrail.net/index.php?/runs/view/895&group_by=cases:section_id&group_order=asc");
    var count = 0;

    beforeEach(async function () {
        await utils.logInfo("Getting Home Page")
        await homepage.get();
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.getCurrentUrl().then(async function (url) {
            await utils.logInfo("Before each : Current Url is "+url);
            await browser.sleep(browser.params.sleep.sleep5);

            if (url == await loginpage.getURL()) {
                utils.logInfo("Sign in since current page is Login page")
                await loginpage.signIn(browser.params.login.superadminuser, browser.params.login.superadminpassword);
                await browser.getCurrentUrl().then(async function (url) {
                    if (url == await verifymobilenumberpage.getUrl()) {
                        await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                        await verifymobilenumberpage.clickRemindme();
                    }//if
                })//then
            }//if
            else if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }

        });//browser.getCurrentUrl()

        if(await homepage.isPresentCancelSearchAppraisalListBtn()){
            await homepage.clickCancelSearchAppraisalListBtn();
            await browser.sleep(browser.params.sleep.sleep5);
        }

        await browser.waitForAngularEnabled(true);


        if(count == 0){
            await homepage.closeAllWalkme();
            count = 1;
        }//if count

    }); //beforeEach    

    afterEach(async function () {
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True
    });
    
    it('*** New Appraisal: Add Vehicle by entering a VIN  ', async function () {
        utils.logInfo("***** TEST CASE : New Appraisal: Add Vehicle by entering a VIN   *****");

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False
        expect(appraisalpage.isScoreCardBarPresent()).toBeTruthy(); // *** Assertion        
        await browser.sleep(browser.params.sleep.sleep5);
        await browser.waitForAngularEnabled(true);
    });


    it('*** Rest API: Add Vehicle by entering a VIN  ', async function () {
        utils.logInfo("***** TEST CASE : Rest API - New Appraisal: Add Vehicle by entering a VIN   *****");


        
    });


});