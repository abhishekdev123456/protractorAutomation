

var loginpage = require('../pages/login.page');
var verifymobilenumberpage = require('../pages/verifymobilenumber.page');
var homepage = require('../pages/home.page');
var perseuspage = require('../pages/perseus.page');
var utils = require('../utilities/utils');

xdescribe('Mutiple Windows',function(){

    browser.manage().timeouts().implicitlyWait(5000);
    browser.driver.manage().window().maximize();
    utils.logInfo("TEST SUITE: MULTIPLE WINDOWS");
    utils.logInfo("TEST RUN : ");
    //var count = 0;
    
    beforeEach(async function () {
        await utils.logInfo("Getting Home Page")
        await homepage.get();
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.getCurrentUrl().then(async function (url) {
            await utils.logInfo("Before each : Current Url is "+url);
            await browser.sleep(browser.params.sleep.sleep5);

            if (url == await loginpage.getURL()) {
                utils.logInfo("Sign in since current page is Login page")
                await loginpage.signIn(browser.params.login.superadminuser, browser.params.login.superadminpassword);
                await browser.getCurrentUrl().then(async function (url) {
                    if (url == await verifymobilenumberpage.getUrl()) {
                        await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                        await verifymobilenumberpage.clickRemindme();
                    }//if
                })//then
            }//if
            else if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }

        });//browser.getCurrentUrl()

        if(await homepage.isPresentCancelSearchAppraisalListBtn()){
            await homepage.clickCancelSearchAppraisalListBtn();
            await browser.sleep(browser.params.sleep.sleep5);
        }
        await browser.waitForAngularEnabled(true);
    }); //beforeEach    

    afterEach(async function () {
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True
    });  

    it('Test New Appraisal Window',async function(){

        await browser.refresh();
        browser.sleep(browser.params.sleep.sleep10);

        browser.getCurrentUrl().then(async function (url) {
            await utils.logInfo("Current Url1 is "+url);
            await browser.sleep(browser.params.sleep.sleep5);
        });    

        browser.getTitle().then(function(txt){
            console.log("Main Browser title after Start Appraisal button is "+txt);

            var windowHandles = browser.getAllWindowHandles();

            windowHandles.then(function(handles){
                var parentHandle = handles[0];
                var childHandle = handles[1];
                console.log("Total Handles: "+handles.length);
                console.log("Handle1: "+handles[0]);
                browser.sleep(browser.params.sleep.sleep5);
            });   
        });


        //await homepage.clickStartAppraisalBtn();
        await homepage.navigateThroughMenu("Customer Experience");
        await browser.sleep(browser.params.sleep.sleep5);


        // browser.getTitle().then(function(txt){
        //     console.log("Main Browser title after Start Appraisal button is "+txt);

        //     var windowHandles = browser.getAllWindowHandles();

        //     windowHandles.then(function(handles){
        //         var parentHandle = handles[0];
        //         var childHandle = handles[1];
        //         console.log("Total Handles: "+handles.length);
        //         console.log("Handle1: "+handles[0]);
        //         console.log("Handle2: "+handles[1]);
        //         //console.log("Handle3: "+handles[2]);

        //         browser.switchTo().window(handles[0]);
        //         browser.sleep(browser.params.sleep.sleep5);

        //         browser.getTitle().then(function(txt){
        //             console.log("Main Browser title after Switching is "+txt);
        //         }); 
        //     });   
        // });


        browser.getAllWindowHandles().then(function(allGUID){
            utils.logInfo("Number of tabs opened: "+allGUID.length);
            // iterate through the tabs
            for(var guid of allGUID){
                utils.logInfo("Starting For Loop");

                //find the new browser tab
                // if(guid !=parentGUID){
                utils.logInfo("Switching to guid: "+guid);
                browser.switchTo().window(guid);
                browser.sleep(browser.params.sleep.sleep5);

                browser.getTitle().then(function(txt){
                    utils.logInfo("Main Browser title after switching tab is "+txt);
                });

                browser.getCurrentUrl().then(async function (url) {
                    await utils.logInfo("Current Url2 is "+url);
                    await browser.sleep(browser.params.sleep.sleep5);
                });   

        //     }); 
                //     break;
                // }
                utils.logInfo("Ending For Loop");

            } //for
            //browser.close();
            browser.sleep(browser.params.sleep.sleep5);
            // switch back to the parent tab
            //browser.switchTo().window(parentGUID);
        });   

        await browser.sleep(browser.params.sleep.sleep10);


    }); //it


    

});//describe


describe('Protractor Typescript Demo', function() {
	browser.ignoreSynchronization = true; // for non-angular websites
	it('Browser Window Operation', function() {
		// set implicit time to 30 seconds
		browser.manage().timeouts().implicitlyWait(30000);
		// navigate to the url
		browser.get("https://chercher.tech/protractor/handle-browser-windows-protractor");
		// get the Session id of the Parent
		browser.getWindowHandle().then(function(parentGUID){
			// click the button to open new window
			element(by.id("two-window")).click();
			browser.sleep(5000);
			// get the All the session id of the browsers
			browser.getAllWindowHandles().then(function(allGUID){
				// print the title of th epage
				console.log("Page title before Switching : "+ browser.getTitle());
				console.log("Total Windows : "+allGUID.length);
				// iterate the values in the set
				for(let guid of allGUID){
					// one enter into if blobk if the GUID is not equal to parent window's GUID
					if(guid !=parentGUID){
						// switch to the guid
						browser.switchTo().window(guid);
						// break the loop
						break;
					}
				}
				// search on the google page
				element(by.name("q")).sendKeys("success");
				// print the title after switching
				browser.sleep(5000).then(function(){
					console.log("Page title after Switching to goolge : "+ browser.getTitle());
				})
				// close the browser
				browser.close();
				// switch back to the parent window
				browser.switchTo().window(parentGUID);
				// print the title
				browser.sleep(5000).then(function(){
					console.log("Page title after switching back to Parent: "+ browser.getTitle());
				})
			})
		})
	});
});