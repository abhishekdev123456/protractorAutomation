var loginpage = require('../pages/login.page');
var verifymobilenumberpage = require('../pages/verifymobilenumber.page');
var homepage = require('../pages/home.page');
var myaccountpage = require('../pages/myaccount.page');
var myprofilepage = require('../pages/myprofile.page');
var appraisalpage = require('../pages/appraisal.page');
var usermgmtpage = require('../pages/usermanagement.page');
var edituserpage = require('../pages/edituser.usermgmt.page');
var dealerconsolepage = require('../pages/dealer.console.page');
var dealershippage = require('../pages/dealership.page');
var recommenderpage = require('../pages/recommender.page');
var dealershippage = require('../pages/dealership.page');
var crpage = require('../pages/cr.page');
var utils = require('../utilities/utils');
var testdata = require('../data/test.data.js');
var using = require('jasmine-data-provider');
var path = require("path");

describe('Appraisals Test Suite', function () { // ********************** Describe1 *******************************
    browser.manage().timeouts().implicitlyWait(5000);
    browser.manage().window().maximize();
    utils.logInfo("TEST SUITE: Appraisals");
    utils.logInfo("TEST RUN : "+"https://autodevteam.testrail.net/index.php?/runs/view/871&group_by=cases:section_id&group_order=asc");
    var count = 0;
    
    beforeEach(async function () {
        await utils.logInfo("Getting Home Page")
        await homepage.get();
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.getCurrentUrl().then(async function (url) {
            await utils.logInfo("Before each : Current Url is "+url);
            await browser.sleep(browser.params.sleep.sleep5);

            if (url == await loginpage.getURL()) {
                utils.logInfo("Sign in since current page is Login page")
                await loginpage.signIn(browser.params.login.superadminuser, browser.params.login.superadminpassword);
                await browser.getCurrentUrl().then(async function (url) {
                    if (url == await verifymobilenumberpage.getUrl()) {
                        await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                        await verifymobilenumberpage.clickRemindme();
                    }//if
                })//then
            }//if
            else if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }

        });//browser.getCurrentUrl()

        if(await homepage.isPresentCancelSearchAppraisalListBtn()){
            await homepage.clickCancelSearchAppraisalListBtn();
            await browser.sleep(browser.params.sleep.sleep5);
        }

        await browser.waitForAngularEnabled(true);


        if(count == 0){
            await homepage.closeAllWalkme();
            count = 1;
        }//if count

    }); //beforeEach    

    afterEach(async function () {
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True
    });    

    it('*** New Appraisal: Add Vehicle by entering a VIN  ', async function () {
        utils.logInfo("***** TEST CASE : New Appraisal: Add Vehicle by entering a VIN   *****");

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        //Click on Back Arrow Button
        await utils.logInfo("Click on Back arrow button");
        await appraisalpage.clickBackArrowBtn();

        //Verify Appraisal available in Appraisals List
        await utils.logInfo("Search Appraisal on Appraisal List");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Search Results in Appraisal List
        expect(await homepage.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
        expect(await homepage.getSearchResultSearchTerm()).toBe(appraisalID,"Verify Search results showing serached term at the bottom of Appraisal List");

        await homepage.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep5);

        expect(await appraisalpage.getAppraisalID()).toBe(appraisalID,"Verify searched Appraisal open successfully");

    }); //it

    it('*** New Appraisal: Add Vehicle by YMMS ', async function () {
        utils.logInfo("***** TEST CASE : New Appraisal: Add Vehicle by YMMS    *****");

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalYMMT(browser.params.ymmt.year,browser.params.ymmt.make,browser.params.ymmt.model,browser.params.ymmt.trim);

        await utils.logInfo("Verify Appraisal Year Make Model matching expected YMM");
        await expect(await appraisalpage.getAppraisalYMM()).toContain(browser.params.ymmt.year+" "+browser.params.ymmt.make+" "+browser.params.ymmt.model,"Verify Appraisal Year Make Model matching expected YMM on Appraisal Page"); //*** Assertion ***/
        
        await utils.logInfo("Verify Appraisal Trim matching expected trim");
        await expect(await appraisalpage.getAppraisalTrim()).toContain(browser.params.ymmt.trim,"Verify Appraisal Trim matching expected trim on Appraisal Page"); //*** Assertion ***/

    }); //it

    it('*** New Appraisal: Create appraisal using customer button - opens in Customer Mode  ', async function () {
        utils.logInfo("***** TEST CASE : New Appraisal: Create appraisal using customer button - opens in Customer Mode   *****");

        //Create New Appraisal using VIN
        await homepage.createCustomerNewAppraisalVIN(browser.params.vin.validvin,"first");
        expect(await appraisalpage.isPresentConsumerPriceBarBar()).toBeTruthy("Verify Consumer Appraisal Page Displayed");
        expect(await appraisalpage.isPresentFirstNameInputCustomerDetail()).toBeTruthy("Verify Customer Details First Name field is present means Consumer mode is ON")

        //Change to Dealer Mode
        await appraisalpage.clickAppraisalConsumerDealerMode();

        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        //Click on Back Arrow Button
        await utils.logInfo("Click on Back arrow button");
        await appraisalpage.clickBackArrowBtn();

        //Verify Appraisal available in Appraisals List
        await utils.logInfo("Search Appraisal on Appraisal List");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Search Results in Appraisal List
        expect(await homepage.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
        expect(await homepage.getSearchResultSearchTerm()).toBe(appraisalID,"Verify Search results showing serached term at the bottom of Appraisal List");

        await homepage.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep5);

        expect(await appraisalpage.getAppraisalID()).toBe(appraisalID,"Verify searched Appraisal open successfully");

    }); //it

    using(testdata.loweruppercasevin, function (data, description) {
        it('*** New Appraisal: Create an appraisal using lower case letters   ', async function () {
            utils.logInfo("***** New Appraisal: Create an appraisal using lower case letters   *****");

            //Create New Appraisal using VIN
            await homepage.createNewAppraisalVIN(data.vin,"first");

            await utils.logInfo("Verify Appraisal VIN matching expected VIN");
            expect(await homepage.getAppraisalVIN()).toContain(data.vin.toUpperCase(),"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/ 

            var appraisalID = await appraisalpage.getAppraisalID();
            await utils.logInfo("Value of Appraisal ID is "+appraisalID);


        }); //it
    });//using

    it('*** New Appraisal: Create a new appraisal while logged as EACH role ', async function () {
        utils.logInfo("***** TEST CASE : New Appraisal: Create a new appraisal while logged as EACH role    *****");
        utils.logInfo("Already Covered this test in Smoke Automated tests");
    }); //it

    it('*** Vehicle Details: Ensure first change is saved ', async function () {
        utils.logInfo("***** TEST CASE : Vehicle Details: Ensure first change is saved   *****");

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);
        expect(await appraisalpage.isSelectedOEMCertifiedServiceStatus()).toBe("false","Verify OEM Certfified service status button is not selected by default");

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await appraisalpage.setServiceStatus("OEM CERTIFIED");
        //Click on Back Arrow Button
        await utils.logInfo("Click on Back arrow button");
        await appraisalpage.clickBackArrowBtn();

        //Verify Appraisal available in Appraisals List
        await utils.logInfo("Search Appraisal on Appraisal List");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Search Results in Appraisal List
        expect(await homepage.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
        expect(await homepage.getSearchResultSearchTerm()).toBe(appraisalID,"Verify Search results showing serached term at the bottom of Appraisal List");

        await homepage.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep5);

        expect(await appraisalpage.getAppraisalID()).toBe(appraisalID,"Verify searched Appraisal open successfully");
        expect(await appraisalpage.isSelectedOEMCertifiedServiceStatus()).toBe("true","Verify OEM Certfified service status button is selected");
        

    }); //it    

    it('*** Vehicle Details: Change Mileage and verify appraisal header updates ', async function () {
        utils.logInfo("***** TEST CASE : Vehicle Details: Ensure first change is saved   *****");

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);

        var odometer = "50,000";
        await appraisalpage.setOdometer(odometer);
        await browser.sleep(browser.params.sleep.sleep10);

        var mileage = await appraisalpage.getMileage();
        utils.logInfo("Value of Mileage is "+mileage); 
        
        expect(mileage).toBe(odometer+" Mi","Verify any changes made to odometer field are instantly reflected on mileage header");

        odometer = "60,000";
        await appraisalpage.setOdometer(odometer);
        await browser.sleep(browser.params.sleep.sleep10);

        mileage = await appraisalpage.getMileage();
        utils.logInfo("Value of Mileage is "+mileage); 
        
        expect(mileage).toBe(odometer+" Mi","Verify any changes made to odometer field are instantly reflected on mileage header");

        odometer = "70,000";
        await appraisalpage.setOdometer(odometer);
        await browser.sleep(browser.params.sleep.sleep10);

        mileage = await appraisalpage.getMileage();
        utils.logInfo("Value of Mileage is "+mileage); 
        
        expect(mileage).toBe(odometer+" Mi","Verify any changes made to odometer field are instantly reflected on mileage header");

    }); //it    

    it('*** Vehicle Details: Modify Vehicle Details ', async function () {
        utils.logInfo("***** TEST CASE : Vehicle Details: Modify Vehicle Details   *****");

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.validvinoptions,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);
                
        expect(await appraisalpage.isSelectedOptions4WheelDrive()).toBe("false","Verify '4 WHEEL DRIVE' option is not selected by default");

        await appraisalpage.setOptions("4 WHEEL DRIVE");
        await appraisalpage.selectCDBodyTab();
        await appraisalpage.selectAdjustmentAppraisalScreen("Body","Roof","rust","repair");
        
        //Verify
        expect(await appraisalpage.isSelectedOptions4WheelDrive()).toBe("true","Verify '4 WHEEL DRIVE' option is selected");
        expect(await appraisalpage.getCDBodyTabCount()).toBe("1","Verify Damage count of Body Tab");

        await browser.refresh();
        expect(await appraisalpage.isSelectedOptions4WheelDrive()).toBe("true","Verify '4 WHEEL DRIVE' option is selected");
        expect(await appraisalpage.getCDBodyTabCount()).toBe("1","Verify Damage count of Body Tab");

        //Click on Back Arrow Button
        await utils.logInfo("Click on Back arrow button");
        await appraisalpage.clickBackArrowBtn();

        //Verify Appraisal available in Appraisals List
        await utils.logInfo("Search Appraisal on Appraisal List");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Search Results in Appraisal List
        expect(await homepage.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
        expect(await homepage.getSearchResultSearchTerm()).toBe(appraisalID,"Verify Search results showing serached term at the bottom of Appraisal List");

        await homepage.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep5);

        expect(await appraisalpage.getAppraisalID()).toBe(appraisalID,"Verify searched Appraisal open successfully");
        

    }); //it    

    it('*** Mileage: Change mileage and verify that is saves and pricing updates as expected ', async function () {
        utils.logInfo("***** TEST CASE : Mileage: Change mileage and verify that is saves and pricing updates as expected   *****");

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);

        var odometer = "100,000";
        await appraisalpage.setOdometer(odometer);
        await browser.sleep(browser.params.sleep.sleep10);

        var mileage = await appraisalpage.getMileage();
        utils.logInfo("Value of Mileage is "+mileage); 
        
        expect(mileage).toBe(odometer+" Mi","Verify any changes made to odometer field are instantly reflected on mileage header");
        
        await browser.refresh();
        expect(await appraisalpage.getMileage()).toBe(odometer+" Mi","Verify any changes made to odometer field are instantly reflected on mileage header");

        //Click on Back Arrow Button
        await utils.logInfo("Click on Back arrow button");
        await appraisalpage.clickBackArrowBtn();

        //Verify Appraisal available in Appraisals List
        await utils.logInfo("Search Appraisal on Appraisal List");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Search Results in Appraisal List
        expect(await homepage.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
        expect(await homepage.getSearchResultSearchTerm()).toBe(appraisalID,"Verify Search results showing serached term at the bottom of Appraisal List");

        await homepage.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep5);

        mileage = await appraisalpage.getMileage();
        utils.logInfo("Value of Mileage at reopening is "+mileage); 

        expect(await appraisalpage.getAppraisalID()).toBe(appraisalID,"Verify searched Appraisal open successfully");
        expect(mileage).toBe(odometer+" Mi","Verify any changes made to odometer field are instantly reflected on mileage header");

        
    }); //it    


    it('*** Mileage: Low Mileage alert is displayed ', async function () {
        utils.logInfo("***** TEST CASE : Mileage: Low Mileage alert is displayed   *****");

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);

        expect(await appraisalpage.isPresentLowMileageAlert()).toBeFalsy("Verify Low Mileage is not present by default as Mileage is quite big");

        var odometer = "1,000";
        await appraisalpage.setOdometer(odometer);
        await browser.sleep(browser.params.sleep.sleep10);

        var mileage = await appraisalpage.getMileage();
        utils.logInfo("Value of Mileage is "+mileage); 
        
        await utils.logInfo("Verify any changes made to odometer field are instantly reflected on mileage header");
        expect(mileage).toBe(odometer+" Mi","Verify any changes made to odometer field are instantly reflected on mileage header");

        await utils.logInfo("Verify Low Mileage Alert is present");
        expect(await appraisalpage.isPresentLowMileageAlert()).toBeTruthy("Verify Low Mileage is present when change the mileage to very low value -"+odometer);


        await utils.logInfo("Verify Low Mileage Alert Text Prefix");
        expect(await appraisalpage.getLowMileageAlertLabel()).toBe("Low Mileage:","Verify Low Mileage Alert Text Prefix");

        await utils.logInfo("Verify Low Mileage Alert Text");
        expect(await appraisalpage.getLowMileageAlertDesc()).toBe("Your vehicle could be worth more than Target Trade. Please contact your inventory consultant for a final number.","Verify Low Mileage Alert Text");
        
        await browser.refresh();

        mileage = await appraisalpage.getMileage();
        expect(mileage).toBe(odometer+" Mi","Verify any changes made to odometer field are instantly reflected on mileage header");
        expect(await appraisalpage.getLowMileageAlertLabel()).toBe("Low Mileage:","Verify Low Mileage Alert Text Prefix");
        expect(await appraisalpage.getLowMileageAlertDesc()).toBe("Your vehicle could be worth more than Target Trade. Please contact your inventory consultant for a final number.","Verify Low Mileage Alert Text");

        //Click on Back Arrow Button
        await utils.logInfo("Click on Back arrow button");
        await appraisalpage.clickBackArrowBtn();

        //Verify Appraisal available in Appraisals List
        await utils.logInfo("Search Appraisal on Appraisal List");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Search Results in Appraisal List
        expect(await homepage.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
        expect(await homepage.getSearchResultSearchTerm()).toBe(appraisalID,"Verify Search results showing serached term at the bottom of Appraisal List");

        await homepage.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep5);

        mileage = await appraisalpage.getMileage();
        utils.logInfo("Value of Mileage at reopening is "+mileage); 

        expect(mileage).toBe(odometer+" Mi","Verify any changes made to odometer field are instantly reflected on mileage header");
        expect(await appraisalpage.getLowMileageAlertLabel()).toBe("Low Mileage:","Verify Low Mileage Alert Text Prefix");
        expect(await appraisalpage.getLowMileageAlertDesc()).toBe("Your vehicle could be worth more than Target Trade. Please contact your inventory consultant for a final number.","Verify Low Mileage Alert Text");

    });    

    it('*** Mileage: Odometer Set To Base updates both the mileage and the odometer amount ', async function () {
        utils.logInfo("***** TEST CASE : Mileage: Odometer Set To Base updates both the mileage and the odometer amount  *****");

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);

        var baseOdometer = await appraisalpage.getBaseOdometer();
        utils.logInfo("Value of Base Odometer is "+baseOdometer);

        var mileage = await appraisalpage.getMileage();
        utils.logInfo("Value of Mileage is "+mileage); 

        expect(mileage).toBe(baseOdometer+" Mi","Verify Base Odometer and Mileage Header readings are the same");


        var odometer = "100,000";
        await appraisalpage.setOdometer(odometer);
        await browser.sleep(browser.params.sleep.sleep10);

        mileage = await appraisalpage.getMileage();
        utils.logInfo("Value of Mileage is "+mileage); 
        
        expect(mileage).toBe(odometer+" Mi","Verify changes made to odometer field are instantly reflected on mileage header");

        await appraisalpage.clickSetToBaseOdometer();

        mileage = await appraisalpage.getMileage();
        utils.logInfo("Value of Mileage is "+mileage); 
        
        expect(mileage).toBe(baseOdometer+" Mi","Verify changes made to odometer field are instantly reflected on mileage header");

        await browser.refresh();

        mileage = await appraisalpage.getMileage();
        expect(mileage).toBe(baseOdometer+" Mi","Verify changes made to odometer field are instantly reflected on mileage header");

    });




    it('*** Read only: ensure damage values cannot be added or removed from the apprasial ', async function () {
        utils.logInfo("***** TEST CASE : Read only: ensure damage values cannot be added or removed from the apprasial   *****");

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);
                
        await appraisalpage.selectCDMechanicalTab();
        await appraisalpage.selectAdjustmentAppraisalScreen("Mechanical","Roof Inop","none","none");

        await appraisalpage.clickBackArrowBtn();
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.refresh();

        await utils.logInfo("Archive Appraisal By ID");
        await homepage.archiveAppraisalByID(appraisalID);
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Open Archived Appraisal By ID");
        await homepage.openArchivedAppraisalByID(appraisalID);

        await browser.sleep(browser.params.sleep.sleep10);
        expect(await appraisalpage.isReadOnlyAppraisal()).toBeTruthy("Verify Appraisal '"+appraisalID+"' is Read Only");

        await appraisalpage.selectCDMechanicalTab();

        expect(await appraisalpage.isDisabledCDMechanicalRoofInopBtn()).toBeTruthy("Verify Mechanical Roof Inop option is disabled for Read Only Appraisal");
        expect(await appraisalpage.isDisabledCDMechanicalSteeringBtn()).toBeTruthy("Verify Mechanical Steering option is disabled for Read Only Appraisal");


    });

    it('*** Read Only: Expired Appraisals should  be displayed in Read-only mode', async function () {
        utils.logInfo("***** TEST CASE : Read Only: Expired Appraisals should  be displayed in Read-only mode *****");

        var appraisalID = browser.params.expiredappraisalids.adminuser
        await browser.refresh();
        await utils.logInfo("Search Appraisal on Appraisal List");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Search Results in Appraisal List
        expect(await homepage.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
        expect(await homepage.getSearchResultSearchTerm()).toBe(appraisalID,"Verify Search results showing serached term at the bottom of Appraisal List");

        await utils.logInfo("Open the searched Appraisal");
        await homepage.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False
        expect(await appraisalpage.getAppraisalID()).toBe(appraisalID,"Verify searched Appraisal open successfully");

        expect(await appraisalpage.isReadOnlyAppraisal()).toBeTruthy("Verify Apprasal is Read Only");
        expect(await appraisalpage.isDisabledOEMCertifiedServiceStatusBtn()).toBe("true","Verify OEM Service Status button is Disabled/Read Only");

        await utils.logInfo("Click on Refresh Button");
        await appraisalpage.clickRefreshOfferBtn();
        await browser.sleep(browser.params.sleep.sleep10);

        expect(await appraisalpage.getAppraisalID()).not.toBe(appraisalID,"Verify searched Appraisal open successfully");

        expect(await appraisalpage.isReadOnlyAppraisal()).toBe(false,"Verify Apprasal is not Read Only");

        expect(await appraisalpage.isDisabledOEMCertifiedServiceStatusBtn()).toBeTruthy("Verify OEM Service Status button is Enable for Appraisal ID - '"+await appraisalpage.getAppraisalID()+"' and Editable after Refresh Offer");


        await browser.waitForAngularEnabled(true); // *** Angular Enabled true

    });

    //

    it('*** Read Only: Admins:  Prospects made by users in another dealership should appear in Read-only mode', async function () {
        utils.logInfo("***** TEST CASE : Read Only: Admins:  Prospects made by users in another dealership should appear in Read-only mode  *****");

        var anotherDealer = "amber";
        await browser.refresh();

        await utils.logInfo("Click on the Prospects List");
        await homepage.clickProspectsAppraisalList();

        await utils.logInfo("Search Prospects on Appraisal List");
        await homepage.searchAppraisalList(anotherDealer);
        await browser.sleep(browser.params.sleep.sleep10);

        var locator = "//table/tbody/tr[2]/td[contains(@class,'age')]";
        var elem = element(by.xpath(locator));
        var age = await elem.getText();

        age = age.substring(0,age.length-1);
        age = Number(age);
        await utils.logInfo("Value of age is "+age);

        await utils.logInfo("Open the searched Appraisal");
        await homepage.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        expect(await appraisalpage.isReadOnlyAppraisal()).toBeTruthy("Verify Apprasal is Read Only");
        expect(await appraisalpage.isDisabledOEMCertifiedServiceStatusBtn()).toBe("true","Verify OEM Service Status button is Disabled/Read Only");

        if(age>3){
            expect(await appraisalpage.isPresentRefreshOfferBtn()).toBeFalsy("Verify Refresh Offer button not present for Read Only expired prospect");
        }


    });    


    it('*** Read Only: Ensure that "Interested in Buying New Car" section is not editable ', async function () {
        utils.logInfo("***** TEST CASE : Read Only: Ensure that 'Interested in Buying New Car' section is not editable  *****");

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Get an Appraisal ID from Appraisal Screen");
        var appraisalID = await appraisalpage.getAppraisalID();


        await utils.logInfo("Enable Wait for Angular");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        await expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   

        await browser.waitForAngularEnabled(false); // *** Angular Disabled

        await utils.logInfo("Click to the Consumer Mode Button");
        await appraisalpage.clickAppraisalConsumerDealerMode();
        await appraisalpage.scrollToFirstNameCustomerDetail();
        //await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Enter First Name into Customer Detail Screen");
        await appraisalpage.setFirstNameConsumerModeCustomerDetail("Jason");
        await utils.logInfo("Enter Last Name into Customer Detail Screen");
        await appraisalpage.setLastNameConsumerModeCustomerDetail("Bland");
        await utils.logInfo("Enter Zip Code into Customer Detail Screen");
        await appraisalpage.setZipCodeConsumerModeCustomerDetail("78641");
        await utils.logInfo("Enter Phone Number into Customer Detail Screen");
        await appraisalpage.setPhoneConsumerModeCustomerDetail("5123334444");
        await utils.logInfo("Enter Email Address into Customer Detail Screen");
        await appraisalpage.setEmailConsumerModeCustomerDetail("fakeemail@accu-trade.com");

        expect(await appraisalpage.isSelectedPaymentYesBtnCustomerDetail()).toBeFalsy("Verify Payment Yes Button is not selected by default in Customer Detail Screen");
        expect(await appraisalpage.isSelectedPaymentNoBtnCustomerDetail()).toBeTruthy("Verify Payment No Button is selected by default in Customer Detail Screen");
        expect(await appraisalpage.isSelectedReplacementVehicleYesBtnCustomerDetail()).toBeFalsy("Verify Replacement Vehicle Yes Button is not selected by default in Customer Detail Screen");
        expect(await appraisalpage.isSelectedReplacementVehicleNoBtnCustomerDetail()).toBeTruthy("Verify Replacement vehicle No Button is selected by default in Customer Detail Screen");

        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Click on Still Making Payment 'Yes' button in Customer Detail");
        await appraisalpage.clickPaymentYesBtnCustomerDetail();
        expect(await appraisalpage.isPresentLoanRadioBtnCustomerDetail()).toBeTruthy("Verify Loan Radio button is present when user select Yes to Still making Payments");
        expect(await appraisalpage.isPresentLeaseRadioBtnCustomerDetail()).toBeTruthy("Verify Lease Radio button is present when user select Yes to Still making Payments");
        expect(await appraisalpage.isPresentLoanAmountRemainingCustomerDetail()).toBeTruthy("Verify 'Approximate Amount Remaining' testfield is present when user select Yes to Still making Payments");

        await utils.logInfo("Click on Interested in Replacement Vehicle 'Yes' button in Customer Detail");
        await appraisalpage.clickReplacementVehicleYesBtnCustomerDetail();
        await appraisalpage.scrollToFirstNameCustomerDetail();
        expect(await appraisalpage.isPresentNewPurchaseRadioBtnCustomerDetail()).toBeTruthy("Verify 'New' Radio Button is present when selected 'Yes' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentUsedPurchaseRadioBtnCustomerDetail()).toBeTruthy("Verify 'Used' Radio Button is present when selected 'Yes' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentCPOPurchaseRadioBtnCustomerDetail()).toBeTruthy("Verify 'CPO' Radio Button is present when selected 'Yes' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentNotSurePurchasedRadioBtnCustomerDetail()).toBeTruthy("Verify 'Not Sure' Radio Button is present when selected 'Yes' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentYearInputCustomerDetail()).toBeTruthy("Verify Year Input field is present when selected 'Yes' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentMakeInputCustomerDetail()).toBeTruthy("Verify Make Input field is present when selected 'Yes' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentModelInputCustomerDetail()).toBeTruthy("Verify Model Input field is present when selected 'Yes' to Interested in Replacement Vehicle Button");
        expect(await appraisalpage.isPresentTrimInputCustomerDetail()).toBeTruthy("Verify Trim Input field is present when selected 'Yes' to Interested in Replacement Vehicle Button");

        await utils.logInfo("Select 'CPO' Purchase Radion button in Customer Detail");
        await appraisalpage.selectCPOPurchaseRadioBtnCustomerDetail();
        expect(await appraisalpage.isPresentYearInputCustomerDetail()).toBeTruthy("Verify Year Input field is present when selected 'CPO' Radio Button");
        expect(await appraisalpage.isPresentMakeInputCustomerDetail()).toBeTruthy("Verify Make Input field is present when selected 'CPO' Radio Button");
        expect(await appraisalpage.isPresentModelInputCustomerDetail()).toBeTruthy("Verify Model Input field is present when selected 'CPO' Radio Button");
        expect(await appraisalpage.isPresentTrimInputCustomerDetail()).toBeTruthy("Verify Trim Input field is present when selected 'CPO' Radio Button");

        await utils.logInfo("Enter Year in Customer Detail screen");
        await appraisalpage.setYearInputCustomerDetail("2017");
        await utils.logInfo("Enter Make in Customer Detail screen");
        await appraisalpage.setMakeInputCustomerDetail("ACURA");
        await utils.logInfo("Enter Model in Customer Detail screen");
        await appraisalpage.setModelInputCustomerDetail("MDX");
        await utils.logInfo("Enter Trim in Customer Detail screen");
        await appraisalpage.setTrimInputCustomerDetail("ADVANCE 2WD 4 Door SUV 3.5L V6");

        await utils.logInfo("Switch back to Dealer Mode");
        await appraisalpage.clickAppraisalConsumerDealerMode();

        await utils.logInfo("Click on Appraisal Back Arrow Button");
        await appraisalpage.clickBackArrowBtn();
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.refresh();

        await utils.logInfo("Archive Appraisal By ID");
        await homepage.archiveAppraisalByID(appraisalID);
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Open Archived Appraisal By ID");
        await homepage.openArchivedAppraisalByID(appraisalID);

        await browser.sleep(browser.params.sleep.sleep10);
        expect(await appraisalpage.isReadOnlyAppraisal()).toBeTruthy("Verify Appraisal '"+appraisalID+"' is Read Only");

        await utils.logInfo("Click on Appraisal Consumer Mode");
        await appraisalpage.clickAppraisalConsumerDealerMode();

        //Verify Values
        expect(await appraisalpage.isPresentCustomerDetailPanel()).toBeTruthy("Verify Customer Detail section is present in Consumer mode");
        expect(await appraisalpage.isSelectedReplacementVehicleYesBtnCustomerDetail()).toBeTruthy("Verify Replacement Vehicle Yes button is selected");
        expect(await appraisalpage.getYearInputCustomerDetail()).toBe("2017","Verify Year value persist when select 'CPO' radion button");
        expect(await appraisalpage.getMakeInputCustomerDetail()).toBe("ACURA","Verify Make value persist when select 'CPO' radion button");
        expect(await appraisalpage.getModelInputCustomerDetail()).toBe("MDX","Verify Model value persist when select 'CPO' radion button");
        expect(await appraisalpage.getTrimInputCustomerDetail()).toBe("ADVANCE 2WD 4 Door SUV 3.5L V6","Verify Trim value persist when select 'CPO' radion button");

        //Verify Control States (Disabled)
        expect(await appraisalpage.isDisabledCPORadioBtnCustomerDetail()).toBeTruthy("Verify 'CPO Radio button' is disabled in Customer Detail when Appraisal is Read Only");
        expect(await appraisalpage.isDisabledYearInputCustomerDetail()).toBeTruthy("Verify 'Year' field is disabled in Customer Detail when Appraisal is Read Only");
        expect(await appraisalpage.isDisabledMakeInputCustomerDetail()).toBeTruthy("Verify 'Make' field is disabled in Customer Detail when Appraisal is Read Only");
        expect(await appraisalpage.isDisabledModelInputCustomerDetail()).toBeTruthy("Verify 'Model' field is disabled in Customer Detail when Appraisal is Read Only");
        expect(await appraisalpage.isDisabledTrimInputCustomerDetail()).toBeTruthy("Verify 'Trim' field is disabled in Customer Detail when Appraisal is Read Only");

        await browser.waitForAngularEnabled(true); // *** Angular Disabled

    });//it    


    it('*** Read Only: Ensure that Guidebook Trim in pricebar is not changeable for READ ONLY appraisals', async function () {
        utils.logInfo("***** TEST CASE : Read Only: Ensure that Guidebook Trim in pricebar is not changeable for READ ONLY appraisals  *****");

        var appraisalID = browser.params.expiredappraisalids.adminuser
        await browser.refresh();
        await utils.logInfo("Search Appraisal on Appraisal List");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Search Results in Appraisal List
        expect(await homepage.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
        expect(await homepage.getSearchResultSearchTerm()).toBe(appraisalID,"Verify Search results showing serached term at the bottom of Appraisal List");

        await utils.logInfo("Open the searched Appraisal");
        await homepage.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False
        expect(await appraisalpage.getAppraisalID()).toBe(appraisalID,"Verify searched Appraisal open successfully");

        expect(await appraisalpage.isReadOnlyAppraisal()).toBeTruthy("Verify Apprasal is Read Only");
        expect(await appraisalpage.isPresentPriceBarBlackBookTrimDropdown()).toBeFalsy("Verify Black Book Trim dropdown not present for expired appraisals");

        //click on Price Bar
        await appraisalpage.getAppraisalMenu();
        await appraisalpage.clickGuidebookAppraisalMenuItem();

        await appraisalpage.clickFirstGuidebook();
        expect(await appraisalpage.isDisabledGuideBookTrimDropdown()).toBeTruthy("Verify Trim dropdown is disabled");
        await browser.sleep(browser.params.sleep.sleep2);

        await appraisalpage.clickSecondGuidebook();
        expect(await appraisalpage.isDisabledGuideBookTrimDropdown()).toBeTruthy("Verify Trim dropdown is disabled");
        await browser.sleep(browser.params.sleep.sleep2);

        await appraisalpage.clickThirdGuidebook();
        expect(await appraisalpage.isDisabledGuideBookTrimDropdown()).toBeTruthy("Verify Trim dropdown is disabled");
        await browser.sleep(browser.params.sleep.sleep2);

        await appraisalpage.clickFourthGuidebook();
        expect(await appraisalpage.isDisabledGuideBookTrimDropdown()).toBeTruthy("Verify Trim dropdown is disabled");

        await appraisalpage.clickBackArrowBtn();
        await appraisalpage.clickBackArrowBtn();

        await homepage.clickCancelSearchAppraisalListBtn();

    });    

    it('*** Estimate Mode: UI & Condition Report & PDF displays in Estimate Mode ', async function () {
        utils.logInfo("***** TEST CASE : Estimate Mode: UI & Condition Report & PDF displays in Estimate Mode   *****");

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        await homepage.clickNewAppraisalVINTab();
        await utils.logInfo("Enter VIN " + browser.params.vin.validvin + " into New Appraisal Window");

        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await homepage.setVin(browser.params.vin.validvin);
        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        await utils.logInfo("Click on First Trim");
        await homepage.clickFirstTrim();

        await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
        await browser.sleep(browser.params.sleep.sleep10);

        await utils.logInfo("Disable Wait for Angular");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
        var sVIN = await homepage.getAppraisalVIN();

        await utils.logInfo("Get an Appraisal ID from Appraisal Screen");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is " + appraisalID);

        await utils.logInfo("Value of Appraisal VIN is " + sVIN);
        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        expect(await sVIN).toContain(browser.params.vin.validvin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/  

        await appraisalpage.clickEstimateCDModeToggleBtn();

        expect(await appraisalpage.isPresentCDBodyTab()).toBeFalsy("Verify Body Tab and Other Tabs not present in Estimate Mode");

        await utils.logInfo("Togger Button Present:"+ await appraisalpage.isPresentEstimateDamageGradeSlider());
        await utils.logInfo("Input textfield Present:"+ await appraisalpage.isPresentEstimateDamageGradeAmountInput());
        expect(await appraisalpage.isPresentEstimateDamageGradeSlider()).toBeTruthy("Verify Conditional Disclosure Damage Slider is present in Estimade Mode");
        expect(await appraisalpage.isPresentEstimateDamageGradeAmountInput()).toBeTruthy("Verify Conditional Disclosure Damage Value Input field is present in Estimate Mode");

        await appraisalpage.clickEstimateDamageGradeSlider();
        await browser.sleep(browser.params.sleep.sleep2);

        var actualGradeNumber = await appraisalpage.getEstimateDamageGradeNumber();
        var actualGradeAmountValue = await appraisalpage.getEstimateDamageGradeAmountValue();

        expect(actualGradeNumber).toBe("3.0","Verify Damage Grade Slider Number");
        expect(actualGradeAmountValue).toBe("-1800","Verify Damage Grade Amount Value");

        var gradeString = utils.splitInToTwoReturnFirstPart(actualGradeNumber,".")+" out of 5.0";
        var gradeCRLocator = "//*[text()='"+gradeString+"']";
        var gradeCRElement = element(by.xpath(gradeCRLocator));
        utils.logInfo("Value of gradeCRLocator is "+gradeCRLocator);

        //await browser.get(appraisalURL);
        await utils.logInfo("Get Appraisal Menu");
        await appraisalpage.getAppraisalMenu();
        //await browser.waitForAngularEnabled(true); // *** Angular Enabled
        await utils.logInfo("Click on Dealer Condition Report menu item");
        await appraisalpage.clickDealerAppraisalMenuItem();
        //await browser.waitForAngularEnabled(false); // *** Angular Disabled
        await browser.sleep(browser.params.sleep.sleep10);
        expect(await browser.getCurrentUrl()).toContain("/report?type=dealer","Verify Dealer CR displayed when user click on Dealer Condition Report under Appraisal Tools Menu"); //Assertion

        expect(await gradeCRElement.isPresent()).toBeTruthy("Verify Damage Estimate with Grade details present in the CR");
        expect(await crpage.isPresentDamageEstimate()).toBeTruthy("Verify Damage Estimate Section is present on CR");
        expect(await crpage.getDamageEstimateValue()).toBe(actualGradeAmountValue,"Verify Damage amount (estimate mode) is same as Appraisal Page for VIN -"+browser.params.vin.validvin+" when Slider value is "+actualGradeNumber);

        await browser.sleep(browser.params.sleep.sleep10);

        

    });//it

    using(testdata.paragraphvin, function (data, description) {

        it('*** VIN: Ensure VIN can be pulled out from a paragraph and from VIN with space in front', async function () {
            utils.logInfo("***** TEST CASE#1 : VIN: Ensure VIN can be pulled out from a paragraph   *****");
            utils.logInfo("***** TEST CASE#2 : VIN: paste vin with a space in front, then edit to remove space   *****");

            var vinParagrapgh = data.parapgraphvin;
            var expectedVin = data.extractedvin;

            await homepage.setSearchAppraisalListInput(vinParagrapgh);
            await browser.sleep(browser.params.sleep.sleep2);

            var numwords = vinParagrapgh.split(" ");
            for(var i =0; i<numwords.length;i++){
                utils.logInfo("Value of i is "+i);
                await homepage.setSearchAppraisalListInput(await utils.getKey("selectallleftarrowkey"));

            }


            await browser.sleep(browser.params.sleep.sleep2);

            await homepage.setSearchAppraisalListInput(await utils.getKey("copy"));
            await browser.sleep(browser.params.sleep.sleep10);

            await utils.logInfo("Click Start Appraisal Button");
            await homepage.clickStartAppraisalBtn();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                    await browser.sleep(browser.params.sleep.sleep5);
                    await browser.refresh();
                }
            });

            await homepage.clickNewAppraisalVINTab();
            await utils.logInfo("Enter VIN '" + vinParagrapgh + "' into New Appraisal Window");

            await homepage.setVin(await utils.getKey("paste")); //set VIN
            await browser.sleep(browser.params.sleep.sleep2);

            await homepage.setVin(await utils.getKey("selectallleftarrowkey"));
            await browser.sleep(browser.params.sleep.sleep2);
            await homepage.setVin(await utils.getKey("copy"));

            await utils.logInfo("Click on the VIN Search button");
            await homepage.clickVinSearch();

            await utils.logInfo("Click on First Trim");
            await homepage.clickFirstTrim();

            await utils.logInfo("Sleeping for " + browser.params.sleep.sleep10);
            await browser.sleep(browser.params.sleep.sleep10);

            await utils.logInfo("Disable Wait for Angular");
            await browser.waitForAngularEnabled(false); // *** Angular Enabled False

            await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
            var vinAppraisalPage = await appraisalpage.getAppraisalVIN();
            await utils.logInfo("Value of Appraisal VIN is " + vinAppraisalPage);

            await utils.logInfo("Verify Appraisal VIN matching expected VIN");
            expect(await vinAppraisalPage).toBe(expectedVin,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   

        }); //it
    }); //using    

    it('*** VIN based options not available for a model are greyed out  ', async function () {
        utils.logInfo("***** TEST CASE : VIN based options not available for a model are greyed out   *****");

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.disableoptions,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        var optionWebElement = appraisalpage.generateOptionsWebElement("1.5L 4 CYL ECOBOOST");
        expect(await optionWebElement.getAttribute("ng-reflect-read-only")).toBeTruthy("Verify Option '1.5L 4 CYL ECOBOOST' is read only for VIN - "+browser.params.vin.disableoptions);

        optionWebElement = appraisalpage.generateOptionsWebElement("1.6L 4 CYL ECOBOOST");
        expect(await optionWebElement.getAttribute("ng-reflect-read-only")).toBeTruthy("Verify Option '1.6L 4 CYL ECOBOOST' is read only for VIN - "+browser.params.vin.disableoptions);

        optionWebElement = appraisalpage.generateOptionsWebElement("2.0L 4 CYL ECOBOOST");
        expect(await optionWebElement.getAttribute("ng-reflect-read-only")).toBe("false","Verify Option '2.0L 4 CYL ECOBOOST' is not read only for VIN - "+browser.params.vin.disableoptions);

        await browser.waitForAngularEnabled(true); // *** Angular Disabled

    });  
    
    it('*** VIN: Vin field limited to max 17 characters  ', async function () {
        utils.logInfo("***** TEST CASE : VIN: Vin field limited to max 17 characters   *****");

        //var vin = "123456789012345678";

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
                await browser.sleep(browser.params.sleep.sleep5);
                await browser.refresh();
            }
        });

        await homepage.clickNewAppraisalVINTab();

        await utils.logInfo("Before Expected Condition");
        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await utils.logInfo("After Expected Condition");

        expect(await homepage.getVINInputMaxLength()).toBe("17","Verify Maximum length of VIN input field is 17 characters");

    });    

    it('*** VIN: Invalid VIN: does not cause system to hang', async function () {
        utils.logInfo("***** TEST CASE : VIN: Invalid VIN: does not cause system to hang  *****");

        var vin = "00000000000000000";
        var errorMsgElement = element(by.xpath("//*[text()='This VIN could not be found. Please check your entry and try again.']"));

        await browser.refresh();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
                await browser.sleep(browser.params.sleep.sleep5);
                await browser.refresh();
            }
        });

        await homepage.clickNewAppraisalVINTab();

        await utils.logInfo("Before Expected Condition");
        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await utils.logInfo("After Expected Condition");

        await utils.logInfo("Enter VIN " + vin + " into New Appraisal Window");
        await homepage.setVin(vin);

        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        expect(await errorMsgElement.isPresent()).toBeTruthy("Verify Error Msg Displayed for VIN - "+vin);

        vin = "aaaaaaaaaaaaaaaaa";

        await homepage.get();
        await utils.logInfo("Click Start Appraisal Button");
        await homepage.clickStartAppraisalBtn();

        await homepage.clickNewAppraisalVINTab();

        await utils.logInfo("Before Expected Condition");
        var EC = protractor.ExpectedConditions;
        await browser.wait(EC.elementToBeClickable(homepage.getVinInputElement(), 5000));
        await utils.logInfo("After Expected Condition");

        await utils.logInfo("Enter VIN " + vin + " into New Appraisal Window");
        await homepage.setVin(vin);

        await utils.logInfo("Click on the VIN Search button");
        await homepage.clickVinSearch();

        expect(await errorMsgElement.isPresent()).toBeTruthy("Verify Error Msg Displayed for VIN - "+vin);


    });    

    it('*** VIN: 10 Digit VINs accepted ', async function () {
        utils.logInfo("***** TEST CASE : VIN: 10 Digit VINs accepted   *****");

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.tendigit,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        expect(await appraisalpage.getAppraisalVIN()).toContain(browser.params.vin.tendigit.toUpperCase(),"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/  

        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    }); 


    it('*** VIN: Difficult to value VINS: display N/A instead of a blank or error page  ', async function () {
        utils.logInfo("***** TEST CASE : VIN: Difficult to value VINS: display N/A instead of a blank or error page   *****");

        var sYear = utils.getCurrentYear();
        var sMake = "BMW";
        var sModel = "5 SERIES";
        var sTrim = "first";
        //Create New Appraisal using YMMT
        await homepage.createNewAppraisalYMMT(sYear,sMake,sModel,sTrim);

        await utils.logInfo("Verify Appraisal Year Make Model matching expected YMM");
        expect(await appraisalpage.getAppraisalYMM()).toContain(sYear+" "+sMake+" "+sModel,"Verify Appraisal Year Make Model matching expected YMM on Appraisal Page"); //*** Assertion ***/
        
        if(sTrim != "first"){
            await utils.logInfo("Verify Appraisal Trim matching expected trim");
            expect(await appraisalpage.getAppraisalTrim()).toContain(sTrim,"Verify Appraisal Trim matching expected trim on Appraisal Page"); //*** Assertion ***/
        }

        var msgLocator = "//*[text()='Please contact inventory consultant via chat or by calling 1.800.215.0001 to get a value']";
        var msgElement = element(by.xpath(msgLocator));

        expect(await msgElement.isPresent()).toBeTruthy("Verify msg Please contact inventory consultant via chat or by calling 1.800.215.0001 to get a value is present when creating current year BMW Appraisal - "+sYear+" "+sMake+" "+sModel);
        expect(await appraisalpage.getTargetTradeTextPriceBar()).toBe("N/A","Verify Target trade value is N/A");
        expect(await appraisalpage.getTargetAuctionTextPriceBar()).toBe("N/A","Verify Target auction value is N/A");
        expect(await appraisalpage.getTargetRetailTextPriceBar()).toBe("N/A","Verify Target retail value is N/A");

        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    });  

    it('*** VIN: entervin manually using keyboard (no copy/paste)  ', async function () {
        utils.logInfo("***** TEST CASE : VIN: entervin manually using keyboard (no copy/paste)  *****");

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.partialvin,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        expect(await appraisalpage.getAppraisalVIN()).toContain(browser.params.vin.partialvin.toUpperCase(),"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/  

        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    }); 

    it('*** VIN: Salvage/Flood Vin: Bad carfax & autocheck', async function () {
        utils.logInfo("***** TEST CASE : VIN: Salvage/Flood Vin: Bad carfax & autocheck *****");

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.badcarfaxautocheck2,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        expect(await appraisalpage.getAppraisalVIN()).toContain(browser.params.vin.badcarfaxautocheck2.toUpperCase(),"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/  

        await utils.logInfo("Verify Carfax bad image is present on Appraisal page for VIN - "+browser.params.vin.badcarfaxautocheck2);
        expect(await appraisalpage.isPresentBadCarFaxImage()).toBeTruthy("Verify Carfax bad image is present on Appraisal page for VIN - "+browser.params.vin.badcarfaxautocheck2);

        await utils.logInfo("Verify Autcheck bad image is present on Appraisal page for VIN - "+browser.params.vin.badcarfaxautocheck2);
        expect(await appraisalpage.isPresentBadAutoCheckImage()).toBeTruthy("Verify Autcheck bad image is present on Appraisal page for VIN - "+browser.params.vin.badcarfaxautocheck2);

        //Carfax
        await utils.logInfo("Click on Carfax icon on Appraisal page");
        await appraisalpage.clickCarFaxImage();
        await browser.sleep(browser.params.sleep.sleep10);

        browser.switchTo().frame(element(by.xpath("//iframe[contains(@srcdoc, 'SafeValue')]")).getWebElement());
        await utils.logInfo("Switched to iFrame");
        await browser.sleep(browser.params.sleep.sleep5);

        var carFaxMsgElement = element(by.xpath("//*[text()='Branded Title: Rebuilt']"));
        expect(await carFaxMsgElement.isPresent()).toBeTruthy("");

        browser.switchTo().defaultContent();
        await browser.sleep(browser.params.sleep.sleep5);

        await appraisalpage.closeCarFaxReportScreen();

        //Autocheck
        await utils.logInfo("Click on Autocheck icon on Appraisal page");
        await appraisalpage.clickAutoCheckImage();
        await browser.sleep(browser.params.sleep.sleep10);

        browser.switchTo().frame(element(by.xpath("//iframe[contains(@srcdoc, 'SafeValue')]")).getWebElement());
        await utils.logInfo("Switched to iFrame");
        await browser.sleep(browser.params.sleep.sleep5);

        var autoCheckMsgElement = element(by.xpath("//*[text()='State Title Brand Reported']"));
        expect(await autoCheckMsgElement.isPresent()).toBeTruthy("");

        browser.switchTo().defaultContent();
        await browser.sleep(browser.params.sleep.sleep5);

        await appraisalpage.closeAutoCheckReportScreen();

        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    }); 

    using(testdata.exoticvin, function (data, description) {
        it('***** VIN: Exotic VIN decode - "'+data.vin+'"', async function () {
            utils.logInfo("***** TEST CASE : VIN: Exotic VIN decode - '"+data.vin+"' *****");

            //Create New Appraisal with VIN
            await homepage.createNewAppraisalVIN(data.vin,"first");

            var appraisalID = await appraisalpage.getAppraisalID();
            await utils.logInfo("Value of Appraisal ID is "+appraisalID);
            await browser.sleep(browser.params.sleep.sleep10);

            await utils.logInfo("Disable Wait for Angular");
            await browser.waitForAngularEnabled(false); // *** Angular Enabled False
    
            await utils.logInfo("Get an Appraisal VIN from Appraisal Screen");
            var vinAppraisalPage = await homepage.getAppraisalVIN();
            await utils.logInfo("Value of Appraisal VIN is " + vinAppraisalPage);
    
            await utils.logInfo("Verify Appraisal VIN matching expected VIN");
            expect(await vinAppraisalPage).toContain(data.vin.toUpperCase(),"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/   


        });//it
    });//using

    it('*** VIN: selected trim associated for the VIN should be selected and other possible trims should be not selectable', async function () {
        utils.logInfo("***** TEST CASE : VIN: selected trim associated for the VIN should be selected and other possible trims should be not selectable *****");

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.singletrim,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        expect(await appraisalpage.getAppraisalVIN()).toContain(browser.params.vin.singletrim.toUpperCase(),"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/  
        expect(await appraisalpage.isPresentTrimDropDown()).toBeFalsy("Verify the VIN -'"+browser.params.vin.singletrim+"' has only single trim on Appraisal page and therefore no trim dropdown");

        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    }); 

    it('*** Enter VIN: add VIN on YMMT Appraisal ', async function () {
        utils.logInfo("***** TEST CASE : Enter VIN: add VIN on YMMT Appraisal  *****");

        var sYear = "2015";
        var sMake = "ACURA";
        var sModel = "ILX";
        var sTrim = "ILX 4 DOOR SEDAN 2.0L 4 CYL";
        var sVIN = "19VDE1F39FE005295";

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalYMMT(sYear,sMake,sModel,sTrim);
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Verify Appraisal Year Make Model matching expected YMM");
        expect(await appraisalpage.getAppraisalYMM()).toContain(sYear+" "+sMake+" "+sModel,"Verify Appraisal Year Make Model matching expected YMM on Appraisal Page"); //*** Assertion ***/

        await utils.logInfo("Verify Appraisal Trim matching expected trim");
        expect(await appraisalpage.getAppraisalTrim()).toContain(sTrim,"Verify Appraisal Trim matching expected trim on Appraisal Page"); //*** Assertion ***/

        await appraisalpage.setVIN(sVIN);
        await browser.sleep(browser.params.sleep.sleep5);

        expect(await appraisalpage.getAppraisalVIN()).toContain(sVIN,"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/  

        //Click on Back Arrow Button
        await utils.logInfo("Click on Back arrow button");
        await appraisalpage.clickBackArrowBtn();

        //Verify Appraisal available in Appraisals List
        await utils.logInfo("Search Appraisal on Appraisal List");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Search Results in Appraisal List
        expect(await homepage.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
        expect(await homepage.getSearchResultSearchTerm()).toBe(appraisalID,"Verify Search results showing serached term at the bottom of Appraisal List");
        expect(await homepage.getVINSearchedAppraisalList()).toBe(sVIN, "Verify added VIN through Apprsial showing up in Appraisal List view");

        await homepage.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep5);

        expect(await appraisalpage.getAppraisalID()).toBe(appraisalID,"Verify searched Appraisal open successfully");
        expect(await appraisalpage.getAppraisalVIN()).toContain(sVIN,"Verify VIN persist in Appraisal")
        

        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    }); 


    using(testdata.notbadvhr, function (data, description) {
        it('*** VHR: Vehicle with Rental or Lien on title should not be flagged as BAD VHR for VIN'+data.vin, async function () {
            utils.logInfo("***** TEST CASE : VHR: Vehicle with Rental or Lien on title should not be flagged as BAD VHR for VIN "+data.vin+" *****");

            //Create New Appraisal using VIN
            await homepage.createNewAppraisalVIN(data.vin,"first");
            var appraisalID = await appraisalpage.getAppraisalID();
            await utils.logInfo("Value of Appraisal ID is "+appraisalID);
            await browser.sleep(browser.params.sleep.sleep10);

            await browser.waitForAngularEnabled(false); // *** Angular Enabled False

            await utils.logInfo("Verify Appraisal VIN matching expected VIN");
            expect(await appraisalpage.getAppraisalVIN()).toContain(data.vin.toUpperCase(),"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/  
            expect(await appraisalpage.isSelectedBadVHR()).toBe("false","Verify BAD VHR is not selected for VIN - "+data.vin);
            
            await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        }); //it
    });//using    

    it('*** VHR: Verify deduction is displayed for vehicles with BAD VHR ', async function () {
        utils.logInfo("***** TEST CASE : VHR: Verify deduction is displayed for vehicles with BAD VHR VIN - '"+browser.params.vin.badvhr+"'  *****");

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.badvhr,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        expect(await appraisalpage.getAppraisalVIN()).toContain(browser.params.vin.badvhr.toUpperCase(),"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/  
        expect(await appraisalpage.isSelectedBadVHR()).toBe("true","Verify BAD VHR is selected for VIN - "+browser.params.vin.badvhr);
        expect(Number(await appraisalpage.getBadVHRValue())).toBeLessThan(0,"Verify Bad BHR has some deduction value");
        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    }); //it

    it('*** VHR: user able to deselect BAD VHR on a VIN that automatically selects it', async function () {
        utils.logInfo("***** TEST CASE : VHR: user able to deselect BAD VHR on a VIN that automatically selects it - '"+browser.params.vin.badvhr+"'  *****");

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.badvhr,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        var taretTradeValue = await appraisalpage.getTargetTradeValuePriceBar();
        var targetRetailValue = await appraisalpage.getTargetRetailValuePriceBar();
        var badVHRValue = await appraisalpage.getBadVHRValue();
        taretTradeValue = Number(taretTradeValue);
        targetRetailValue = Number(targetRetailValue);
        badVHRValue = Number(badVHRValue);


        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        expect(await appraisalpage.getAppraisalVIN()).toContain(browser.params.vin.badvhr.toUpperCase(),"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/  
        expect(await appraisalpage.isSelectedBadVHR()).toBe("true","Verify BAD VHR is selected for VIN - "+browser.params.vin.badvhr);
        expect(Number(await appraisalpage.getBadVHRValue())).toBeLessThan(0,"Verify Bad BHR has some deduction value");

        await appraisalpage.clickBadVHR();
        expect(await appraisalpage.isSelectedBadVHR()).toBe("false","Verify user is able to deselect BAD VHR for VIN - "+browser.params.vin.badvhr);
        expect(await appraisalpage.getTargetTradeValuePriceBar()).toBe((taretTradeValue-badVHRValue).toString(), "Verify Target Trade Value After deselcting Bad VHR");
        expect(await appraisalpage.getTargetRetailValuePriceBar()).toBe((targetRetailValue-badVHRValue).toString(), "Verify Target Trade Retail Value After deselcting Bad VHR");


        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    }); //it

    using(testdata.multipletrims, function (data, description) {
        it('*** Create appraisal search using keyboard ENTER for VIN with Multiple Trims ', async function () {
            utils.logInfo("***** TEST CASE : Create appraisal search using keyboard ENTER for VIN with Multiple Trims *****");

            await homepage.clickStartAppraisalBtn();
            await homepage.setVin(data.vin);
            await homepage.setVin(protractor.Key.chord(protractor.Key.ENTER));
            await browser.sleep(browser.params.sleep.sleep10);

            expect(await homepage.isPresentSelectTrimNewAppraisalScreen()).toBeTruthy("");
            await homepage.closeSelectTrimNewAppraisalScreen();

        }); //it
    });//using  

    it('*** Multiple Trims: Verify "Common Problems" section update with selected Trims ', async function () {
        utils.logInfo("***** TEST CASE : Multiple Trims: Verify 'Common Problems' section update with selected Trims  *****");
        utils.logInfo("***** STEPS: \n(1) Create an appraisal using YMMT with no known Common Problems - 2015 BMW 7 SERIES, ALPINA B7 XDRIVE 4 DOOR SEDAN 4.4L V8 TWIN TURBO \n(2) Review Common Problems Section in Appraisal modal - there are none listed \n(3) In TRIM dropdown select, 750I 4 DOOR SEDAN 4.4L V8 TWIN TURBO (its the 5th item in menu list) \n(4) Click on trim dropdown and select 760LI 4 DOOR SEDAN 6.0L V12 \n(5) Review the Common Problems section these should update update.");

        var sYear = "2015";
        var sMake = "BMW";
        var sModel = "7 SERIES";
        var sTrim = "ALPINA B7 XDRIVE 4 DOOR SEDAN 4.4L V8 TWIN TURBO";

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalYMMT(sYear,sMake,sModel,sTrim);
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Verify Appraisal Year Make Model matching expected YMM");
        expect(await appraisalpage.getAppraisalYMM()).toContain(sYear+" "+sMake+" "+sModel,"Verify Appraisal Year Make Model matching expected YMM on Appraisal Page"); //*** Assertion ***/

        await utils.logInfo("Verify Appraisal Trim matching expected trim");
        expect(await appraisalpage.getAppraisalTrim()).toContain(sTrim,"Verify Appraisal Trim matching expected trim on Appraisal Page"); //*** Assertion ***/

        await utils.logInfo("Verify Common Problems section is hidden for YMMT appraisal - "+sYear+" "+sMake+" "+sModel+" "+sTrim);
        expect(await appraisalpage.isHiddenCommonProblems()).toBeTruthy("Verify Common Problems section is hidden for YMMT appraisal - "+sYear+" "+sMake+" "+sModel+" "+sTrim);

        
        //Change Trim
        sTrim = "750I 4 DOOR SEDAN 4.4L V8 TWIN TURBO";
        await utils.logInfo("Changing the Trim to "+sTrim);
        await appraisalpage.selectAppraisalTrim(sTrim);
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Verify Common Problems section is displaying for YMMT appraisal - "+sYear+" "+sMake+" "+sModel+" "+sTrim);
        expect(await appraisalpage.isHiddenCommonProblems()).toBeFalsy("Verify Common Problems section is displaying for YMMT appraisal - "+sYear+" "+sMake+" "+sModel+" "+sTrim);

        sTrim = "760LI 4 DOOR SEDAN 6.0L V12";
        await appraisalpage.selectAppraisalTrim(sTrim);
        await browser.sleep(browser.params.sleep.sleep5);

        await utils.logInfo("Verify Common Problems section is displaying for YMMT appraisal - "+sYear+" "+sMake+" "+sModel+" "+sTrim);
        expect(await appraisalpage.isHiddenCommonProblems()).toBeFalsy("Verify Common Problems section is displaying for YMMT appraisal - "+sYear+" "+sMake+" "+sModel+" "+sTrim);

        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    }); //it

    it('*** Appraisal with N/A: damages can be added but pricebar should not update ', async function () {
        utils.logInfo("***** TEST CASE : Appraisal with N/A: damages can be added but pricebar should not update   *****");

        var sYear = utils.getCurrentYear();
        var sMake = "BMW";
        var sModel = "5 SERIES";
        var sTrim = "first";

        //Create New Appraisal using YMMT
        await homepage.createNewAppraisalYMMT(sYear,sMake,sModel,sTrim);

        await utils.logInfo("Verify Appraisal Year Make Model matching expected YMM");
        expect(await appraisalpage.getAppraisalYMM()).toContain(sYear+" "+sMake+" "+sModel,"Verify Appraisal Year Make Model matching expected YMM on Appraisal Page"); //*** Assertion ***/
        
        if(sTrim != "first"){
            await utils.logInfo("Verify Appraisal Trim matching expected trim");
            expect(await appraisalpage.getAppraisalTrim()).toContain(sTrim,"Verify Appraisal Trim matching expected trim on Appraisal Page"); //*** Assertion ***/
        }

        var msgLocator = "//*[text()='Please contact inventory consultant via chat or by calling 1.800.215.0001 to get a value']";
        var msgElement = element(by.xpath(msgLocator));

        expect(await msgElement.isPresent()).toBeTruthy("Verify msg Please contact inventory consultant via chat or by calling 1.800.215.0001 to get a value is present when creating current year BMW Appraisal - "+sYear+" "+sMake+" "+sModel);
        expect(await appraisalpage.getTargetTradeTextPriceBar()).toBe("N/A","Verify Target trade value is N/A");
        expect(await appraisalpage.getTargetAuctionTextPriceBar()).toBe("N/A","Verify Target auction value is N/A");
        expect(await appraisalpage.getTargetRetailTextPriceBar()).toBe("N/A","Verify Target retail value is N/A");

        await utils.logInfo("Click to Bad VHR");
        await appraisalpage.clickBadVHR();

        expect(await appraisalpage.getBadVHRValue()).toBe("0","Verify Bad VHR Damage amount should be $0 for "+sYear+" "+sMake+" "+sModel);

        //Body
        await appraisalpage.selectCDBodyTab();
        await appraisalpage.selectAdjustmentAppraisalScreen("Body","Roof","rust","repair");
        expect(await appraisalpage.getCDBodyTabCount()).toBe("1","Verify Damage count of Body Tab");
        expect(await appraisalpage.getCDBodyTabValue()).toBe("0","Verify any Body Damage amount should be $0 for "+sYear+" "+sMake+" "+sModel);

        //Glass
        await appraisalpage.selectCDGlassTab();
        await appraisalpage.selectAdjustmentAppraisalScreen("Glass","Rear Window","replace","none");
        expect(await appraisalpage.getCDGlassTabCount()).toBe("1","Verify Damage count of Body Tab");
        expect(await appraisalpage.getCDGlassTabValue()).toBe("0","Verify any Glass Damage amount should be $0 for "+sYear+" "+sMake+" "+sModel);

        expect(await appraisalpage.getTargetTradeTextPriceBar()).toBe("N/A","Verify Target trade value is N/A");
        expect(await appraisalpage.getTargetAuctionTextPriceBar()).toBe("N/A","Verify Target auction value is N/A");
        expect(await appraisalpage.getTargetRetailTextPriceBar()).toBe("N/A","Verify Target retail value is N/A");

        await browser.waitForAngularEnabled(true); // *** Angular Enabled True

    });  

    it('*** Default to APPRAISAL view on logon ', async function () {
        utils.logInfo("***** TEST CASE : Default to APPRAISAL view on logon  *****");

        await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first"); //Create New Appraisal

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        expect(await appraisalpage.getAppraisalVIN()).toBe(browser.params.vin.validvin.toUpperCase(),"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/ 

        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);

        expect(await homepage.isActiveAppraisalListTabSelected()).toBe("true","Verify Appraisal Tab is selected by Default");
        expect(await homepage.isPresentYearAppraisalList()).toBeTruthy("Verify Appraisal List Table present");


    });    

    it('*** New VIN appraisal: display existing appraisals info in search results [config-dealerdetails]  ', async function () {
        utils.logInfo("***** TEST CASE : New VIN appraisal: display existing appraisals info in search results[config-dealerdetails]  *****");

        utils.logInfo("[config-browser.params.dealerdetails.dealername] = "+browser.params.dealerdetails.dealername);
        utils.logInfo("[config-browser.params.dealerdetails.dealername] = "+browser.params.dealerdetails.dealerlocation);
        utils.logInfo("[config-browser.params.dealerdetails.dealername] = "+browser.params.dealerdetails.salesperson);

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False

        await utils.logInfo("Verify Appraisal VIN matching expected VIN");
        expect(await appraisalpage.getAppraisalVIN()).toContain(browser.params.vin.validvin.toUpperCase(),"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/  

        await utils.logInfo("Open Appraisal Tools Menu");
        await appraisalpage.getAppraisalMenu();
        await utils.logInfo("Verify 'Customer Information' Menu item present in Appraisal Menu");
        expect(await appraisalpage.isPresentCustomerInfoMenuItem()).toBeTruthy("Verify 'Customer Information' Menu item present in Appraisal Menu");

        //Customer Information
        await utils.logInfo("Click on Customer Information menu item");
        await appraisalpage.clickCustomerInfoMenuItem();
        await appraisalpage.setFirstNameCustomerInfo("Ranveer");
        await appraisalpage.setLastNameCustomerInfo("Singh");
        await browser.sleep(browser.params.sleep.sleep2);
        await utils.logInfo("Close the Customer Information screen");
        await appraisalpage.closeCustomerInfoScreen();

        //await browser.waitForAngularEnabled(true); // *** Angular Enabled False

        //Select Trim
        await homepage.clickStartAppraisalBtn();
        await browser.waitForAngularEnabled(true); // *** Angular Enabled False

        await homepage.setVin(browser.params.vin.validvin);
        await homepage.setVin(protractor.Key.chord(protractor.Key.ENTER));
        //await browser.sleep(browser.params.sleep.sleep10);

        expect(await homepage.isPresentSelectTrimNewAppraisalScreen()).toBeTruthy("");
        
        expect(await appraisalpage.getCustomerNameFirstExistingAppraisalSelectTrimScreen()).toBe("Ranveer Singh","Verify Customer Name on Existing Appraisal on Select Trim screen");
        expect(await appraisalpage.getSalesPersonFirstExistingAppraisalSelectTrimScreen()).toContain(browser.params.dealerdetails.salesperson,"Verify Sales Person on Existing Appraisal on Select Trim screen");
        expect(await appraisalpage.getDealerFirstExistingAppraisalSelectTrimScreen()).toBe(browser.params.dealerdetails.dealername,"Verify Dealer Name on Existing Appraisal on Select Trim screen");
        expect(await appraisalpage.getYMMFirstExistingAppraisalSelectTrimScreen()).toBe("2018 TOYOTA CAMRY","Verify Year Make Model on Existing Appraisal on Select Trim screen");
        expect(await appraisalpage.getAgeFirstExistingAppraisalSelectTrimScreen()).toContain("0D 00H","Verify Age on Existing Appraisal on Select Trim screen");
        expect(await appraisalpage.getLocationFirstExistingAppraisalSelectTrimScreen()).toContain(browser.params.dealerdetails.dealerlocation,"Verify location on Existing Appraisal on Select Trim screen");

        expect(await appraisalpage.getTrimFirstExistingAppraisalSelectTrimScreen()).toBe("L 4 DOOR SEDAN 2.5L 4 CYL","Verify Trim on Existing Appraisal on Select Trim screen");
        expect(await appraisalpage.getVINFirstExistingAppraisalSelectTrimScreen()).toBe("4T1B11HK7JU037859","Verify VIN on Existing Appraisal on Select Trim screen");
        expect(await appraisalpage.getMileageFirstExistingAppraisalSelectTrimScreen()).toContain(",000 Miles","Verify Mileage on Existing Appraisal on Select Trim screen");

    });  //it

    it('*** Vehicle Options: Verify selected options are saved/retained ', async function () {
        utils.logInfo("***** TEST CASE : Vehicle Options: Verify selected options are saved/retained  *****");

        //Create New Appraisal using VIN
        await homepage.createNewAppraisalVIN(browser.params.vin.validvinoptions,"first");
        var appraisalID = await appraisalpage.getAppraisalID();
        await utils.logInfo("Value of Appraisal ID is "+appraisalID);
                
        expect(await appraisalpage.isSelectedOptions4WheelDrive()).toBe("false","Verify '4 WHEEL DRIVE' option is not selected by default");

        await appraisalpage.selectOption("4 WHEEL DRIVE");
        
        //Verify
        expect(await appraisalpage.isSelectedOption("4 WHEEL DRIVE")).toBe("true","Verify '4 WHEEL DRIVE' option is selected");
        expect(await appraisalpage.getOptionValue("4 WHEEL DRIVE")).toBeGreaterThan("0","Verify adjustent value changes after adding an option");

        await browser.refresh();
        expect(await appraisalpage.isSelectedOption("4 WHEEL DRIVE")).toBe("true","Verify '4 WHEEL DRIVE' option is selected");
        expect(await appraisalpage.getOptionValue("4 WHEEL DRIVE")).toBeGreaterThan("0","Verify adjustent value changes after adding an option");


        //Click on Back Arrow Button
        await utils.logInfo("Click on Back arrow button");
        await appraisalpage.clickBackArrowBtn();

        //Verify Appraisal available in Appraisals List
        await utils.logInfo("Search Appraisal on Appraisal List");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Search Results in Appraisal List
        expect(await homepage.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
        expect(await homepage.getSearchResultSearchTerm()).toBe(appraisalID,"Verify Search results showing serached term at the bottom of Appraisal List");

        await homepage.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep10);

        expect(await appraisalpage.getAppraisalID()).toBe(appraisalID,"Verify searched Appraisal open successfully");
        expect(await appraisalpage.isSelectedOption("4 WHEEL DRIVE")).toBe("true","Verify '4 WHEEL DRIVE' option is selected");
        expect(await appraisalpage.getOptionValue("4 WHEEL DRIVE")).toBeGreaterThan("0","Verify adjustent value changes after adding an option");


        //Unselect
        await appraisalpage.unselectOption("4 WHEEL DRIVE");
        //await browser.sleep(browser.params.sleep.sleep10);

        expect(await appraisalpage.isSelectedOption("4 WHEEL DRIVE")).toBe("false","Verify '4 WHEEL DRIVE' option is selected");
        expect(await appraisalpage.getOptionValue("4 WHEEL DRIVE")).toBe("0","Verify adjustent value changes to zero after removing an option");


        await browser.refresh();
        expect(await appraisalpage.isSelectedOption("4 WHEEL DRIVE")).toBe("false","Verify '4 WHEEL DRIVE' option is selected");
        expect(await appraisalpage.getOptionValue("4 WHEEL DRIVE")).toBe("0","Verify adjustent value changes to zero after removing an option");


        //Click on Back Arrow Button
        await utils.logInfo("Click on Back arrow button");
        await appraisalpage.clickBackArrowBtn();

        //Verify Appraisal available in Appraisals List
        await utils.logInfo("Search Appraisal on Appraisal List");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Search Results in Appraisal List
        expect(await homepage.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
        expect(await homepage.getSearchResultSearchTerm()).toBe(appraisalID,"Verify Search results showing serached term at the bottom of Appraisal List");

        await homepage.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep10);

        expect(await appraisalpage.getAppraisalID()).toBe(appraisalID,"Verify searched Appraisal open successfully");
        expect(await appraisalpage.isSelectedOption("4 WHEEL DRIVE")).toBe("false","Verify '4 WHEEL DRIVE' option is not selected");
        expect(await appraisalpage.getOptionValue("4 WHEEL DRIVE")).toBe("0","Verify adjustent value changes to zero after removing an option");

    

        });  //it   

        it('*** GID: Multiple Trims: Verify the GID changes with TRIM selection ', async function () {
            utils.logInfo("***** GID: Multiple Trims: Verify the GID changes with TRIM selection  *****");

            //Create New Appraisal using VIN
            await homepage.createNewAppraisalVIN(browser.params.vin.multitrim,"first");
            await browser.waitForAngularEnabled(false); // *** Angular Enabled False

            await utils.logInfo("Verify Appraisal VIN matching expected VIN");
            expect(await homepage.getAppraisalVIN()).toContain(browser.params.vin.multitrim.toUpperCase(),"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/ 

            var appraisalID = await appraisalpage.getAppraisalID();
            await utils.logInfo("Value of Appraisal ID is "+appraisalID);

            await utils.logInfo("Open Appraisal Tools Menu");
            await appraisalpage.getAppraisalMenu();
            await browser.sleep(browser.params.sleep.sleep2);

            var gid = await appraisalpage.getGIDDebugInfoAppraisalMenu();
            await utils.logInfo("Value of GID is "+gid);
            expect(gid).toBe("gid: 205187 None ti: 2150 gmr: 2950 adj: -0.05 region: 6","Verify GID Debug Info matching for VIN - "+browser.params.vin.multitrim);

            await browser.waitForAngularEnabled(true); // *** Angular Enabled True
            await browser.refresh();
            await browser.sleep(browser.params.sleep.sleep10);

            await browser.waitForAngularEnabled(false); // *** Angular Enabled False
            await appraisalpage.selectAppraisalTrim("SE 4 DOOR SEDAN 2.0L 4 CYL");

            await utils.logInfo("Open Appraisal Tools Menu");
            await appraisalpage.getAppraisalMenu();
            await browser.sleep(browser.params.sleep.sleep2);

            var gid = await appraisalpage.getGIDDebugInfoAppraisalMenu();
            await utils.logInfo("Value of GID is "+gid);
            expect(gid).toBe("gid: 205188 None ti: 2450 gmr: 3300 adj: -0.05 region: 6","Verify GID Debug Info matching for VIN - "+browser.params.vin.multitrim+" and Trim -"+"SE 4 DOOR SEDAN 2.0L 4 CYL");

            await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        }); //it

        it('*** Copy VIN: click link copies the VIN to clipboard ', async function () {
            utils.logInfo("***** Copy VIN: click link copies the VIN to clipboard  *****");

            //Create New Appraisal using VIN
            await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");
            await browser.waitForAngularEnabled(false); // *** Angular Enabled False

            var appraisalVIN = await appraisalpage.getAppraisalVIN();
            await utils.logInfo("Verify Appraisal VIN matching expected VIN");
            expect(appraisalVIN).toContain(browser.params.vin.validvin.toUpperCase(),"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/ 

            var appraisalID = await appraisalpage.getAppraisalID();
            await utils.logInfo("Value of Appraisal ID is "+appraisalID);

            await appraisalpage.clickCopyVIN();
            await browser.sleep(browser.params.sleep.sleep5);

            await utils.logInfo("Open Appraisal Tools Menu");
            await appraisalpage.getAppraisalMenu();
            await browser.sleep(browser.params.sleep.sleep2);
            await utils.logInfo("Click on Customer Information menu item");
            await appraisalpage.clickCustomerInfoMenuItem();

            await appraisalpage.setFirstNameCustomerInfo(await utils.getKey("paste"));
            await browser.sleep(browser.params.sleep.sleep10);
            expect(await appraisalpage.getFirstNameCustomerInfo()).toBe(appraisalVIN,"Verify Copied VIN");
        });   

        it('*** MMR icon: directs to MMR web site and herc adjusted mileage is passed  ', async function () {
            utils.logInfo("***** MMR icon: directs to MMR web site and herc adjusted mileage is passed  *****");

            //Create New Appraisal using VIN
            await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");
            await browser.waitForAngularEnabled(false); // *** Angular Enabled False

            var appraisalVIN = await appraisalpage.getAppraisalVIN();
            await utils.logInfo("Verify Appraisal VIN matching expected VIN");
            expect(appraisalVIN).toContain(browser.params.vin.validvin.toUpperCase(),"Verify correct VIN showing up on Appraisal page"); //*** Assertion ***/ 

            var appraisalID = await appraisalpage.getAppraisalID();
            await utils.logInfo("Value of Appraisal ID is "+appraisalID);

            expect(await appraisalpage.isPresentMMRIcon()).toBeTruthy("Verify MMR icon is present on Appraisal page");
            expect(await appraisalpage.getMMRIconURL()).toBe("https://mmr.manheim.com/?count","Verify MMR Icon hyperlink URL");

            await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        });
        
        it('*** Archive: Unarchive: Any user is able to archive an appraisal. Verify all roles ', async function () {
            utils.logInfo("***** Archive: Unarchive: Any user is able to archive an appraisal. Verify all roles   *****");

            //Create New Appraisal using VIN
            await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");
            var appraisalID = await appraisalpage.getAppraisalID();
            await utils.logInfo("Value of Appraisal ID is "+appraisalID);
                    
            await appraisalpage.selectCDMechanicalTab();
            await appraisalpage.selectAdjustmentAppraisalScreen("Mechanical","Roof Inop","none","none");

            await appraisalpage.clickBackArrowBtn();
            await browser.sleep(browser.params.sleep.sleep5);

            await browser.refresh();

            await utils.logInfo("Archive Appraisal By ID");
            await homepage.archiveAppraisalByID(appraisalID);
            await browser.sleep(browser.params.sleep.sleep5);

            await utils.logInfo("Open Archived Appraisal By ID");
            await homepage.openArchivedAppraisalByID(appraisalID);

            await browser.sleep(browser.params.sleep.sleep10);
            expect(await appraisalpage.isReadOnlyAppraisal()).toBeTruthy("Verify Appraisal '"+appraisalID+"' is Read Only");

            await appraisalpage.selectCDMechanicalTab();

            expect(await appraisalpage.isDisabledCDMechanicalRoofInopBtn()).toBeTruthy("Verify Mechanical Roof Inop option is disabled for Read Only Appraisal");
            expect(await appraisalpage.isDisabledCDMechanicalSteeringBtn()).toBeTruthy("Verify Mechanical Steering option is disabled for Read Only Appraisal");


            await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        }); //it
        


}); //describe   


describe('Appraisal Test Suite with different test data', function () { // ********************** Describe2 *******************************
    var count = 0;
    beforeEach(async function () {
        //await utils.logInfo("Start beforEach():loginpage.get() - Navigate to Login page");
        await loginpage.get();
        await browser.getCurrentUrl().then(async function (url) {
            if (url != await loginpage.getForceURL()) {
                await homepage.navigateThroughMenu("Log Out");
                await loginpage.get();
            }
        });

        //await utils.logInfo("End beforEach():loginpage.get() - Navigate to Login page");
        await browser.waitForAngularEnabled(true);
    });

    afterEach(async function () {
        //await utils.logInfo("Start afterEach():navigateThroughMenu('Log Out')");
        await homepage.navigateThroughMenu("Log Out");
        //await utils.logInfo("End afterEach():navigateThroughMenu('Log Out')");
    });


    using(testdata.allusers, function (data, description) {
        it('***** Read only: ensure that other users cannot add or removed images: User- '+data.user+'[testdata.allusers]', async function () {
            utils.logInfo("***** TEST CASE : Read only: ensure that other users cannot add or removed images: User- '"+data.user+"' *****");

            await utils.logInfo("Set Valid User Name: " + data.user);
            await loginpage.setUsername(data.user);

            await utils.logInfo("Set Valid Password: " + data.password);
            await loginpage.setPassword(data.password);

            await utils.logInfo("Click SignIn Button");
            await loginpage.clickSignIn();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            });

            if(count == 0){
                await homepage.closeAllWalkme();
                count = 1;
            }//if count

            await browser.sleep(browser.params.sleep.sleep5);

            //Create New Appraisal using VIN
            await homepage.createNewAppraisalVIN(browser.params.vin.validvin,"first");
            var appraisalID = await appraisalpage.getAppraisalID();
            await utils.logInfo("Value of Appraisal ID is "+appraisalID);
                    
            // await appraisalpage.selectCDMechanicalTab();
            // await appraisalpage.selectAdjustmentAppraisalScreen("Mechanical","Roof Inop","none","none");

            await appraisalpage.clickBackArrowBtn();
            await browser.sleep(browser.params.sleep.sleep5);

            await browser.refresh();

            await utils.logInfo("Archive Appraisal By ID");
            await homepage.archiveAppraisalByID(appraisalID);
            await browser.sleep(browser.params.sleep.sleep5);

            await utils.logInfo("Open Archived Appraisal By ID");
            await homepage.openArchivedAppraisalByID(appraisalID);

            await browser.sleep(browser.params.sleep.sleep10);
            expect(await appraisalpage.isReadOnlyAppraisal()).toBeTruthy("Verify Appraisal '"+appraisalID+"' is Read Only");

            // //Open Read Only Appraisal
            // await utils.logInfo("Click on First Archived Appraisal");
            // await homepage.openReadOnlyFirstArchivedAppraisal();
            // expect(await appraisalpage.isReadOnlyAppraisal()).toBeTruthy("Verify Apprasal is Read Only");
            expect(await appraisalpage.isPresentAddImageBtn()).toBeFalsy("Verify Add Image Button is unavailable for Read-Only Appraisal");
            
            if(await appraisalpage.isPresentAppraisalThumbnailBtn()){
                await utils.logInfo("Click on Appraisal thumbnail Image Button");
                await appraisalpage.clickAppraisalThumbnailBtn();

                await utils.logInfo("Disable Wait for Angular");
                await browser.waitForAngularEnabled(false); // *** Angular Enabled False

                if(await appraisalpage.isPresentPicsNotAvailableGallery()){
                    await utils.logInfo("Inside if  appraisalpage.isPresentPicsNotAvailableGallery()");
                    expect(await appraisalpage.isPresentPicsNotAvailableGallery()).toBeTruthy();
                    expect(await appraisalpage.isPresentDeleteIconPhotoGallery()).toBeFalsy("Verify Photo Gallery Delete button is unavailable for Ready Only Appraisal");
                    expect(await appraisalpage.isPresentUploadAdditionalPhotosGalleryBtn()).toBeFalsy("Verify Photo Gallery Upload Additional Photos button is unavailable for Ready Only Appraisal");
                }
                else{
                    await utils.logInfo("Inside else  appraisalpage.isPresentPicsNotAvailableGallery()");
                    expect(await appraisalpage.isPresentDeleteIconPhotoGallery()).toBeFalsy("Verify Photo Gallery Delete button is unavailable for Ready Only Appraisal");
                    expect(await appraisalpage.isPresentUploadAdditionalPhotosGalleryBtn()).toBeFalsy("Verify Photo Gallery Upload Additional Photos button is unavailable for Ready Only Appraisal");
                    expect(await appraisalpage.isDisabledExteriorPhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Exterior photo tag button is unavailable for Ready Only Appraisal");
                    expect(await appraisalpage.isDisabledInteriorPhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Interior photo tag button is unavailable for Ready Only Appraisal");
                    expect(await appraisalpage.isDisabledDamagePhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Damage photo tag button is unavailable for Ready Only Appraisal");
                    expect(await appraisalpage.isDisabledRepairedPhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Repaired photo tag button is unavailable for Ready Only Appraisal");
                    expect(await appraisalpage.isDisabledOdometerPhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Odometer photo tag button is unavailable for Ready Only Appraisal");
    
                }

            }//if
            else if(await appraisalpage.isPresentImagesAvailableBtn()){
                await utils.logInfo("Click on Appraisal Images Available Button");
                await appraisalpage.clickImagesAvailableBtn();

                expect(await appraisalpage.isPresentClickToAddPhotosGalleryBtn()).toBeFalsy("Verify 'Click to Add Photos' button should not be available on Photo Gallery for Read Only Appraisal");
                expect(await appraisalpage.isPresentPhotoCameraGalleryBtn()).toBeFalsy("Verify 'Photo Camera Icon' button should not be available on Photo Gallery for Read Only Appraisal");
            }

            await browser.waitForAngularEnabled(true);


        }); //it
    }); //using

    it('***** Read only#2: ensure that other users cannot add or removed images', async function () {
        utils.logInfo("***** TEST CASE : Read only: ensure that other users cannot add or removed images *****");
 
        var appraisalID = browser.params.expiredappraisalids.adminuser;
        var user = browser.params.login.superadminuser; 
        var password = browser.params.login.superadminpassword;

        //Admin User
        await utils.logInfo("Set Valid User Name: " + user);
        await loginpage.setUsername(user);

        await utils.logInfo("Set Valid Password: " + password);
        await loginpage.setPassword(password);

        await utils.logInfo("Click SignIn Button");
        await loginpage.clickSignIn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        if(count == 0){
            await homepage.closeAllWalkme();
            count = 1;
        }//if count

        await browser.sleep(browser.params.sleep.sleep5);


        //Open Read Only Appraisal

        await utils.logInfo("Search Appraisal on Appraisal List");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Search Results in Appraisal List
        expect(await homepage.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
        expect(await homepage.getSearchResultSearchTerm()).toBe(appraisalID,"Verify Search results showing serached term at the bottom of Appraisal List");

        await utils.logInfo("Open the searched Appraisal");
        await homepage.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False
        expect(await appraisalpage.getAppraisalID()).toBe(appraisalID,"Verify searched Appraisal open successfully");

        expect(await appraisalpage.isReadOnlyAppraisal()).toBeTruthy("Verify Apprasal is Read Only");
        expect(await appraisalpage.isPresentAddImageBtn()).toBeFalsy("Verify Add Image Button is unavailable for Read-Only Appraisal");
        
        if(await appraisalpage.isPresentAppraisalThumbnailBtn()){
            await utils.logInfo("Click on Appraisal thumbnail Image Button");
            await appraisalpage.clickAppraisalThumbnailBtn();

            await utils.logInfo("Disable Wait for Angular");
            await browser.waitForAngularEnabled(false); // *** Angular Enabled False

            if(await appraisalpage.isPresentPicsNotAvailableGallery()){
                expect(await appraisalpage.isPresentPicsNotAvailableGallery()).toBeTruthy();
                expect(await appraisalpage.isPresentDeleteIconPhotoGallery()).toBeFalsy("Verify Photo Gallery Delete button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isPresentUploadAdditionalPhotosGalleryBtn()).toBeFalsy("Verify Photo Gallery Upload Additional Photos button is unavailable for Ready Only Appraisal");
            }
            else{
                expect(await appraisalpage.isPresentDeleteIconPhotoGallery()).toBeFalsy("Verify Photo Gallery Delete button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isPresentUploadAdditionalPhotosGalleryBtn()).toBeFalsy("Verify Photo Gallery Upload Additional Photos button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isDisabledExteriorPhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Exterior photo tag button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isDisabledInteriorPhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Interior photo tag button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isDisabledDamagePhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Damage photo tag button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isDisabledRepairedPhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Repaired photo tag button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isDisabledOdometerPhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Odometer photo tag button is unavailable for Ready Only Appraisal");

            }

        }//if
        else if(await appraisalpage.isPresentImagesAvailableBtn()){
            await utils.logInfo("Click on Appraisal Images Available Button");
            await appraisalpage.clickImagesAvailableBtn();

            expect(await appraisalpage.isPresentClickToAddPhotosGalleryBtn()).toBeFalsy("Verify 'Click to Add Photos' button should not be available on Photo Gallery for Read Only Appraisal");
            expect(await appraisalpage.isPresentPhotoCameraGalleryBtn()).toBeFalsy("Verify 'Photo Camera Icon' button should not be available on Photo Gallery for Read Only Appraisal");
        }

        await browser.waitForAngularEnabled(true);

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        await utils.logInfo("Log Out");
        await homepage.navigateThroughMenu("Log Out");

        await utils.logInfo("Start beforEach():loginpage.get() - Navigate to Login page");
        await loginpage.get();
        await browser.getCurrentUrl().then(async function (url) {
            if (url != await loginpage.getForceURL()) {
                await homepage.navigateThroughMenu("Log Out");
                await loginpage.get();
            }
        });

        await utils.logInfo("End beforEach():loginpage.get() - Navigate to Login page");
        await browser.waitForAngularEnabled(true);

        await browser.waitForAngularEnabled(true);

        appraisalID = browser.params.expiredappraisalids.manageruser;
        user = browser.params.login.acquisitionmanageruser; 
        password = browser.params.login.acquisitionmanagerpassword;

        //Admin User
        await utils.logInfo("Set Valid User Name: " + user);
        await loginpage.setUsername(user);

        await utils.logInfo("Set Valid Password: " + password);
        await loginpage.setPassword(password);

        await utils.logInfo("Click SignIn Button");
        await loginpage.clickSignIn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        if(count == 0){
            await homepage.closeAllWalkme();
            count = 1;
        }//if count

        await browser.sleep(browser.params.sleep.sleep5);


        //Open Read Only Appraisal

        await utils.logInfo("Search Appraisal on Appraisal List");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Search Results in Appraisal List
        expect(await homepage.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
        expect(await homepage.getSearchResultSearchTerm()).toBe(appraisalID,"Verify Search results showing serached term at the bottom of Appraisal List");

        await utils.logInfo("Open the searched Appraisal");
        await homepage.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False
        expect(await appraisalpage.getAppraisalID()).toBe(appraisalID,"Verify searched Appraisal open successfully");

        expect(await appraisalpage.isReadOnlyAppraisal()).toBeTruthy("Verify Apprasal is Read Only");
        expect(await appraisalpage.isPresentAddImageBtn()).toBeFalsy("Verify Add Image Button is unavailable for Read-Only Appraisal");
        
        if(await appraisalpage.isPresentAppraisalThumbnailBtn()){
            await utils.logInfo("Click on Appraisal thumbnail Image Button");
            await appraisalpage.clickAppraisalThumbnailBtn();

            await utils.logInfo("Disable Wait for Angular");
            await browser.waitForAngularEnabled(false); // *** Angular Enabled False

            if(await appraisalpage.isPresentPicsNotAvailableGallery()){
                expect(await appraisalpage.isPresentPicsNotAvailableGallery()).toBeTruthy();
                expect(await appraisalpage.isPresentDeleteIconPhotoGallery()).toBeFalsy("Verify Photo Gallery Delete button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isPresentUploadAdditionalPhotosGalleryBtn()).toBeFalsy("Verify Photo Gallery Upload Additional Photos button is unavailable for Ready Only Appraisal");
            }
            else{
                expect(await appraisalpage.isPresentDeleteIconPhotoGallery()).toBeFalsy("Verify Photo Gallery Delete button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isPresentUploadAdditionalPhotosGalleryBtn()).toBeFalsy("Verify Photo Gallery Upload Additional Photos button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isDisabledExteriorPhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Exterior photo tag button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isDisabledInteriorPhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Interior photo tag button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isDisabledDamagePhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Damage photo tag button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isDisabledRepairedPhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Repaired photo tag button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isDisabledOdometerPhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Odometer photo tag button is unavailable for Ready Only Appraisal");

            }

        }//if
        else if(await appraisalpage.isPresentImagesAvailableBtn()){
            await utils.logInfo("Click on Appraisal Images Available Button");
            await appraisalpage.clickImagesAvailableBtn();

            expect(await appraisalpage.isPresentClickToAddPhotosGalleryBtn()).toBeFalsy("Verify 'Click to Add Photos' button should not be available on Photo Gallery for Read Only Appraisal");
            expect(await appraisalpage.isPresentPhotoCameraGalleryBtn()).toBeFalsy("Verify 'Photo Camera Icon' button should not be available on Photo Gallery for Read Only Appraisal");
        }

        await browser.waitForAngularEnabled(true);

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        await utils.logInfo("Log Out");
        await homepage.navigateThroughMenu("Log Out");

        await utils.logInfo("Start beforEach():loginpage.get() - Navigate to Login page");
        await loginpage.get();
        await browser.getCurrentUrl().then(async function (url) {
            if (url != await loginpage.getForceURL()) {
                await homepage.navigateThroughMenu("Log Out");
                await loginpage.get();
            }
        });

        await utils.logInfo("End beforEach():loginpage.get() - Navigate to Login page");
        await browser.waitForAngularEnabled(true);

        await browser.waitForAngularEnabled(true);

        appraisalID = browser.params.expiredappraisalids.basicuser;
        user = browser.params.login.basicuser; 
        password = browser.params.login.basicuserpassword;

        //Admin User
        await utils.logInfo("Set Valid User Name: " + user);
        await loginpage.setUsername(user);

        await utils.logInfo("Set Valid Password: " + password);
        await loginpage.setPassword(password);

        await utils.logInfo("Click SignIn Button");
        await loginpage.clickSignIn();

        await browser.getCurrentUrl().then(async function (url) {
            if (url == await verifymobilenumberpage.getUrl()) {
                await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                await verifymobilenumberpage.clickRemindme();
            }
        });

        if(count == 0){
            await homepage.closeAllWalkme();
            count = 1;
        }//if count

        await browser.sleep(browser.params.sleep.sleep5);


        //Open Read Only Appraisal

        await utils.logInfo("Search Appraisal on Appraisal List");
        await homepage.searchAppraisalList(appraisalID);
        await browser.sleep(browser.params.sleep.sleep10);

        //Verify Search Results in Appraisal List
        expect(await homepage.getSearchResultCount()).toBe("1","Verify Search results showing only one result for Appraisal ID:"+appraisalID);
        expect(await homepage.getSearchResultSearchTerm()).toBe(appraisalID,"Verify Search results showing serached term at the bottom of Appraisal List");

        await utils.logInfo("Open the searched Appraisal");
        await homepage.clickFirstAppraisal();
        await browser.sleep(browser.params.sleep.sleep5);

        await browser.waitForAngularEnabled(false); // *** Angular Enabled False
        expect(await appraisalpage.getAppraisalID()).toBe(appraisalID,"Verify searched Appraisal open successfully");

        expect(await appraisalpage.isReadOnlyAppraisal()).toBeTruthy("Verify Apprasal is Read Only");
        expect(await appraisalpage.isPresentAddImageBtn()).toBeFalsy("Verify Add Image Button is unavailable for Read-Only Appraisal");
        
        if(await appraisalpage.isPresentAppraisalThumbnailBtn()){
            await utils.logInfo("Click on Appraisal thumbnail Image Button");
            await appraisalpage.clickAppraisalThumbnailBtn();

            await utils.logInfo("Disable Wait for Angular");
            await browser.waitForAngularEnabled(false); // *** Angular Enabled False

            if(await appraisalpage.isPresentPicsNotAvailableGallery()){
                expect(await appraisalpage.isPresentPicsNotAvailableGallery()).toBeTruthy();
                expect(await appraisalpage.isPresentDeleteIconPhotoGallery()).toBeFalsy("Verify Photo Gallery Delete button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isPresentUploadAdditionalPhotosGalleryBtn()).toBeFalsy("Verify Photo Gallery Upload Additional Photos button is unavailable for Ready Only Appraisal");
            }
            else{
                expect(await appraisalpage.isPresentDeleteIconPhotoGallery()).toBeFalsy("Verify Photo Gallery Delete button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isPresentUploadAdditionalPhotosGalleryBtn()).toBeFalsy("Verify Photo Gallery Upload Additional Photos button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isDisabledExteriorPhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Exterior photo tag button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isDisabledInteriorPhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Interior photo tag button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isDisabledDamagePhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Damage photo tag button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isDisabledRepairedPhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Repaired photo tag button is unavailable for Ready Only Appraisal");
                expect(await appraisalpage.isDisabledOdometerPhotoTagGalleryBtn()).toBeTruthy("Verify Photo Gallery Odometer photo tag button is unavailable for Ready Only Appraisal");

            }

        }//if
        else if(await appraisalpage.isPresentImagesAvailableBtn()){
            await utils.logInfo("Click on Appraisal Images Available Button");
            await appraisalpage.clickImagesAvailableBtn();

            expect(await appraisalpage.isPresentClickToAddPhotosGalleryBtn()).toBeFalsy("Verify 'Click to Add Photos' button should not be available on Photo Gallery for Read Only Appraisal");
            expect(await appraisalpage.isPresentPhotoCameraGalleryBtn()).toBeFalsy("Verify 'Photo Camera Icon' button should not be available on Photo Gallery for Read Only Appraisal");
        }

        await browser.waitForAngularEnabled(true);


    }); //it


    using(testdata.adminmanagerbasicusers, function (data, description) {
        it('*** Archive: Unarchive: Any user is able to archive an appraisal. Verify all roles ', async function () {
            utils.logInfo("***** TEST CASE : Archive: Unarchive: Any user is able to archive an appraisal. Verify all roles *****");
            utils.logInfo("***** TEST CASE : Archive: Archive multiple appraisal all at once   *****");


            await utils.logInfo("Set Valid User Name: " + data.user);
            await loginpage.setUsername(data.user);

            await utils.logInfo("Set Valid Password: " + data.password);
            await loginpage.setPassword(data.password);

            await utils.logInfo("Click SignIn Button");
            await loginpage.clickSignIn();

            await browser.getCurrentUrl().then(async function (url) {
                if (url == await verifymobilenumberpage.getUrl()) {
                    await expect(await url).toBe(await verifymobilenumberpage.getUrl(),"Verify the current page url is for Verify Mobile Number page"); //*** Assertion ***/
                    await utils.logInfo("Click Remind me on Verify Mobile Number Page");
                    await verifymobilenumberpage.clickRemindme();
                }
            });

            if(count == 0){
                await homepage.closeAllWalkme();
                count = 1;
            }//if count

            await browser.sleep(browser.params.sleep.sleep5);

            var archivedAppraisalsTabCountBeforeArchive = await homepage.getArchivedAppraisalsTabCount();
            var activeAppraisalsTabCountBeforeArchive = await homepage.getActiveAppraisalsTabCount();

            //Create New Appraisal using VIN
            await homepage.createNewAppraisalVIN(browser.params.vin.tendigit,"first");

            var appraisalID = await appraisalpage.getAppraisalID();
            await utils.logInfo("Value of Appraisal ID is "+appraisalID);

            var appraisalVIN = await appraisalpage.getAppraisalVIN();
            await utils.logInfo("Value of Appraisal VIN is "+appraisalVIN);
            
            await homepage.createNewAppraisalVIN(browser.params.vin.tendigit,"first");
            var appraisalID2 = await appraisalpage.getAppraisalID();
            await utils.logInfo("Value of Appraisal ID is "+appraisalID2);

            var appraisalVIN2 = await appraisalpage.getAppraisalVIN();
            await utils.logInfo("Value of Appraisal VIN is "+appraisalVIN2);

            await browser.waitForAngularEnabled(true); // *** Angular Enabled True
            await homepage.get();

            expect(await homepage.getArchivedAppraisalsTabCount()).toBe(archivedAppraisalsTabCountBeforeArchive,"Verify Archived Appraisals remain the same");
            expect(await homepage.getActiveAppraisalsTabCount()).toBe((Number(activeAppraisalsTabCountBeforeArchive)+2).toString(),"Verify Active Appraisal Count increased by 2");

            await utils.logInfo("Search Appraisal on Appraisal List");
            await homepage.searchAppraisalList(appraisalVIN);
            await browser.sleep(browser.params.sleep.sleep5);
    
            expect(await homepage.getSearchResultSearchTerm()).toBe(appraisalVIN,"Verify Search results showing searched term at the bottom of Appraisal List");
            await browser.waitForAngularEnabled(false); // *** Angular Enabled True

            await utils.logInfo("Click first checkbox of Searched Appraisal List");
            await homepage.clickCheckBoxAppraisalList("1");
            await browser.sleep(browser.params.sleep.sleep2);

            await utils.logInfo("Click second checkbox of Searched Appraisal List");
            await homepage.clickCheckBoxAppraisalList("2");

            await browser.sleep(browser.params.sleep.sleep5);
    
            await utils.logInfo("Click on Archive button");
            await homepage.clickArchiveAppraisalListBtn();
            await browser.sleep(browser.params.sleep.sleep10);

            await utils.logInfo("Click the Close button of Search Input text field");
            await homepage.clickCancelSearchAppraisalListBtn();
            await browser.sleep(browser.params.sleep.sleep5);

            expect(await homepage.getArchivedAppraisalsTabCount()).toBe((Number(archivedAppraisalsTabCountBeforeArchive)+2).toString(),"Verify Archived Appraisals increased by 2");
            expect(await homepage.getActiveAppraisalsTabCount()).toBe(activeAppraisalsTabCountBeforeArchive,"Verify Active Appraisal Count remain the same");

            await homepage.clickArchivedAppraisalList();
            await browser.sleep(browser.params.sleep.sleep10);

            var dispositionValueAppraisalList = await homepage.getDispositionValueAppraisalList();
            var dispositionColorAppraisalList = await homepage.getDispositionColorAppraisalList();

            expect(dispositionValueAppraisalList).toBe("lost","Verify Disposition Value on Archived Appraisal List");
            expect(dispositionColorAppraisalList).toBe("red","Verify Disposition Color on Archived Appraisal List");

            await browser.waitForAngularEnabled(true); // *** Angular Enabled True

            await utils.logInfo("Search Appraisal on Appraisal List");
            await homepage.searchAppraisalList(appraisalVIN);
            await browser.sleep(browser.params.sleep.sleep5);
    
            expect(await homepage.getSearchResultSearchTerm()).toBe(appraisalVIN,"Verify Search results showing searched term at the bottom of Appraisal List");
            await browser.waitForAngularEnabled(false); // *** Angular Enabled True

            await utils.logInfo("Click first checkbox of Searched Appraisal List");
            await homepage.clickCheckBoxAppraisalList("1");
            await browser.sleep(browser.params.sleep.sleep2);

            await utils.logInfo("Click second checkbox of Searched Appraisal List");
            await homepage.clickCheckBoxAppraisalList("2");

            await browser.sleep(browser.params.sleep.sleep5);
    
            await utils.logInfo("Click on Unarchive button");
            await homepage.clickUnarchiveAppraisalListBtn();
            await browser.sleep(browser.params.sleep.sleep10);

            await utils.logInfo("Click the Close button of Search Input text field");
            await homepage.clickCancelSearchAppraisalListBtn();
            await browser.sleep(browser.params.sleep.sleep5);

            expect(await homepage.getArchivedAppraisalsTabCount()).toBe(archivedAppraisalsTabCountBeforeArchive,"Verify Archived Appraisals decrease by 2 after Unarchive 2 archived appraisals");
            expect(await homepage.getActiveAppraisalsTabCount()).toBe((Number(activeAppraisalsTabCountBeforeArchive)+2).toString(),"Verify Active Appraisal Count increased by 2 after Unarchive 2 archived appraisals");

            dispositionValueAppraisalList = await homepage.getDispositionValueAppraisalList();
            dispositionColorAppraisalList = await homepage.getDispositionColorAppraisalList();

            expect(dispositionValueAppraisalList).toBe("lost","Verify Disposition Value on Archived Appraisal List");
            expect(dispositionColorAppraisalList).toBe("red","Verify Disposition Color on Archived Appraisal List");

            await browser.waitForAngularEnabled(true); // *** Angular Enabled True

        }); //it
    }); //using   


}); //describe