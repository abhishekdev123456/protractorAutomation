## How to run locally
1. `export TEST=<smoke or pricing>`
2. `export ENV=<environment you want to test>`
3. `docker-compose -f local.yml up`

## How to run from Slack
1. From Accu-Trade Slack (any channel, even in private messages) run `/gitlab ui-automation run test <environment> <type of test>`
2. Wait for the response via Slack. There will be no response after running the command until it completes.

## Arguments
Environments:
- development
- qa
- qa2
- stage
- production

Types of Tests:
- smoke - runs a smoke test
- pricing - runs a test on the pricing data
- all - runs both a smoke test and a pricing test

## Examples
- /gitlab ui-automation run test qa smoke
- /gitlab ui-automation run test stage smoke
- /giitlab ui-automation run test qa pricing
- /gitlab ui-automation run test qa2 all