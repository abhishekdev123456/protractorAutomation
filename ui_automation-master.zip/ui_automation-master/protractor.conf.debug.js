'use strict';
var HtmlReporter = require('protractor-beautiful-reporter');
var log4js = require('log4js');

exports.config = {
    framework: 'jasmine2',
    SELENIUM_PROMISE_MANAGER: false,

    //getPageTimeout: Time to wait for the page to load
    //Default page timeout is 10 seconds. I deliberately added here incase we need to change globally in future
    getPageTimeout: 10000,

    //Time to wait for page to synchronize. More information on timeouts can be found in Protractor’s wiki.
    allScriptsTimeout: 80000,

    seleniumAddress: 'http://selenium-hub:4444/wd/hub',
    specs: ['spec.js'],
    suites: {
        full: 'specs/spec.js',
        scorecard: 'specs/scorecard.spec.js',
        smoke: 'specs/smoke.spec.js',
        test: 'specs/test.spec.js',
        test2: 'specs/test2.spec.js',
        multi: './multiwindows.js'

    },
    capabilities: {
        directConnect: true,
        browserName: 'chrome',
        // chromeOptions: {
        //     args:["--disable-browser-side-navigation"]
        //     }
    },

    jasmineNodeOpts: {

        showColors: true, // Use colors in the command line report.
        defaultTimeoutInterval: 70000 //Default time out is 30 seconds.
    },

    params: {
        login: {
            validuser: 'amit+TrueCarUSSA@accu-trade.com',
            validpassword: 'Test777',
            invaliduser: 'invaliduser@accu-trade.com',
            invalidpassword: 'WrongPassword',
            errormessage: 'Wrong email or password.',
            superadminuser: 'Amit+ATUSSA@accu-trade.com',
            superadminpassword: 'Test777',
            superadminfname: 'Amit',
            superadminlname: 'ATUSSA',
            basicadminuser: 'amit+ATUSBA@accu-trade.com',
            basicadminpassword: 'Test777',
            basicuser: 'amit+ATUSBU@accu-trade.com',
            basicuserpassword: 'Test777',
            bdcmanageruser: 'amit+ATUSBDCM@accu-trade.com',
            bdcmanagerpassword: 'Test777',
            salesmanageruser: 'amit+ATUSSM@accu-trade.com',
            salesmanagerpassword: 'Test777',
            acquisitionuser: 'amit+ATUSAU@accu-trade.com',
            acquisitionuserpassword: 'Test777',
            acquisitionmanageruser: 'amit+ATUSAM@accu-trade.com',
            acquisitionmanagerpassword: 'Test777'
        },
        vin: {
            validvin: '4T1B11HK7JU037859'
        },
        sleep: {
            sleep5: 5000,
            sleep10: 10000,
            sleep20: 20000,
            sleep30: 30000,
            sleep50: 50000
        },
        env: {
            url: 'https://hercules-qa.accu-trade.com'
        }
    },

    beforeLaunch: function () {
        //if (fs.existsSync('./logs/ExecutionLog.log')) {
        //    fs.unlink('./logs/ExecutionLog.log')
        //}
        log4js.configure({
            appenders: {
                fileLog: { type: 'file', filename: './logs/ExecutionLog.log' },
                console: { type: 'log4js-protractor-appender' }
            },
            categories: {
                file: { appenders: ['fileLog'], level: 'error' },
                another: { appenders: ['console'], level: 'trace' },
                default: { appenders: ['console', 'fileLog'], level: 'trace' }
            }
        });
    },
    onPrepare: function () {

        browser.logger = log4js.getLogger(); //log4js

        // Add a screenshot reporter and store screenshots to `/tmp/screenshots`:
        jasmine.getEnv().addReporter(new HtmlReporter({
            baseDirectory: 'herc-test-reports/screenshots',
            preserveDirectory: false,
            takeScreenShotsOnlyForFailedSpecs: false,
            gatherBrowserLogs: false,
            docTitle: 'Hercules Test Results',
            clientDefaults: {
                searchSettings: {
                    allselected: true,
                    passed: true,
                    failed: true,
                    pending: true,
                    withLog: true
                },
                columnSettings: {
                    displayTime: true,
                    displayBrowser: true,
                    displaySessionId: true,
                    inlineScreenshots: true
                }
            }
        }).getJasmine2Reporter());
    }

};