'use strict';

module.exports = {
	adminusers: {
        'Super Admin User': {user: 'amit+ATUSSA@accu-trade.com',password: 'Test777'},
        'Basic Admin User': {user: 'amit+ATUSBA@accu-trade.com',password: 'Test777'},
    },
    nonadminusers: {
        'Basic User': {user: 'amit+ATUSBU@accu-trade.com',password: 'Test777'},
        'BDC Manager User': {user: 'amit+ATUSBDCM@accu-trade.com',password: 'Test777'},
        'Sales Manager User': {user: 'amit+ATUSSM@accu-trade.com',password: 'Test777'},
        'Acquisition User': {user: 'amit+ATUSAU@accu-trade.com',password: 'Test777'},
        'Acquisition Manager User': {user: 'amit+ATUSAM@accu-trade.com',password: 'Test777'}
    },
    xtest:{
        'truecar':{screen:{getoffer:'true cash offer'}}
    },
    allusers:{
        'Super Admin User': {user: 'amit+ATUSSA@accu-trade.com',password: 'Test777'},
        'Basic Admin User': {user: 'amit+ATUSBA@accu-trade.com',password: 'Test777'}, 
        'Basic User': {user: 'amit+ATUSBU@accu-trade.com',password: 'Test777'},
        'BDC Manager User': {user: 'amit+ATUSBDCM@accu-trade.com',password: 'Test777'},
        'Sales Manager User': {user: 'amit+ATUSSM@accu-trade.com',password: 'Test777'},
        'Acquisition User': {user: 'amit+ATUSAU@accu-trade.com',password: 'Test777'},
        'Acquisition Manager User': {user: 'amit+ATUSAM@accu-trade.com',password: 'Test777'}
    },
    adminmanagerbasicusers:{
        'Super Admin User': {user: 'amit+ATUSSA@accu-trade.com',password: 'Test777'},
        'Acquisition Manager User': {user: 'amit+ATUSAM@accu-trade.com',password: 'Test777'},
        'Basic User': {user: 'amit+ATUSBU@accu-trade.com',password: 'Test777'},

    },
    atusers: {
        'AT Super Admin User': {user: 'amit+ATUSSA@accu-trade.com',password: 'Test777'}
    },
    truecarusers: {
        'True Car Super Admin User': {user: 'amit+TrueCarUSSA@accu-trade.com',password: 'Test777'}
    },
    traderusers: {
        'Trader Super Admin User': {user: 'amit+TRADERCANSA@accu-trade.com',password: 'Test777'}
    },
    allusertypes: {
        'AT Super Admin User': {user: 'amit+ATUSSA@accu-trade.com',password: 'Test777'},
        'True Car Super Admin User': {user: 'amit+TrueCarUSSA@accu-trade.com',password: 'Test777'},
        'Trader Super Admin User': {user: 'amit+TRADERCANSA@accu-trade.com',password: 'Test777'}
    },
    branding:{
        'Accu-Trade': {user: 'amit+ATUSSA@accu-trade.com',password: 'Test777',brandoffertext:'Accu-Trade Instant Offer',action: 'Get Instant Offer',actionlabel: 'Get a check for the Instant Offer amount'},
        // 'TrueCar': {user: 'amit+TrueCarUSSA@accu-trade.com',password: 'Test777',brandoffertext:'True Cash Offer',action: 'Get True Cash Offer',actionlabel: 'Get a check for the True Cash Offer amount'},
        // 'Trader': {user: 'amit+TRADERCANSA@accu-trade.com',password: 'Test777',brandoffertext:'Instant Cash Offer',action: 'Get Instant Cash Offer',actionlabel: 'Get a check for the Instant Cash Offer amount'} 
    },
    brandingmaster:{
        'accutrade-us': {user: 'amit+ATUSSA@accu-trade.com',password: 'Test777',brandprospecttext:'IO',zip:'78641',perseusurl:'https://perseus-consumer-qa.rhcapl.com/?ot=Accu-Trade%20Appraiser&dlr=8fe79fc9a5da51b27ec543870de1d6a517dcc803',
            screen: {
                appraisallist:{
                },
                prospect:{
                },
                consumerappraisal:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-white.png',
                    pricebarbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-dark.png',
                    offerpricebarlabel: 'Accu-Trade Instant Offer',
                    offerpricereviewsend: 'Accu-Trade Instant Offer'
                },
                consumerconditionreport:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-white.png',
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-galves-dark.png',
                    offerpricelabel:'Trade Insurance Guarantee'
                },
                dealerappraisal:{
                    customerstartappraisalbtnlabel: 'Accu-Trade Customer',
                    offerpricelabelpricebar:'Accu-Trade Instant Offer',
                    offerpricereviewsend: 'Accu-Trade Instant Offer'
                },
                dealerconditionreport:{
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-galves-dark.png',
                    offerpricelabel:'Accu-Trade Instant Offer',
                    reportsettingsvaluesfirstcheckboxlabel: 'Accu-Trade Instant Offer / Target Trade'
                },
                increaseoffer:{
                    increaseofferbtnlabel: 'Accu-Trade Instant Offer',
                    increaseofferbtndescriptiontext: 'If the Accu-Trade Instant Offer is expired, Dealer is responsible for the entire Updated Offer Amount',
                    updatedofferlabel: 'Updated Accu-Trade Instant Offer',
                    updatedofferagreementtxt: 'I acknowledge that I am responsible for any offer increase amount above the Accu-Trade Instant Offer amount and any extension of the offer period.',
                    increaseofferconfirmationlabel: 'Updated Accu-Trade Instant Offer:'
                },
                ground:{
                },
                getoffer:{
                    getofferbtnlabel: 'Get Instant Offer',
                    getofferbtndescriptiontxt: 'Get a check for the Instant Offer amount',
                    getofferscreenheading: 'Get Instant Offer',
                    getofferscreentitle: 'Accu-Trade Instant Offer',
                    getoffersuccessdescriptionmsg: 'This vehicle was submitted for Accu-Trade Instant Offer on',
                    getofferpendingmsgstatusbar: 'Accu-Trade Instant Offer Pending'
                },
            }, //screen
        }, // accutrade-us   

        'accutrade-can': {user: 'amit+ATCANSA@accu-trade.com',password: 'Test777',brandprospecttext:'IO',zip:'M5V1J5',perseusurl:'https://perseus-consumer-qa.rhcapl.com/?ot=Accu-Trade%20Appraiser&dlr=1b55ebb5935ab510b1c8f5623fcc03a9c6059141',
            screen: {
                appraisallist:{

                },
                prospect:{

                },
                consumerappraisal:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-white.png',
                    pricebarbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-dark.png',
                    offerpricebarlabel: 'Accu-Trade Instant Offer',
                    offerpricereviewsend: 'Accu-Trade Instant Offer'
                },
                consumerconditionreport:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-white.png',
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-galves-dark.png',
                    offerpricelabel:'Trade Insurance Guarantee'
                },
                dealerappraisal:{
                    customerstartappraisalbtnlabel: 'Accu-Trade Customer',
                    offerpricelabelpricebar:'Accu-Trade Instant Offer',
                    offerpricereviewsend: 'Accu-Trade Instant Offer'
                },
                dealerconditionreport:{
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-galves-dark.png',
                    offerpricelabel:'Accu-Trade Instant Offer',
                    reportsettingsvaluesfirstcheckboxlabel: 'Accu-Trade Instant Offer / Target Trade'
                },
                increaseoffer:{
                    increaseofferbtnlabel: 'Accu-Trade Instant Offer',
                    increaseofferbtndescriptiontext: 'If the Accu-Trade Instant Offer is expired, Dealer is responsible for the entire Updated Offer Amount',
                    updatedofferlabel: 'Updated Accu-Trade Instant Offer',
                    updatedofferagreementtxt: 'I acknowledge that I am responsible for any offer increase amount above the Accu-Trade Instant Offer amount and any extension of the offer period.',
                    increaseofferconfirmationlabel: 'Updated Accu-Trade Instant Offer:'
                },
                ground:{
                },
                getoffer:{
                    getofferbtnlabel: 'Get Instant Offer',
                    getofferbtndescriptiontxt: 'Get a check for the Instant Offer amount',
                    getofferscreenheading: 'Get Instant Offer',
                    getofferscreentitle: 'Accu-Trade Instant Offer',
                    getoffersuccessdescriptionmsg: 'This vehicle was submitted for Accu-Trade Instant Offer on',
                    getofferpendingmsgstatusbar: 'Accu-Trade Instant Offer Pending'
                },
            }, // screen
        }, // accutrade-can

        'truecar': {user: 'amit+TrueCarUSSA@accu-trade.com',password: 'Test777',brandprospecttext:'TCO',zip:'78641',perseusurl:'https://perseus-consumer-qa.rhcapl.com/?ot=Accu-Trade%20Appraiser&dlr=d7e06b9ee2524f2e6ee6aa1c5ae09cbe2c3e543f',
            screen: {
                appraisallist:{

                },
                prospect:{

                },
                consumerappraisal:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/truecar-logo-white.svg',
                    pricebarbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/truecar-logo-dark.svg',
                    offerpricebarlabel: 'True Cash Offer',
                    offerpricereviewsend: 'True Cash Offer'
                },
                consumerconditionreport:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/truecar-logo-white.svg',
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/truecar-logo-dark.svg',
                    offerpricelabel:'True Cash Offer'
                },
                dealerappraisal:{
                    customerstartappraisalbtnlabel: 'TRUECar Customer',
                    offerpricelabelpricebar:'True Cash Offer',
                    offerpricereviewsend: 'True Cash Offer'
                },
                dealerconditionreport:{
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-galves-dark.png',
                    offerpricelabel:'True Cash Offer',
                    reportsettingsvaluesfirstcheckboxlabel: 'True Cash Offer / Target Trade'
                },
                increaseoffer:{
                    increaseofferbtnlabel: 'True Cash Offer',
                    increaseofferbtndescriptiontext: 'If the True Cash Offer is expired, Dealer is responsible for the entire Updated Offer Amount',
                    updatedofferlabel: 'Updated True Cash Offer',
                    updatedofferagreementtxt: 'I acknowledge that I am responsible for any offer increase amount above the True Cash Offer amount and any extension of the offer period.',
                    increaseofferconfirmationlabel: 'Updated True Cash Offer:'
                },
                ground:{
                },
                getoffer:{
                    getofferbtnlabel: 'Get True Cash Offer',
                    getofferbtndescriptiontxt: 'Get a check for the True Cash Offer amount',
                    getofferscreenheading: 'Get True Cash Offer',
                    getofferscreentitle: 'True Cash Offer',
                    getoffersuccessdescriptionmsg: 'This vehicle was submitted for True Cash Offer on',
                    getofferpendingmsgstatusbar: 'True Cash Offer Pending'
                },
            },//screen
        },//truecar    

        'trader': {user: 'amit+TRADERCANSA@accu-trade.com',password: 'Test777',brandprospecttext:'ICO',zip:'M5V1J5',perseusurl:'https://perseus-consumer-qa.rhcapl.com/?ot=Accu-Trade%20Appraiser&dlr=6c8ee976d283a2afd0588bb12db124eeceabaa84',
            screen: {
                appraisallist:{

                },
                prospect:{

                },
                consumerappraisal:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/trader-logo-red.svg',
                    pricebarbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/trader-logo-red.svg',
                    offerpricebarlabel: 'Target Trade',
                    offerpricereviewsend: 'Target Trade'
                },
                consumerconditionreport:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/trader-logo-red.svg',
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/trader-logo-red.svg',
                    offerpricelabel:'Target Trade'
                },
                dealerappraisal:{
                    customerstartappraisalbtnlabel: 'Trader Customer',
                    offerpricelabelpricebar:'Target Trade',
                    offerpricereviewsend: 'Target Trade'
                },
                dealerconditionreport:{
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-galves-dark.png',
                    offerpricelabel:'Target Trade',
                    reportsettingsvaluesfirstcheckboxlabel: 'Target Trade'
                },
                increaseoffer:{
                    increaseofferbtnlabel: 'Instant Cash Offer',
                    increaseofferbtndescriptiontext: 'If the Instant Cash Offer is expired, Dealer is responsible for the entire Updated Offer Amount',
                    updatedofferlabel: 'Updated Instant Cash Offer',
                    updatedofferagreementtxt: 'I acknowledge that I am responsible for any offer increase amount above the Instant Cash Offer amount and any extension of the offer period.',
                    increaseofferconfirmationlabel: 'Updated Instant Cash Offer:'
                },
                ground:{
                },
                getoffer:{
                    getofferbtnlabel: 'Get Instant Offer',
                    getofferbtndescriptiontxt: 'Get a check for the Instant Offer amount',
                    getofferscreenheading: 'Get Instant Offer',
                    getofferscreentitle: 'Accu-Trade Instant Offer',
                    getoffersuccessdescriptionmsg: 'This vehicle was submitted for Accu-Trade Instant Offer on',
                    getofferpendingmsgstatusbar: 'Accu-Trade Instant Offer Pending'
                },
            }, //screen
        }, //trader   

    }, //brandingmaster

    brandingprospectmaster:{
        'accutrade-us': {user: 'amit+ATUSSA@accu-trade.com',password: 'Test777',brandprospecttext:'IO',zip:'78641',perseusurl:'https://perseus-consumer-qa.rhcapl.com/?ot=Accu-Trade%20Appraiser&dlr=8fe79fc9a5da51b27ec543870de1d6a517dcc803',
            screen: {
                appraisallist:{
                },
                prospect:{
                },
                consumerappraisal:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-white.png',
                    pricebarbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-dark.png',
                    offerpricebarlabel: 'Accu-Trade Instant Offer',
                    offerpricereviewsend: 'Accu-Trade Instant Offer'
                },
                consumerconditionreport:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-white.png',
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-galves-dark.png',
                    offerpricelabel:'Trade Insurance Guarantee'
                },
                dealerappraisal:{
                    customerstartappraisalbtnlabel: 'Accu-Trade Customer',
                    offerpricelabelpricebar:'Accu-Trade Instant Offer',
                    offerpricereviewsend: 'Accu-Trade Instant Offer'
                },
                dealerconditionreport:{
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-galves-dark.png',
                    offerpricelabel:'Accu-Trade Instant Offer',
                    reportsettingsvaluesfirstcheckboxlabel: 'Accu-Trade Instant Offer / Target Trade'
                },
                increaseoffer:{
                    increaseofferbtnlabel: 'Accu-Trade Instant Offer',
                    increaseofferbtndescriptiontext: 'If the Accu-Trade Instant Offer is expired, Dealer is responsible for the entire Updated Offer Amount',
                    updatedofferlabel: 'Updated Accu-Trade Instant Offer',
                    updatedofferagreementtxt: 'I acknowledge that I am responsible for any offer increase amount above the Accu-Trade Instant Offer amount and any extension of the offer period.',
                    increaseofferconfirmationlabel: 'Updated Accu-Trade Instant Offer:'
                },
                ground:{
                },
                getoffer:{
                    getofferbtnlabel: 'Get Instant Offer',
                    getofferbtndescriptiontxt: 'Get a check for the Instant Offer amount',
                    getofferscreenheading: 'Get Instant Offer',
                    getofferscreentitle: 'Accu-Trade Instant Offer',
                    getoffersuccessdescriptionmsg: 'This vehicle was submitted for Accu-Trade Instant Offer on',
                    getofferpendingmsgstatusbar: 'Accu-Trade Instant Offer Pending'
                },
            }, //screen
        }, // accutrade-us   

        'accutrade-can': {user: 'amit+ATCANSA@accu-trade.com',password: 'Test777',brandprospecttext:'IO',zip:'M5V1J5',perseusurl:'https://perseus-consumer-qa.rhcapl.com/?ot=Accu-Trade%20Appraiser&dlr=1b55ebb5935ab510b1c8f5623fcc03a9c6059141',
            screen: {
                appraisallist:{

                },
                prospect:{

                },
                consumerappraisal:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-white.png',
                    pricebarbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-dark.png',
                    offerpricebarlabel: 'Accu-Trade Instant Offer',
                    offerpricereviewsend: 'Accu-Trade Instant Offer'
                },
                consumerconditionreport:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-white.png',
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-galves-dark.png',
                    offerpricelabel:'Trade Insurance Guarantee'
                },
                dealerappraisal:{
                    customerstartappraisalbtnlabel: 'Accu-Trade Customer',
                    offerpricelabelpricebar:'Accu-Trade Instant Offer',
                    offerpricereviewsend: 'Accu-Trade Instant Offer'
                },
                dealerconditionreport:{
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-galves-dark.png',
                    offerpricelabel:'Accu-Trade Instant Offer',
                    reportsettingsvaluesfirstcheckboxlabel: 'Accu-Trade Instant Offer / Target Trade'
                },
                increaseoffer:{
                    increaseofferbtnlabel: 'Accu-Trade Instant Offer',
                    increaseofferbtndescriptiontext: 'If the Accu-Trade Instant Offer is expired, Dealer is responsible for the entire Updated Offer Amount',
                    updatedofferlabel: 'Updated Accu-Trade Instant Offer',
                    updatedofferagreementtxt: 'I acknowledge that I am responsible for any offer increase amount above the Accu-Trade Instant Offer amount and any extension of the offer period.',
                    increaseofferconfirmationlabel: 'Updated Accu-Trade Instant Offer:'
                },
                ground:{
                },
                getoffer:{
                    getofferbtnlabel: 'Get Instant Offer',
                    getofferbtndescriptiontxt: 'Get a check for the Instant Offer amount',
                    getofferscreenheading: 'Get Instant Offer',
                    getofferscreentitle: 'Accu-Trade Instant Offer',
                    getoffersuccessdescriptionmsg: 'This vehicle was submitted for Accu-Trade Instant Offer on',
                    getofferpendingmsgstatusbar: 'Accu-Trade Instant Offer Pending'
                },
            }, // screen
        }, // accutrade-can

        'truecar': {user: 'amit+TrueCarUSSA@accu-trade.com',password: 'Test777',brandprospecttext:'TCO',zip:'78641',perseusurl:'https://perseus-consumer-qa.rhcapl.com/?ot=Accu-Trade%20Appraiser&dlr=d7e06b9ee2524f2e6ee6aa1c5ae09cbe2c3e543f',
            screen: {
                appraisallist:{

                },
                prospect:{

                },
                consumerappraisal:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/truecar-logo-white.svg',
                    pricebarbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/truecar-logo-dark.svg',
                    offerpricebarlabel: 'True Cash Offer',
                    offerpricereviewsend: 'True Cash Offer'
                },
                consumerconditionreport:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/truecar-logo-white.svg',
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/truecar-logo-dark.svg',
                    offerpricelabel:'True Cash Offer'
                },
                dealerappraisal:{
                    customerstartappraisalbtnlabel: 'TRUECar Customer',
                    offerpricelabelpricebar:'True Cash Offer',
                    offerpricereviewsend: 'True Cash Offer'
                },
                dealerconditionreport:{
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-galves-dark.png',
                    offerpricelabel:'True Cash Offer',
                    reportsettingsvaluesfirstcheckboxlabel: 'True Cash Offer / Target Trade'
                },
                increaseoffer:{
                    increaseofferbtnlabel: 'True Cash Offer',
                    increaseofferbtndescriptiontext: 'If the True Cash Offer is expired, Dealer is responsible for the entire Updated Offer Amount',
                    updatedofferlabel: 'Updated True Cash Offer',
                    updatedofferagreementtxt: 'I acknowledge that I am responsible for any offer increase amount above the True Cash Offer amount and any extension of the offer period.',
                    increaseofferconfirmationlabel: 'Updated True Cash Offer:'
                },
                ground:{
                },
                getoffer:{
                    getofferbtnlabel: 'Get True Cash Offer',
                    getofferbtndescriptiontxt: 'Get a check for the True Cash Offer amount',
                    getofferscreenheading: 'Get True Cash Offer',
                    getofferscreentitle: 'True Cash Offer',
                    getoffersuccessdescriptionmsg: 'This vehicle was submitted for True Cash Offer on',
                    getofferpendingmsgstatusbar: 'True Cash Offer Pending'
                },
            },//screen
        },//truecar    

        'truecarpartnerusaa': {user: 'amit+TrueCarUSSA@accu-trade.com',password: 'Test777',brandprospecttext:'TCO',zip:'78641',perseusurl:'https://perseus-consumer-qa.rhcapl.com/?dlr=7d7e3375e9462ff407569cadb235e41412edfeec&pag_id=3',
            screen: {
                appraisallist:{

                },
                prospect:{

                },
                consumerappraisal:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/truecar-logo-white.svg',
                    pricebarbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/usaa.svg',
                    offerpricebarlabel: 'True Cash Offer',
                    offerpricereviewsend: 'True Cash Offer'
                },
                consumerconditionreport:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/truecar-logo-white.svg',
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/usaa.svg',
                    offerpricelabel:'True Cash Offer'
                },
                dealerappraisal:{
                    customerstartappraisalbtnlabel: 'TRUECar Customer',
                    offerpricelabelpricebar:'True Cash Offer',
                    offerpricereviewsend: 'True Cash Offer'
                },
                dealerconditionreport:{
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-galves-dark.png',
                    offerpricelabel:'True Cash Offer',
                    reportsettingsvaluesfirstcheckboxlabel: 'True Cash Offer / Target Trade'
                },
                increaseoffer:{
                    increaseofferbtnlabel: 'True Cash Offer',
                    increaseofferbtndescriptiontext: 'If the True Cash Offer is expired, Dealer is responsible for the entire Updated Offer Amount',
                    updatedofferlabel: 'Updated True Cash Offer',
                    updatedofferagreementtxt: 'I acknowledge that I am responsible for any offer increase amount above the True Cash Offer amount and any extension of the offer period.',
                    increaseofferconfirmationlabel: 'Updated True Cash Offer:'
                },
                ground:{
                },
                getoffer:{
                    getofferbtnlabel: 'Get True Cash Offer',
                    getofferbtndescriptiontxt: 'Get a check for the True Cash Offer amount',
                    getofferscreenheading: 'Get True Cash Offer',
                    getofferscreentitle: 'True Cash Offer',
                    getoffersuccessdescriptionmsg: 'This vehicle was submitted for True Cash Offer on',
                    getofferpendingmsgstatusbar: 'True Cash Offer Pending'
                },
            },//screen
        },//truecar  

        'truecarpartnerboost': {user: 'amit+TrueCarUSSA@accu-trade.com',password: 'Test777',brandprospecttext:'TCO',zip:'78641',perseusurl:'https://perseus-consumer-qa.rhcapl.com/?dlr=57830ff9a83836ab759a5214e7b430a03db0013b',
            screen: {
                appraisallist:{

                },
                prospect:{

                },
                consumerappraisal:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/truecar-logo-white.svg',
                    pricebarbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/truecar-logo-dark.svg',
                    offerpricebarlabel: 'True Cash Offer',
                    offerpricereviewsend: 'True Cash Offer'
                },
                consumerconditionreport:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/truecar-logo-white.svg',
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/truecar-logo-dark.svg',
                    offerpricelabel:'True Cash Offer'
                },
                dealerappraisal:{
                    customerstartappraisalbtnlabel: 'TRUECar Customer',
                    offerpricelabelpricebar:'True Cash Offer',
                    offerpricereviewsend: 'True Cash Offer'
                },
                dealerconditionreport:{
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-galves-dark.png',
                    offerpricelabel:'True Cash Offer',
                    reportsettingsvaluesfirstcheckboxlabel: 'True Cash Offer / Target Trade'
                },
                increaseoffer:{
                    increaseofferbtnlabel: 'True Cash Offer',
                    increaseofferbtndescriptiontext: 'If the True Cash Offer is expired, Dealer is responsible for the entire Updated Offer Amount',
                    updatedofferlabel: 'Updated True Cash Offer',
                    updatedofferagreementtxt: 'I acknowledge that I am responsible for any offer increase amount above the True Cash Offer amount and any extension of the offer period.',
                    increaseofferconfirmationlabel: 'Updated True Cash Offer:'
                },
                ground:{
                },
                getoffer:{
                    getofferbtnlabel: 'Get True Cash Offer',
                    getofferbtndescriptiontxt: 'Get a check for the True Cash Offer amount',
                    getofferscreenheading: 'Get True Cash Offer',
                    getofferscreentitle: 'True Cash Offer',
                    getoffersuccessdescriptionmsg: 'This vehicle was submitted for True Cash Offer on',
                    getofferpendingmsgstatusbar: 'True Cash Offer Pending'
                },
            },//screen
        },//truecar          

        'trader': {user: 'amit+TRADERCANSA@accu-trade.com',password: 'Test777',brandprospecttext:'ICO',zip:'M5V1J5',perseusurl:'https://perseus-consumer-qa.rhcapl.com/?ot=Accu-Trade%20Appraiser&dlr=6c8ee976d283a2afd0588bb12db124eeceabaa84',
            screen: {
                appraisallist:{

                },
                prospect:{

                },
                consumerappraisal:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/trader-logo-red.svg',
                    pricebarbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/trader-logo-red.svg',
                    offerpricebarlabel: 'Target Trade',
                    offerpricereviewsend: 'Target Trade'
                },
                consumerconditionreport:{
                    leftsectionbrandlogo: 'https://hercules-qa.accu-trade.com/assets/images/logos/trader-logo-red.svg',
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/trader-logo-red.svg',
                    offerpricelabel:'Target Trade'
                },
                dealerappraisal:{
                    customerstartappraisalbtnlabel: 'Trader Customer',
                    offerpricelabelpricebar:'Target Trade',
                    offerpricereviewsend: 'Target Trade'
                },
                dealerconditionreport:{
                    brandlogo:'https://hercules-qa.accu-trade.com/assets/images/logos/accutrade-appraiser-galves-dark.png',
                    offerpricelabel:'Target Trade',
                    reportsettingsvaluesfirstcheckboxlabel: 'Target Trade'
                },
                increaseoffer:{
                    increaseofferbtnlabel: 'Instant Cash Offer',
                    increaseofferbtndescriptiontext: 'If the Instant Cash Offer is expired, Dealer is responsible for the entire Updated Offer Amount',
                    updatedofferlabel: 'Updated Instant Cash Offer',
                    updatedofferagreementtxt: 'I acknowledge that I am responsible for any offer increase amount above the Instant Cash Offer amount and any extension of the offer period.',
                    increaseofferconfirmationlabel: 'Updated Instant Cash Offer:'
                },
                ground:{
                },
                getoffer:{
                    getofferbtnlabel: 'Get Instant Offer',
                    getofferbtndescriptiontxt: 'Get a check for the Instant Offer amount',
                    getofferscreenheading: 'Get Instant Offer',
                    getofferscreentitle: 'Accu-Trade Instant Offer',
                    getoffersuccessdescriptionmsg: 'This vehicle was submitted for Accu-Trade Instant Offer on',
                    getofferpendingmsgstatusbar: 'Accu-Trade Instant Offer Pending'
                },
            }, //screen
        }, //trader   

    }, //brandingprospectmaster

    brandingappraisalreportbtn:{
        'Accu-Trade US': {user: 'amit+ATUSSA@accu-trade.com',password: 'Test777',brandvintext:'Print the Instant Offer for the Customer using the appraisal.',brandymmttext:'Print the Target Trade for the Customer using the appraisal.'},
        // 'Accu-Trade CANADA': {user: 'amit+ATCANSA@accu-trade.com',password: 'Test777',brandvintext:'Print the Instant Offer for the Customer using the appraisal.',brandymmttext:'Print the Target Trade for the Customer using the appraisal.'},
        // 'TrueCar': {user: 'amit+TrueCarUSSA@accu-trade.com',password: 'Test777',brandvintext:'Print the True Cash Offer for the Customer using the appraisal.',brandymmttext:'Print the Target Trade for the Customer using the appraisal.'},
        // 'Trader': {user: 'amit+TRADERCANSA@accu-trade.com',password: 'Test777',brandvintext:'Print the Target Trade for the Customer using the appraisal.',brandymmttext:'Print the Target Trade for the Customer using the appraisal.'}
    },
    brandingprospect:{
        'accutrade-us': {user: 'amit+ATUSSA@accu-trade.com',password: 'Test777',brandprospecttext:'IO',zip:'78641',perseusurl:'https://perseus-consumer-qa.rhcapl.com/?ot=Accu-Trade%20Appraiser&dlr=8fe79fc9a5da51b27ec543870de1d6a517dcc803'},
        'accutrade-can': {user: 'amit+ATCANSA@accu-trade.com',password: 'Test777',brandprospecttext:'IO',zip:'M5V1J5',perseusurl:'https://perseus-consumer-qa.rhcapl.com/?ot=Accu-Trade%20Appraiser&dlr=1b55ebb5935ab510b1c8f5623fcc03a9c6059141'},
        'truecar': {user: 'amit+TrueCarUSSA@accu-trade.com',password: 'Test777',brandprospecttext:'TCO',zip:'78641',perseusurl:'https://perseus-consumer-qa.rhcapl.com/?ot=Accu-Trade%20Appraiser&dlr=d7e06b9ee2524f2e6ee6aa1c5ae09cbe2c3e543f'},
        // 'trader': {user: 'amit+TRADERCANSA@accu-trade.com',password: 'Test777',brandprospecttext:'ICO',zip:'M5V1J5',perseusurl:'https://perseus-consumer-qa.rhcapl.com/?ot=Accu-Trade%20Appraiser&dlr=6c8ee976d283a2afd0588bb12db124eeceabaa84'}
    },
    brandingdealerprospect:{
        'truecar': {user: 'amit+TrueCarUSSA@accu-trade.com',password: 'Test777',brandprospecttext:'TCO',brandprospectsourcetext:'DEALER WEBSITE',zip:'78641',perseusurl:'https://perseus-consumer-qa.rhcapl.com/?dlr=d7e06b9ee2524f2e6ee6aa1c5ae09cbe2c3e543f'},
    },
    
    ymmttestdata: {
        'smoke-ymmt': {year: '2017',make: 'ACURA',model: 'MDX', trim: 'ADVANCE AWD 4 DOOR SUV 3.5L V6'}
    },
    loweruppercasevin:{
        'lowercase1':{vin:'1gdgg31v341903986'},
        'uppercase1':{vin:'1GDGG31V341903986'},
        'lowercase2':{vin:'3c4pdcgg9ft556777'},
        'uppercase2':{vin:'3C4PDCGG9FT556777'}
    },
    exoticvin:{
            exoticvin1: {vin: 'ZFF73SKA8D0189737'},
            exoticvin2: {vin: 'ZFFYU51A340136948'},
            exoticvin3: {vin: '1FADP3L91EL198687'},
            exoticvin4: {vin: 'SCFHMDBS0FGF04663'},
    },
    notbadvhr:{
        vin1:{vin: '1FTEW1CP7GKD94985'},
        vin2:{vin: 'WDDYK8AA4JA015766'},
    },
    multipletrims:{
        vin1:{vin: '1FTRW08L73KA63075'},
        vin2:{vin: 'WMEEJ31X98K083638'},
        vin3:{vin: '3N1AB7AP2EY312615'},
        vin4:{vin: 'JTDKN3DUXB5311949'},
    },
    paragraphvin:{
        vin1:{parapgraphvin: 'this is a test KMHTC6AD4CU069176 dskfjkljsdf', extractedvin: 'KMHTC6AD4CU069176'},
        vin2:{parapgraphvin: 'Newtons view of gravity assumed that massive objects created a "field" that permeated space, rather like the field of a magnet. 1D7RV1CT7AS194560 This field enabled one body with mass, like the Earth, to exert a force on another, like the Moon or an apple. Newton did not claim to know what this force was. It was simply a fact of nature that all objects that possess mass create it.', extractedvin: '1D7RV1CT7AS194560'},
        vin3:{parapgraphvin: ' KMHTC6AD4CU069176', extractedvin: 'KMHTC6AD4CU069176'},

    },
    expiredvin:{
        basicuser:{user:'amit+ATUSBU@accu-trade.com',pwd:'Test777',appraisalid:'924527'},
        adminuser:{user:'amit+ATUSSA@accu-trade.com',pwd:'Test777',appraisalid:'923701'},
        manageruser:{user:'amit+ATUSAM@accu-trade.com',pwd:'Test777',appraisalid:'924527'}
    },
    pricing: {
        'body-roof-rust-repair-10300': {appraisal:'vin',mainadjustment:'Body',adjustment:'Roof',category:'rust',subcategory:'repair',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-450',finalofferprice:'9850',finaltargetauction:'10900',finaltargetretail:'13550'},                
        'body-roof-rust-repair-14600': {appraisal:'vin',mainadjustment:'Body',adjustment:'Roof',category:'rust',subcategory:'repair',vin:'4T1B11HK7JU037859',baseprice:'14600',offerprice:'12875',targetauction:'14025',targetretail:'16375',adjustmentvalue:'-450',finalofferprice:'12425',finaltargetauction:'13575',finaltargetretail:'16375'},       
        'body-roof-rust-repair-19000': {appraisal:'vin',mainadjustment:'Body',adjustment:'Roof',category:'rust',subcategory:'repair',vin:'1GYS4BEF3CR151009',baseprice:'19000',offerprice:'19000',targetauction:'20300',targetretail:'22725',adjustmentvalue:'-450',finalofferprice:'18550',finaltargetauction:'19850',finaltargetretail:'22725'},        
        'body-roof-scratch-touchup-42000': {appraisal:'vin',mainadjustment:'Body',adjustment:'Roof',category:'scratch',subcategory:'touchup',vin:'4JGDF6EE4JB116763',baseprice:'4200',offerprice:'42000',targetauction:'44350',targetretail:'48200',adjustmentvalue:'-150',finalofferprice:'41850',finaltargetauction:'44200',finaltargetretail:'48200'},
        'glass-rear-replace-10300': {appraisal:'vin',mainadjustment:'Glass',adjustment:'Rear Window',category:'replace',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-750',finalofferprice:'9550',finaltargetauction:'10600',finaltargetretail:'13550'},        
        'glass-rear-replace-14600': {appraisal:'vin',mainadjustment:'Glass',adjustment:'Rear Window',category:'replace',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'14600',offerprice:'12875',targetauction:'14025',targetretail:'16375',adjustmentvalue:'-750',finalofferprice:'12125',finaltargetauction:'13275',finaltargetretail:'16375'},
        'glass-rear-cracked-42000': {appraisal:'vin',mainadjustment:'Glass',adjustment:'Rear Window',category:'cracked',subcategory:'none',vin:'4JGDF6EE4JB116763',baseprice:'42000',offerprice:'42000',targetauction:'44350',targetretail:'48200',adjustmentvalue:'-1275',finalofferprice:'40725',finaltargetauction:'43075',finaltargetretail:'48200'},
        'interior-reardoorpanelleft-scratched-4000': {appraisal:'vin',mainadjustment:'Interior',adjustment:'Rear Door Panel-Left',category:'scratched',subcategory:'none',vin:'5GAER23718J211084',baseprice:'4000',offerprice:'3850',targetauction:'4850',targetretail:'6850',adjustmentvalue:'-150',finalofferprice:'3700',finaltargetauction:'4700',finaltargetretail:'6850'},
        'interior-reardoorpanelleft-scratched-10300': {appraisal:'vin',mainadjustment:'Interior',adjustment:'Rear Door Panel-Left',category:'scratched',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-150',finalofferprice:'10150',finaltargetauction:'11200',finaltargetretail:'13550'},
        'interior-reardoorpanelleft-scratched-14600': {appraisal:'vin',mainadjustment:'Interior',adjustment:'Rear Door Panel-Left',category:'scratched',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'14600',offerprice:'12875',targetauction:'14025',targetretail:'16375',adjustmentvalue:'-150',finalofferprice:'12725',finaltargetauction:'13875',finaltargetretail:'16375'},
        'interior-frontdoorpanelleft-missing-43500': {appraisal:'vin',mainadjustment:'Interior',adjustment:'Front Door Panel-Left',category:'missing',subcategory:'none',vin:'SALGR2FV2HA357908',baseprice:'43500',offerprice:'43650',targetauction:'46000',targetretail:'49800',adjustmentvalue:'-1325',finalofferprice:'42325',finaltargetauction:'44675',finaltargetretail:'49800'},
        'tire/wheel-rearright-0-3/32-replacewheel-4000': {appraisal:'vin',mainadjustment:'Tire/Wheel',adjustment:'Rear Right',category:'0 - 3/32',subcategory:'replace wheel',vin:'5GAER23718J211084',baseprice:'4000',offerprice:'3850',targetauction:'4850',targetretail:'6850',adjustmentvalue:'-150:-500',finalofferprice:'3200',finaltargetauction:'4200',finaltargetretail:'6850'},
        'tire/wheel-rearright-4/32-7/32-replacewheel-10300': {appraisal:'vin',mainadjustment:'Tire/Wheel',adjustment:'Rear Right',category:'4/32 - 7/32',subcategory:'replace wheel',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-75:-500',finalofferprice:'9725',finaltargetauction:'10775',finaltargetretail:'13550'},
        'tire/wheel-rearright-4/32-7/32-replacewheel-14600': {appraisal:'vin',mainadjustment:'Tire/Wheel',adjustment:'Rear Right',category:'4/32 - 7/32',subcategory:'replace wheel',vin:'4T1B11HK7JU037859',baseprice:'14600',offerprice:'12875',targetauction:'14025',targetretail:'16375',adjustmentvalue:'-100:-500',finalofferprice:'12275',finaltargetauction:'13425',finaltargetretail:'16375'},
        'tire/wheel-rearright-0-3/32-replacewheel-57000': {appraisal:'vin',mainadjustment:'Tire/Wheel',adjustment:'Rear Right',category:'0 - 3/32',subcategory:'replace wheel',vin:'JTJHY7AX0H4242160',baseprice:'57000',offerprice:'56850',targetauction:'59600',targetretail:'64525',adjustmentvalue:'-450:-1725',finalofferprice:'54675',finaltargetauction:'57425',finaltargetretail:'64525'},
        'warninglights-battery-10000': {appraisal:'vin',mainadjustment:'Warning Lights',adjustment:'Battery',category:'none',subcategory:'none',vin:'JTHCE1KS0B0029373',baseprice:'10000',offerprice:'10000',targetauction:'11450',targetretail:'13650',adjustmentvalue:'-225',finalofferprice:'10175',finaltargetauction:'11225',finaltargetretail:'13650'},
        'warninglights-airbag/srs-10300': {appraisal:'vin',mainadjustment:'Warning Lights',adjustment:'Airbag/SRS',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-650',finalofferprice:'9650',finaltargetauction:'10700',finaltargetretail:'13550'},
        'warninglights-airbag/srs-14600': {appraisal:'vin',mainadjustment:'Warning Lights',adjustment:'Airbag/SRS',category:'none',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'14600',offerprice:'12875',targetauction:'14025',targetretail:'16375',adjustmentvalue:'-800',finalofferprice:'12075',finaltargetauction:'13225',finaltargetretail:'16375'},
        'warninglights-engine-42000': {appraisal:'vin',mainadjustment:'Warning Lights',adjustment:'Engine',category:'none',subcategory:'none',vin:'4JGDF6EE4JB116763',baseprice:'42000',offerprice:'42000',targetauction:'44350',targetretail:'48200',adjustmentvalue:'-1700',finalofferprice:'40300',finaltargetauction:'42650',finaltargetretail:'48200'},
        'warninglights-traction-ymmt-650': {appraisal:'ymmt',mainadjustment:'Warning Lights',adjustment:'Traction',category:'none',subcategory:'none',year:'2002',make:'CADILLAC',model:'DEVILLE',trim:'BASE 4 DOOR SEDAN 4.6L V8 NORTHSTAR',baseprice:'650',offerprice:'650',targetauction:'1100',targetretail:'3100',adjustmentvalue:'-350',finalofferprice:'300',finaltargetauction:'750',finaltargetretail:'3100'},
        'warninglights-ABS-ymmt-100000': {appraisal:'ymmt',mainadjustment:'Warning Lights',adjustment:'ABS',category:'none',subcategory:'none',year:'2018',make:'ASTON MARTIN',model:'VANTAGE',trim:'BASE COUPE 4.0L 8 CYL TURBO',baseprice:'100000',offerprice:'100000',targetauction:'0',targetretail:'0',adjustmentvalue:'-2750',finalofferprice:'97250',finaltargetauction:'0',finaltargetretail:'0'},
        'warninglights-suspensionfault-ymmt-38000': {appraisal:'ymmt',mainadjustment:'Warning Lights',adjustment:'Suspension Fault',category:'none',subcategory:'none',year:'2017',make:'BMW',model:'7 SERIES',trim:'740E XDRIVE 4 DOOR SEDAN 2.0L 4 CYL TURBO',baseprice:'38000',offerprice:'38000',targetauction:'40250',targetretail:'43875',adjustmentvalue:'-2500',finalofferprice:'35500',finaltargetauction:'37750',finaltargetretail:'43875'},
        'mechanical-brakes-10300': {appraisal:'vin',mainadjustment:'Mechanical',adjustment:'Brakes',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-725',finalofferprice:'9575',finaltargetauction:'10625',finaltargetretail:'13550'},
        'mechanical-brakes-14600': {appraisal:'vin',mainadjustment:'Mechanical',adjustment:'Brakes',category:'none',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'14600',offerprice:'12875',targetauction:'14025',targetretail:'16375',adjustmentvalue:'-900',finalofferprice:'11975',finaltargetauction:'13125',finaltargetretail:'16375'},
        'mechanical-oilleak-43500': {appraisal:'vin',mainadjustment:'Mechanical',adjustment:'Oil Leak',category:'none',subcategory:'none',vin:'SALGR2FV2HA357908',baseprice:'43500',offerprice:'43650',targetauction:'46000',targetretail:'49800',adjustmentvalue:'-2525',finalofferprice:'41125',finaltargetauction:'43475',finaltargetretail:'49800'},
        'mechanical-suspension-350': {appraisal:'vin',mainadjustment:'Mechanical',adjustment:'Suspension',category:'none',subcategory:'none',vin:'1B3EL36T64N134411',baseprice:'350',offerprice:'250',targetauction:'650',targetretail:'2650',adjustmentvalue:'-350',finalofferprice:'100',finaltargetauction:'300',finaltargetretail:'2650'},
        'mechanical-engine-ymmt-2000': {appraisal:'ymmt',mainadjustment:'Mechanical',adjustment:'Engine',category:'none',subcategory:'none',year:'2004',make:'BMW',model:'5 SERIES',trim:'525I 4 DOOR SEDAN 6 CYL',baseprice:'2000',offerprice:'2000',targetauction:'2800',targetretail:'4800',adjustmentvalue:'-1500',finalofferprice:'500',finaltargetauction:'1300',finaltargetretail:'4800'}, 
        'mechanical-headgasket-ymmt-173000': {appraisal:'ymmt',mainadjustment:'Mechanical',adjustment:'Head Gasket',category:'none',subcategory:'none',year:'2016',make:'LAMBORGHINI',model:'HURACAN',trim:'LP580-2 COUPE 5.2L 10 CYL',baseprice:'173000',offerprice:'173000',targetauction:'0',targetretail:'0',adjustmentvalue:'-5500',finalofferprice:'167500',finaltargetauction:'0',finaltargetretail:'0'},
        'mechanical-turbo-ymmt-173000': {appraisal:'ymmt',mainadjustment:'Mechanical',adjustment:'Turbo',category:'none',subcategory:'none',year:'2016',make:'LAMBORGHINI',model:'HURACAN',trim:'LP580-2 COUPE 5.2L 10 CYL',baseprice:'173000',offerprice:'173000',targetauction:'0',targetretail:'0',adjustmentvalue:'-7500',finalofferprice:'165500',finaltargetauction:'0',finaltargetretail:'0'},
        'aftermarket-stereo-10300': {appraisal:'vin',mainadjustment:'Aftermarket',adjustment:'Stereo',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-225',finalofferprice:'10075',finaltargetauction:'11125',finaltargetretail:'13550'},
        'aftermarket-stereo-14600': {appraisal:'vin',mainadjustment:'Aftermarket',adjustment:'Stereo',category:'none',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'14600',offerprice:'12875',targetauction:'14025',targetretail:'16375',adjustmentvalue:'-250',finalofferprice:'12625',finaltargetauction:'13775',finaltargetretail:'16375'},
        'aftermarket-spoiler-16100': {appraisal:'vin',mainadjustment:'Aftermarket',adjustment:'Spoiler',category:'none',subcategory:'none',vin:'1C4RDJAGXFC722953',baseprice:'16100',offerprice:'14475',targetauction:'15675',targetretail:'17725',adjustmentvalue:'-350',finalofferprice:'14125',finaltargetauction:'15325',finaltargetretail:'17725'},
        'aftermarket-performance-42000': {appraisal:'vin',mainadjustment:'Aftermarket',adjustment:'Performance',category:'none',subcategory:'none',vin:'4JGDF6EE4JB116763',baseprice:'42000',offerprice:'42000',targetauction:'44350',targetretail:'48200',adjustmentvalue:'-2700',finalofferprice:'39300',finaltargetauction:'41650',finaltargetretail:'48200'},
        'aftermarket-suspensionraised-ymmt-650': {appraisal:'ymmt',mainadjustment:'Aftermarket',adjustment:'Suspension Raised',category:'none',subcategory:'none',year:'2002',make:'CADILLAC',model:'DEVILLE',trim:'BASE 4 DOOR SEDAN 4.6L V8 NORTHSTAR',baseprice:'650',offerprice:'650',targetauction:'1100',targetretail:'3100',adjustmentvalue:'300',finalofferprice:'950',finaltargetauction:'1400',finaltargetretail:'3100'},
        'aftermarket-sunroofmoonroof-ymmt-100000': {appraisal:'ymmt',mainadjustment:'Aftermarket',adjustment:'Sunroof/Moonroof',category:'none',subcategory:'none',year:'2018',make:'ASTON MARTIN',model:'VANTAGE',trim:'BASE COUPE 4.0L 8 CYL TURBO',baseprice:'100000',offerprice:'100000',targetauction:'0',targetretail:'0',adjustmentvalue:'-3000',finalofferprice:'97000',finaltargetauction:'0',finaltargetretail:'0'},
        'aftermarket-Exhaust-ymmt-38000': {appraisal:'ymmt',mainadjustment:'Aftermarket',adjustment:'Exhaust',category:'none',subcategory:'none',year:'2017',make:'BMW',model:'7 SERIES',trim:'740E XDRIVE 4 DOOR SEDAN 2.0L 4 CYL TURBO',baseprice:'38000',offerprice:'38000',targetauction:'40250',targetretail:'43875',adjustmentvalue:'-2125',finalofferprice:'35875',finaltargetauction:'38125',finaltargetretail:'43875'},
        'other-Smoke/Odor-10300': {appraisal:'vin',mainadjustment:'Other',adjustment:'Smoke/Odor',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-200',finalofferprice:'10100',finaltargetauction:'11150',finaltargetretail:'13550'},
        'other-Smoke/Odor-14600': {appraisal:'vin',mainadjustment:'Other',adjustment:'Smoke/Odor',category:'none',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'14600',offerprice:'14450',targetauction:'15600',targetretail:'17950',adjustmentvalue:'-300',finalofferprice:'14150',finaltargetauction:'15300',finaltargetretail:'17950'},
        'other-mediumrust-16500': {appraisal:'vin',mainadjustment:'Other',adjustment:'Medium Rust',category:'none',subcategory:'none',vin:'WDCGG5HB6FG369209',baseprice:'16500',offerprice:'16000',targetauction:'17200',targetretail:'19400',adjustmentvalue:'-3300',finalofferprice:'12700',finaltargetauction:'13900',finaltargetretail:'19400'},
        'other-lemonlaws-14850': {appraisal:'vin',mainadjustment:'Other',adjustment:'Lemon Laws',category:'none',subcategory:'none',vin:'5GRGN23U67H105212',baseprice:'14850',offerprice:'13250',targetauction:'14400',targetretail:'16600',adjustmentvalue:'-2100',finalofferprice:'11150',finaltargetauction:'12300',finaltargetretail:'16600'},
        'other-lemonlaws-9200': {appraisal:'vin',mainadjustment:'Other',adjustment:'Lemon Laws',category:'none',subcategory:'none',vin:'2G1FB3D31D9216549',baseprice:'9200',offerprice:'8300',targetauction:'9350',targetretail:'11550',adjustmentvalue:'-1475',finalofferprice:'6825',finaltargetauction:'7875',finaltargetretail:'11550'},
        'other-lemonlaws-ymmt-45300': {appraisal:'ymmt',mainadjustment:'Other',adjustment:'Lemon Laws',category:'none',subcategory:'none',year:'2017',make:'PORSCHE',model:'MACAN',trim:'GTS 4 DOOR SUV 3.0L V6 TURBO',baseprice:'45300',offerprice:'45300',targetauction:'47650',targetretail:'51700',adjustmentvalue:'-5225',finalofferprice:'40075',finaltargetauction:'42425',finaltargetretail:'51700'},
        'other-lemonlaws-ymmt-105000': {appraisal:'ymmt',mainadjustment:'Other',adjustment:'Lemon Laws',category:'none',subcategory:'none',year:'2014',make:'LAMBORGHINI',model:'GALLARDO',trim:'LP560-2 COUPE 5.2L 10 CYL',baseprice:'105000',offerprice:'105000',targetauction:'0',targetretail:'0',adjustmentvalue:'-13825',finalofferprice:'91175',finaltargetauction:'0',finaltargetretail:'0'},
        'options-navigation-10300': {appraisal:'vin',mainadjustment:'Options',adjustment:'NAVIGATION',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'200',finalofferprice:'10500',finaltargetauction:'11550',finaltargetretail:'13750'},        
        'options-manualtransmission-10300': {appraisal:'vin',mainadjustment:'Options',adjustment:'MANUAL TRANSMISSION',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-550',finalofferprice:'9750',finaltargetauction:'10800',finaltargetretail:'13000'},        
        'options-rearDVDentertainmentsystem-19000': {appraisal:'vin',mainadjustment:'Options',adjustment:'REAR DVD ENTERTAINMENT SYSTEM',category:'none',subcategory:'none',vin:'1GYS4BEF3CR151009',baseprice:'19000',offerprice:'19000',targetauction:'20300',targetretail:'22775',adjustmentvalue:'350',finalofferprice:'19350',finaltargetauction:'20650',finaltargetretail:'23075'},                
        'servicestatus-astraded-5000': {appraisal:'vin',mainadjustment:'Service Status',adjustment:'As Traded',category:'none',subcategory:'none',vin:'4JGBB86E28A329420',baseprice:'5000',offerprice:'5000',targetauction:'6050',targetretail:'8250',adjustmentvalue:'0',finalofferprice:'5000',finaltargetauction:'6050',finaltargetretail:'8250'},
        'servicestatus-oemcertified-10300': {appraisal:'vin',mainadjustment:'Service Status',adjustment:'OEM Certified',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'300',finalofferprice:'10600',finaltargetauction:'11650',finaltargetretail:'15050'},
        'servicestatus-servicerecords-14600': {appraisal:'vin',mainadjustment:'Service Status',adjustment:'Service Records',category:'none',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'14600',offerprice:'12875',targetauction:'14025',targetretail:'16375',adjustmentvalue:'150',finalofferprice:'13025',finaltargetauction:'14175',finaltargetretail:'17075'},
        'servicestatus-oemcertified-57000': {appraisal:'vin',mainadjustment:'Service Status',adjustment:'OEM Certified',category:'none',subcategory:'none',vin:'JTJHY7AX0H4242160',baseprice:'57000',offerprice:'56850',targetauction:'59600',targetretail:'64525',adjustmentvalue:'300',finalofferprice:'57150',finaltargetauction:'59900',finaltargetretail:'66025'},
        'badvhr-5000': {appraisal:'vin',mainadjustment:'Vehicle History',adjustment:'Bad VHR',category:'none',subcategory:'none',vin:'4JGBB86E28A329420',baseprice:'5000',offerprice:'5000',targetauction:'6050',targetretail:'8250',adjustmentvalue:'-375',finalofferprice:'4625',finaltargetauction:'5675',finaltargetretail:'7875'},
        'badvhr-10300': {appraisal:'vin',mainadjustment:'Vehicle History',adjustment:'Bad VHR',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-1050',finalofferprice:'9250',finaltargetauction:'10300',finaltargetretail:'12500'},
        'badvhr-19000': {appraisal:'vin',mainadjustment:'Vehicle History',adjustment:'Bad VHR',category:'none',subcategory:'none',vin:'1GYS4BEF3CR151009',baseprice:'19000',offerprice:'19000',targetauction:'20300',targetretail:'22725',adjustmentvalue:'-2125',finalofferprice:'16875',finaltargetauction:'18175',finaltargetretail:'20600'},
        'badvhr-57000': {appraisal:'vin',mainadjustment:'Vehicle History',adjustment:'Bad VHR',category:'none',subcategory:'none',vin:'JTJHY7AX0H4242160',baseprice:'57000',offerprice:'56850',targetauction:'59600',targetretail:'64525',adjustmentvalue:'-5900',finalofferprice:'50950',finaltargetauction:'53700',finaltargetretail:'58625'},
        //------------------------ Above updated with 3.26 Results ---------------------------------------//
        'framedamage-5000': {appraisal:'vin',mainadjustment:'Vehicle History',adjustment:'Frame Damage',category:'none',subcategory:'none',vin:'4JGBB86E28A329420',baseprice:'5000',offerprice:'5000',targetauction:'6050',targetretail:'8250',adjustmentvalue:'-500',finalofferprice:'4500',finaltargetauction:'5550',finaltargetretail:'8250'},
        'framedamage-10300': {appraisal:'vin',mainadjustment:'Vehicle History',adjustment:'Frame Damage',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-875',finalofferprice:'9425',finaltargetauction:'10475',finaltargetretail:'13550'},
        'framedamage-20000': {appraisal:'vin',mainadjustment:'Vehicle History',adjustment:'Frame Damage',category:'none',subcategory:'none',vin:'1GYS4BEF3CR151009',baseprice:'20000',offerprice:'20000',targetauction:'21300',targetretail:'23775',adjustmentvalue:'-1275',finalofferprice:'18725',finaltargetauction:'20025',finaltargetretail:'23775'},
        'framedamage-58500': {appraisal:'vin',mainadjustment:'Vehicle History',adjustment:'Frame Damage',category:'none',subcategory:'none',vin:'JTJHY7AX0H4242160',baseprice:'58500',offerprice:'58350',targetauction:'61250',targetretail:'66275',adjustmentvalue:'-3000',finalofferprice:'55350',finaltargetauction:'58250',finaltargetretail:'66275'},

        'keys-1-10300': {appraisal:'vin',mainadjustment:'Keys',adjustment:'1',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-150',finalofferprice:'10150',finaltargetauction:'11200',finaltargetretail:'13550'},        
        'keys-0-15100': {appraisal:'vin',mainadjustment:'Keys',adjustment:'0',category:'none',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'-750',finalofferprice:'12550',finaltargetauction:'13750',finaltargetretail:'16850'},        
        'keys-2-15100': {appraisal:'vin',mainadjustment:'Keys',adjustment:'2',category:'none',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'0',finalofferprice:'13300',finaltargetauction:'14500',finaltargetretail:'16850'},        
        'keys-2-45000': {appraisal:'vin',mainadjustment:'Keys',adjustment:'2',category:'none',subcategory:'none',vin:'4JGDF6EE4JB116763',baseprice:'45000',offerprice:'45000',targetauction:'47350',targetretail:'51400',adjustmentvalue:'0',finalofferprice:'45000',finaltargetauction:'47350',finaltargetretail:'51400'},        

        'originalowner-yes-10300': {appraisal:'vin',mainadjustment:'Original Owner',adjustment:'1',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'100',finalofferprice:'10400',finaltargetauction:'11450',finaltargetretail:'13550'},
        'originalowner-no-15100': {appraisal:'vin',mainadjustment:'Original Owner',adjustment:'2+',category:'none',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'-150',finalofferprice:'13300',finaltargetauction:'14500',finaltargetretail:'16850'},
        'originalowner-yes-20000': {appraisal:'vin',mainadjustment:'Original Owner',adjustment:'1',category:'none',subcategory:'none',vin:'1GYS4BEF3CR151009',baseprice:'20000',offerprice:'20000',targetauction:'21300',targetretail:'23775',adjustmentvalue:'200',finalofferprice:'20200',finaltargetauction:'21500',finaltargetretail:'23775'},
        
        'odometer-100000-10300': {appraisal:'vin',mainadjustment:'Odometer',adjustment:'100,000',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-1975',finalofferprice:'8325',finaltargetauction:'9375',finaltargetretail:'11575'},        
        'odometer-100000-15100': {appraisal:'vin',mainadjustment:'Odometer',adjustment:'100,000',category:'none',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'-5375',finalofferprice:'7925',finaltargetauction:'9125',finaltargetretail:'11475'},        
        'odometer-50000-20000': {appraisal:'vin',mainadjustment:'Odometer',adjustment:'50,000',category:'none',subcategory:'none',vin:'1GYS4BEF3CR151009',baseprice:'20000',offerprice:'20000',targetauction:'21300',targetretail:'23775',adjustmentvalue:'3950',finalofferprice:'23950',finaltargetauction:'25250',finaltargetretail:'27725'},        

        'color-exteriorcolor-black-5000': {appraisal:'vin',mainadjustment:'Color',adjustment:'Exterior Color',category:'Black',subcategory:'none',vin:'4JGBB86E28A329420',baseprice:'5000',offerprice:'5000',targetauction:'6050',targetretail:'8250',adjustmentvalue:'75',finalofferprice:'5075',finaltargetauction:'6125',finaltargetretail:'8325'},
        'color-exteriorcolor-black-10300': {appraisal:'vin',mainadjustment:'Color',adjustment:'Exterior Color',category:'Black',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'125',finalofferprice:'10425',finaltargetauction:'11475',finaltargetretail:'13675'},
        'color-exteriorcolor-grey-15100': {appraisal:'vin',mainadjustment:'Color',adjustment:'Exterior Color',category:'Grey',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'-150',finalofferprice:'13150',finaltargetauction:'14350',finaltargetretail:'16700'},
    
        'color-interiorcolor-black-5000': {appraisal:'vin',mainadjustment:'Color',adjustment:'Interior Color',category:'Black',subcategory:'none',vin:'4JGBB86E28A329420',baseprice:'5000',offerprice:'5000',targetauction:'6050',targetretail:'8250',adjustmentvalue:'0',finalofferprice:'5000',finaltargetauction:'6050',finaltargetretail:'8250'},
        'color-interiorcolor-black-10300': {appraisal:'vin',mainadjustment:'Color',adjustment:'Interior Color',category:'Black',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'0',finalofferprice:'10300',finaltargetauction:'11350',finaltargetretail:'13550'},
        'color-interiorcolor-grey-14650': {appraisal:'vin',mainadjustment:'Color',adjustment:'Interior Color',category:'Grey',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'0',finalofferprice:'13300',finaltargetauction:'14500',finaltargetretail:'16850'},

    },
    alerts:{
        'servicestatus-flunked':{appraisal:'vin',mainadjustment:'Service Status',adjustments:{adjustment1:'Flunked Shop'},category:'none',subcategory:'none',vin:'SALGR2FV2HA357908'},
        'mechanical-engine-topendnoise':{appraisal:'vin',mainadjustment:'Mechanical',adjustments:{adjustment1:'Engine',adjustment2:'Top End Noise'},category:'none',subcategory:'none',vin:'SALGR2FV2HA357908'},
        'aftermarket-suspensionlowered':{appraisal:'vin',mainadjustment:'Aftermarket',adjustments:{adjustment1:'Suspension Lowered'},category:'none',subcategory:'none',vin:'SALGR2FV2HA357908'},
        'other-multipledamages': {appraisal:'vin',mainadjustment:'Other',adjustments:{adjustment1:'Open Recalls',adjustment2:'Previous Livery/Uber',adjustment3:'Sold at auction in last 45 day',adjustment4:'Previously Arbitrated',adjustment5:'Salvage',adjustment6:'Water Damge',adjustment7:'Stolen/Recovered',adjustment8:'Hail Damage',adjustment9:'Airbag Currently Deployed',adjustment10:'Heavy Rust',adjustment11:'Medium Rust',adjustment12:'Light Rust',adjustment13:'TMU'},category:'none',subcategory:'none',vin:'SALGR2FV2HA357908'}
    }
    
}