'use strict';

module.exports = {
	adminusers: {
        'Super Admin User': {user: 'amit+stageatsa@accu-trade.com',password: 'Test777'},
        //'Basic Admin User': {user: 'amit+ATUSBA@accu-trade.com',password: 'Test777'},
    },
    nonadminusers: {
        'Basic User': {user: 'amit+stagingATUSBU@accu-trade.com',password: 'Test777'},
        //'BDC Manager User': {user: 'amit+ATUSBDCM@accu-trade.com',password: 'Test777'},
        //'Sales Manager User': {user: 'amit+ATUSSM@accu-trade.com',password: 'Test777'},
        //'Acquisition User': {user: 'amit+ATUSAU@accu-trade.com',password: 'Test777'},
        'Acquisition Manager User': {user: 'amit+stagingATUSAM@accu-trade.com',password: 'Test777'}
    },
    atusers: {
        'AT Super Admin User': {user: 'amit+stageatsa@accu-trade.com',password: 'Test777'}
    },
    truecarusers: {
        //'True Car Super Admin User': {user: 'amit+TrueCarUSSA@accu-trade.com',password: 'Test777'}
    },
    traderusers: {
        //'Trader Super Admin User': {user: 'amit+TRADERCANSA@accu-trade.com',password: 'Test777'}
    },
    allusertypes: {
        'AT Super Admin User': {user: 'amit+stageatsa@accu-trade.com',password: 'Test777'},
        //'True Car Super Admin User': {user: 'amit+TrueCarUSSA@accu-trade.com',password: 'Test777'},
        //'Trader Super Admin User': {user: 'amit+TRADERCANSA@accu-trade.com',password: 'Test777'}
    },
    brandingusers:{
        'AT Super Admin User': {user: 'amit+stageatsa@accu-trade.com',password: 'Test777'},
        //'True Car Super Admin User': {user: 'amit+TrueCarUSSA@accu-trade.com',password: 'Test777'},
        //'Trader Super Admin User': {user: 'amit+TRADERCANSA@accu-trade.com',password: 'Test777'} 
    },
    ymmttestdata: {
        'year make model': {ymm: '2017 ACURA MDX', trim: 'ADVANCE AWD 4 DOOR SUV 3.5L V6'}
    },
    pricing: {
        'body-roof-rust-repair-10300': {mainadjustment:'Body',adjustment:'Roof',category:'rust',subcategory:'repair',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-450',finalofferprice:'9850',finaltargetauction:'10900',finaltargetretail:'13550'},
        'body-roof-rust-repair-15100': {mainadjustment:'Body',adjustment:'Roof',category:'rust',subcategory:'repair',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'-450',finalofferprice:'12850',finaltargetauction:'14050',finaltargetretail:'16850'},
        'body-roof-rust-repair-20000': {mainadjustment:'Body',adjustment:'Roof',category:'rust',subcategory:'repair',vin:'1GYS4BEF3CR151009',baseprice:'20000',offerprice:'20000',targetauction:'21300',targetretail:'23775',adjustmentvalue:'-450',finalofferprice:'19550',finaltargetauction:'20850',finaltargetretail:'23775'},
        'body-roof-scratch-touchup-45000': {mainadjustment:'Body',adjustment:'Roof',category:'scratch',subcategory:'touchup',vin:'4JGDF6EE4JB116763',baseprice:'45000',offerprice:'45000',targetauction:'47350',targetretail:'51400',adjustmentvalue:'-150',finalofferprice:'44850',finaltargetauction:'47200',finaltargetretail:'51400'},

        'glass-rear-replace-10300': {mainadjustment:'Glass',adjustment:'Rear Window',category:'replace',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-750',finalofferprice:'9550',finaltargetauction:'10600',finaltargetretail:'13550'},
        'glass-rear-replace-15100': {mainadjustment:'Glass',adjustment:'Rear Window',category:'replace',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'-750',finalofferprice:'12550',finaltargetauction:'13750',finaltargetretail:'16850'},
        'glass-rear-cracked-45000': {mainadjustment:'Glass',adjustment:'Rear Window',category:'cracked',subcategory:'none',vin:'4JGDF6EE4JB116763',baseprice:'45000',offerprice:'45000',targetauction:'47350',targetretail:'51400',adjustmentvalue:'-1350',finalofferprice:'43650',finaltargetauction:'46000',finaltargetretail:'51400'},

        'interior-reardoorpanelleft-scratched-4250': {mainadjustment:'Interior',adjustment:'Rear Door Panel-Left',category:'scratched',subcategory:'none',vin:'5GAER23718J211084',baseprice:'4400',offerprice:'4250',targetauction:'5300',targetretail:'7500',adjustmentvalue:'-150',finalofferprice:'4100',finaltargetauction:'5150',finaltargetretail:'7500'},
        'interior-reardoorpanelleft-scratched-10300': {mainadjustment:'Interior',adjustment:'Rear Door Panel-Left',category:'scratched',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-150',finalofferprice:'10150',finaltargetauction:'11200',finaltargetretail:'13550'},
        'interior-reardoorpanelleft-scratched-15100': {mainadjustment:'Interior',adjustment:'Rear Door Panel-Left',category:'scratched',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'-150',finalofferprice:'13150',finaltargetauction:'14350',finaltargetretail:'16850'},
        'interior-frontdoorpanelleft-missing-44500': {mainadjustment:'Interior',adjustment:'Front Door Panel-Left',category:'missing',subcategory:'none',vin:'SALGR2FV2HA357908',baseprice:'44500',offerprice:'44650',targetauction:'47000',targetretail:'50850',adjustmentvalue:'-1350',finalofferprice:'43300',finaltargetauction:'45650',finaltargetretail:'50850'},

        'tire/wheel-rearright-0-3/32-replacewheel-4250': {mainadjustment:'Tire/Wheel',adjustment:'Rear Right',category:'0 - 3/32',subcategory:'replace wheel',vin:'5GAER23718J211084',baseprice:'4400',offerprice:'4250',targetauction:'5300',targetretail:'7500',adjustmentvalue:'-150:-500',finalofferprice:'3600',finaltargetauction:'4650',finaltargetretail:'7500'},
        'tire/wheel-rearright-4/32-7/32-replacewheel-10300': {mainadjustment:'Tire/Wheel',adjustment:'Rear Right',category:'4/32 - 7/32',subcategory:'replace wheel',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-75:-500',finalofferprice:'9725',finaltargetauction:'10775',finaltargetretail:'13550'},
        'tire/wheel-rearright-4/32-7/32-replacewheel-15100': {mainadjustment:'Tire/Wheel',adjustment:'Rear Right',category:'4/32 - 7/32',subcategory:'replace wheel',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'-100:-500',finalofferprice:'12700',finaltargetauction:'13900',finaltargetretail:'16850'},
        'tire/wheel-rearright-0-3/32-replacewheel-58500': {mainadjustment:'Tire/Wheel',adjustment:'Rear Right',category:'0 - 3/32',subcategory:'replace wheel',vin:'JTJHY7AX0H4242160',baseprice:'58500',offerprice:'58350',targetauction:'61250',targetretail:'66275',adjustmentvalue:'-450:-1775',finalofferprice:'56125',finaltargetauction:'59025',finaltargetretail:'66275'},

        'warninglights-battery-10700': {mainadjustment:'Warning Lights',adjustment:'Battery',category:'none',subcategory:'none',vin:'JTHCE1KS0B0029373',baseprice:'10250',offerprice:'10700',targetauction:'11850',targetretail:'14050',adjustmentvalue:'-250',finalofferprice:'10450',finaltargetauction:'11600',finaltargetretail:'14050'},
        'warninglights-airbag/srs-10300': {mainadjustment:'Warning Lights',adjustment:'Airbag/SRS',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-650',finalofferprice:'9650',finaltargetauction:'10700',finaltargetretail:'13550'},
        'warninglights-airbag/srs-15100': {mainadjustment:'Warning Lights',adjustment:'Airbag/SRS',category:'none',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'-800',finalofferprice:'12500',finaltargetauction:'13700',finaltargetretail:'16850'},
        'warninglights-engine-45000': {mainadjustment:'Warning Lights',adjustment:'Engine',category:'none',subcategory:'none',vin:'4JGDF6EE4JB116763',baseprice:'45000',offerprice:'45000',targetauction:'47350',targetretail:'51400',adjustmentvalue:'-1700',finalofferprice:'43300',finaltargetauction:'45650',finaltargetretail:'51400'},

        'mechanical-brakes-10300': {mainadjustment:'Mechanical',adjustment:'Brakes',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-725',finalofferprice:'9575',finaltargetauction:'10625',finaltargetretail:'13550'},
        'mechanical-brakes-15100': {mainadjustment:'Mechanical',adjustment:'Brakes',category:'none',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'-925',finalofferprice:'12375',finaltargetauction:'13575',finaltargetretail:'16850'},
        'mechanical-oilleak-44500': {mainadjustment:'Mechanical',adjustment:'Oil Leak',category:'none',subcategory:'none',vin:'SALGR2FV2HA357908',baseprice:'44500',offerprice:'44650',targetauction:'47000',targetretail:'50850',adjustmentvalue:'-2575',finalofferprice:'42075',finaltargetauction:'44425',finaltargetretail:'50850'},

        'aftermarket-stereo-10300': {mainadjustment:'Aftermarket',adjustment:'Stereo',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-225',finalofferprice:'10075',finaltargetauction:'11125',finaltargetretail:'13550'},
        'aftermarket-stereo-15100': {mainadjustment:'Aftermarket',adjustment:'Stereo',category:'none',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'-275',finalofferprice:'13025',finaltargetauction:'14225',finaltargetretail:'16850'},
        'aftermarket-spoiler-16500': {mainadjustment:'Aftermarket',adjustment:'Spoiler',category:'none',subcategory:'none',vin:'1C4RDJAGXFC722953',baseprice:'16500',offerprice:'14850',targetauction:'16050',targetretail:'18075',adjustmentvalue:'-350',finalofferprice:'14500',finaltargetauction:'15700',finaltargetretail:'18075'},
        'aftermarket-performance-45000': {mainadjustment:'Aftermarket',adjustment:'Performance',category:'none',subcategory:'none',vin:'4JGDF6EE4JB116763',baseprice:'45000',offerprice:'45000',targetauction:'47350',targetretail:'51400',adjustmentvalue:'-2825',finalofferprice:'42175',finaltargetauction:'44525',finaltargetretail:'51400'},

        'other-Smoke/Odor-10300': {mainadjustment:'Other',adjustment:'Smoke/Odor',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-200',finalofferprice:'10100',finaltargetauction:'11150',finaltargetretail:'13550'},
        'other-Smoke/Odor-15100': {mainadjustment:'Other',adjustment:'Smoke/Odor',category:'none',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'-300',finalofferprice:'13000',finaltargetauction:'14200',finaltargetretail:'16850'},
        'other-mediumrust-17250': {mainadjustment:'Other',adjustment:'Medium Rust',category:'none',subcategory:'none',vin:'WDCGG5HB6FG369209',baseprice:'17250',offerprice:'16750',targetauction:'18000',targetretail:'20200',adjustmentvalue:'-3450',finalofferprice:'13300',finaltargetauction:'14550',finaltargetretail:'20200'},

        'options-navigation-10300': {mainadjustment:'Options',adjustment:'NAVIGATION',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'200',finalofferprice:'10500',finaltargetauction:'11550',finaltargetretail:'13750'},        
        'options-manualtransmission-10300': {mainadjustment:'Options',adjustment:'MANUAL TRANSMISSION',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-550',finalofferprice:'9750',finaltargetauction:'10800',finaltargetretail:'13000'},        
        'options-rearDVDentertainmentsystem-20000': {mainadjustment:'Options',adjustment:'REAR DVD ENTERTAINMENT SYSTEM',category:'none',subcategory:'none',vin:'1GYS4BEF3CR151009',baseprice:'20000',offerprice:'20000',targetauction:'21300',targetretail:'23775',adjustmentvalue:'350',finalofferprice:'20350',finaltargetauction:'21650',finaltargetretail:'24125'},        
        
        'servicestatus-astraded-5000': {mainadjustment:'Service Status',adjustment:'As Traded',category:'none',subcategory:'none',vin:'4JGBB86E28A329420',baseprice:'5000',offerprice:'5000',targetauction:'6050',targetretail:'8250',adjustmentvalue:'0',finalofferprice:'5000',finaltargetauction:'6050',finaltargetretail:'8250'},
        'servicestatus-oemcertified-10300': {mainadjustment:'Service Status',adjustment:'OEM Certified',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'300',finalofferprice:'10600',finaltargetauction:'11650',finaltargetretail:'15050'},
        'servicestatus-servicerecords-15100': {mainadjustment:'Service Status',adjustment:'Service Records',category:'none',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'150',finalofferprice:'13450',finaltargetauction:'14650',finaltargetretail:'17550'},
        'servicestatus-oemcertified-58500': {mainadjustment:'Service Status',adjustment:'OEM Certified',category:'none',subcategory:'none',vin:'JTJHY7AX0H4242160',baseprice:'58500',offerprice:'58350',targetauction:'61250',targetretail:'66275',adjustmentvalue:'300',finalofferprice:'58650',finaltargetauction:'61550',finaltargetretail:'67775'},

        'badvhr-5000': {mainadjustment:'Vehicle History',adjustment:'Bad VHR',category:'none',subcategory:'none',vin:'4JGBB86E28A329420',baseprice:'5000',offerprice:'5000',targetauction:'6050',targetretail:'8250',adjustmentvalue:'-375',finalofferprice:'4625',finaltargetauction:'5675',finaltargetretail:'7875'},
        'badvhr-10300': {mainadjustment:'Vehicle History',adjustment:'Bad VHR',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-1050',finalofferprice:'9250',finaltargetauction:'10300',finaltargetretail:'12500'},
        'badvhr-20000': {mainadjustment:'Vehicle History',adjustment:'Bad VHR',category:'none',subcategory:'none',vin:'1GYS4BEF3CR151009',baseprice:'20000',offerprice:'20000',targetauction:'21300',targetretail:'23775',adjustmentvalue:'-2250',finalofferprice:'17750',finaltargetauction:'19050',finaltargetretail:'21525'},
        'badvhr-58500': {mainadjustment:'Vehicle History',adjustment:'Bad VHR',category:'none',subcategory:'none',vin:'JTJHY7AX0H4242160',baseprice:'58500',offerprice:'58350',targetauction:'61250',targetretail:'66275',adjustmentvalue:'-6050',finalofferprice:'52300',finaltargetauction:'55200',finaltargetretail:'60225'},

        'framedamage-5000': {mainadjustment:'Vehicle History',adjustment:'Frame Damage',category:'none',subcategory:'none',vin:'4JGBB86E28A329420',baseprice:'5000',offerprice:'5000',targetauction:'6050',targetretail:'8250',adjustmentvalue:'-500',finalofferprice:'4500',finaltargetauction:'5550',finaltargetretail:'8250'},
        'framedamage-10300': {mainadjustment:'Vehicle History',adjustment:'Frame Damage',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-875',finalofferprice:'9425',finaltargetauction:'10475',finaltargetretail:'13550'},
        'framedamage-20000': {mainadjustment:'Vehicle History',adjustment:'Frame Damage',category:'none',subcategory:'none',vin:'1GYS4BEF3CR151009',baseprice:'20000',offerprice:'20000',targetauction:'21300',targetretail:'23775',adjustmentvalue:'-1275',finalofferprice:'18725',finaltargetauction:'20025',finaltargetretail:'23775'},
        'framedamage-58500': {mainadjustment:'Vehicle History',adjustment:'Frame Damage',category:'none',subcategory:'none',vin:'JTJHY7AX0H4242160',baseprice:'58500',offerprice:'58350',targetauction:'61250',targetretail:'66275',adjustmentvalue:'-3000',finalofferprice:'55350',finaltargetauction:'58250',finaltargetretail:'66275'},

        'keys-1-10300': {mainadjustment:'Keys',adjustment:'1',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-150',finalofferprice:'10150',finaltargetauction:'11200',finaltargetretail:'13550'},        
        'keys-0-15100': {mainadjustment:'Keys',adjustment:'0',category:'none',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'-750',finalofferprice:'12550',finaltargetauction:'13750',finaltargetretail:'16850'},        
        'keys-2-15100': {mainadjustment:'Keys',adjustment:'2',category:'none',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'0',finalofferprice:'13300',finaltargetauction:'14500',finaltargetretail:'16850'},        
        'keys-2-45000': {mainadjustment:'Keys',adjustment:'2',category:'none',subcategory:'none',vin:'4JGDF6EE4JB116763',baseprice:'45000',offerprice:'45000',targetauction:'47350',targetretail:'51400',adjustmentvalue:'0',finalofferprice:'45000',finaltargetauction:'47350',finaltargetretail:'51400'},        

        'originalowner-yes-10300': {mainadjustment:'Original Owner',adjustment:'1',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'100',finalofferprice:'10400',finaltargetauction:'11450',finaltargetretail:'13550'},
        'originalowner-no-15100': {mainadjustment:'Original Owner',adjustment:'2+',category:'none',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'-150',finalofferprice:'13300',finaltargetauction:'14500',finaltargetretail:'16850'},
        'originalowner-yes-20000': {mainadjustment:'Original Owner',adjustment:'1',category:'none',subcategory:'none',vin:'1GYS4BEF3CR151009',baseprice:'20000',offerprice:'20000',targetauction:'21300',targetretail:'23775',adjustmentvalue:'200',finalofferprice:'20200',finaltargetauction:'21500',finaltargetretail:'23775'},
        
        'odometer-100000-10300': {mainadjustment:'Odometer',adjustment:'100,000',category:'none',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'-1975',finalofferprice:'8325',finaltargetauction:'9375',finaltargetretail:'11575'},        
        'odometer-100000-15100': {mainadjustment:'Odometer',adjustment:'100,000',category:'none',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'-5375',finalofferprice:'7925',finaltargetauction:'9125',finaltargetretail:'11475'},        
        'odometer-50000-20000': {mainadjustment:'Odometer',adjustment:'50,000',category:'none',subcategory:'none',vin:'1GYS4BEF3CR151009',baseprice:'20000',offerprice:'20000',targetauction:'21300',targetretail:'23775',adjustmentvalue:'3950',finalofferprice:'23950',finaltargetauction:'25250',finaltargetretail:'27725'},        

        'color-exteriorcolor-black-5000': {mainadjustment:'Color',adjustment:'Exterior Color',category:'Black',subcategory:'none',vin:'4JGBB86E28A329420',baseprice:'5000',offerprice:'5000',targetauction:'6050',targetretail:'8250',adjustmentvalue:'75',finalofferprice:'5075',finaltargetauction:'6125',finaltargetretail:'8325'},
        'color-exteriorcolor-black-10300': {mainadjustment:'Color',adjustment:'Exterior Color',category:'Black',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'125',finalofferprice:'10425',finaltargetauction:'11475',finaltargetretail:'13675'},
        'color-exteriorcolor-grey-15100': {mainadjustment:'Color',adjustment:'Exterior Color',category:'Grey',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'-150',finalofferprice:'13150',finaltargetauction:'14350',finaltargetretail:'16700'},
    
        'color-interiorcolor-black-5000': {mainadjustment:'Color',adjustment:'Interior Color',category:'Black',subcategory:'none',vin:'4JGBB86E28A329420',baseprice:'5000',offerprice:'5000',targetauction:'6050',targetretail:'8250',adjustmentvalue:'0',finalofferprice:'5000',finaltargetauction:'6050',finaltargetretail:'8250'},
        'color-interiorcolor-black-10300': {mainadjustment:'Color',adjustment:'Interior Color',category:'Black',subcategory:'none',vin:'JF2GPAVC6D2872682',baseprice:'10300',offerprice:'10300',targetauction:'11350',targetretail:'13550',adjustmentvalue:'0',finalofferprice:'10300',finaltargetauction:'11350',finaltargetretail:'13550'},
        'color-interiorcolor-grey-14650': {mainadjustment:'Color',adjustment:'Interior Color',category:'Grey',subcategory:'none',vin:'4T1B11HK7JU037859',baseprice:'15100',offerprice:'13300',targetauction:'14500',targetretail:'16850',adjustmentvalue:'0',finalofferprice:'13300',finaltargetauction:'14500',finaltargetretail:'16850'},
    },
    alerts:{
        'servicestatus-flunked':{mainadjustment:'Service Status',adjustments:{adjustment1:'Flunked Shop'},category:'none',subcategory:'none',vin:'SALGR2FV2HA357908'},
        'mechanical-engine-topendnoise':{mainadjustment:'Mechanical',adjustments:{adjustment1:'Engine',adjustment2:'Top End Noise'},category:'none',subcategory:'none',vin:'SALGR2FV2HA357908'},
        'aftermarket-suspensionlowered':{mainadjustment:'Aftermarket',adjustments:{adjustment1:'Suspension Lowered'},category:'none',subcategory:'none',vin:'SALGR2FV2HA357908'},
        'other-multipledamages': {mainadjustment:'Other',adjustments:{adjustment1:'Open Recalls',adjustment2:'Previous Livery/Uber',adjustment3:'Sold at auction in last 45 day',adjustment4:'Previously Arbitrated',adjustment5:'Salvage',adjustment6:'Water Damge',adjustment7:'Stolen/Recovered',adjustment8:'Hail Damage',adjustment9:'Airbag Currently Deployed',adjustment10:'Heavy Rust',adjustment11:'Medium Rust',adjustment12:'Light Rust',adjustment13:'TMU'},category:'none',subcategory:'none',vin:'SALGR2FV2HA357908'}
    }
    
}