#!/usr/bin/env bash
set -x
export ENV=$1
export TEST=$2
docker-compose -f local.yml run --rm node
exit_code=$?
docker-compose -f local.yml down
