var utils = function(){
    
    this.logInfo = async function(txt){
        await browser.logger.info("------------- "+txt+" -------------");
    }  

    this.paginatorTotalCount = function(range){
        var res = range.split("of");
        return res[1].trim();
    }
    
    // 0 of 0

    this.paginatotRowCount = function(range){
        var res = range.split("of");

        if(res[0].trim() != 0){
            var res2 = res[0].split("-");
            return res2[1].trim();
        }
        return res[0].trim();
    }

    this.paginatotFirstDigit = function(range){
        var res = range.split("of");

        if(res[0].trim() != 0){
            var res2 = res[0].split("-");
            return res2[0].trim();
        }
        return 0;
    }

    this.splitInToTwoReturnFirstPart = function(anystring,delimiter){
        var res = anystring.split(delimiter);
        return res[0].trim();
    }

    this.splitInToTwoReturnSecondPart = function(anystring,delimiter){
        var res = anystring.split(delimiter);
        return res[1].trim();
    }

    this.replaceOneValueInString = function(anystring,from,to){
        var res = anystring.split(from);
        var res2 = res[0].concat(to,res[1]);
        return res2;
    }

    this.replaceDollarCommaInString = function(anystring){
        var str1 = anystring.replace(',', '');
        var str2 = str1.replace('$','');
        return str2;
    }

    this.getCurrentDateMonthYear = function(){
        var today = new Date();
        // utils.logInfo("Todays Date is = "+today);
        // utils.logInfo("today.getMonth() = "+(today.getMonth()+1));
        // utils.logInfo("today.getDate() = "+today.getDate());
        // utils.logInfo("today.getFullYear() = "+today.getFullYear());
        var dd = today.getDate();
        if(dd<10){
            dd = "0"+dd;
        }

        return (today.getMonth()+1)+"/"+dd+"/"+today.getFullYear();
    }

    this.getCurrentYear = function(){
        var today = new Date();
        return today.getFullYear();
    }


    this.getPlatformName = async function(){
        return browser.getCapabilities().then(function(c) {

            if(c.get('platformName') == undefined){
                return c.get('platform');
            }
            else{
                return c.get('platformName');
            }
        });
    }


    this.copyToClipboardFromWebElement = async function(webElement){
        var platformName = await this.getPlatformName();
        var platformAbbrevation = platformName.substring(0,3);

        switch(platformAbbrevation){
            case 'mac' :
                await webElement.sendKeys(protractor.Key.chord(protractor.Key.CONTROL, protractor.Key.SHIFT, protractor.Key.HOME));//Select All
                await webElement.sendKeys(protractor.Key.chord(protractor.Key.CONTROL, protractor.Key.INSERT)); //Copy
                break;
            case 'Lin' :
                await webElement.sendKeys(protractor.Key.chord(protractor.Key.CONTROL, "a"));//Select All
                await webElement.sendKeys(protractor.Key.chord(protractor.Key.CONTROL, "c")); //Copy
                break;
        } //switch
    } //copyToClipboardFromWebElement


    this.pasteFromClipboardToWebElement = async function(webElement){
        var platformName = await this.getPlatformName();
        var platformAbbrevation = platformName.substring(0,3);

        switch(platformAbbrevation){
            case 'mac' :
                await webElement.sendKeys(protractor.Key.chord(protractor.Key.SHIFT, protractor.Key.INSERT));//Paste
                break;
            case 'Lin' :
                await webElement.sendKeys(protractor.Key.chord(protractor.Key.CONTROL, "v"));//Paste
                break;
        }
    }

    this.getKey = async function(sKey){
        var platformName = await this.getPlatformName();
        var platformAbbrevation = platformName.substring(0,3);

        if(platformAbbrevation == "mac" ){
            switch(sKey){
                case 'copy' :
                    return protractor.Key.chord(protractor.Key.CONTROL, protractor.Key.INSERT);
                    break;
                case 'paste' :
                    return protractor.Key.chord(protractor.Key.SHIFT, protractor.Key.INSERT);
                    break; 
                case 'selectallleftarrowkey' :
                    return protractor.Key.chord(protractor.Key.ALT, protractor.Key.SHIFT, protractor.Key.ARROW_LEFT);
                    break;         
            } //switch sKey
        }//if mac
        else if(platformAbbrevation == "Lin"){
            switch(sKey){
                case 'copy' :
                    return protractor.Key.chord(protractor.Key.CONTROL, "c");
                    break;
                case 'paste' :
                    return protractor.Key.chord(protractor.Key.CONTROL, "v");
                    break; 
                case 'selectallleftarrowkey' :
                    return protractor.Key.chord(protractor.Key.CONTROL, "a");
                    break;  
                case 'selectall' :
                    return protractor.Key.chord(protractor.Key.CONTROL, "a");
                    break;              
            } //switch sKey
        }//else if Lin


    }//getKey

    
    this.getCurrentPageURL = async function(){
        
        return await browser.getCurrentUrl().then(async function (url) {
            console.log("Current Url1 is "+url);
            await browser.sleep(browser.params.sleep.sleep5);
            return url;
        });
    }

    this.generateRandomRealVIN = async function(){
        var currentURL = await this.getCurrentPageURL();
        await browser.sleep(browser.params.sleep.sleep5);

        console.log("Current Url2 is "+currentURL);
        
        console.log("Disable waitForAngularEnabled");
        await browser.waitForAngularEnabled(false); // *** Angular Enabled True

        var randomVINURL = "https://randomvin.com/";

        console.log("Get RandomVIN page");
        await browser.get(randomVINURL);

        console.log("Sleep for 5 seconds");
        await browser.sleep(browser.params.sleep.sleep5);

        var realVinBtn = element(by.xpath("//input[@name='mk_real_vin']"));
        await realVinBtn.click();
        await browser.sleep(browser.params.sleep.sleep5);

        var vinElement = element(by.xpath("//*[@id='Result']/h2"));
        var vinValue = await vinElement.getText();

        console.log("Value of First VIN is "+vinValue);

        await browser.waitForAngularEnabled(true); // *** Angular Enabled True
        await browser.get(currentURL);
        await browser.sleep(browser.params.sleep.sleep10);

        return vinValue;
    }


    this.getMDSScoreCardAPI = async function(){
        var mdsEndPoint = "https://marketcheck-test.apigee.net/v1/mds/?api_key=wxHiTWpzfiuE3lSFORAzDi8mfQJsmsvD&vin=5GAKVBED0BJ107047&latitude=40.8928771&longitude=-73.9726381&radius=5000&exact=true";
    }


} //utils function

module.exports = new utils();
